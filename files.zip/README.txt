Semantic KG Explorer for LIS - Profreehost edition (single zip)
================================================================

Upload and extract
------------------
1. In the Profreehost control panel open File Manager and go to public_html.
2. Upload lis-kg-profreehost.zip and right-click it > Extract.
3. Make sure these files end up in the same folder:
      index.html
      data/dataset.bin
4. Open your site address. The loading message finishes when the
   knowledge base is ready ("27,825 records").

If the page shows "Could not load the local dataset", the message under it
says what is missing. Check that data/dataset.bin exists and has the same
name and folder as shown above.

Notes
-----
- No server, database or Node.js is needed. Everything runs in the browser.
- data/dataset.bin is compressed with LZMA. Do not rename or edit it.
- The first load decodes about 34 MB of records; allow a few seconds.
- Search, filters, knowledge graph, tree, maps, analyses and AI Search
  (offline engine) all work without internet access.
- Linked Open Data, Diamond OA and Graph Database features need internet
  access from the visitor's browser.
