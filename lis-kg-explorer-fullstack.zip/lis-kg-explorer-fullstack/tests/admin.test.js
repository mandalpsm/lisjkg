'use strict';
const os = require('os'), path = require('path'), fs = require('fs');
const LOGS = fs.mkdtempSync(path.join(os.tmpdir(), 'lis-logs-')), BK = fs.mkdtempSync(path.join(os.tmpdir(), 'lis-bk-'));
Object.assign(process.env, { LOG_DIR: LOGS, BACKUP_DIR: BK, ADMIN_TOKEN: 'test-secret-token', TELEMETRY: 'true', PROXY_ENABLED: 'true', RATE_LIMIT_PER_MIN: '100000',
  NEO4J_USER: 'neo', NEO4J_PASSWORD: 'pw', GRAPHDB_USER: 'gdb', GRAPHDB_PASSWORD: 'gpw' });
const test = require('node:test'), assert = require('node:assert/strict');
const { boot, get, post, stub } = require('./helpers');
let S, up, seen = [];
test.before(async () => {
  up = await stub((req, res) => { let b = ''; req.on('data', c => b += c); req.on('end', () => { seen.push({ url: req.url, auth: req.headers.authorization, body: b }); res.setHeader('Content-Type', 'application/json'); res.end(JSON.stringify({ data: { fields: ['ok'], values: [[1]] }, results: { bindings: [] } })); }); });
  process.env.NEO4J_URL = up.url; process.env.GRAPHDB_URL = up.url + '/repositories/library';
  S = await boot();      // config is read when the app module is first required, i.e. after the stub URLs are set
});
test.after(async () => { await S.close(); up.s.close(); });
const auth = { Authorization: 'Bearer test-secret-token' };

test('admin token required', async () => {
  assert.equal((await get(S.base, '/metrics')).status, 401);
  assert.equal((await get(S.base, '/metrics', { headers: { Authorization: 'Bearer wrong' } })).status, 401);
  const m = await get(S.base, '/metrics', { headers: auth }); assert.equal(m.status, 200); assert.match(m.text, /lis_http_requests_total/); assert.match(m.text, /lis_records \d+/);
});
test('telemetry: anonymous events, no query text by default, summary is admin-only', async () => {
  assert.equal((await post(S.base, '/api/telemetry', { type: 'search', n: 12, ms: 40, eng: true, tEng: 3, q: 'secret query' })).status, 204);
  assert.equal((await post(S.base, '/api/telemetry', { type: 'search', n: 0, ms: 20 })).status, 204);
  await new Promise(r => setTimeout(r, 250));
  const file = fs.readdirSync(LOGS).find(f => f.startsWith('telemetry-')); const txt = fs.readFileSync(path.join(LOGS, file), 'utf8');
  assert.ok(!txt.includes('secret query'), 'query text must not be stored'); assert.equal(txt.trim().split('\n').length, 2);
  assert.equal((await get(S.base, '/api/admin/telemetry-summary')).status, 401);
  const s = (await get(S.base, '/api/admin/telemetry-summary', { headers: auth })).json; assert.equal(s.searches, 2); assert.equal(s.zeroResultRate, 0.5); assert.equal(s.searchSuccessRate, 0.5);
  assert.equal((await post(S.base, '/api/telemetry', 'x'.repeat(5000))).status, 413);
});
test('backup endpoint creates a verifiable backup; tampering is detected', async () => {
  const r = await post(S.base, '/api/admin/backup', {}, auth); assert.equal(r.status, 200); assert.ok(r.json.files >= 1);
  const b = require('../server/lib/backup'); assert.equal(b.verify(r.json.dir).ok, true);
  fs.appendFileSync(path.join(r.json.dir, 'data', 'dataset.json.gz'), 'tamper'); assert.equal(b.verify(r.json.dir).ok, false);
});
test('Neo4j proxy: forwards read queries with server-side credentials, blocks writes', async () => {
  seen = [];
  const ok = await post(S.base, '/api/neo4j/query', { query: 'MATCH (n) RETURN count(n) AS c', parameters: {} }); assert.equal(ok.status, 200); assert.deepEqual(ok.json.data.fields, ['ok']);
  assert.equal(seen[0].url, '/db/neo4j/query/v2'); assert.equal(seen[0].auth, 'Basic ' + Buffer.from('neo:pw').toString('base64')); assert.equal(JSON.parse(seen[0].body).statement, 'MATCH (n) RETURN count(n) AS c');
  for (const w of ['CREATE (n:X)', 'MATCH (n) DETACH DELETE n', 'MERGE (a:A)', 'MATCH (n) SET n.x=1', 'LOAD CSV FROM "file:///x" AS r RETURN r', 'CALL dbms.listConfig()']) assert.equal((await post(S.base, '/api/neo4j/query', { query: w })).status, 403, w);
  assert.equal((await post(S.base, '/api/neo4j/query', { query: "MATCH (n {name:'CREATE SET DELETE'}) RETURN n" })).status, 200, 'keywords inside strings are fine');
  assert.equal((await post(S.base, '/api/neo4j/query', {})).status, 400);
  assert.equal(seen.length, 2);
});
test('SPARQL proxy: read-only queries only, no SERVICE', async () => {
  seen = [];
  const ok = await post(S.base, '/api/graphdb/query', { query: 'PREFIX dc: <http://purl.org/dc/elements/1.1/>\n# comment\nSELECT * WHERE { ?s ?p ?o } LIMIT 1' }); assert.equal(ok.status, 200);
  assert.equal(seen[0].auth, 'Basic ' + Buffer.from('gdb:gpw').toString('base64')); assert.match(decodeURIComponent(seen[0].body), /^query=PREFIX/);
  for (const w of ['INSERT DATA { <a> <b> <c> }', 'DELETE WHERE { ?s ?p ?o }', 'DROP ALL', 'LOAD <http://x>', 'SELECT * WHERE { SERVICE <http://evil/sparql> { ?s ?p ?o } }']) assert.equal((await post(S.base, '/api/graphdb/query', { query: w })).status, 403, w);
  assert.equal(seen.length, 1);
});
