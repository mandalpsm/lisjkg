'use strict';
const test = require('node:test'), assert = require('node:assert/strict');
const fs = require('fs'), os = require('os'), path = require('path'), zlib = require('zlib'), { execFileSync } = require('child_process');
const script = n => path.join(__dirname, '..', 'scripts', n);
test('build-dataset.js converts CSV (quotes, commas, newlines, BOM) into the dataset format and rejects bad headers', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'lis-csv-')), csv = path.join(dir, 'in.csv'), out = path.join(dir, 'out.json.gz');
  fs.writeFileSync(csv, '\ufeffCites,Authors,Title,Year,Source,Publisher,Place,Country,ArticleURL,DOI,ISSN,Keywords,Abstract\n' +
    '5,"Doe, Jane; Roy, A.","A ""quoted"" title, with comma",2022,Journal A,Pub X,Kolkata,India,https://x/1,10.1/a,1111-1111,"open access; metadata","Line one\nline two"\n' +
    '0,Lee,Second paper,2023,Journal B,Pub Y,Leeds,United Kingdom,,,,,\n' +
    'x,Bad,,notayear,Journal B,Pub Y,Leeds,United Kingdom,,,,,\n');
  execFileSync('node', [script('build-dataset.js'), csv, out]);
  const d = JSON.parse(zlib.gunzipSync(fs.readFileSync(out)));
  assert.equal(d.m.recordCount, 2); assert.equal(d.r[0][2], 'A "quoted" title, with comma'); assert.equal(d.r[0][12], 'Line one\nline two');
  assert.deepEqual(d.m.sources, ['Journal A', 'Journal B']); assert.equal(d.m.minYear, 2022); assert.equal(d.m.maxYear, 2023); assert.equal(d.m.missing.DOI, 1);
  execFileSync('node', [script('check-dataset.js'), out]);
  fs.writeFileSync(csv, 'Foo,Bar\n1,2\n'); assert.throws(() => execFileSync('node', [script('build-dataset.js'), csv, out], { stdio: 'pipe' }));
});
