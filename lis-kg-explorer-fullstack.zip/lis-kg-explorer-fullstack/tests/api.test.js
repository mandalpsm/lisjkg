'use strict';
const os = require('os'), path = require('path'), fs = require('fs');
process.env.LOG_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'lis-logs-'));
process.env.BACKUP_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'lis-bk-'));
process.env.RATE_LIMIT_PER_MIN = '100000'; process.env.DATASET_RATE_LIMIT_PER_MIN = '100000';
const test = require('node:test'), assert = require('node:assert/strict');
const zlib = require('zlib');
const { boot, get } = require('./helpers');
let S;
test.before(async () => { S = await boot(); });
test.after(async () => { await S.close(); });

test('health and config', async () => {
  const h = await get(S.base, '/health'); assert.equal(h.status, 200); assert.equal(h.json.status, 'ok'); assert.ok(h.json.records > 1000);
  const c = await get(S.base, '/api/config'); assert.equal(c.json.records, h.json.records); assert.equal(c.json.telemetry, false);
});
test('security headers are present', async () => {
  const r = await get(S.base, '/health');
  for (const h of ['content-security-policy', 'x-content-type-options', 'referrer-policy', 'x-frame-options', 'x-request-id']) assert.ok(r.headers.get(h), h);
  assert.equal(r.headers.get('x-content-type-options'), 'nosniff');
});
test('search: implicit AND, OR, NOT, phrase, wildcard, truncation, fields, year', async () => {
  const q = async (s, extra = '') => (await get(S.base, '/api/search?size=5&q=' + encodeURIComponent(s) + extra)).json;
  const a = await q('digital libraries'), n = await q('digital libraries NOT covid'), o = await q('digital OR libraries');
  assert.ok(a.total > 0 && n.total > 0 && n.total < a.total, 'NOT must shrink results');
  assert.ok(o.total >= a.total, 'OR must widen results');
  const ph = await q('"open access"'); assert.ok(ph.total > 0); assert.ok(ph.results.every(r => /open\W+access/i.test(r.title + ' ' + r.keywords.join(' ') + ' ' + r.abstract + ' ' + r.source)), 'phrase must appear');
  assert.ok((await q('librar*')).total >= (await q('library')).total, 'truncation');
  assert.ok((await q('organi?ation')).total > 0, 'single-char wildcard');
  const t = await q('title:bibliometric year:2023'); assert.ok(t.total > 0 && t.results.every(r => r.year === 2023 && /bibliometric/i.test(r.title)));
  const au = await q('author:majhi'); assert.ok(au.total > 0 && au.results.every(r => r.authors.join(' ').toLowerCase().includes('majhi')));
  assert.equal(a.query.parsed, '(digital AND libraries)');
});
test('search: filters, facets, sorting, pagination', async () => {
  const r = (await get(S.base, '/api/search?q=library&year_from=2022&year_to=2023&min_cites=5&facets=1&sort=cites&size=10&page=2')).json;
  assert.equal(r.page, 2); assert.ok(r.results.length > 0);
  assert.ok(r.results.every(x => x.year >= 2022 && x.year <= 2023 && x.cites >= 5));
  for (let i = 1; i < r.results.length; i++) assert.ok(r.results[i - 1].cites >= r.results[i].cites, 'sorted by citations');
  assert.ok(r.facets.year.length && r.facets.source.length && r.facets.country.length);
  const c = (await get(S.base, '/api/search?q=library&country=India&size=3')).json; assert.ok(c.total > 0 && c.results.every(x => x.country === 'India'));
});
test('search: synonym expansion can be switched off', async () => {
  const on = (await get(S.base, '/api/search?q=AI&size=1')).json.total, off = (await get(S.base, '/api/search?q=AI&size=1&expand=false')).json.total;
  assert.ok(on > off, 'expansion adds artificial-intelligence records');
});
test('did-you-mean and suggest', async () => {
  const r = (await get(S.base, '/api/search?q=bibliometrcs')).json; assert.equal(r.total, 0); assert.match(r.didYouMean, /bibliometric/);
  const s = (await get(S.base, '/api/suggest?q=biblio')).json; assert.ok(s.suggestions.length && s.suggestions.every(x => x.term.startsWith('biblio')));
  const a = (await get(S.base, '/api/authors?q=majhi')).json; assert.ok(a.authors.length);
});
test('records, DOI lookup and formats', async () => {
  const hit = (await get(S.base, '/api/search?q=digital+library&size=1')).json.results[0];
  const rec = (await get(S.base, '/api/records/' + hit.id)).json; assert.equal(rec.title, hit.title); assert.ok(Array.isArray(rec.authors));
  const d = await get(S.base, '/api/doi/' + hit.doi); assert.equal(d.status, 200); assert.equal(d.json.id, hit.id);
  const d2 = await get(S.base, '/api/doi/' + encodeURIComponent('https://doi.org/' + hit.doi.toUpperCase())); assert.equal(d2.status, 200);
  assert.match((await get(S.base, `/api/records/${hit.id}?format=ris`)).text, /^TY  - JOUR/);
  assert.match((await get(S.base, `/api/records/${hit.id}?format=bibtex`)).text, /^@article\{/);
  const ld = (await get(S.base, `/api/records/${hit.id}?format=jsonld`)).json; assert.deepEqual(ld['@type'], ['ScholarlyArticle', 'bibo:AcademicArticle']);
  assert.match((await get(S.base, `/api/records/${hit.id}?format=dc`)).text, /<dc:title>/);
  assert.equal((await get(S.base, '/api/records/99999999')).status, 404);
  assert.equal((await get(S.base, '/api/doi/10.0000/does-not-exist')).status, 404);
  assert.equal((await get(S.base, `/api/records/${hit.id}?format=nope`)).status, 400);
});
test('export formats', async () => {
  const csv = await get(S.base, '/api/export?q=bibliometric&format=csv&limit=5'); assert.equal(csv.status, 200); assert.match(csv.headers.get('content-disposition'), /attachment/);
  assert.equal(csv.text.replace(/^\ufeff/, '').split('\r\n')[0].split(',')[0], 'id');
  assert.ok((await get(S.base, '/api/export?q=bibliometric&format=ris&limit=3')).text.includes('ER  - '));
  assert.ok((await get(S.base, '/api/export?q=bibliometric&format=bibtex&limit=3')).text.includes('@article'));
  assert.equal((await get(S.base, '/api/export?q=bibliometric&format=json&limit=3')).json.count, 3);
  assert.equal((await get(S.base, '/api/export?ids=1,2&format=json')).json.count, 2);
  assert.ok((await get(S.base, '/api/export?q=x&format=jsonld&limit=2')).json['@graph']);
});
test('dataset endpoint serves valid gzip JSON and honours ETag', async () => {
  const r = await fetch(S.base + '/api/dataset', { headers: { 'Accept-Encoding': 'gzip' } });
  const etag = r.headers.get('etag'); const buf = Buffer.from(await r.arrayBuffer());
  assert.equal(r.headers.get('content-encoding'), 'gzip');
  const j = JSON.parse((buf[0] === 0x1f && buf[1] === 0x8b ? zlib.gunzipSync(buf) : buf).toString()); assert.ok(j.m && j.r.length > 1000);   // fetch() may already have decoded it
  const r2 = await fetch(S.base + '/api/dataset', { headers: { 'If-None-Match': etag } }); assert.equal(r2.status, 304);
});
test('OAI-PMH', async () => {
  const x = p => get(S.base, '/oai?' + p);
  assert.match((await x('verb=Identify')).text, /<protocolVersion>2\.0<\/protocolVersion>/);
  assert.match((await x('verb=ListMetadataFormats')).text, /oai_dc/);
  assert.match((await x('verb=ListSets')).text, /<setSpec>src0<\/setSpec>/);
  const lr = (await x('verb=ListRecords&metadataPrefix=oai_dc&from=2023-01-01&until=2023-12-31')).text;
  assert.equal((lr.match(/<record>/g) || []).length, 100); const tok = lr.match(/<resumptionToken[^>]*>([^<]+)</)[1];
  const lr2 = (await x('verb=ListRecords&resumptionToken=' + encodeURIComponent(tok))).text; assert.equal((lr2.match(/<record>/g) || []).length, 100);
  assert.notEqual(lr2.match(/<identifier>([^<]+)</)[1], lr.match(/<identifier>([^<]+)</)[1]);
  const id = lr.match(/<identifier>([^<]+)</)[1];
  assert.match((await x('verb=GetRecord&metadataPrefix=oai_dc&identifier=' + encodeURIComponent(id))).text, /<dc:title>/);
  assert.match((await x('verb=GetRecord&metadataPrefix=oai_dc&identifier=oai:nope:1')).text, /idDoesNotExist/);
  assert.match((await x('verb=Bogus')).text, /badVerb/);
  assert.match((await x('verb=ListRecords')).text, /badArgument/);
  assert.match((await x('verb=ListRecords&metadataPrefix=marc21')).text, /cannotDisseminateFormat/);
  assert.match((await x('verb=ListRecords&metadataPrefix=oai_dc&from=2030-01-01')).text, /noRecordsMatch/);
  assert.match((await x('verb=ListRecords&resumptionToken=garbage')).text, /badResumptionToken/);
  assert.match((await x('verb=Identify&foo=1')).text, /badArgument/);
});
test('static files: index, journal map, docs; traversal and dotfiles blocked', async () => {
  const i = await get(S.base, '/'); assert.equal(i.status, 200); assert.match(i.text, /Explorer/i);
  assert.equal((await get(S.base, '/journal-map.html')).status, 200);
  assert.equal((await get(S.base, '/api/docs')).status, 200);
  assert.equal((await get(S.base, '/api/openapi.json')).json.openapi, '3.0.3');
  for (const bad of ['/..%2f..%2fpackage.json', '/%2e%2e/package.json', '/../package.json', '/.env', '/data/dataset.json.gz', '/server/index.js']) {
    const r = await get(S.base, bad); assert.ok([400, 403, 404].includes(r.status), bad + ' -> ' + r.status); assert.ok(!r.text.includes('lis-kg-explorer-fullstack'), bad + ' leaked a file');
  }
});
test('error handling: unknown endpoint, wrong method, bad input', async () => {
  assert.equal((await get(S.base, '/api/nope')).status, 404);
  assert.equal((await get(S.base, '/api/nope')).json.error.code, 'not_found');
  assert.equal((await get(S.base, '/api/search', { method: 'DELETE' })).status, 405);
  assert.equal((await get(S.base, '/api/search?page=abc')).status, 400);
  assert.equal((await get(S.base, '/api/telemetry', { method: 'POST', body: '{}' })).status, 404);   // telemetry disabled by default
});
test('admin endpoints hidden without ADMIN_TOKEN; proxies disabled by default', async () => {
  assert.equal((await get(S.base, '/metrics')).status, 404);
  assert.equal((await get(S.base, '/api/admin/backup', { method: 'POST' })).status, 404);
  assert.equal((await get(S.base, '/api/neo4j/query', { method: 'POST', headers: { 'content-type': 'application/json' }, body: '{"query":"RETURN 1"}' })).status, 503);
});
test('search performance sanity (< 500 ms for typical queries)', async () => {
  for (const q of ['digital library', 'librar* AND (covid OR pandemic)', '"open access"']) { const r = (await get(S.base, '/api/search?q=' + encodeURIComponent(q))).json; assert.ok(r.tookMs < 500, q + ' took ' + r.tookMs); }
});
