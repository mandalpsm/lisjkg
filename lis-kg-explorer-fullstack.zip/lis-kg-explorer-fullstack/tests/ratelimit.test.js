'use strict';
const os = require('os'), path = require('path'), fs = require('fs');
Object.assign(process.env, { LOG_DIR: fs.mkdtempSync(path.join(os.tmpdir(), 'lis-logs-')), RATE_LIMIT_PER_MIN: '5', DATASET_RATE_LIMIT_PER_MIN: '2', CORS_ORIGINS: 'https://allowed.example' });
const test = require('node:test'), assert = require('node:assert/strict');
const { boot, get } = require('./helpers');
test('rate limiting (429 + Retry-After), separate dataset bucket, static files unlimited, CORS allow-list', async () => {
  const S = await boot();
  try {
    const codes = []; for (let i = 0; i < 7; i++) codes.push((await get(S.base, '/api/meta')).status);
    assert.deepEqual(codes, [200, 200, 200, 200, 200, 429, 429]);
    const r = await get(S.base, '/api/meta'); assert.ok(Number(r.headers.get('retry-after')) >= 1); assert.equal(r.json.error.code, 'rate_limited');
    const d = []; for (let i = 0; i < 3; i++) d.push(await fetch(S.base + '/api/dataset', { headers: { 'Accept-Encoding': 'gzip' } }).then(x => { x.body.cancel(); return x.status; }));
    assert.deepEqual(d, [200, 200, 429]);
    for (let i = 0; i < 10; i++) assert.equal((await get(S.base, '/')).status, 200);
    const ok = await get(S.base, '/health', { headers: { Origin: 'https://allowed.example' } }); assert.equal(ok.headers.get('access-control-allow-origin'), 'https://allowed.example');
    assert.equal((await get(S.base, '/health', { headers: { Origin: 'https://evil.example' } })).headers.get('access-control-allow-origin'), null);
  } finally { await S.close(); }
});
