'use strict';
const http = require('http');
/** Start the app on a random port. Environment variables must be set BEFORE this module's callers require the app. */
async function boot() {
  const { createApp } = require('../server/index.js');
  const app = createApp();
  await new Promise(r => app.server.listen(0, '127.0.0.1', r));
  const base = 'http://127.0.0.1:' + app.server.address().port;
  return { app, base, close: () => new Promise(r => { app.server.closeAllConnections && app.server.closeAllConnections(); app.server.close(r); }) };
}
const get = async (base, p, init) => { const r = await fetch(base + p, init); const t = await r.text(); let j = null; try { j = JSON.parse(t); } catch (e) { /* not json */ } return { status: r.status, headers: r.headers, text: t, json: j }; };
const post = (base, p, body, headers = {}) => get(base, p, { method: 'POST', headers: { 'Content-Type': 'application/json', ...headers }, body: typeof body === 'string' ? body : JSON.stringify(body) });
/** Tiny upstream stub used to test the database proxies. */
function stub(handler) { return new Promise(r => { const s = http.createServer(handler); s.listen(0, '127.0.0.1', () => r({ s, url: 'http://127.0.0.1:' + s.address().port })); }); }
module.exports = { boot, get, post, stub };
