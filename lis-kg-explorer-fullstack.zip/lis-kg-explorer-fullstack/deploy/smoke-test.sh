#!/bin/sh
# Quick post-deployment check:  sh deploy/smoke-test.sh https://example.org
BASE="${1:-http://localhost:8080}"; fail=0
check() { if curl -fsS "$BASE$2" >/dev/null 2>&1; then echo "OK   $1"; else echo "FAIL $1 ($2)"; fail=1; fi; }
check "health"          /health
check "front end"       /
check "search API"      "/api/search?q=digital+libraries&size=1"
check "DOI lookup"      "/api/doi/10.17821/srels/2023/v60i3/171028"
check "OAI-PMH"         "/oai?verb=Identify"
check "API docs"        /api/docs
check "journal map"     /journal-map.html
exit $fail
