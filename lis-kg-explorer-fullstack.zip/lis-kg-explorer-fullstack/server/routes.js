'use strict';
const zlib = require('zlib');
const cfg = require('./lib/config');
const { toRecord, normDoi } = require('./lib/dataset');
const F = require('./lib/formats');
const oai = require('./lib/oai');
const proxy = require('./lib/proxy');
const telemetry = require('./lib/telemetry');
const metrics = require('./lib/metrics');
const backup = require('./lib/backup');
const { isAdmin } = require('./lib/security');

class HttpError extends Error { constructor(status, code, msg) { super(msg); this.status = status; this.code = code; } }
const bad = msg => new HttpError(400, 'bad_request', msg);

function send(res, status, body, type = 'application/json; charset=utf-8', headers = {}) {
  const buf = Buffer.isBuffer(body) ? body : Buffer.from(typeof body === 'string' ? body : JSON.stringify(body));
  res.statusCode = status; res.setHeader('Content-Type', type); res.setHeader('Content-Length', buf.length);
  for (const [k, v] of Object.entries(headers)) res.setHeader(k, v);
  res.end(buf);
}
const json = (res, obj, status = 200, headers = {}) => send(res, status, JSON.stringify(obj), 'application/json; charset=utf-8', headers);

function readBody(req, max = 65536) {
  return new Promise((resolve, reject) => {
    let n = 0; const chunks = [];
    let over = false;
    req.on('data', c => {
      if (over) return; n += c.length;
      if (n > max) { over = true; chunks.length = 0; req.resume(); reject(new HttpError(413, 'payload_too_large', 'Request body too large')); } else chunks.push(c);
    });
    req.on('end', () => { if (over) return; const t = Buffer.concat(chunks).toString('utf8'); if (!t) return resolve({}); try { resolve(JSON.parse(t)); } catch (e) { reject(bad('Body must be valid JSON')); } });
    req.on('error', reject);
  });
}
const num = (v, d, lo, hi) => { if (v === null || v === undefined || v === '') return d; const n = Number(v); if (!Number.isFinite(n)) throw bad('Invalid number: ' + v); return Math.min(hi, Math.max(lo, Math.trunc(n))); };
const baseUrl = req => { const proto = req.socket.encrypted || (cfg.TRUST_PROXY && /https/.test(req.headers['x-forwarded-proto'] || '')) ? 'https' : 'http'; return proto + '://' + (req.headers['x-forwarded-host'] || req.headers.host || 'localhost'); };

function parseFilters(p) {
  return {
    yearFrom: num(p.get('year_from'), 0, 0, 9999), yearTo: num(p.get('year_to'), 0, 0, 9999),
    source: p.get('source') ?? '', publisher: p.get('publisher') ?? '', country: p.get('country') ?? '', subject: p.get('subject') ?? '',
    minCites: num(p.get('min_cites'), 0, 0, 1e9), hasDoi: /^(1|true)$/i.test(p.get('has_doi') || ''),
  };
}

function build(ctx) {
  const { ds, ix, limiter } = ctx;
  const routes = [];
  const add = (method, re, fn, opts = {}) => routes.push({ method, re, fn, opts });

  add('GET', /^\/(health|api\/health)$/, ({ res }) => json(res, { status: 'ok', version: cfg.VERSION, records: ds.r.length, uptimeSec: metrics.snapshot().uptimeSec }));

  add('GET', /^\/api\/config$/, ({ res }) => json(res, { name: cfg.NAME, version: cfg.VERSION, records: ds.r.length, telemetry: cfg.TELEMETRY, telemetryQueries: cfg.TELEMETRY_QUERIES,
    proxies: { neo4j: cfg.PROXY_ENABLED && !!cfg.NEO4J_URL, graphdb: cfg.PROXY_ENABLED && !!cfg.GRAPHDB_URL }, docs: '/api/docs', oai: '/oai' }));

  add('GET', /^\/api\/meta$/, ({ res }) => { const m = ds.m;
    json(res, { recordCount: m.recordCount, minYear: m.minYear, maxYear: m.maxYear, maxCites: m.maxCites, missing: m.missing,
      years: m.yearCounts.map(([y, n]) => ({ value: y, count: n })),
      sources: m.sourceCounts.map(([i, n]) => ({ value: m.sources[i], count: n })),
      publishers: m.publisherCounts.map(([i, n]) => ({ value: m.publishers[i], count: n })),
      countries: m.countryCounts.map(([i, n]) => ({ value: m.countries[i], count: n })), topKeywords: m.topKeywords.map(([w, n]) => ({ term: w, count: n })) }, 200, { 'Cache-Control': 'public, max-age=300' }); });

  add('GET', /^\/api\/dataset$/, ({ req, res }) => {
    res.setHeader('ETag', ds.etag); res.setHeader('Cache-Control', 'public, max-age=3600'); res.setHeader('Vary', 'Accept-Encoding');
    if (req.headers['if-none-match'] === ds.etag) { res.statusCode = 304; return res.end(); }
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    if (/\bgzip\b/.test(req.headers['accept-encoding'] || '')) { res.setHeader('Content-Encoding', 'gzip'); res.setHeader('Content-Length', ds.gz.length); res.statusCode = 200; return res.end(req.method === 'HEAD' ? undefined : ds.gz); }
    res.statusCode = 200; res.end(zlib.gunzipSync(ds.gz));      // client without gzip support
  }, { bucket: 'dataset' });

  add('GET', /^\/api\/search$/, ({ url, res }) => {
    const p = url.searchParams, t0 = process.hrtime.bigint();
    const q = (p.get('q') || '').slice(0, 500); const page = num(p.get('page'), 1, 1, 100000), size = num(p.get('size'), 20, 1, 100);
    const r = ix.search(q, { expand: !/^(0|false)$/i.test(p.get('expand') || ''), sort: p.get('sort') || 'relevance', filters: parseFilters(p) });
    const start = (page - 1) * size, slice = r.ids.slice(start, start + size);
    const out = { query: { raw: q, parsed: r.ast ? ix.explain(r.ast) : null, sort: r.sort, expand: !/^(0|false)$/i.test(p.get('expand') || '') },
      total: r.ids.length, page, size, pages: Math.max(1, Math.ceil(r.ids.length / size)), didYouMean: ix.didYouMean(q),
      results: slice.map(i => ({ ...toRecord(ds, i, { snippet: 300 }), score: Math.round((r.scores.get(i) || 0) * 100) / 100 })) };
    if (/^(1|true)$/i.test(p.get('facets') || '')) out.facets = ix.facets(r.ids);
    out.tookMs = Number(process.hrtime.bigint() - t0) / 1e6; out.tookMs = Math.round(out.tookMs * 10) / 10;
    json(res, out);
  });

  add('GET', /^\/api\/records\/(\d+)$/, ({ req, url, res, m }) => {
    const r = toRecord(ds, +m[1]); if (!r) throw new HttpError(404, 'not_found', 'No such record');
    return sendRecord(req, res, r, url.searchParams.get('format'));
  });
  add('GET', /^\/api\/doi\/(.+)$/, ({ req, url, res, m }) => {
    let d; try { d = normDoi(decodeURIComponent(m[1])); } catch (e) { throw bad('Malformed DOI'); }
    const i = ix.doi.get(d); if (i === undefined) throw new HttpError(404, 'not_found', 'No record with this DOI in the dataset');
    return sendRecord(req, res, toRecord(ds, i), url.searchParams.get('format'));
  });
  function sendRecord(req, res, r, fmt) {
    fmt = (fmt || '').toLowerCase(); if (!fmt && /ld\+json/.test(req.headers.accept || '')) fmt = 'jsonld';
    switch (fmt) {
      case 'ris': return send(res, 200, F.toRIS(r) + '\r\n', 'application/x-research-info-systems; charset=utf-8');
      case 'bibtex': return send(res, 200, F.toBibTeX(r) + '\n', 'application/x-bibtex; charset=utf-8');
      case 'jsonld': return send(res, 200, JSON.stringify(F.toJSONLD(r, baseUrl(req))), 'application/ld+json; charset=utf-8');
      case 'dc': return send(res, 200, '<?xml version="1.0" encoding="UTF-8"?>\n' + F.toOaiDc(r), 'application/xml; charset=utf-8');
      case '': case 'json': return json(res, r);
      default: throw bad('format must be json, jsonld, ris, bibtex or dc');
    }
  }

  add('GET', /^\/api\/suggest$/, ({ url, res }) => { const q = (url.searchParams.get('q') || '').slice(0, 100);
    json(res, { q, suggestions: ix.suggest(q.split(/\s+/).pop(), num(url.searchParams.get('limit'), 10, 1, 25)), didYouMean: ix.didYouMean(q) }); });
  add('GET', /^\/api\/authors$/, ({ url, res }) => { const q = (url.searchParams.get('q') || '').slice(0, 100); json(res, { q, authors: ix.authors(q, num(url.searchParams.get('limit'), 20, 1, 100)) }); });

  add('GET', /^\/api\/export$/, ({ req, url, res }) => {
    const p = url.searchParams, fmt = (p.get('format') || 'csv').toLowerCase(); const limit = num(p.get('limit'), 1000, 1, 5000);
    let ids; if (p.get('ids')) ids = p.get('ids').split(',').slice(0, limit).map(Number).filter(i => Number.isInteger(i) && ds.r[i]);
    else ids = ix.search((p.get('q') || '').slice(0, 500), { expand: !/^(0|false)$/i.test(p.get('expand') || ''), sort: p.get('sort') || 'relevance', filters: parseFilters(p) }).ids.slice(0, limit);
    const recs = ids.map(i => toRecord(ds, i)); const stamp = new Date().toISOString().slice(0, 10);
    const dl = ext => ({ 'Content-Disposition': `attachment; filename="lis-export-${stamp}.${ext}"` });
    switch (fmt) {
      case 'csv': return send(res, 200, '\ufeff' + [F.CSV_HEAD.join(','), ...recs.map(F.csvRow)].join('\r\n') + '\r\n', 'text/csv; charset=utf-8', dl('csv'));
      case 'ris': return send(res, 200, recs.map(F.toRIS).join('\r\n') + '\r\n', 'application/x-research-info-systems; charset=utf-8', dl('ris'));
      case 'bibtex': return send(res, 200, recs.map(F.toBibTeX).join('\n\n') + '\n', 'application/x-bibtex; charset=utf-8', dl('bib'));
      case 'json': return send(res, 200, JSON.stringify({ count: recs.length, records: recs }), 'application/json; charset=utf-8', dl('json'));
      case 'jsonld': { const b = baseUrl(req); return send(res, 200, JSON.stringify({ '@context': { '@vocab': 'https://schema.org/' }, '@graph': recs.map(r => F.toJSONLD(r, b)) }), 'application/ld+json; charset=utf-8', dl('jsonld')); }
      default: throw bad('format must be csv, ris, bibtex, json or jsonld');
    }
  });

  add('GET', /^\/oai$/, ({ req, url, res }) => { send(res, 200, oai.handle(url.searchParams, ds, baseUrl(req) + '/oai'), 'text/xml; charset=utf-8'); });

  add('GET', /^\/api\/openapi\.json$/, ({ res }) => send(res, 200, ctx.openapi, 'application/json; charset=utf-8'));
  add('GET', /^\/api\/docs$/, ({ res }) => send(res, 200, ctx.docs, 'text/html; charset=utf-8'));

  add('POST', /^\/api\/telemetry$/, async ({ req, res }) => {
    if (!cfg.TELEMETRY) return json(res, { error: { code: 'disabled', message: 'Telemetry is disabled.' } }, 404);
    telemetry.record(await readBody(req, 2048)); res.statusCode = 204; res.end();
  });
  add('POST', /^\/api\/neo4j\/query$/, async ({ req, res }) => relay(res, await proxy.neo4j(await readBody(req, 32768))));
  add('POST', /^\/api\/graphdb\/query$/, async ({ req, res }) => relay(res, await proxy.graphdb(await readBody(req, 32768))));
  const relay = (res, r) => send(res, r.status, r.body, r.type);

  const admin = fn => async c => { if (!cfg.ADMIN_TOKEN) throw new HttpError(404, 'not_found', 'Not found'); if (!isAdmin(c.req)) { c.res.setHeader('WWW-Authenticate', 'Bearer'); throw new HttpError(401, 'unauthorized', 'Admin token required'); } return fn(c); };
  add('GET', /^\/api\/admin\/telemetry-summary$/, admin(({ url, res }) => json(res, telemetry.summary(num(url.searchParams.get('days'), 7, 1, 90)))));
  add('POST', /^\/api\/admin\/backup$/, admin(({ res }) => json(res, backup.run())));
  add('GET', /^\/metrics$/, admin(({ res }) => send(res, 200, metrics.render({ lis_records: ds.r.length, lis_vocabulary_terms: ix.post.size }), 'text/plain; version=0.0.4; charset=utf-8')));

  return { routes, HttpError };
}
module.exports = { build, HttpError, json, send };
