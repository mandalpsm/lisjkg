'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const cfg = require('./lib/config');
const dataset = require('./lib/dataset');
const { SearchIndex } = require('./lib/search');
const { StaticFiles } = require('./lib/static');
const sec = require('./lib/security');
const metrics = require('./lib/metrics');
const { build, HttpError, json } = require('./routes');

function log(o) { process.stdout.write(JSON.stringify({ t: new Date().toISOString(), ...o }) + '\n'); }

function createApp() {
  const t0 = Date.now();
  const ds = dataset.load(cfg.DATA_FILE);
  const ix = new SearchIndex(ds);
  log({ level: 'info', msg: 'dataset loaded', records: ds.r.length, indexTerms: ix.post.size, ms: Date.now() - t0 });
  const limiter = new sec.RateLimiter();
  const openapi = fs.readFileSync(path.join(__dirname, '..', 'docs', 'openapi.json'));
  const docs = fs.readFileSync(path.join(__dirname, '..', 'docs', 'api-docs.html'));
  const { routes } = build({ ds, ix, limiter, openapi, docs });
  const files = new StaticFiles(cfg.PUBLIC_DIR);

  const server = http.createServer(async (req, res) => {
    const started = process.hrtime.bigint(); const rid = crypto.randomBytes(4).toString('hex');
    res.setHeader('X-Request-Id', rid); sec.securityHeaders(req, res);
    const ip = sec.clientIp(req);
    res.on('finish', () => { const ms = Number(process.hrtime.bigint() - started) / 1e6; metrics.observe(res.statusCode, ms);
      if (!/^\/(health|metrics)/.test(req.url)) log({ level: 'info', rid, method: req.method, path: req.url.split('?')[0], status: res.statusCode, ms: Math.round(ms * 10) / 10 }); });
    try {
      const url = new URL(req.url, 'http://localhost'); const pathname = url.pathname;
      const corsOk = sec.cors(req, res);
      if (req.method === 'OPTIONS') { res.statusCode = corsOk ? 204 : 405; return res.end(); }
      const isApi = pathname.startsWith('/api/') || pathname === '/oai' || pathname === '/metrics';
      if (isApi) {
        const route = routes.find(r => (r.method === req.method || (r.method === 'GET' && req.method === 'HEAD')) && r.re.test(pathname));
        const bucket = route && route.opts.bucket === 'dataset' ? 'dataset' : 'api';
        const limit = bucket === 'dataset' ? cfg.DATASET_RATE_LIMIT_PER_MIN : cfg.RATE_LIMIT_PER_MIN;
        const rl = limiter.take(ip + ':' + bucket, limit);
        res.setHeader('RateLimit-Limit', rl.limit); res.setHeader('RateLimit-Remaining', rl.remaining);
        if (!rl.ok) { res.setHeader('Retry-After', Math.max(1, Math.ceil((rl.reset - Date.now()) / 1000))); throw new HttpError(429, 'rate_limited', 'Too many requests; slow down.'); }
        if (!route) {
          if (routes.some(r => r.re.test(pathname))) { res.setHeader('Allow', 'GET, POST, OPTIONS'); throw new HttpError(405, 'method_not_allowed', 'Method not allowed'); }
          throw new HttpError(404, 'not_found', 'Unknown API endpoint. See /api/docs');
        }
        const m = pathname.match(route.re);
        if (pathname.startsWith('/api/') && req.method !== 'POST') res.setHeader('Cache-Control', res.getHeader('Cache-Control') || 'no-store');
        return await route.fn({ req, res, url, m });
      }
      if (req.method !== 'GET' && req.method !== 'HEAD') throw new HttpError(405, 'method_not_allowed', 'Method not allowed');
      if (pathname === '/healthz' || pathname === '/health') return routes.find(r => r.re.test('/health')).fn({ req, res, url, m: [] });
      if (files.serve(req, res, pathname)) return;
      throw new HttpError(404, 'not_found', 'Not found');
    } catch (e) {
      const status = e.status || 500;
      if (status >= 500) log({ level: 'error', rid, msg: e.message, stack: cfg.PRODUCTION ? undefined : e.stack });
      if (res.headersSent) return res.end();
      if (status === 413) res.setHeader('Connection', 'close');
      json(res, { error: { code: e.code || (status === 500 ? 'internal_error' : 'error'), message: status === 500 && cfg.PRODUCTION ? 'Internal server error' : e.message } }, status);
    }
  });
  server.requestTimeout = 30000; server.headersTimeout = 15000; server.keepAliveTimeout = 65000; server.maxRequestsPerSocket = 1000;
  server.on('close', () => limiter.stop());
  return { server, ds, ix };
}

function start(port = cfg.PORT, host = cfg.HOST) {
  const app = createApp();
  return new Promise(resolve => app.server.listen(port, host, () => { log({ level: 'info', msg: 'listening', url: `http://${host === '0.0.0.0' ? 'localhost' : host}:${app.server.address().port}`, version: cfg.VERSION }); resolve(app); }));
}
module.exports = { createApp, start };

if (require.main === module) {
  start().then(app => {
    const stop = sig => { log({ level: 'info', msg: 'shutting down', sig }); app.server.close(() => process.exit(0)); setTimeout(() => process.exit(1), 10000).unref(); };
    process.on('SIGTERM', () => stop('SIGTERM')); process.on('SIGINT', () => stop('SIGINT'));
  }).catch(e => { log({ level: 'fatal', msg: e.message }); process.exit(1); });
  process.on('unhandledRejection', e => log({ level: 'error', msg: 'unhandledRejection', err: String(e && e.message || e) }));
}
