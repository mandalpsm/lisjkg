'use strict';
// Validates data/dataset.json.gz (structure + quality report). Exit code 1 on structural errors.
const cfg = require('../server/lib/config'); const ds = require('../server/lib/dataset').load(process.argv[2] || cfg.DATA_FILE);
const errors = [], N = ds.r.length, miss = { title: 0, authors: 0, year: 0, doi: 0, keywords: 0, abstract: 0 }, seen = new Map();
ds.r.forEach((r, i) => {
  if (!Array.isArray(r) || r.length < 13) { errors.push(`row ${i}: expected 13 columns`); return; }
  if (!Number.isInteger(r[3]) || r[3] < 1000 || r[3] > 2100) errors.push(`row ${i}: invalid year ${r[3]}`);
  for (const [k, list] of [[4, 'sources'], [5, 'publishers'], [6, 'places'], [7, 'countries']]) if (ds.m[list][r[k]] === undefined) errors.push(`row ${i}: bad ${list} index ${r[k]}`);
  if (!r[2]) miss.title++; if (!r[1]) miss.authors++; if (!r[9]) miss.doi++; if (!r[11]) miss.keywords++; if (!r[12]) miss.abstract++;
  if (r[9]) seen.set(String(r[9]).toLowerCase(), (seen.get(String(r[9]).toLowerCase()) || 0) + 1);
});
if (ds.m.recordCount !== N) errors.push(`meta.recordCount (${ds.m.recordCount}) != rows (${N})`);
const dup = [...seen.values()].filter(c => c > 1).length;
console.log(JSON.stringify({ records: N, missing: miss, duplicateDois: dup, errors: errors.length, firstErrors: errors.slice(0, 10) }, null, 2));
process.exit(errors.length ? 1 : 0);
