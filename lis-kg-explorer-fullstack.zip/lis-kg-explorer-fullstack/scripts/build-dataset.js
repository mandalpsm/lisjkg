'use strict';
/**
 * Build data/dataset.json.gz from a CSV export of your journal metadata.
 * Usage: node scripts/build-dataset.js path/to/kg_dataset.csv [out.json.gz]
 * Required header names (case-insensitive): Title, Year.  Recognised: Cites, Authors, Source, Publisher, Place, Country,
 * ArticleURL, DOI, ISSN, Keywords, Abstract.  Delimiter , or ; is auto-detected.
 */
const fs = require('fs'), path = require('path'), zlib = require('zlib');
const { tokenize, STOP } = require('../server/lib/text');
const src = process.argv[2], out = process.argv[3] || path.join(__dirname, '..', 'data', 'dataset.json.gz');
if (!src) { console.error('Usage: node scripts/build-dataset.js <file.csv> [out.json.gz]'); process.exit(1); }

function parseCsv(text, delim) {
  const rows = []; let row = [], cur = '', q = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (q) { if (c === '"') { if (text[i + 1] === '"') { cur += '"'; i++; } else q = false; } else cur += c; }
    else if (c === '"') q = true;
    else if (c === delim) { row.push(cur); cur = ''; }
    else if (c === '\n' || c === '\r') { if (c === '\r' && text[i + 1] === '\n') i++; row.push(cur); cur = ''; if (row.length > 1 || row[0] !== '') rows.push(row); row = []; }
    else cur += c;
  }
  if (cur !== '' || row.length) { row.push(cur); rows.push(row); }
  return rows;
}
let text = fs.readFileSync(src, 'utf8').replace(/^\ufeff/, '');
const first = text.split(/\r?\n/, 1)[0]; const delim = (first.match(/;/g) || []).length > (first.match(/,/g) || []).length ? ';' : ',';
const rows = parseCsv(text, delim), head = rows.shift().map(h => h.trim().toLowerCase());
const col = n => head.indexOf(n.toLowerCase());
const C = { cites: col('cites'), authors: col('authors'), title: col('title'), year: col('year'), source: col('source'), publisher: col('publisher'), place: col('place'),
  country: col('country'), url: col('articleurl'), doi: col('doi'), issn: col('issn'), kw: col('keywords'), abs: col('abstract') };
if (C.title < 0 || C.year < 0) { console.error('CSV needs at least Title and Year columns. Found: ' + head.join(', ')); process.exit(1); }

const lists = { sources: [], publishers: [], places: [], countries: [] }, idx = { sources: new Map(), publishers: new Map(), places: new Map(), countries: new Map() };
const ix = (k, v) => { v = (v || '').trim(); if (!idx[k].has(v)) { idx[k].set(v, lists[k].length); lists[k].push(v); } return idx[k].get(v); };
const get = (r, i) => (i >= 0 && r[i] !== undefined ? r[i].trim() : '');
const R = [], yearC = new Map(), srcC = new Map(), pubC = new Map(), ctyC = new Map(), kwC = new Map(), missing = { DOI: 0, Keywords: 0, Abstract: 0, ArticleURL: 0 };
let skipped = 0, maxCites = 0;
for (const r of rows) {
  const year = parseInt(get(r, C.year), 10), title = get(r, C.title);
  if (!title || !Number.isInteger(year)) { skipped++; continue; }
  const row = [parseInt(get(r, C.cites), 10) || 0, get(r, C.authors), title, year, ix('sources', get(r, C.source)), ix('publishers', get(r, C.publisher)), ix('places', get(r, C.place)), ix('countries', get(r, C.country)),
    get(r, C.url), get(r, C.doi), get(r, C.issn), get(r, C.kw), get(r, C.abs)];
  if (!row[9]) missing.DOI++; if (!row[11]) missing.Keywords++; if (!row[12]) missing.Abstract++; if (!row[8]) missing.ArticleURL++;
  maxCites = Math.max(maxCites, row[0]); R.push(row);
  yearC.set(year, (yearC.get(year) || 0) + 1); srcC.set(row[4], (srcC.get(row[4]) || 0) + 1); pubC.set(row[5], (pubC.get(row[5]) || 0) + 1); ctyC.set(row[7], (ctyC.get(row[7]) || 0) + 1);
  for (const w of new Set(tokenize(row[11] + ' ' + title))) if (w.length > 3 && !STOP.has(w)) kwC.set(w, (kwC.get(w) || 0) + 1);
}
const sortC = m => [...m].sort((a, b) => b[1] - a[1]);
const years = R.map(r => r[3]);
const data = { m: { ...lists, yearCounts: [...yearC].sort((a, b) => b[0] - a[0]), sourceCounts: sortC(srcC), publisherCounts: sortC(pubC), countryCounts: sortC(ctyC),
  topKeywords: sortC(kwC).slice(0, 120), recordCount: R.length, missing, minYear: Math.min(...years), maxYear: Math.max(...years), maxCites }, r: R };
fs.mkdirSync(path.dirname(out), { recursive: true });
fs.writeFileSync(out, zlib.gzipSync(Buffer.from(JSON.stringify(data)), { level: 9 }));
console.log(`Wrote ${out}: ${R.length} records (${skipped} rows skipped), ${lists.sources.length} sources, years ${data.m.minYear}-${data.m.maxYear}`);
