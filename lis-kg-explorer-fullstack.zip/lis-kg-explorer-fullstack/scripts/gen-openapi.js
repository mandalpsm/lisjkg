'use strict';
// Generates docs/openapi.json (run: node scripts/gen-openapi.js)
const fs = require('fs'), path = require('path');
const P = (name, desc, extra = {}) => ({ name, in: 'query', description: desc, schema: { type: 'string' }, ...extra });
const filters = [P('year_from', 'Earliest year'), P('year_to', 'Latest year'), P('source', 'Journal name or index'), P('publisher', 'Publisher name or index'), P('country', 'Country name or index'),
  P('subject', 'Exact keyword (subject term)'), P('min_cites', 'Minimum citation count'), P('has_doi', 'true = only records with a DOI')];
const ok = d => ({ '200': { description: d } });
const spec = {
  openapi: '3.0.3',
  info: { title: 'LIS Knowledge Graph Explorer API', version: '1.0.0', description: 'Read-only bibliographic search API, OAI-PMH endpoint and optional graph-database proxies.' },
  servers: [{ url: '/' }],
  tags: [{ name: 'Search' }, { name: 'Records' }, { name: 'Interoperability' }, { name: 'Operations' }, { name: 'Graph databases' }],
  paths: {
    '/api/search': { get: { tags: ['Search'], summary: 'Search records',
      description: 'Query syntax: implicit AND, OR, NOT / -term, "phrase", trunc*, wild?card, (grouping), field prefixes title: author: keyword: abstract: source: and year:2020 / year:2020-2024, doi:10.xxxx/yyyy.',
      parameters: [P('q', 'Query string'), P('page', 'Page number (default 1)'), P('size', 'Page size 1-100 (default 20)'), P('sort', 'relevance | cites | newest | oldest | title'),
        P('expand', 'false disables synonym/abbreviation expansion'), P('facets', '1 = include facet counts'), ...filters], responses: ok('Search results') } },
    '/api/records/{id}': { get: { tags: ['Records'], summary: 'Get one record', parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'integer' } }, P('format', 'json | jsonld | ris | bibtex | dc')], responses: { ...ok('Record'), '404': { description: 'Not found' } } } },
    '/api/doi/{doi}': { get: { tags: ['Records'], summary: 'Look up a record by DOI', parameters: [{ name: 'doi', in: 'path', required: true, schema: { type: 'string' }, description: 'e.g. 10.17821/srels/2023/v60i3/171028' }, P('format', 'json | jsonld | ris | bibtex | dc')], responses: { ...ok('Record'), '404': { description: 'Not in dataset' } } } },
    '/api/suggest': { get: { tags: ['Search'], summary: 'Type-ahead terms and spelling suggestion', parameters: [P('q', 'Prefix or query'), P('limit', 'Max suggestions')], responses: ok('Suggestions') } },
    '/api/authors': { get: { tags: ['Search'], summary: 'Find author names', parameters: [P('q', 'Name fragment'), P('limit', 'Max authors')], responses: ok('Authors') } },
    '/api/export': { get: { tags: ['Records'], summary: 'Export search results', parameters: [P('format', 'csv | ris | bibtex | json | jsonld'), P('q', 'Query'), P('ids', 'Comma-separated record ids (overrides q)'), P('limit', 'Max 5000'), ...filters], responses: ok('File download') } },
    '/api/meta': { get: { tags: ['Search'], summary: 'Collection statistics and facet values', responses: ok('Metadata') } },
    '/api/dataset': { get: { tags: ['Interoperability'], summary: 'Full dataset (gzip JSON) used by the web front end', responses: ok('Dataset') } },
    '/oai': { get: { tags: ['Interoperability'], summary: 'OAI-PMH 2.0 (oai_dc)', description: 'Verbs: Identify, ListMetadataFormats, ListSets, ListIdentifiers, ListRecords, GetRecord. Datestamps are <year>-01-01.', parameters: [P('verb', 'OAI verb', { required: true }), P('metadataPrefix', 'oai_dc'), P('identifier', 'oai:<namespace>:<id>'), P('from', 'YYYY-MM-DD'), P('until', 'YYYY-MM-DD'), P('set', 'src<N>'), P('resumptionToken', 'Token from previous page')], responses: ok('OAI-PMH XML') } },
    '/health': { get: { tags: ['Operations'], summary: 'Liveness probe', responses: ok('OK') } },
    '/api/config': { get: { tags: ['Operations'], summary: 'Public server configuration', responses: ok('Config') } },
    '/api/telemetry': { post: { tags: ['Operations'], summary: 'Anonymous usage event (only when TELEMETRY=true)', responses: { '204': { description: 'Recorded' }, '404': { description: 'Disabled' } } } },
    '/api/admin/telemetry-summary': { get: { tags: ['Operations'], summary: 'Aggregated telemetry (admin token)', security: [{ bearer: [] }], responses: ok('Summary') } },
    '/api/admin/backup': { post: { tags: ['Operations'], summary: 'Create a backup (admin token)', security: [{ bearer: [] }], responses: ok('Backup info') } },
    '/metrics': { get: { tags: ['Operations'], summary: 'Prometheus metrics (admin token if set)', responses: ok('Text metrics') } },
    '/api/neo4j/query': { post: { tags: ['Graph databases'], summary: 'Read-only Cypher through the server', requestBody: { content: { 'application/json': { schema: { type: 'object', properties: { query: { type: 'string' }, parameters: { type: 'object' } } } } } }, responses: { ...ok('Neo4j Query API v2 response'), '403': { description: 'Write query blocked' }, '503': { description: 'Proxy disabled' } } } },
    '/api/graphdb/query': { post: { tags: ['Graph databases'], summary: 'Read-only SPARQL through the server', requestBody: { content: { 'application/json': { schema: { type: 'object', properties: { query: { type: 'string' } } } } } }, responses: { ...ok('SPARQL JSON results'), '403': { description: 'Update/SERVICE blocked' }, '503': { description: 'Proxy disabled' } } } },
  },
  components: { securitySchemes: { bearer: { type: 'http', scheme: 'bearer' } } },
};
fs.writeFileSync(path.join(__dirname, '..', 'docs', 'openapi.json'), JSON.stringify(spec, null, 2));
console.log('docs/openapi.json written');
