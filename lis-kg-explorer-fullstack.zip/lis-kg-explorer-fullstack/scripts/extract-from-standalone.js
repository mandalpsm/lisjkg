'use strict';
/**
 * Derives the full-stack assets from the single-file edition (LIS-KG-Explorer-*.html):
 *   data/dataset.json.gz   - the embedded record set
 *   public/journal-map.html - the embedded 3D journal map
 *   public/index.html       - the front end with the 13 MB payloads removed and the server hooks added
 * Usage: node scripts/extract-from-standalone.js path/to/LIS-KG-Explorer-standalone.html
 */
const fs = require('fs'), path = require('path'), zlib = require('zlib');
const root = path.resolve(__dirname, '..');
const src = process.argv[2];
if (!src || !fs.existsSync(src)) { console.error('Usage: node scripts/extract-from-standalone.js <standalone.html>'); process.exit(1); }
let html = fs.readFileSync(src, 'utf8');

function take(id) {
  const re = new RegExp('(<script id="' + id + '"[^>]*>)([\\s\\S]*?)(</script>)');
  const m = html.match(re); if (!m) return null;
  html = html.replace(re, '$1$3'); return m[2].trim();
}
const unz = b64 => zlib.gunzipSync(Buffer.from(b64.replace(/^GZB64:/, ''), 'base64'));

const data = take('embeddedData');
if (!data) { console.error('No <script id="embeddedData"> found (already a full-stack build?)'); process.exit(1); }
const raw = data.startsWith('GZB64:') ? unz(data) : Buffer.from(data);
const parsed = JSON.parse(raw.toString('utf8'));
if (!parsed.m || !Array.isArray(parsed.r)) throw new Error('Unexpected dataset structure');
fs.mkdirSync(path.join(root, 'data'), { recursive: true });
fs.writeFileSync(path.join(root, 'data', 'dataset.json.gz'), zlib.gzipSync(Buffer.from(JSON.stringify(parsed)), { level: 9 }));
console.log('data/dataset.json.gz  records:', parsed.r.length);

const jm = take('jmEmbedded');
if (jm) { fs.writeFileSync(path.join(root, 'public', 'journal-map.html'), unz(jm)); console.log('public/journal-map.html written'); }

// Journal map: use the static file instead of the embedded blob.
html = html.replace("const b64=document.getElementById('jmEmbedded').textContent.trim().slice(6);",
  "const b64=document.getElementById('jmEmbedded').textContent.trim().slice(6); if(!b64){jmUrl=Promise.resolve('/journal-map.html');return jmUrl.then(u=>{frame.src=u});}");
// Graph-database panel: same-origin proxy by default.
html = html.replace(/http:\/\/localhost:8000\/api\/(neo4j|graphdb)\/query/g, '/api/$1/query');
html = html.replace('<option value="direct">Direct browser → local databases</option><option value="proxy">', '<option value="direct">Direct browser → local databases</option><option value="proxy" selected>');

const hook = fs.readFileSync(path.join(__dirname, 'frontend-server-hook.html'), 'utf8');
if (!html.includes('id="x7-server"')) html = html.replace(/<\/body>\s*<\/html>\s*$/, hook + '\n</body></html>\n');
fs.mkdirSync(path.join(root, 'public'), { recursive: true });
fs.writeFileSync(path.join(root, 'public', 'index.html'), html);
console.log('public/index.html     ', (html.length / 1024).toFixed(0), 'KB');
