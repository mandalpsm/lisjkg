'use strict';
// Usage: node scripts/backup.js            create a backup (dataset + logs) with SHA-256 manifest and prune old ones
//        node scripts/backup.js verify <dir>   verify a backup against its manifest
const backup = require('../server/lib/backup');
if (process.argv[2] === 'verify') {
  if (!process.argv[3]) { console.error('Usage: node scripts/backup.js verify <backup-dir>'); process.exit(1); }
  const r = backup.verify(process.argv[3]); console.log(JSON.stringify(r)); process.exit(r.ok ? 0 : 2);
} else console.log(JSON.stringify(backup.run()));
