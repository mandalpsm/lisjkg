'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const http = require('http');
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const { createServer } = require('../server/index.js');

function get(port, p, method = 'GET') {
  return new Promise((resolve, reject) => {
    const req = http.request({ host: '127.0.0.1', port, path: p, method }, res => {
      const chunks = [];
      res.on('data', c => chunks.push(c));
      res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, body: Buffer.concat(chunks) }));
    });
    req.on('error', reject);
    req.end();
  });
}

async function withServer(fn) {
  const server = createServer();
  await new Promise(r => server.listen(0, '127.0.0.1', r));
  try { await fn(server.address().port); } finally { server.close(); }
}

test('health endpoint reports ok', async () => {
  await withServer(async port => {
    const r = await get(port, '/api/health');
    assert.equal(r.status, 200);
    assert.equal(JSON.parse(r.body).status, 'ok');
  });
});

test('front end is served at /', async () => {
  await withServer(async port => {
    const r = await get(port, '/');
    assert.equal(r.status, 200);
    assert.match(r.headers['content-type'], /text\/html/);
    assert.match(r.body.toString('utf8'), /Semantic KG Explorer/);
  });
});

test('path traversal is blocked', async () => {
  await withServer(async port => {
    const r = await get(port, '/..%2f..%2fpackage.json');
    assert.notEqual(r.status, 200);
  });
});

test('unknown API route returns 404', async () => {
  await withServer(async port => {
    const r = await get(port, '/api/nope');
    assert.equal(r.status, 404);
  });
});

test('dataset is gzip and decodes to JSON with records', async t => {
  const file = path.join(__dirname, '..', 'data', 'dataset.json.gz');
  if (!fs.existsSync(file)) return t.skip('dataset not built: run npm run build');
  await withServer(async port => {
    const r = await get(port, '/api/dataset');
    assert.equal(r.status, 200);
    assert.equal(r.headers['content-encoding'], 'gzip');
    const data = JSON.parse(zlib.gunzipSync(r.body).toString('utf8'));
    assert.ok(Array.isArray(data.r) && data.r.length > 0);
  });
});
