#!/usr/bin/env node
'use strict';
/**
 * Splits the single-file app into the full-stack layout:
 *   data/dataset.json.gz  <- the embedded (base64 gzip) dataset
 *   public/index.html     <- the same front end, which fetches /api/dataset
 *
 * Usage:  node scripts/build-from-standalone.js path/to/Semantic-KG-Explorer-LISJKG.html
 */
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

const ROOT = path.resolve(__dirname, '..');
const src = process.argv[2];
if (!src) {
  console.error('Usage: node scripts/build-from-standalone.js <Semantic-KG-Explorer-LISJKG.html>');
  process.exit(1);
}

const html = fs.readFileSync(src, 'utf8');
const OPEN = '<script id="embeddedData" type="text/plain">';
const CLOSE = '</script>';

const a = html.indexOf(OPEN);
if (a < 0) throw new Error('Embedded data block not found in the standalone file.');
const payloadStart = a + OPEN.length;
const payloadEnd = html.indexOf(CLOSE, payloadStart);
const payload = html.slice(payloadStart, payloadEnd).trim();
if (!payload.startsWith('GZB64:')) throw new Error('Unexpected data format (expected GZB64:).');

const gz = Buffer.from(payload.slice(6), 'base64');
if (gz[0] !== 0x1f || gz[1] !== 0x8b) throw new Error('Embedded data is not gzip.');
const dataset = JSON.parse(zlib.gunzipSync(gz).toString('utf8')); // validate once

fs.mkdirSync(path.join(ROOT, 'data'), { recursive: true });
fs.writeFileSync(path.join(ROOT, 'data', 'dataset.json.gz'), gz);

function replaceOnce(text, from, to, label) {
  const n = text.split(from).length - 1;
  if (n !== 1) throw new Error(`${label}: expected 1 match, found ${n}`);
  return text.replace(from, () => to);
}

// 1. Remove the inline dataset (keep the empty container element).
let out = html.slice(0, a) + OPEN + CLOSE + html.slice(payloadEnd + CLOSE.length);

// 2. Dataset is loaded from the API instead of the page.
out = replaceOnce(out,
  "const EMBEDDED_DATA=document.getElementById('embeddedData').textContent;",
  "let EMBEDDED_DATA=document.getElementById('embeddedData').textContent; // empty in the full-stack build: fetched from /api/dataset",
  'EMBEDDED_DATA declaration');

out = replaceOnce(out,
  "async function unpack(){\n  if(!EMBEDDED_DATA.startsWith('GZB64:')) return JSON.parse(EMBEDDED_DATA);",
  "async function unpack(){\n  if(!EMBEDDED_DATA){\n    const r=await fetch('/api/dataset');\n    if(!r.ok) throw new Error('Dataset request failed (HTTP '+r.status+')');\n    return r.json();\n  }\n  if(!EMBEDDED_DATA.startsWith('GZB64:')) return JSON.parse(EMBEDDED_DATA);",
  'unpack()');

// 3. Fix: "Reload embedded library" must use unpack(), not JSON.parse on the raw string.
out = replaceOnce(out,
  'const payload=JSON.parse(EMBEDDED_DATA);',
  'const payload=await unpack();',
  'reload embedded library');

fs.mkdirSync(path.join(ROOT, 'public'), { recursive: true });
fs.writeFileSync(path.join(ROOT, 'public', 'index.html'), out, 'utf8');

const recs = Array.isArray(dataset.r) ? dataset.r.length : '?';
console.log(`OK: data/dataset.json.gz (${(gz.length / 1048576).toFixed(1)} MB, ${recs} records)`);
console.log(`OK: public/index.html (${(Buffer.byteLength(out) / 1048576).toFixed(1)} MB)`);
