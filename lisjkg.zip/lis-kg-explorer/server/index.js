'use strict';
/**
 * Semantic KG Explorer for LIS — HTTP server.
 *
 *  GET /api/health    -> service status (JSON)
 *  GET /api/dataset   -> bibliographic dataset (JSON, gzip-compressed on the wire)
 *  GET /*             -> front-end files from ../public
 *
 * Zero runtime dependencies: uses only Node.js built-in modules.
 */
const http = require('http');
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const PUBLIC_DIR = path.join(ROOT, 'public');
const DATASET_FILE = path.join(ROOT, 'data', 'dataset.json.gz');

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.webmanifest': 'application/manifest+json',
  '.txt': 'text/plain; charset=utf-8',
};

const SECURITY_HEADERS = {
  'X-Content-Type-Options': 'nosniff',
  'Referrer-Policy': 'no-referrer',
};

function sendJson(res, status, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(status, {
    ...SECURITY_HEADERS,
    'Content-Type': MIME['.json'],
    'Content-Length': Buffer.byteLength(body),
    'Cache-Control': 'no-store',
  });
  res.end(body);
}

function sendText(res, status, text) {
  res.writeHead(status, { ...SECURITY_HEADERS, 'Content-Type': MIME['.txt'] });
  res.end(text);
}

function serveDataset(req, res) {
  fs.stat(DATASET_FILE, (err, st) => {
    if (err || !st.isFile()) {
      return sendJson(res, 503, {
        error: 'Dataset not built',
        hint: 'Run "npm run build -- <standalone.html>", see README.',
      });
    }
    res.writeHead(200, {
      ...SECURITY_HEADERS,
      'Content-Type': MIME['.json'],
      // The file is stored gzip-compressed; browsers decompress it transparently.
      'Content-Encoding': 'gzip',
      'Content-Length': st.size,
      'Cache-Control': 'public, max-age=86400',
    });
    if (req.method === 'HEAD') return res.end();
    fs.createReadStream(DATASET_FILE).pipe(res);
  });
}

function serveStatic(req, res, pathname) {
  const rel = pathname === '/' ? 'index.html' : pathname.replace(/^\/+/, '');
  const file = path.resolve(PUBLIC_DIR, rel);
  // Block path traversal: the resolved file must stay inside PUBLIC_DIR.
  if (file !== PUBLIC_DIR && !file.startsWith(PUBLIC_DIR + path.sep)) {
    return sendText(res, 403, 'Forbidden');
  }
  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) return sendText(res, 404, 'Not found');
    res.writeHead(200, {
      ...SECURITY_HEADERS,
      'Content-Type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream',
      'Content-Length': st.size,
      'Cache-Control': 'no-cache',
    });
    if (req.method === 'HEAD') return res.end();
    fs.createReadStream(file).pipe(res);
  });
}

function createServer() {
  return http.createServer((req, res) => {
    if (req.method !== 'GET' && req.method !== 'HEAD') {
      res.writeHead(405, { Allow: 'GET, HEAD' });
      return res.end();
    }
    let pathname;
    try {
      pathname = decodeURIComponent(new URL(req.url, 'http://localhost').pathname);
    } catch {
      return sendText(res, 400, 'Bad request');
    }
    if (pathname === '/api/health') {
      return sendJson(res, 200, { status: 'ok', uptime_seconds: Math.round(process.uptime()) });
    }
    if (pathname === '/api/dataset') return serveDataset(req, res);
    if (pathname.startsWith('/api/')) return sendJson(res, 404, { error: 'Unknown API route' });
    return serveStatic(req, res, pathname);
  });
}

module.exports = { createServer };

if (require.main === module) {
  const PORT = Number(process.env.PORT) || 3000;
  const HOST = process.env.HOST || '0.0.0.0';
  createServer().listen(PORT, HOST, () => {
    console.log(`Semantic KG Explorer running at http://localhost:${PORT}`);
  });
}
