/* Runtime helpers: run a callback now if the event has already fired. */
function __onReady(fn){if(document.readyState==='loading')__onReady(fn);else fn();}
function __onLoad(fn){if(document.readyState==='complete')fn();else __onLoad(fn);}
/* ---- inline-block-0 ---- */
let EMBEDDED_DATA=document.getElementById('embeddedData').textContent; // empty in the full-stack build: fetched from /api/dataset
const PAGE_SIZE=20;
let DATA=null,M=null,R=null,S=null,PUB=null,PLC=null,CO=null,INDEX=null;
let state={query:'',page:1,sort:'relevance',savedOnly:false,yearSet:new Set(),yearFrom:null,yearTo:null,source:'',publisher:'',country:'',subject:'',hasLink:false,minCites:0,advanced:[]};
let currentResults=[];
let SEARCH_SAVED=null;
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
function esc(s){return String(s??'').replace(/[&<>\"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',"'":'&#39;'}[m]))}
function safeUrl(u){try{let x=new URL(String(u||''));return (x.protocol==='http:'||x.protocol==='https:')?x.href:''}catch{return ''}}
function norm(s){return String(s||'').toLowerCase().normalize('NFKD').replace(/[\u0300-\u036f\u200c\u200d]/g,'')}
function tokens(s){return norm(s).match(/[a-z0-9][a-z0-9.+#-]*/g)||[]}
/* ===== Language ID, Bengali transliteration, near-duplicate helpers (offline, zero deps) =====
   Interface and field lookups remain English-only. Bengali (or mixed) queries are detected by
   script, transliterated to Latin for matching against the English index, and noted in the UI.
   Machine translation / full multilingual embeddings are not bundled; use Semantic AI (optional
   LLM key) when online translation is needed. Language identification here is script-based. */
const BN_RANGE=/[\u0980-\u09FF]/;
const HI_RANGE=/[\u0900-\u097F]/;
const BN_MAP={
  'অ':'o','আ':'a','ই':'i','ঈ':'ii','উ':'u','ঊ':'uu','ঋ':'ri','এ':'e','ঐ':'oi','ও':'o','ঔ':'ou',
  'ক':'k','খ':'kh','গ':'g','ঘ':'gh','ঙ':'ng','চ':'ch','ছ':'chh','জ':'j','ঝ':'jh','ঞ':'ny',
  'ট':'t','ঠ':'th','ড':'d','ঢ':'dh','ণ':'n','ত':'t','থ':'th','দ':'d','ধ':'dh','ন':'n',
  'প':'p','ফ':'ph','ব':'b','ভ':'bh','ম':'m','য':'y','র':'r','ল':'l','শ':'sh','ষ':'sh','স':'s','হ':'h',
  'ড়':'r','ঢ়':'rh','য়':'y','ৎ':'t','ং':'ng','ঃ':'h','ঁ':'n',
  'া':'a','ি':'i','ী':'ii','ু':'u','ূ':'uu','ৃ':'ri','ে':'e','ৈ':'oi','ো':'o','ৌ':'ou',
  '্':'','০':'0','১':'1','২':'2','৩':'3','৪':'4','৫':'5','৬':'6','৭':'7','৮':'8','৯':'9',
  'ক্ষ':'ksh','জ্ঞ':'gy'
};
/* Devanagari (Hindi) → Latin for unknown-token fallback */
const HI_MAP={
  'अ':'a','आ':'a','इ':'i','ई':'ii','उ':'u','ऊ':'uu','ऋ':'ri','ए':'e','ऐ':'ai','ओ':'o','औ':'au',
  'क':'k','ख':'kh','ग':'g','घ':'gh','ङ':'ng','च':'ch','छ':'chh','ज':'j','झ':'jh','ञ':'ny',
  'ट':'t','ठ':'th','ड':'d','ढ':'dh','ण':'n','त':'t','थ':'th','द':'d','ध':'dh','न':'n',
  'प':'p','फ':'ph','ब':'b','भ':'bh','म':'m','य':'y','र':'r','ल':'l','व':'v','श':'sh','ष':'sh','स':'s','ह':'h',
  'क्ष':'ksh','ज्ञ':'gy','त्र':'tr','श्र':'shr',
  'ा':'a','ि':'i','ी':'ii','ु':'u','ू':'uu','ृ':'ri','े':'e','ै':'ai','ो':'o','ौ':'au',
  '्':'','ं':'n','ः':'h','ँ':'n','़':'',
  '०':'0','१':'1','२':'2','३':'3','४':'4','५':'5','६':'6','७':'7','८':'8','९':'9'
};
function detectLang(s){
  const t=String(s||'');
  if(!t.trim())return 'en';
  let bn=0,hi=0,lat=0;
  for(const ch of t){
    if(BN_RANGE.test(ch))bn++;
    else if(HI_RANGE.test(ch))hi++;
    else if(/[A-Za-z]/.test(ch))lat++;
  }
  if(hi>0&&bn>0)return 'mixed';
  if(hi>0&&lat>0)return 'mixed-hi';
  if(bn>0&&lat>0)return 'mixed';
  if(hi>0)return 'hi';
  if(bn>0)return 'bn';
  return 'en';
}
function bnToLatin(s){
  let out='';
  const str=String(s||'');
  for(let i=0;i<str.length;){
    const two=str.slice(i,i+2);
    if(BN_MAP[two]!=null){out+=BN_MAP[two];i+=2;continue}
    const one=str[i];
    if(BN_MAP[one]!=null)out+=BN_MAP[one];
    else if(BN_RANGE.test(one))out+='';
    else out+=one;
    i++;
  }
  return out.replace(/\s+/g,' ').trim();
}
function hiToLatin(s){
  let out='';
  const str=String(s||'');
  for(let i=0;i<str.length;){
    const two=str.slice(i,i+2);
    if(HI_MAP[two]!=null){out+=HI_MAP[two];i+=2;continue}
    const one=str[i];
    if(HI_MAP[one]!=null)out+=HI_MAP[one];
    else if(HI_RANGE.test(one))out+='';
    else out+=one;
    i++;
  }
  return out.replace(/\s+/g,' ').trim();
}
/** Prepare a query for the English index: keep Latin as-is; transliterate Bengali/Hindi script. */
function prepareSearchQueryLegacy(raw){
  const q=String(raw||'').trim();
  if(!q)return {searchQ:q,lang:'en',transliterated:false,note:''};
  const lang=detectLang(q);
  if(lang==='en')return {searchQ:q,lang,transliterated:false,note:''};
  let searchQ=q;
  if(lang==='hi'||lang==='mixed-hi')searchQ=hiToLatin(q)||q;
  else searchQ=bnToLatin(q)||q;
  return {
    searchQ,
    lang,
    transliterated:true,
    original:q,
    note: (lang==='hi'||lang==='mixed-hi')
      ? 'Hindi query transliterated for English index: “'+searchQ+'”'
      : (lang==='bn'
        ? 'Bengali query transliterated for English index: “'+searchQ+'”'
        : 'Mixed-script query; non-Latin parts transliterated: “'+searchQ+'”')
  };
}
let LAST_LANG_INFO={lang:'en',transliterated:false,note:''};
/*XL-BEGIN*/
/* ===== Cross-language retrieval: Bengali / Banglish queries <-> English index =====
   Offline pipeline: (1) bilingual LIS glossary with Bengali suffix handling, (2) transliteration
   matched against the collection vocabulary (names, loanwords), (3) optional online translation for
   still-unknown words, (4) English queries also search Bengali-script records when the collection has any. */
const XL_GLOSS_SRC=`library;libraries|গ্রন্থাগার;লাইব্রেরি;লাইব্রেরী;পাঠাগার;গ্রন্থশালা|granthagar;grantagar;pathagar;laibrari
librarian;librarians|গ্রন্থাগারিক;লাইব্রেরিয়ান|granthagarik;laibrerian
librarianship|গ্রন্থাগারিকতা;গ্রন্থাগারবিদ্যা|granthagarbidya
library science;library and information science|গ্রন্থাগার বিজ্ঞান;গ্রন্থাগার ও তথ্য বিজ্ঞান;লাইব্রেরি সায়েন্স|granthagar bigyan;granthagar biggyan
information science;information sciences|তথ্যবিজ্ঞান;তথ্য বিজ্ঞান|tathya bigyan;tothyo biggan
information|তথ্য|tathya;tothyo;totthyo
information retrieval|তথ্য পুনরুদ্ধার;তথ্য সন্ধান;তথ্য আহরণ;তথ্য উদ্ধার|tathya punaruddhar;tathya sandhan;tothyo punoruddhar
information system;information systems|তথ্য ব্যবস্থা;তথ্য পদ্ধতি;তথ্য সিস্টেম|tathya byabostha
information technology|তথ্যপ্রযুক্তি;তথ্য প্রযুক্তি|tathya projukti;tothyo projukti
information and communication technology;ict|তথ্য ও যোগাযোগ প্রযুক্তি|
information literacy|তথ্য সাক্ষরতা|tathya shakkharota
information seeking;information behaviour;information behavior|তথ্য অন্বেষণ;তথ্য অনুসন্ধান আচরণ|
information needs;information need|তথ্য চাহিদা;তথ্যের চাহিদা|tathyer chahida
information policy|তথ্য নীতি|
information society|তথ্য সমাজ|
knowledge|জ্ঞান|gyan;gyaan;jnan
knowledge organization;knowledge organisation|জ্ঞান সংগঠন|gyan sangathan
knowledge management|জ্ঞান ব্যবস্থাপনা;নলেজ ম্যানেজমেন্ট|gyan byabosthapona
knowledge graph;knowledge graphs|নলেজ গ্রাফ;জ্ঞান গ্রাফ;জ্ঞানগ্রাফ|gyan graph
knowledge base|জ্ঞানভান্ডার;জ্ঞানভাণ্ডার;নলেজ বেস|
ontology;ontologies|অন্টোলজি;অনটোলজি;সত্তাতত্ত্ব|
metadata|মেটাডেটা;মেটাডাটা;মেটা ডেটা|
data|ডেটা;ডাটা;উপাত্ত|
big data|বিগ ডেটা;বিগ ডাটা|
open data|ওপেন ডেটা;উন্মুক্ত ডেটা;উন্মুক্ত উপাত্ত|
database;databases|ডেটাবেস;ডাটাবেস;তথ্যভান্ডার;তথ্যভাণ্ডার|
data science|ডেটা সায়েন্স;উপাত্ত বিজ্ঞান|
data mining|ডেটা মাইনিং;উপাত্ত খনন|
text mining|টেক্সট মাইনিং;পাঠ্য খনন|
research data management|গবেষণা উপাত্ত ব্যবস্থাপনা|
digital|ডিজিটাল|
digital library;digital libraries|ডিজিটাল গ্রন্থাগার;ডিজিটাল লাইব্রেরি;ডিজিটাল লাইব্রেরী|digital granthagar
digital preservation|ডিজিটাল সংরক্ষণ|
digitization;digitisation;digitalization;digitalisation|ডিজিটাইজেশন;ডিজিটালাইজেশন;ডিজিটালীকরণ|
digital humanities|ডিজিটাল মানববিদ্যা|
digital literacy|ডিজিটাল সাক্ষরতা|
preservation|সংরক্ষণ|songrokkhon;sangrakshan
archive;archives;archival|আর্কাইভ;মহাফেজখানা;সংরক্ষণাগার|
repository;repositories|রিপোজিটরি;সংগ্রহশালা;ভান্ডার;ভাণ্ডার|
institutional repository;institutional repositories|প্রাতিষ্ঠানিক ভান্ডার;প্রাতিষ্ঠানিক রিপোজিটরি|
open access|মুক্ত প্রবেশাধিকার;উন্মুক্ত প্রবেশাধিকার;ওপেন অ্যাক্সেস;ওপেন এক্সেস;মুক্ত অভিগম্যতা|mukto probeshadhikar
open science|মুক্ত বিজ্ঞান;উন্মুক্ত বিজ্ঞান|
catalog;catalogue;cataloging;cataloguing|ক্যাটালগ;ক্যাটালগিং;ক্যাটালগকরণ;তালিকাকরণ|
classification|শ্রেণিবিন্যাস;শ্রেণীবিন্যাস;শ্রেণিবিভাগ;শ্রেণীবিভাগ|sreni binyas;shrenibinyas
colon classification|কোলন ক্লাসিফিকেশন;কোলন শ্রেণিবিন্যাস|
indexing|সূচিকরণ;সূচীকরণ;ইনডেক্সিং|suchikaran
index;indexes|সূচি;সূচী|
thesaurus;thesauri|থিসরাস;সমার্থক শব্দকোষ|
taxonomy;taxonomies|ট্যাক্সোনমি;শ্রেণিবিজ্ঞান|
subject headings;subject heading|বিষয় শিরোনাম|
semantic web|সিম্যান্টিক ওয়েব;সেমান্টিক ওয়েব;শব্দার্থিক ওয়েব|
linked data|সংযুক্ত তথ্য;লিংকড ডেটা;লিঙ্কড ডেটা;সংযুক্ত উপাত্ত|
semantic|সিম্যান্টিক;শব্দার্থিক|
search|অনুসন্ধান;সার্চ;খোঁজ|onusandhan;onushondhan
search engine;search engines|সার্চ ইঞ্জিন;অনুসন্ধান ইঞ্জিন|
retrieval|পুনরুদ্ধার;আহরণ|
evaluation;assessment|মূল্যায়ন|mullayon
user;users|ব্যবহারকারী;ব্যবহারকারীরা|byabohar
user experience|ব্যবহারকারীর অভিজ্ঞতা|
usability|ব্যবহারযোগ্যতা|
user satisfaction|ব্যবহারকারী সন্তুষ্টি|
accessibility|অভিগম্যতা;প্রবেশযোগ্যতা|
literacy|সাক্ষরতা|
reading;reading habits;reading habit|পঠন;পাঠাভ্যাস;পড়ার অভ্যাস|pathabhyas
research|গবেষণা|gobeshona;gabeshana;goveshona
researcher;researchers|গবেষক|gobeshok
citation;citations|উদ্ধৃতি;সাইটেশন|uddhriti
citation analysis|উদ্ধৃতি বিশ্লেষণ;সাইটেশন বিশ্লেষণ|
bibliometrics;bibliometric;bibliometric analysis|গ্রন্থমিতি;বিবলিওমেট্রিক্স;বিবলিওমেট্রিক|granthomiti
scientometrics|বিজ্ঞানমিতি;সায়েন্টোমেট্রিক্স|
informetrics|তথ্যমিতি|
altmetrics|অল্টমেট্রিক্স|
impact factor|ইমপ্যাক্ট ফ্যাক্টর;প্রভাবাঙ্ক|
scholarly communication|স্কলারলি কমিউনিকেশন;গবেষণা যোগাযোগ|
publication;publications;publishing|প্রকাশনা|prokashona
publisher;publishers|প্রকাশক|prokashok
journal;journals|জার্নাল;পত্রিকা;সাময়িকী;সাময়িকপত্র|potrika
article;articles|প্রবন্ধ;নিবন্ধ;আর্টিকেল|probondho
book;books|বই;গ্রন্থ;পুস্তক|boi;pustak;grantha
e-book;ebook;e-books;electronic book|ই-বুক;ইবুক;ই বুক|
electronic resources;e-resources;e-resource|ই-রিসোর্স;ইলেকট্রনিক সম্পদ;ই-সম্পদ|
electronic|ইলেকট্রনিক|
author;authors|লেখক;লেখকরা|lekhok
authorship|লেখকত্ব|
co-authorship;coauthorship;collaboration|সহ-লেখকত্ব;যৌথ লেখকত্ব;সহযোগিতা|
university;universities|বিশ্ববিদ্যালয়|biswabidyalay;bishwabidyalay
academic library;academic libraries;university library;university libraries|একাডেমিক গ্রন্থাগার;বিশ্ববিদ্যালয় গ্রন্থাগার|
public library;public libraries|গণগ্রন্থাগার;সার্বজনীন গ্রন্থাগার;পাবলিক লাইব্রেরি;গণ গ্রন্থাগার|gono granthagar
school library;school libraries|বিদ্যালয় গ্রন্থাগার;স্কুল লাইব্রেরি|
special library;special libraries|বিশেষ গ্রন্থাগার|
national library|জাতীয় গ্রন্থাগার|
rural library;rural libraries|গ্রামীণ গ্রন্থাগার|
library automation|গ্রন্থাগার স্বয়ংক্রিয়করণ;লাইব্রেরি অটোমেশন|
library management|গ্রন্থাগার ব্যবস্থাপনা|
library services;library service|গ্রন্থাগার সেবা|
library education;lis education|গ্রন্থাগার শিক্ষা|
management|ব্যবস্থাপনা|
service;services|সেবা|
reference service;reference services|রেফারেন্স সেবা|
education|শিক্ষা|shikkha;shiksha
student;students|ছাত্র;ছাত্রছাত্রী;শিক্ষার্থী|shikkharthi
teacher;teachers|শিক্ষক|shikkhok
school;schools|বিদ্যালয়;স্কুল|
children;child|শিশু;শিশুরা;শিশু-কিশোর|shishu
women;woman|নারী;মহিলা|nari
gender|জেন্ডার;লিঙ্গ|
health|স্বাস্থ্য|shastho
agriculture;agricultural|কৃষি|krishi
covid;covid-19;coronavirus|কোভিড;করোনা;কোভিড-১৯;করোনাভাইরাস|
pandemic|মহামারি;মহামারী|
social media|সামাজিক মাধ্যম;সোশ্যাল মিডিয়া|
internet|ইন্টারনেট|
web|ওয়েব|
website;websites|ওয়েবসাইট|
mobile|মোবাইল|
artificial intelligence|কৃত্রিম বুদ্ধিমত্তা;আর্টিফিশিয়াল ইন্টেলিজেন্স;কৃত্রিম বুদ্ধিমত্তা|
machine learning|মেশিন লার্নিং;যন্ত্র শিক্ষণ;যন্ত্রশিক্ষণ|
deep learning|ডিপ লার্নিং|
natural language processing|প্রাকৃতিক ভাষা প্রক্রিয়াকরণ|
large language model;large language models|বৃহৎ ভাষা মডেল|
generative ai|জেনারেটিভ এআই|
chatgpt|চ্যাটজিপিটি|
chatbot;chatbots|চ্যাটবট|
blockchain|ব্লকচেইন|
cloud|ক্লাউড|
technology;technologies|প্রযুক্তি|projukti
communication|যোগাযোগ|jogajog
copyright|কপিরাইট;স্বত্বাধিকার|
plagiarism|চৌর্যবৃত্তি;প্লেজিয়ারিজম|
ethics;ethical|নৈতিকতা;নীতিশাস্ত্র|
privacy|গোপনীয়তা|
peer review|পিয়ার রিভিউ;সহকর্মী পর্যালোচনা|
literature review|সাহিত্য পর্যালোচনা|
review;reviews|পর্যালোচনা|
survey;surveys|জরিপ;সমীক্ষা|jorip
case study;case studies|কেস স্টাডি;ঘটনা সমীক্ষা|
content analysis|বিষয়বস্তু বিশ্লেষণ|
analysis|বিশ্লেষণ|bishleshon
trend;trends|প্রবণতা|
model;models|মডেল|
framework;frameworks|কাঠামো;ফ্রেমওয়ার্ক|
system;systems|ব্যবস্থা;সিস্টেম|
network;networks|নেটওয়ার্ক;জালিকা|
graph;graphs|গ্রাফ|
visualization;visualisation|দৃশ্যায়ন;ভিজ্যুয়ালাইজেশন|
recommender;recommendation;recommendations|সুপারিশ ব্যবস্থা;সুপারিশ|
ranking|র‍্যাঙ্কিং;ক্রমবিন্যাস|
language;languages|ভাষা|bhasha
multilingual|বহুভাষিক|
translation|অনুবাদ|anubad
bengali;bangla|বাংলা;বাঙালি|bangla
bangladesh|বাংলাদেশ|
india;indian|ভারত;ভারতবর্ষ|bharat
west bengal|পশ্চিমবঙ্গ;পশ্চিম বঙ্গ|poschimbongo
kolkata;calcutta|কলকাতা;কলিকাতা|
dhaka;dacca|ঢাকা|
assam|অসম;আসাম|
tripura|ত্রিপুরা|
nepal|নেপাল|
pakistan|পাকিস্তান|
sri lanka|শ্রীলঙ্কা|
china;chinese|চীন|
japan|জাপান|
united states;usa;america|যুক্তরাষ্ট্র;আমেরিকা|
united kingdom;uk|যুক্তরাজ্য|
nigeria|নাইজেরিয়া|
africa;african|আফ্রিকা|
asia;asian|এশিয়া|
europe;european|ইউরোপ|
iran|ইরান|
malaysia|মালয়েশিয়া|
rural|গ্রামীণ|
urban|শহর;নগর|
community;communities|সম্প্রদায়;কমিউনিটি|
society|সমাজ|
culture;cultural|সংস্কৃতি|
heritage|ঐতিহ্য|
cultural heritage|সাংস্কৃতিক ঐতিহ্য|
museum;museums|জাদুঘর;মিউজিয়াম|
manuscript;manuscripts|পাণ্ডুলিপি|
records management;record management|নথি ব্যবস্থাপনা;রেকর্ড ব্যবস্থাপনা|
document;documents|নথি;দলিল|
disability;disabilities;disabled|প্রতিবন্ধী;প্রতিবন্ধিতা|
quality|গুণমান|
training|প্রশিক্ষণ|
skills;skill;competencies;competency|দক্ষতা|
professional;professionals|পেশাদার|
wikipedia|উইকিপিডিয়া|
web of science|ওয়েব অফ সায়েন্স|
scopus|স্কোপাস|
google scholar|গুগল স্কলার|
tagore|ঠাকুর;ঠাকুরের|
rabindranath|রবীন্দ্রনাথ|
ranganathan|রঙ্গনাথন;রঙ্গনাথন|
dewey|ডিউই|`;
const XL_BN_RANGE=/[\u0980-\u09FF]/;
const XL_HI_RANGE=/[\u0900-\u097F]/;
const XL_BN_STOP=new Set('এবং ও এর এই এটি এটা সেই তার তাদের যে যা কি কী কেন কোন কোনো থেকে জন্য সঙ্গে সাথে দ্বারা সম্পর্কে বিষয়ে নিয়ে মধ্যে উপর ওপর আর না হয় হয়েছে করা করে করার একটি একটা কিছু সব সকল এক আমি আমার আমরা আছে নেই ও'.split(' ').map(s=>s.normalize('NFC')));
const XL_HI_STOP=new Set('और एवं तथा या कि यह वह जो के का की को से में पर द्वारा लिए लिये साथ बिना नहीं है हैं था थी थे होगा होगी होगा एक कुछ सभी कोई अपने अपना अपनी मैं हम आप'.split(' ').map(s=>s.normalize('NFC')));
const XL_BN_OR=new Set(['বা','অথবা','কিংবা']);
const XL_HI_OR=new Set(['या','अथवा']);
const XL_SUFFIXES=['গুলোকে','গুলিকে','গুলোর','গুলির','গুলো','গুলি','েরকে','দেরকে','দের','টিকে','টির','টাকে','টার','টি','টা','খানা','খানি','েরা','রা','ের','েতে','তে','কে','য়','ে','র','ও'];
const XL_HI_SUFFIXES=['ों','ियों','ियों','ियों','ों','े','ी','ा','ों','ने','ना','नी','ता','ती','ते','कर','से','को','का','की','के','में','पर'];
/* Hindi LIS glossary: English key terms → Devanagari forms (semicolon-separated variants) */
const XL_HI_GLOSS_SRC=`library;libraries|पुस्तकालय;लाइब्रेरी;पुस्तकालय
librarian;librarians|पुस्तकालयाध्यक्ष;लाइब्रेरियन
librarianship|पुस्तकालय विज्ञान
library science;library and information science|पुस्तकालय विज्ञान;पुस्तकालय एवं सूचना विज्ञान
information science|सूचना विज्ञान
information|सूचना;जानकारी
information retrieval|सूचना पुनर्प्राप्ति;सूचना खोज
information system;information systems|सूचना प्रणाली
information technology|सूचना प्रौद्योगिकी
information and communication technology;ict|सूचना एवं संचार प्रौद्योगिकी
information literacy|सूचना साक्षरता
information seeking;information behaviour;information behavior|सूचना खोज व्यवहार
information needs;information need|सूचना आवश्यकता
knowledge|ज्ञान
knowledge organization;knowledge organisation|ज्ञान संगठन
knowledge management|ज्ञान प्रबंधन
knowledge graph;knowledge graphs|ज्ञान ग्राफ;नॉलेज ग्राफ
knowledge base|ज्ञान आधार
ontology;ontologies|ऑन्टोलॉजी
metadata|मेटाडेटा
data|डेटा;आँकड़े
big data|बिग डेटा
open data|मुक्त डेटा;ओपन डेटा
database;databases|डेटाबेस
data science|डेटा विज्ञान
data mining|डेटा माइनिंग
text mining|पाठ खनन
digital|डिजिटल
digital library;digital libraries|डिजिटल पुस्तकालय
digital preservation|डिजिटल संरक्षण
digitization;digitisation|डिजिटलीकरण
digital literacy|डिजिटल साक्षरता
preservation|संरक्षण
archive;archives|अभिलेखागार;आर्काइव
repository;repositories|रिपॉजिटरी;संग्रह
institutional repository|संस्थागत रिपॉजिटरी
open access|मुक्त अभिगम;ओपन एक्सेस
open science|मुक्त विज्ञान
catalog;catalogue;cataloging;cataloguing|सूची;कैटलॉग;सूचीकरण
classification|वर्गीकरण
indexing|अनुक्रमण;इंडेक्सिंग
index;indexes|अनुक्रमणिका
thesaurus|थिसॉरस
taxonomy|वर्गीकरण प्रणाली
subject headings|विषय शीर्षक
semantic web|सिमेंटिक वेब
linked data|लिंक्ड डेटा
search|खोज;अनुसंधान
search engine|खोज इंजन
retrieval|पुनर्प्राप्ति
evaluation|मूल्यांकन
user;users|उपयोगकर्ता
user experience|उपयोगकर्ता अनुभव
usability|उपयोगिता
accessibility|अभिगम्यता
literacy|साक्षरता
research|अनुसंधान;शोध
researcher;researchers|शोधकर्ता
citation;citations|उद्धरण
citation analysis|उद्धरण विश्लेषण
bibliometrics|ग्रंथमिति;बिब्लियोमेट्रिक्स
scientometrics|साइंटोमेट्रिक्स
altmetrics|अल्टमेट्रिक्स
impact factor|इम्पैक्ट फैक्टर
scholarly communication|शैक्षिक संचार
publication;publications|प्रकाशन
publisher;publishers|प्रकाशक
journal;journals|जर्नल;पत्रिका
article;articles|लेख;आर्टिकल
book;books|पुस्तक;किताब
e-book;ebook|ई-पुस्तक
thesis;dissertation|शोध प्रबंध;थीसिस
abstract|सार;सारांश
author;authors|लेखक
editor;editors|संपादक
keyword;keywords|कीवर्ड;मुख्य शब्द
reference|संदर्भ
bibliography|संदर्भ सूची
collection|संग्रह
acquisition|अधिग्रहण
circulation|परिसंचरण
interlibrary loan|अंतर-पुस्तकालय ऋण
opac|ओपैक
marc|मार्क
rda|आरडीए
classification scheme|वर्गीकरण योजना
dewey|डीवी
ranganathan|रंगनाथन
artificial intelligence;ai|कृत्रिम बुद्धिमत्ता;एआई
machine learning|मशीन लर्निंग
natural language processing;nlp|प्राकृतिक भाषा प्रसंस्करण
chatbot|चैटबॉट
semantic search|सिमेंटिक खोज
recommendation|सिफारिश
ranking|रैंकिंग
precision|परिशुद्धता
recall|स्मरण
relevance|प्रासंगिकता
query|क्वेरी;प्रश्न
boolean|बूलियन
facet;faceted|पहलू;फेसटेड
filter|फ़िल्टर
sorting|क्रमबद्धता
citation count|उद्धरण संख्या
peer review|सहकर्मी समीक्षा
preprint|प्रीप्रिंट
doi|डीओआई
issn|आईएसएसएन
orcid|ऑर्सिड
university|विश्वविद्यालय
college|महाविद्यालय
school|विद्यालय
india|भारत
hindi|हिंदी;हिन्दी`;
let XL=null,XL_VOC=null,XL_CACHE=new Map(),XL_OUT=new Set(),XL_HB={ref:null,n:-1,v:false};
const XL_MT=new Map();
try{const s=JSON.parse(localStorage.getItem('lisMtCache')||'{}');for(const k in s)XL_MT.set(k,s[k])}catch(e){}
function xlNormBn(s){return String(s||'').normalize('NFC').replace(/[\u200c\u200d]/g,'').replace(/[০-৯]/g,d=>'০১২৩৪৫৬৭৮৯'.indexOf(d)).replace(/\s+/g,' ').trim()}
function xlSkel(w){
  let s=String(w||'').toLowerCase().replace(/[^a-z]/g,'');
  s=s.replace(/ch/g,'@').replace(/c/g,'k').replace(/@/g,'c').replace(/(kh|gh|jh|th|dh|ph|bh|sh)/g,m=>({kh:'k',gh:'g',jh:'j',th:'t',dh:'d',ph:'p',bh:'b',sh:'s'}[m])).replace(/ng/g,'n');
  s=s.replace(/[aeiouyh]/g,'').replace(/[jz]/g,'g').replace(/[vw]/g,'b').replace(/f/g,'p').replace(/q/g,'k').replace(/(.)\1+/g,'$1');
  return s;
}
function xlRoKey(s){return String(s||'').toLowerCase().replace(/[^a-z]/g,'').replace(/(.)\1+/g,'$1')}
function xlRoman(tok){return norm(bnToLatin(tok)).replace(/[^a-z]/g,'')}
function xlForms(w,depth){
  const out=[w];depth=depth||0;
  if(depth>=2)return out;
  for(const suf of XL_SUFFIXES_N){const sn=suf.n;if(w.length-sn.length>=2&&w.endsWith(sn)){const st=w.slice(0,-sn.length);for(const f of xlForms(st,depth+1))if(!out.includes(f))out.push(f)}}
  return out;
}
let XL_SUFFIXES_N=null;
function xlNormHi(s){return String(s||'').normalize('NFC').replace(/[\u200c\u200d]/g,'').replace(/[०-९]/g,d=>'०१२३४५६७८९'.indexOf(d)).replace(/\s+/g,' ').trim()}
function xlHiForms(w,depth){
  const out=[w];depth=depth||0;if(depth>=2)return out;
  for(const suf of (XL_HI_SUFFIXES_N||[])){const sn=suf;if(w.length-sn.length>=2&&w.endsWith(sn)){const st=w.slice(0,-sn.length);for(const f of xlHiForms(st,depth+1))if(!out.includes(f))out.push(f)}}
  return out;
}
let XL_HI_SUFFIXES_N=null;
function xlInit(){
  if(XL)return XL;
  XL_SUFFIXES_N=XL_SUFFIXES.map(s=>({n:xlNormBn(s)})).sort((a,b)=>b.n.length-a.n.length);
  XL_HI_SUFFIXES_N=XL_HI_SUFFIXES.map(s=>xlNormHi(s)).sort((a,b)=>b.length-a.length);
  const G=[],BNMAP=new Map(),HIMAP=new Map(),ROMAP=new Map(),SKMAP=new Map(),ENMAP=new Map(),ROWORDS=new Set();
  const add=(m,k,i)=>{if(!k)return;(m.get(k)||m.set(k,new Set()).get(k)).add(i)};
  const byEn=new Map();
  XL_GLOSS_SRC.split('\n').forEach(line=>{
    const p=line.split('|');if(p.length<2)return;
    const e={en:p[0].split(';').map(x=>x.trim()).filter(Boolean),bn:p[1].split(';').map(x=>xlNormBn(x)).filter(Boolean),ro:(p[2]||'').split(';').map(x=>x.trim().toLowerCase()).filter(Boolean),hi:[]};
    const i=G.push(e)-1;
    e.bn.forEach(b=>{add(BNMAP,b,i);const sk=xlSkel(b.split(' ').map(xlRoman).join(''));if(sk.length>=3)add(SKMAP,sk,i)});
    e.ro.forEach(r=>{add(ROMAP,xlRoKey(r),i);const sk=xlSkel(r);if(sk.length>=3)add(SKMAP,sk,i);r.split(/\s+/).forEach(w=>{if(w.length>=5)ROWORDS.add(xlRoKey(w))})});
    e.en.forEach(v=>{add(ENMAP,v.toLowerCase(),i);byEn.set(v.toLowerCase(),i)});
  });
  /* Attach Hindi forms onto matching English glossary entries (or create new ones) */
  XL_HI_GLOSS_SRC.split('\n').forEach(line=>{
    const p=line.split('|');if(p.length<2)return;
    const ens=p[0].split(';').map(x=>x.trim().toLowerCase()).filter(Boolean);
    const his=p[1].split(';').map(x=>xlNormHi(x)).filter(Boolean);
    let idx=-1;
    for(const en of ens){if(byEn.has(en)){idx=byEn.get(en);break}}
    if(idx<0){
      const e={en:ens,bn:[],ro:[],hi:his};idx=G.push(e)-1;
      ens.forEach(v=>{add(ENMAP,v,idx);byEn.set(v,idx)});
    }else{
      his.forEach(h=>{if(!G[idx].hi.includes(h))G[idx].hi.push(h)});
    }
    his.forEach(h=>{
      add(HIMAP,h,idx);
      const sk=xlSkel(h.split(' ').map(t=>hiToLatin(t)).join(''));
      if(sk.length>=3)add(SKMAP,sk,idx);
    });
  });
  const ENW=new Set();G.forEach(e=>e.en.forEach(v=>v.split(/[^A-Za-z]+/).forEach(w=>{if(w)ENW.add(xlRoKey(w))})));
  [...ROWORDS].forEach(w=>{if(ENW.has(w)||(typeof SRCH_STOP!=='undefined'&&SRCH_STOP.has(w)))ROWORDS.delete(w)});
  XL={G,BNMAP,HIMAP,ROMAP,SKMAP,ENMAP,ROWORDS};return XL;
}
function xlHasBnData(){
  try{
    if(XL_HB.ref===R&&XL_HB.n===R.length)return XL_HB.v;
    let v=false;for(let i=0;i<R.length&&!v;i++){const r=R[i];if(XL_BN_RANGE.test(r[2]||'')||XL_BN_RANGE.test(r[11]||'')||XL_BN_RANGE.test(r[12]||'')||XL_BN_RANGE.test(r[1]||''))v=true}
    XL_HB={ref:R,n:R.length,v};return v;
  }catch(e){return false}
}
function xlVocab(){
  if(XL_VOC&&XL_VOC.ref===INDEX)return XL_VOC.map;
  const df=new Map(),auth=new Set();
  for(let i=0;i<INDEX.length;i++){
    const x=INDEX[i];
    for(const f of ['a','k','t']){const s=x[f];if(!s)continue;for(const w of s.split(/[^a-z0-9]+/)){if(w.length>=4&&w.length<=20&&!/\d/.test(w)){df.set(w,(df.get(w)||0)+1);if(f==='a')auth.add(w)}}}
  }
  const map=new Map();
  df.forEach((n,w)=>{if(typeof SRCH_STOP!=='undefined'&&SRCH_STOP.has(w))return;if(n<2&&!auth.has(w))return;const k=xlSkel(w);if(k.length<3)return;(map.get(k)||map.set(k,[]).get(k)).push([w,n])});
  map.forEach(a=>a.sort((x,y)=>y[1]-x[1]));
  XL_VOC={ref:INDEX,map};return map;
}
function xlVocabCands(tr){
  if(tr.length<3)return [];
  const k=xlSkel(tr);if(k.length<3)return [];
  const a=xlVocab().get(k);if(!a)return [];const top=a[0][1];return a.filter(x=>x[1]>=Math.max(1,Math.ceil(top*0.15))).slice(0,3).map(x=>x[0]);
}
function xlBanglishHint(q){
  const w=(String(q).toLowerCase().match(/[a-z]+/g)||[]);if(!w.length)return false;
  const G=xlInit();let hit=0;for(const x of w)if(G.ROWORDS.has(xlRoKey(x)))hit++;
  return hit>=1&&hit*2>=w.length;
}
function xlQuote(v){return /\s/.test(v)?'"'+v+'"':v}
function xlGroup(set,hasData,extraBn){
  const G=xlInit().G,en=[],bn=[];
  [...set].forEach(i=>{G[i].en.forEach(v=>{if(!en.includes(v))en.push(v)});G[i].bn.slice(0,3).forEach(v=>{if(!bn.includes(v))bn.push(v)})});
  const items=[];en.slice(0,8).forEach((v,ix)=>{items.push(xlQuote(v));if(ix===0&&/\s/.test(v)&&!/[-]/.test(v))items.push('('+v+')')});
  if(hasData)bn.slice(0,4).forEach(v=>items.push(xlQuote(v)));
  return items.length===1?items[0]:'('+items.join(' OR ')+')';
}
function xlConvert(q,mode){
  const G=xlInit(),hasData=xlHasBnData(),toks=q.match(/"[^"]*"|\(|\)|[^\s()"]+/g)||[];
  const out=[],pairs=[],unresolved=[],plain=[];let translit=false;
  const unit=(w,neg)=>{out.push((neg?'-':'')+w)};
  function matchBn(words,i){
    let lim=0;while(i+lim<words.length&&lim<4&&XL_BN_RANGE.test(words[i+lim]))lim++;
    for(let n=lim;n>=1;n--){
      const t=words.slice(i,i+n).map(xlNormBn),last=t[n-1];
      for(const f of xlForms(last)){const key=t.slice(0,n-1).concat([f]).join(' ');const h=G.BNMAP.get(key);if(h)return {set:h,n}}
    }
    return null;
  }
  function matchHi(words,i){
    let lim=0;while(i+lim<words.length&&lim<4&&XL_HI_RANGE.test(words[i+lim]))lim++;
    for(let n=lim;n>=1;n--){
      const t=words.slice(i,i+n).map(xlNormHi),last=t[n-1];
      for(const f of xlHiForms(last)){const key=t.slice(0,n-1).concat([f]).join(' ');const h=G.HIMAP.get(key);if(h)return {set:h,n}}
    }
    return null;
  }
  function matchRo(words,i,fuzzy){
    let lim=0;while(i+lim<words.length&&lim<3&&/^[A-Za-z]+$/.test(words[i+lim]))lim++;
    for(let n=lim;n>=1;n--){
      const j=words.slice(i,i+n).join(''),h=G.ROMAP.get(xlRoKey(j));if(h)return {set:h,n};
      if(fuzzy){const sk=xlSkel(j);if(sk.length>=3){const f=G.SKMAP.get(sk);if(f)return {set:f,n}}}
    }
    return null;
  }
  function run(words,neg){
    const units=[];let i=0;
    while(i<words.length){
      const w=words[i];
      if(/[*?]/.test(w)){units.push(w);i++;continue}
      const isBn=XL_BN_RANGE.test(w);
      const isHi=XL_HI_RANGE.test(w);
      if(isHi){
        const m=matchHi(words,i);
        if(m){
          const src=words.slice(i,i+m.n).join(' '),g=xlGroup(m.set,hasData);
          units.push(g);pairs.push({src,out:[...m.set].map(k=>G.G[k].en[0]).filter((v,x,a)=>a.indexOf(v)===x).join(' / '),kind:'glossary'});
          plain.push(G.G[[...m.set][0]].en[0]);i+=m.n;continue;
        }
        const nh=xlNormHi(w);
        if(XL_HI_OR.has(nh)){units.push('OR');i++;continue}
        if(XL_HI_STOP.has(nh)){i++;continue}
        const tr=hiToLatin(w),mt=XL_MT.get(w),cands=xlVocabCands(tr);let items=[],kind='transliteration';
        if(cands.length){items=items.concat(cands);kind='vocabulary match'}
        if(mt){items=items.concat([mt]);kind='online translation'}
        if(!items.length&&tr.length>=2)items=[tr];
        if(!cands.length&&!mt)unresolved.push(w);
        if(kind!=='online translation')translit=true;
        units.push(items.length>1?'('+items.map(xlQuote).join(' OR ')+')':(items[0]||''));
        pairs.push({src:w,out:items.filter(x=>!XL_HI_RANGE.test(x)&&!XL_BN_RANGE.test(x)).join(' / '),kind});
        plain.push((items.find(x=>!XL_HI_RANGE.test(x)&&!XL_BN_RANGE.test(x)))||'');i++;continue;
      }
      if(isBn||mode==='banglish'||G.ROWORDS.has(xlRoKey(w))){
        const m=isBn?matchBn(words,i):matchRo(words,i,mode==='banglish');
        if(m){
          const src=words.slice(i,i+m.n).join(' '),g=xlGroup(m.set,hasData);
          units.push(g);pairs.push({src,out:[...m.set].map(k=>G.G[k].en[0]).filter((v,x,a)=>a.indexOf(v)===x).join(' / '),kind:'glossary'});
          plain.push(G.G[[...m.set][0]].en[0]);i+=m.n;continue;
        }
      }
      if(isBn){
        const nb=xlNormBn(w);
        if(XL_BN_OR.has(nb)){units.push('OR');i++;continue}
        if(XL_BN_STOP.has(nb)){i++;continue}
        const tr=xlRoman(w),mt=XL_MT.get(w),cands=xlVocabCands(tr);let items=[],kind='transliteration';
        if(cands.length){items=items.concat(cands);kind='vocabulary match'}
        if(mt){items=items.concat([mt]);kind='online translation'}
        if(!items.length&&tr.length>=2)items=[tr];
        if(!cands.length&&!mt){unresolved.push(w)}
        if(kind!=='online translation')translit=true;
        if(hasData){const st=xlForms(nb).slice(-1)[0];if(st&&st.length>=2)items.push(st)}
        units.push(items.length>1?'('+items.map(xlQuote).join(' OR ')+')':(items[0]||''));
        pairs.push({src:w,out:items.filter(x=>!XL_BN_RANGE.test(x)).join(' / '),kind});
        plain.push((items.find(x=>!XL_BN_RANGE.test(x)))||'');i++;continue;
      }
      units.push(w);plain.push(w);i++;
    }
    return units.filter(Boolean);
  }
  let runW=[];
  const flush=()=>{if(runW.length){run(runW,false).forEach(u=>unit(u,false));runW=[]}};
  for(const t of toks){
    if(t==='('||t===')'||/^(AND|OR|NOT|\|\||&&|\|)$/.test(t)){flush();out.push(t);continue}
    if(t[0]==='"'){
      flush();const inner=t.replace(/^"|"$/g,''),ws=inner.match(/[\u0980-\u09FF\u0900-\u097FA-Za-z0-9*?]+/g)||[];
      if(ws.some(w=>XL_BN_RANGE.test(w)||XL_HI_RANGE.test(w))||mode==='banglish'){const u=run(ws,false);out.push(u.length>1?'('+u.join(' ')+')':(u[0]||''))}else out.push(t);
      continue;
    }
    let c=t,neg=false;if(/^[-!]/.test(c)&&c.length>1){neg=true;c=c.slice(1)}
    c=c.replace(/[,.;:।॥]+$/,'');if(!c)continue;
    if(neg){flush();run([c],true).forEach(u=>unit(u,true))}else runW.push(c);
  }
  flush();
  const searchQ=out.join(' ').replace(/\s+/g,' ').trim();
  return {q:searchQ,pairs,unresolved,translit,plain:plain.filter(Boolean).join(' ')};
}
function prepareSearchQuery(raw){
  const q=String(raw||'').trim();
  if(!q)return {searchQ:q,lang:'en',transliterated:false,note:''};
  const mode=(typeof state!=='undefined'&&state&&state.xl)||'auto';
  if(mode==='off')return prepareSearchQueryLegacy(q);
  const ck=mode+'|'+(xlHasBnData()?1:0)+'|'+q;
  const hit=XL_CACHE.get(ck);if(hit)return hit;
  const lang=detectLang(q);
  const hasBn=lang==='bn'||lang==='mixed';
  const hasHi=lang==='hi'||lang==='mixed-hi';
  const nonEn=lang!=='en';
  let info;
  if(!nonEn&&mode!=='banglish'&&!xlBanglishHint(q)){
    info={searchQ:q,lang,transliterated:false,note:''};
    if(xlHasBnData()){ // English query, collection holds Bengali text: add Bengali equivalents
      const r=xlEnToBn(q);if(r&&r!==q){XL_OUT.add(r);info={searchQ:r,lang,transliterated:false,translated:true,original:q,note:'',xl:{pairs:[],unresolved:[],direction:'en→bn'}}}
    }
  }else{
    const convMode=hasHi?'hi':(hasBn?'bn':'banglish');
    const r=xlConvert(q,convMode);
    if(r.q)XL_OUT.add(r.q);
    const dir=hasHi?'hi→en':(hasBn||lang==='mixed'?'bn→en':'bn→en');
    info={searchQ:r.q||q,lang:hasHi?lang:(hasBn?lang:'bn-latn'),transliterated:r.translit,translated:true,original:q,plain:r.plain,xl:Object.assign({direction:dir},r),
      note:'Cross-language: '+(r.pairs.length?r.pairs.map(p=>p.src+' → '+(p.out||'?')).join('; '):'')};
  }
  if(XL_CACHE.size>200)XL_CACHE.clear();
  XL_CACHE.set(ck,info);return info;
}
function xlEnToBn(q){
  const G=xlInit(),toks=q.match(/"[^"]*"|\(|\)|[^\s()"]+/g)||[],out=[];
  const words=[];toks.forEach((t,ix)=>{if(/^[A-Za-z][A-Za-z0-9-]*$/.test(t))words.push({t,ix})});
  const used=new Set();let changed=false;
  const rep=new Map();
  for(let a=0;a<words.length;a++){
    if(used.has(a))continue;
    for(let n=Math.min(3,words.length-a);n>=1;n--){
      const seg=words.slice(a,a+n);if(seg.some((s,j)=>j&&s.ix!==seg[j-1].ix+1))continue;
      const key=seg.map(s=>s.t.toLowerCase()).join(' '),h=G.ENMAP.get(key);
      if(h){const bn=[];[...h].forEach(i=>G.G[i].bn.slice(0,3).forEach(v=>{if(!bn.includes(v))bn.push(v)}));
        if(bn.length){rep.set(seg[0].ix,{n,txt:'('+[seg.map(s=>s.t).join(' ')].map(xlQuote).concat(bn.map(xlQuote)).join(' OR ')+')'});for(let j=0;j<n;j++)used.add(a+j);changed=true;break}}
    }
  }
  if(!changed)return q;
  let ix=0;const skip=new Set();
  rep.forEach((v,k)=>{for(let j=1;j<v.n;j++)skip.add(k+j)});
  toks.forEach((t,i)=>{if(skip.has(i))return;out.push(rep.has(i)?rep.get(i).txt:t)});
  return out.join(' ');
}
function xlPlain(q){
  try{
    const s=String(q||'').trim();if(!s)return s;
    const mode=(typeof state!=='undefined'&&state&&state.xl)||'auto';
    if(mode==='off')return s;
    const lang=detectLang(s);
    if(lang==='en'&&mode!=='banglish'&&!xlBanglishHint(s))return s;
    const r=xlConvert(s,lang==='en'?'banglish':'bn');return r.plain||s;
  }catch(e){return q}
}
async function xlMtFetch(word,pair){
  const r=await fetch('https://api.mymemory.translated.net/get?q='+encodeURIComponent(word)+'&langpair='+pair);
  const j=await r.json();let t=String((j&&j.responseData&&j.responseData.translatedText)||'').trim();
  if(!t||/mymemory|warning|invalid/i.test(t)||t.length>((pair==='bn|en'||pair==='hi|en')?50:600))return '';
  if(pair==='bn|en'||pair==='hi|en'){t=t.toLowerCase().replace(/[^a-z0-9 -]/g,' ').replace(/\s+/g,' ').trim();if(!t||XL_BN_RANGE.test(t)||XL_HI_RANGE.test(t))return ''}
  return t;
}
function xlResolveUnknown(info){
  try{
    if(typeof state!=='undefined'&&state.mt===false)return;
    if(!info||!info.xl||!info.xl.unresolved||!info.xl.unresolved.length||(typeof navigator!=='undefined'&&navigator.onLine===false))return;
    const pair=(info.xl.direction==='hi→en')?'hi|en':'bn|en';
    const todo=info.xl.unresolved.filter(w=>!XL_MT.has(w)).slice(0,4);if(!todo.length)return;
    Promise.all(todo.map(async w=>{try{XL_MT.set(w,await xlMtFetch(w,pair))}catch(e){XL_MT.set(w,'')}})).then(()=>{
      try{const o={};XL_MT.forEach((v,k)=>{if(v)o[k]=v});localStorage.setItem('lisMtCache',JSON.stringify(o))}catch(e){}
      XL_CACHE.clear();QCACHE.clear();QLAST=null;
      if(typeof state!=='undefined'&&(state.query||'').trim()===info.original&&todo.some(w=>XL_MT.get(w)))doSearch(false);
    });
  }catch(e){}
}
function xlNoticeHtml(info){
  if(!info||!info.xl||!info.xl.pairs)return '';
  const x=info.xl;let h='';
  if(x.direction==='hi→en'){
    const lbl=info.lang==='mixed-hi'?'Mixed Hindi + English':'Hindi';
    h+='<div><b>Cross-language:</b> '+esc(lbl)+' → English. '+x.pairs.map(p=>'<span class="chip" title="'+esc(p.kind)+'">'+esc(p.src)+' → '+esc(p.out||'?')+'</span>').join(' ')+'</div>';
    h+='<div><b>Searching as:</b> <code>'+esc(info.searchQ)+'</code> <button class="ghost" type="button" data-xl="off">Search as typed (cross-language off)</button></div>';
    if(x.unresolved&&x.unresolved.length)h+='<div><b>No English equivalent found for:</b> '+x.unresolved.map(esc).join(', ')+'. Showing a transliteration only'+(XL_MT.size?' (online translation was tried)':' — online translation will be tried if you are connected')+'.</div>';
  }else if(x.direction==='bn→en'){
    const lbl=info.lang==='bn-latn'?'Banglish (romanised Bengali)':(info.lang==='mixed'?'Mixed Bengali + English':'Bengali');
    h+='<div><b>Cross-language:</b> '+esc(lbl)+' → English. '+x.pairs.map(p=>'<span class="chip" title="'+esc(p.kind)+'">'+esc(p.src)+' → '+esc(p.out||'?')+'</span>').join(' ')+'</div>';
    h+='<div><b>Searching as:</b> <code>'+esc(info.searchQ)+'</code> <button class="ghost" type="button" data-xl="off">Search as typed (cross-language off)</button></div>';
    if(x.unresolved.length)h+='<div><b>No English equivalent found for:</b> '+x.unresolved.map(esc).join(', ')+'. Showing a transliteration only'+(XL_MT.size?' (online translation was tried)':' — online translation will be tried if you are connected')+'.</div>';
  }else if(x.direction==='en→bn'){
    h+='<div><b>Cross-language:</b> this collection contains Bengali text, so Bengali equivalents were added: <code>'+esc(info.searchQ)+'</code></div>';
  }
  return h;
}
function xlRecordModal(i){
  const G=xlInit(),r=R[i];if(!r)return;
  const text=' '+norm([r[2],r[11],r[12]].join(' ')).replace(/[^a-z0-9]+/g,' ')+' ';
  const found=[];
  G.G.forEach(e=>{const v=e.en.find(v=>text.includes(' '+v.toLowerCase().replace(/[^a-z0-9]+/g,' ')+' '));if(v&&e.bn.length)found.push({en:v,bn:e.bn.slice(0,3)})});
  found.sort((a,b)=>b.en.length-a.en.length);
  const rows=found.slice(0,24).map(f=>'<tr><td>'+esc(f.en)+'</td><td lang="bn">'+f.bn.map(esc).join(' · ')+'</td></tr>').join('');
  showModal('<h3>বাংলা / Bengali key terms</h3><p class="tiny">'+esc(r[2])+'</p>'+(rows?'<table><tr><th>English term</th><th>বাংলা</th></tr>'+rows+'</table>':'<p>No glossary terms were found in this record.</p>')+
   '<p class="tiny">Offline glossary lookup. <button class="ghost" type="button" id="xlMtBtn">Translate title and abstract (online)</button></p><div id="xlMtOut" lang="bn"></div>');
  const b=document.getElementById('xlMtBtn');
  if(b)b.onclick=async()=>{
    const out=document.getElementById('xlMtOut');out.textContent='Translating…';
    try{
      const parts=[r[2],String(r[12]||'').slice(0,450)].filter(Boolean),res=[];
      for(const p of parts)res.push(await xlMtFetch(p,'en|bn'));
      out.innerHTML=res.filter(Boolean).map(t=>'<p>'+esc(t)+'</p>').join('')||'<p>No translation returned.</p>';
    }catch(e){out.textContent='Online translation is unavailable (no connection or the service refused the request).'}
  };
}
function xlInitUi(){
  try{state.xl=localStorage.getItem('lisXl')||'auto';state.mt=localStorage.getItem('lisMt')!=='0'}catch(e){state.xl='auto';state.mt=true}
  const sel=document.getElementById('xlMode'),mt=document.getElementById('xlMt');
  const rerun=()=>{XL_CACHE.clear();QCACHE.clear();QLAST=null;if(R&&(state.query||'').trim()){state.page=1;doSearch(false)}};
  if(sel){sel.value=state.xl;sel.addEventListener('change',()=>{state.xl=sel.value;try{localStorage.setItem('lisXl',sel.value)}catch(e){}rerun()})}
  if(mt){mt.checked=state.mt!==false;mt.addEventListener('change',()=>{state.mt=mt.checked;try{localStorage.setItem('lisMt',mt.checked?'1':'0')}catch(e){}})}
  document.addEventListener('click',e=>{const b=e.target.closest&&e.target.closest('[data-xl="off"]');if(!b)return;state.xl='off';if(sel)sel.value='off';try{localStorage.setItem('lisXl','off')}catch(x){}rerun()});
}
setTimeout(xlInitUi,0);
function xlBnRx(p){
  xlInit();
  const suf=XL_SUFFIXES_N.map(s=>srchEsc(norm(s.n))).join('|'),B='a-z0-9\u0980-\u09ff';
  return new RegExp('(^|[^'+B+'])'+srchEsc(p)+'(?:'+suf+')?(?=$|[^'+B+'])');
}
function xlBnWordTest(lw,t){
  if(lw===t)return true;if(!lw.startsWith(t))return false;
  const rest=lw.slice(t.length);xlInit();return XL_SUFFIXES_N.some(s=>norm(s.n)===rest);
}
function xlNeedsXlate(q){
  if(!q||!XL_BN_RANGE.test(q)||XL_OUT.has(q))return false;
  return ((typeof state!=='undefined'&&state&&state.xl)||'auto')!=='off';
}
/*XL-END*/

/** Title/DOI/author normalisation for duplicate detection */
function tnormDup(s){return norm(s).replace(/[^a-z0-9]+/g,' ').trim()}
function doiNorm(d){return String(d||'').toLowerCase().replace(/^https?:\/\/(dx\.)?doi\.org\//,'').trim()}
function authorTokens(a){return norm(a||'').split(/[;,&]+/).map(x=>x.trim()).filter(x=>x.length>1)}
function titleTokens(t){return tnormDup(t).split(/\s+/).filter(x=>x.length>2)}
function jaccard(a,b){
  const A=new Set(a),B=new Set(b);if(!A.size||!B.size)return 0;
  let inter=0;for(const x of A)if(B.has(x))inter++;
  return inter/(A.size+B.size-inter);
}
/**
 * Find exact and near-duplicate clusters among indices (or all records if empty).
 * Exact: same DOI, or same normalised title+year.
 * Near: title Jaccard ≥ 0.82, year within 1, and some author overlap (or no authors).
 */
function findNearDuplicates(indices,opts){
  opts=opts||{};
  const minJac=opts.minJac??0.82;
  const yearWin=opts.yearWin??1;
  const ids=(indices&&indices.length)?indices:[...Array(R.length).keys()];
  const byDoi=new Map(), byTitleYear=new Map();
  const clusters=[];
  const used=new Set();
  // Exact DOI groups
  for(const i of ids){
    const d=doiNorm(R[i][9]);if(!d)continue;
    if(!byDoi.has(d))byDoi.set(d,[]);
    byDoi.get(d).push(i);
  }
  for(const [d,arr] of byDoi){
    if(arr.length<2)continue;
    arr.forEach(i=>used.add(i));
    clusters.push({kind:'exact-doi',key:d,ids:arr});
  }
  // Exact title+year
  for(const i of ids){
    if(used.has(i))continue;
    const t=tnormDup(R[i][2]),y=R[i][3];if(!t)continue;
    const k=t+'|'+y;
    if(!byTitleYear.has(k))byTitleYear.set(k,[]);
    byTitleYear.get(k).push(i);
  }
  for(const [k,arr] of byTitleYear){
    if(arr.length<2)continue;
    arr.forEach(i=>used.add(i));
    clusters.push({kind:'exact-title-year',key:k,ids:arr});
  }
  // Near-duplicates (pairwise on remaining, limited for performance)
  const rest=ids.filter(i=>!used.has(i));
  const nearPairs=[];
  const N=rest.length, CAP=Math.min(N,2500); // safety for full-set scans
  for(let a=0;a<CAP;a++){
    const i=rest[a], ti=titleTokens(R[i][2]), yi=R[i][3], ai=new Set(authorTokens(R[i][1]));
    if(ti.length<3)continue;
    for(let b=a+1;b<CAP;b++){
      const j=rest[b], yj=R[j][3];
      if(Math.abs((yi||0)-(yj||0))>yearWin)continue;
      const tj=titleTokens(R[j][2]);
      const jac=jaccard(ti,tj);
      if(jac<minJac)continue;
      const aj=authorTokens(R[j][1]);
      let aOverlap=0;for(const x of aj)if(ai.has(x))aOverlap++;
      if(ai.size&&aj.length&&aOverlap===0)continue;
      nearPairs.push({i,j,jac,aOverlap});
    }
  }
  // Union-find style grouping of near pairs
  const parent=new Map();
  const find=x=>{if(!parent.has(x))parent.set(x,x);let p=parent.get(x);if(p!==x){p=find(p);parent.set(x,p)}return p};
  const uni=(x,y)=>{const a=find(x),b=find(y);if(a!==b)parent.set(a,b)};
  nearPairs.forEach(p=>uni(p.i,p.j));
  const groups=new Map();
  for(const p of nearPairs){
    const root=find(p.i);
    if(!groups.has(root))groups.set(root,new Set());
    groups.get(root).add(p.i);groups.get(root).add(p.j);
  }
  for(const set of groups.values()){
    if(set.size<2)continue;
    const arr=[...set];
    arr.forEach(i=>used.add(i));
    clusters.push({kind:'near-title',key:'',ids:arr});
  }
  clusters.sort((a,b)=>b.ids.length-a.ids.length);
  return clusters;
}
function source(r){return S[r[4]]||''} function publisher(r){return PUB[r[5]]||''} function place(r){return PLC[r[6]]||''} function country(r){return CO[r[7]]||''}
function recObj(i){if(typeof i==='string'&&i.indexOf('online|')===0)return onlineRecObj(i);const r=R[i];return{index:i,cites:r[0],authors:r[1],title:r[2],year:r[3],source:source(r),publisher:publisher(r),place:place(r),country:country(r),url:r[8],doi:r[9],issn:r[10],keywords:r[11],abstract:r[12]}}
function savedSet(){try{return new Set(JSON.parse(localStorage.getItem('libSaved')||'[]'))}catch{return new Set()}}
function setSaved(s){localStorage.setItem('libSaved',JSON.stringify([...s]));updateSavedCount()}
function updateSavedCount(){ $('#savedCount').textContent=savedSet().size }
function toast(msg){let t=$('#toast');t.textContent=msg;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),1800)}
async function unpack(){
  if(!EMBEDDED_DATA){
    const r=await fetch('/api/dataset');
    if(!r.ok) throw new Error('Dataset request failed (HTTP '+r.status+')');
    return r.json();
  }
  if(!EMBEDDED_DATA.startsWith('GZB64:')) return JSON.parse(EMBEDDED_DATA);
  if(typeof DecompressionStream==='undefined') throw new Error('This browser cannot decompress the embedded dataset. Use a current Chrome, Edge, Firefox or Safari.');
  const bin=Uint8Array.from(atob(EMBEDDED_DATA.slice(6)),c=>c.charCodeAt(0));
  const text=await new Response(new Blob([bin]).stream().pipeThrough(new DecompressionStream('gzip'))).text();
  return JSON.parse(text);
}
function buildIndex(){INDEX=R.map(r=>({t:norm(r[2]),a:norm(r[1]),k:norm(r[11]),s:norm(S[r[4]]||''),b:norm(r[12]),d:norm(r[9]),p:norm(PUB[r[5]]||''),c:norm(CO[r[7]]||'')}));buildEmbeddings();buildAuthorRegistry();buildCountryGroups()}
/* ===== TF-IDF random-projection embedding ranking (offline; not a trained neural model) =====
   Dense vectors via TF-IDF + deterministic random projection. Intent detection
   in Semantic AI remains rule-based; this supplies embedding ranking for search. */
let EMB={ready:false,dim:96,vecs:null,idf:null,vocab:null,proj:null};
function embHash(s){let h=2166136261>>>0;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619)}return h>>>0}
function embTokens(s){const stop=(typeof SRCH_STOP!=='undefined'&&SRCH_STOP)||new Set('a an the and or of in on for to with by from at as is are was were be been being this that these those it its into than then not no'.split(' '));return (norm(s).match(/[a-z0-9][a-z0-9.+#-]{1,}/g)||[]).filter(t=>t.length>2&&!stop.has(t))}
function buildEmbeddings(){
  try{
    const N=R.length,dim=EMB.dim,df=new Map(),docs=[];
    for(let i=0;i<N;i++){
      const r=R[i],bag=new Map();
      // title ×3, keywords ×2, abstract ×1 (capped)
      embTokens(r[2]).forEach(t=>bag.set(t,(bag.get(t)||0)+3));
      embTokens(r[11]).forEach(t=>bag.set(t,(bag.get(t)||0)+2));
      embTokens(String(r[12]||'').slice(0,800)).forEach(t=>bag.set(t,(bag.get(t)||0)+1));
      docs.push(bag);
      bag.forEach((_,t)=>df.set(t,(df.get(t)||0)+1));
    }
    // Keep informative mid-frequency terms
    const vocab=[...df.entries()].filter(([,c])=>c>=3&&c<N*0.45).sort((a,b)=>b[1]-a[1]).slice(0,8000).map(([t])=>t);
    const vset=new Set(vocab),idf=new Map();
    vocab.forEach(t=>idf.set(t,Math.log(1+N/(1+(df.get(t)||0)))));
    // Deterministic random projection matrix (vocab → dim)
    const proj=new Float32Array(vocab.length*dim);
    for(let vi=0;vi<vocab.length;vi++){
      const seed=embHash(vocab[vi]+'|proj');
      for(let d=0;d<dim;d++){
        const x=embHash(String(seed)+':'+d);
        proj[vi*dim+d]=((x%1000)/1000-0.5)*2; // [-1,1]
      }
    }
    const vecs=new Array(N);
    for(let i=0;i<N;i++){
      const v=new Float32Array(dim),bag=docs[i];
      let n=0;
      vocab.forEach((t,vi)=>{
        const c=bag.get(t);if(!c)return;
        const w=(1+Math.log(c))*idf.get(t);
        const base=vi*dim;
        for(let d=0;d<dim;d++)v[d]+=w*proj[base+d];
        n++;
      });
      // L2 normalise
      let s=0;for(let d=0;d<dim;d++)s+=v[d]*v[d];s=Math.sqrt(s)||1;
      for(let d=0;d<dim;d++)v[d]/=s;
      vecs[i]=v;
    }
    EMB={ready:true,dim,vecs,idf,vocab,vset,proj,N};
  }catch(e){console.warn('Embedding index failed',e);EMB.ready=false}
}
function embedQuery(q){
  if(!EMB.ready)return null;
  const bag=new Map();embTokens(q).forEach(t=>bag.set(t,(bag.get(t)||0)+1));
  const v=new Float32Array(EMB.dim);
  EMB.vocab.forEach((t,vi)=>{
    const c=bag.get(t);if(!c)return;
    const w=(1+Math.log(c))*(EMB.idf.get(t)||0);
    const base=vi*EMB.dim;
    for(let d=0;d<EMB.dim;d++)v[d]+=w*EMB.proj[base+d];
  });
  let s=0;for(let d=0;d<EMB.dim;d++)s+=v[d]*v[d];s=Math.sqrt(s)||1;
  for(let d=0;d<EMB.dim;d++)v[d]/=s;
  return v;
}
function cosineEmb(a,b){if(!a||!b)return 0;let s=0;for(let i=0;i<a.length;i++)s+=a[i]*b[i];return s}
function neuralScores(q,candidates){
  const qv=embedQuery(q);if(!qv||!EMB.ready)return new Map();
  const m=new Map();
  const list=candidates||[...Array(R.length).keys()];
  for(const i of list){const c=cosineEmb(qv,EMB.vecs[i]);if(c>0.02)m.set(i,c)}
  return m;
}
/* ===== Country normalisation (aliases only; UK ≠ England kept separate) ===== */
const COUNTRY_ALIAS={
  'usa':'United States','united states':'United States','united states of america':'United States',
  'united state of america':'United States','united state of america':'United States',
  'america':'United States','u.s.':'United States','u.s.a.':'United States','us':'United States',
  'united kingdom':'United Kingdom','uk':'United Kingdom','u.k.':'United Kingdom','great britain':'United Kingdom','britain':'United Kingdom',
  'england':'England', // deliberately distinct from United Kingdom
  'south korea':'South Korea','korea, republic of':'South Korea','republic of korea':'South Korea',
  'iran':'Iran','islamic republic of iran':'Iran'
};
function countryCanon(name){
  const k=norm(name||'').replace(/\./g,'').trim();
  if(!k)return '';
  return COUNTRY_ALIAS[k]||String(name||'').trim();
}
let COUNTRY_GROUPS=null; // Map canonical → [original indices in CO]
function buildCountryGroups(){
  COUNTRY_GROUPS=new Map();
  (CO||[]).forEach((name,idx)=>{
    const c=countryCanon(name)||name;
    if(!COUNTRY_GROUPS.has(c))COUNTRY_GROUPS.set(c,[]);
    COUNTRY_GROUPS.get(c).push(idx);
  });
}
function countryIndicesForFilter(value){
  // value may be a CO index (legacy) or a canonical name prefixed with c:
  if(value===''||value==null)return null;
  if(String(value).startsWith('c:')){
    const canon=String(value).slice(2);
    return new Set(COUNTRY_GROUPS.get(canon)||[]);
  }
  const idx=Number(value);
  if(!Number.isNaN(idx)&&CO[idx]!=null){
    const canon=countryCanon(CO[idx])||CO[idx];
    return new Set(COUNTRY_GROUPS.get(canon)||[idx]);
  }
  return new Set([Number(value)]);
}
/* ===== Author registry + authority file links (VIAF, LCNAF, LCSH, ORCID) ===== */
let AUTH_REG=null; // Map normName → {label, ids:Set, papers:n, cites:n, orcid?}
function authorKey(name){return norm(name).replace(/[^a-z0-9]+/g,' ').trim()}
function authorLocalId(name){
  const k=authorKey(name);let h=embHash(k||'unknown');
  return 'local:'+(h>>>0).toString(16);
}
function buildAuthorRegistry(){
  AUTH_REG=new Map();
  for(let i=0;i<R.length;i++){
    const r=R[i];
    String(r[1]||'').split(';').map(x=>x.trim()).filter(Boolean).forEach(name=>{
      const k=authorKey(name);if(!k)return;
      let e=AUTH_REG.get(k);
      if(!e){e={label:name,key:k,localId:authorLocalId(name),papers:0,cites:0,orcid:null};AUTH_REG.set(k,e)}
      e.papers++;e.cites+=Number(r[0])||0;
      if(name.length>e.label.length)e.label=name; // prefer longer display form
    });
  }
}
function authLinksForAuthor(name){
  const q=encodeURIComponent(String(name||'').trim());
  const k=authorKey(name),e=AUTH_REG&&AUTH_REG.get(k);
  const local=e?e.localId:authorLocalId(name);
  return {
    localId:local,
    orcid:e&&e.orcid?('https://orcid.org/'+e.orcid):('https://orcid.org/orcid-search/search?searchQuery='+q),
    viaf:'https://viaf.org/viaf/search?query=local.personalNames+all+%22'+q+'%22&sortKeys=holdingscount',
    lcnaf:'https://id.loc.gov/search/?q='+q+'&q=cs%3Ahttp%3A%2F%2Fid.loc.gov%2Fauthorities%2Fnames',
    wikidata:'https://www.wikidata.org/w/index.php?search='+q+'&title=Special%3ASearch',
    openalex:'https://openalex.org/authors?q='+q,
    scholar:'https://scholar.google.com/scholar?q='+encodeURIComponent('author:"'+name+'"')
  };
}
function authLinksForSubject(label){
  const q=encodeURIComponent(String(label||'').trim());
  return {
    lcsh:'https://id.loc.gov/search/?q='+q+'&q=cs%3Ahttp%3A%2F%2Fid.loc.gov%2Fauthorities%2Fsubjects',
    viaf:'https://viaf.org/viaf/search?query=local.subjects+all+%22'+q+'%22',
    wikidata:'https://www.wikidata.org/w/index.php?search='+q
  };
}
function authorityModal(){
  showModal(`<h2>Authority files &amp; identifiers</h2>
<p class="tiny">Links to <b>VIAF</b>, <b>LCNAF</b> (Library of Congress Name Authority File), <b>LCSH</b> (Subject Headings), and <b>ORCID</b>. Persistent local author IDs are derived from normalised names. Country filter uses canonical labels; <b>United Kingdom</b> and <b>England</b> stay separate. Online lookups need internet; the local corpus works offline.</p>
<div class="row" style="gap:8px;flex-wrap:wrap;margin:10px 0">
  <label>Lookup type
    <select id="authType"><option value="person">Person (VIAF / LCNAF / ORCID)</option><option value="subject">Subject (LCSH)</option><option value="country">Country normalisation</option></select>
  </label>
  <input type="text" id="authQ" placeholder="Name or subject…" style="flex:1;min-width:160px">
  <button class="primary" type="button" id="authGo">Look up</button>
</div>
<div id="authOut"></div>
<div class="card" style="margin-top:12px"><b>Country groups in this dataset</b>
<p class="tiny">Aliases of the same country are grouped for filtering. United Kingdom and England are not merged.</p>
<ul class="tiny" id="authCountries"></ul></div>`);
  const ul=$('#authCountries');
  if(ul&&COUNTRY_GROUPS){
    ul.innerHTML=[...COUNTRY_GROUPS.entries()].sort((a,b)=>a[0].localeCompare(b[0])).map(([c,idxs])=>{
      const labels=idxs.map(i=>CO[i]);
      const extra=labels.filter(l=>l!==c);
      return `<li><b>${esc(c)}</b> ← indices ${idxs.join(', ')}${extra.length?' (raw: '+extra.map(esc).join(', ')+')':''}</li>`;
    }).join('');
  }
  const run=()=>{
    const type=$('#authType').value,q=($('#authQ').value||'').trim(),out=$('#authOut');
    if(!out)return;
    if(type==='country'){
      out.innerHTML=`<p>Canonical form of <code>${esc(q||'—')}</code>: <b>${esc(countryCanon(q)||'(empty)')}</b></p>
<p class="tiny">Filter value would match dataset indices: ${[...(countryIndicesForFilter('c:'+(countryCanon(q)||q))||[])].join(', ')||'—'}</p>`;
      return;
    }
    if(!q){out.innerHTML='<p class="tiny">Enter a name or subject.</p>';return}
    if(type==='person'){
      const L=authLinksForAuthor(q),e=AUTH_REG&&AUTH_REG.get(authorKey(q));
      out.innerHTML=`<div class="card"><b>${esc(e?e.label:q)}</b>
<div class="tiny">Local persistent ID: <code>${esc(L.localId)}</code>${e?` · ${e.papers} paper(s) in corpus · ${e.cites} cites`:''}</div>
<p class="actions" style="flex-wrap:wrap">
  <a class="ghost" target="_blank" rel="noopener" href="${esc(L.viaf)}">VIAF ↗</a>
  <a class="ghost" target="_blank" rel="noopener" href="${esc(L.lcnaf)}">LCNAF (id.loc.gov) ↗</a>
  <a class="ghost" target="_blank" rel="noopener" href="${esc(L.orcid)}">ORCID ↗</a>
  <a class="ghost" target="_blank" rel="noopener" href="${esc(L.wikidata)}">Wikidata ↗</a>
  <a class="ghost" target="_blank" rel="noopener" href="${esc(L.openalex)}">OpenAlex ↗</a>
  <a class="ghost" target="_blank" rel="noopener" href="${esc(L.scholar)}">Google Scholar ↗</a>
</p>
<p class="tiny">VIAF / LCNAF open the live authority files. Results are not cached in this offline app.</p></div>`;
    }else{
      const L=authLinksForSubject(q);
      out.innerHTML=`<div class="card"><b>Subject: ${esc(q)}</b>
<p class="actions" style="flex-wrap:wrap">
  <a class="ghost" target="_blank" rel="noopener" href="${esc(L.lcsh)}">LCSH (id.loc.gov) ↗</a>
  <a class="ghost" target="_blank" rel="noopener" href="${esc(L.viaf)}">VIAF subjects ↗</a>
  <a class="ghost" target="_blank" rel="noopener" href="${esc(L.wikidata)}">Wikidata ↗</a>
</p></div>`;
    }
  };
  $('#authGo').onclick=run;
  $('#authQ').onkeydown=e=>{if(e.key==='Enter')run()};
}
function populateFacets(){
  const yc=$('#yearChecks'); M.yearCounts.sort((a,b)=>b[0]-a[0]).forEach(([y,c])=>yc.insertAdjacentHTML('beforeend',`<label class="check"><input type="checkbox" data-year="${y}"><span>${y}</span><span>${c.toLocaleString()}</span></label>`));
  const sf=$('#sourceFilter'); M.sourceCounts.forEach(([idx,c])=>{let o=document.createElement('option');o.value=idx;o.textContent=`${S[idx]} (${c.toLocaleString()})`;sf.appendChild(o)});
  const pf=$('#publisherFilter'); M.publisherCounts.forEach(([idx,c])=>{let o=document.createElement('option');o.value=idx;o.textContent=`${PUB[idx]} (${c.toLocaleString()})`;pf.appendChild(o)});
  // Country filter: one option per canonical country; value is c:Name so aliases match together
  const cf=$('#countryFilter');
  if(COUNTRY_GROUPS){
    const counts=new Map();
    (M.countryCounts||[]).forEach(([idx,c])=>{
      const canon=countryCanon(CO[idx])||CO[idx];
      counts.set(canon,(counts.get(canon)||0)+c);
    });
    [...counts.entries()].sort((a,b)=>b[1]-a[1]||a[0].localeCompare(b[0])).forEach(([name,c])=>{
      let o=document.createElement('option');o.value='c:'+name;o.textContent=`${name} (${c.toLocaleString()})`;cf.appendChild(o);
    });
  }else{
    M.countryCounts.forEach(([idx,c])=>{let o=document.createElement('option');o.value=idx;o.textContent=`${CO[idx]} (${c.toLocaleString()})`;cf.appendChild(o)});
  }
  const sub=$('#subjectFilter'); M.topKeywords.forEach(([k,c])=>{let o=document.createElement('option');o.value=k;o.textContent=`${k} (${c.toLocaleString()})`;sub.appendChild(o)});
  $('#yearFrom').min=M.minYear;$('#yearFrom').max=M.maxYear;$('#yearTo').min=M.minYear;$('#yearTo').max=M.maxYear;
}
function exactPhrases(q){return [...q.matchAll(/"([^"]+)"/g)].map(m=>norm(m[1])).filter(Boolean)}
const QWR=new Map();
function qFieldRx(v,op){const k=op+'|'+v;let r=QWR.get(k);if(!r){const body=srchEsc(v.replace(/\*+/g,'*')).replace(/\\\*/g,'.*').replace(/\\\?/g,'.');r=new RegExp((op==='exact'||op==='starts'?'^':'')+body+(op==='exact'||op==='ends'?'$':''));QWR.set(k,r)}return r}
function matchText(field,op,val){let x=norm(field),v=norm(val).trim();if(!v)return true;
 if(/[*?]/.test(v)&&(op==='exact'||op==='starts'||op==='ends'||op==='substr'))return qFieldRx(v,op).test(x);
 if(op==='exact')return x===v;if(op==='starts')return x.startsWith(v);if(op==='ends')return x.endsWith(v);if(op==='substr')return x.includes(v);if(op==='not')return !wordsContain(field,val);return wordsContain(field,val)}
function advancedMatch(i){if(!state.advanced.length)return true;let result=null;const r=R[i], ix=INDEX[i];for(let row of state.advanced){let field='';switch(row.field){case'title':field=r[2];break;case'authors':field=r[1];break;case'keywords':field=r[11];break;case'source':field=S[r[4]];break;case'publisher':field=PUB[r[5]];break;case'country':field=CO[r[7]];break;case'abstract':field=r[12];break;case'doi':field=r[9];break;case'year':field=String(r[3]);break;}let m=matchText(field,row.op,row.value);if(result===null)result=m;else result=row.bool==='OR'?(result||m):(result&&m)}return result===null?true:result}
/* ===== Accurate search matching: whole words, every term required, stop words ignored ===== */
/*QE-BEGIN*/
const SRCH_STOP=new Set('a an the and or of in on for to with by from at as is are was were be been being this that these those it its into than then not no do does did how what which who whom when where why can could about over under via vs versus within without per'.split(' '));
const SRCH_RX=new Map(),SRCH_PRX=new Map();
function srchEsc(t){return String(t).replace(/[.*+?^${}()|[\]\\]/g,'\\$&')}
function srchTermRx(t){let r=SRCH_RX.get(t);if(!r){r=new RegExp('(^|[^a-z0-9\u0980-\u09ff])'+srchEsc(t)+'(s|es|ed|ing)?(?=$|[^a-z0-9\u0980-\u09ff])');SRCH_RX.set(t,r)}return r}
function srchPhraseRx(p){let r=SRCH_PRX.get(p);if(!r){r=new RegExp('(^|[^a-z0-9\u0980-\u09ff])'+srchEsc(p).replace(/\s+/g,'[^a-z0-9\u0980-\u09ff]+')+'(?=$|[^a-z0-9\u0980-\u09ff])');SRCH_PRX.set(p,r)}return r}
function srchTerms(q){
  const plain=norm(q).replace(/"[^"]*"/g,' ').replace(/^https?:\/\/(dx\.)?doi\.org\//,'');
  const all=plain.match(/[a-z0-9]+/g)||[];
  const kept=all.filter(w=>w.length>=2&&!SRCH_STOP.has(w));
  return [...new Set(kept.length?kept:all)];
}
function wordsContain(field,val){const v=norm(val).trim();if(!v)return true;return (typeof qPhraseRx==='function'?qPhraseRx(v):srchPhraseRx(v)).test(norm(field))}
function relevanceClassic(i,q){
  const r=R[i],x=INDEX[i];
  const terms=srchTerms(q),phr=exactPhrases(q);
  if(!terms.length&&!phr.length)return Math.log1p(r[0])*.2;
  let sc=0;const why=[];const add=(label,n)=>{if(n>0){sc+=n;why.push([label,n])}};
  const nq=norm(q).replace(/^https?:\/\/(dx\.)?doi\.org\//,'').trim();
  if(nq&&x.d&&x.d===nq){add('exact DOI',140);sc+=Math.min(5,Math.log1p(r[0])*.7);return {score:sc,why}}
  for(const ph of phr){
    const hits=[['exact title phrase',x.t,55],['keyword phrase',x.k,34],['author phrase',x.a,28],['journal/source phrase',x.s,20],['abstract phrase',x.b,10]]
      .filter(([l,f])=>f&&srchPhraseRx(ph).test(f));
    if(!hits.length)return {score:0,why:[]};
    hits.forEach(([l,f,w])=>add(l,w));
  }
  for(const t of terms){
    const rx=srchTermRx(t);
    const hits=[['title',x.t,12],['keywords',x.k,8],['authors',x.a,6],['journal/source',x.s,5],['abstract',x.b,2],['DOI',x.d,18]]
      .filter(([l,f])=>f&&rx.test(f));
    if(!hits.length)return {score:0,why:[]};
    hits.forEach(([l,f,w])=>add(l,w));
  }
  if(terms.length&&x.t&&terms.every(t=>srchTermRx(t).test(x.t)))add('all terms in title',20);
  if(sc>0)sc+=Math.min(5,Math.log1p(r[0])*.7);
  return {score:sc,why};
}
/* ===== Boolean (OR / NOT / brackets), wildcards & truncation, automatic query expansion =====
   Plain queries (no OR/NOT/-/wildcards, no expansion hit) still use the original ranking code
   (relevanceClassic), so existing behaviour is unchanged. */
const QCACHE=new Map();let QLAST=null;
function qHasWild(s){return /[*?]/.test(s)}
function qWild(s){return srchEsc(String(s).replace(/\*+/g,'*')).replace(/\\\*/g,'[a-z0-9]*').replace(/\\\?/g,'[a-z0-9]')}
function qTermRx(t,wild){if(!wild)return srchTermRx(t);const k='w:'+t;let r=SRCH_RX.get(k);if(!r){r=new RegExp('(^|[^a-z0-9\u0980-\u09ff])'+qWild(t)+'(?=$|[^a-z0-9\u0980-\u09ff])');SRCH_RX.set(k,r)}return r}
function qPhraseRx(p){if(!qHasWild(p))return srchPhraseRx(p);const k='q:'+p;let r=SRCH_PRX.get(k);if(!r){r=new RegExp('(^|[^a-z0-9\u0980-\u09ff])'+qWild(p).replace(/\s+/g,'[^a-z0-9\u0980-\u09ff]+')+'(?=$|[^a-z0-9\u0980-\u09ff])');SRCH_PRX.set(k,r)}return r}
function qLex(q){
  q=String(q||'').replace(/^\s*https?:\/\/(dx\.)?doi\.org\//i,'');
  const T=[],n=q.length;let i=0,special=false;
  while(i<n){
    const c=q[i];
    if(/\s/.test(c)){i++;continue}
    if(c==='('||c===')'){T.push({t:c});i++;continue}
    if(c==='"'){let j=q.indexOf('"',i+1);if(j<0)j=n;const s=q.slice(i+1,j);if(/\S/.test(s))T.push({t:'phrase',v:s});i=j+1;continue}
    if((c==='-'||c==='!')&&i+1<n&&/[^\s)\-!]/.test(q[i+1])&&(i===0||/[\s(]/.test(q[i-1]))){T.push({t:'NOT'});special=true;i++;continue}
    let j=i;while(j<n&&!/[\s()"]/.test(q[j]))j++;
    const w=q.slice(i,j);i=j;
    if(w==='OR'||w==='||'||w==='|'){T.push({t:'OR'});special=true}
    else if(w==='NOT'){T.push({t:'NOT'});special=true}
    else if(w==='AND'||w==='&&'||w==='&')T.push({t:'AND'});
    else if(/^NEAR(\/\d+)?$/i.test(w)){T.push({t:'NEAR',n:parseInt((w.match(/\/(\d+)/)||[])[1]||'5',10)||5});special=true}
    else T.push({t:'word',v:w});
  }
  return {T,special};
}
function qWords(v,keep){
  const out=[];
  for(const p of norm(v).split(/[^a-z0-9*?\u0980-\u09ff]+/)){
    if(!p)continue;
    if(/[\u0980-\u09ff]/.test(p)){out.push({k:'term',text:p,bn:true,rx:xlBnRx(p)});continue}
    if(qHasWild(p)){const t=p.replace(/\*+/g,'*');if(/[a-z0-9]/.test(t))out.push({k:'term',text:t,wild:true,rx:qTermRx(t,true)});continue}
    if(p.length>=2&&(keep||!SRCH_STOP.has(p)))out.push({k:'term',text:p,rx:srchTermRx(p)});
  }
  return out.length>1?{k:'and',kids:out}:(out[0]||null);
}
function qParse(T,keep){
  let p=0;
  const peek=()=>T[p];
  function orExpr(){const kids=[andExpr()];while(peek()&&peek().t==='OR'){p++;kids.push(andExpr())}const k=kids.filter(Boolean);return k.length>1?{k:'or',kids:k}:(k[0]||null)}
  function andExpr(){
    const kids=[];
    while(p<T.length){
      const t=peek();
      if(t.t==='OR'||t.t===')')break;
      if(t.t==='AND'){p++;continue}
      if(t.t==='NEAR'){ /* handled after left operand */ break }
      const u=unary();
      if(!u)break;
      /* look ahead for NEAR /n */
      if(peek()&&peek().t==='NEAR'){
        const n=peek().n||5; p++;
        const right=unary();
        if(right){kids.push({k:'near',n,left:u,right});continue}
      }
      kids.push(u);
    }
    return kids.length>1?{k:'and',kids}:(kids[0]||null);
  }
  function unary(){const t=peek();if(t.t==='NOT'){p++;if(p>=T.length)return null;const u=unary();return u?{k:'not',kid:u}:null}return primary()}
  function primary(){
    const t=T[p++];
    if(!t)return null;
    if(t.t==='('){const e=orExpr();if(peek()&&peek().t===')')p++;return e}
    if(t.t==='phrase'){const s=norm(t.v).trim().replace(/\*+/g,'*');return /[a-z0-9]/.test(s)?{k:'phrase',text:s,wild:qHasWild(s),rx:qPhraseRx(s)}:null}
    if(t.t==='word')return qWords(t.v,keep);
    return null;
  }
  const parts=[];
  while(p<T.length){const e=orExpr();if(e)parts.push(e);if(p<T.length&&T[p].t===')')p++}
  return parts.length>1?{k:'and',kids:parts}:(parts[0]||null);
}
function qHasPos(n,neg){if(!n)return false;if(n.k==='term'||n.k==='phrase'||n.k==='near')return !neg;if(n.k==='not')return qHasPos(n.kid,!neg);return (n.kids||[]).some(k=>qHasPos(k,neg))}
function qAnyWild(n){if(!n)return false;if(n.k==='term'||n.k==='phrase')return !!n.wild;if(n.k==='not')return qAnyWild(n.kid);if(n.k==='near')return qAnyWild(n.left)||qAnyWild(n.right);return (n.kids||[]).some(qAnyWild)}
function qReq(n){if(!n)return [];if(n.k==='term')return [n.rx];if(n.k==='and')return n.kids.filter(k=>k.k==='term').map(k=>k.rx);return []}
function qDesc(n,nested){
  if(!n)return '';
  if(n.k==='term')return n.text;
  if(n.k==='phrase')return '"'+n.text+'"';
  if(n.k==='not')return 'NOT '+qDesc(n.kid,true);
  if(n.k==='near')return qDesc(n.left,true)+' NEAR/'+(n.n||5)+' '+qDesc(n.right,true);
  const s=(n.kids||[]).map(k=>qDesc(k,true)).join(n.k==='or'?' OR ':' AND ');
  return nested&&n.kids&&n.kids.length>1?'('+s+')':s;
}
const qStem=w=>w.length>3?w.replace(/ies$/,'y').replace(/([^s])s$/,'$1'):w;

/* Curated LIS synonym groups (any member expands to the others) and spelling variants. Short abbreviations are only used as the typed term, never added as an expansion. */
const QTHES_SRC=[
 ['opac','online public access catalog','online public access catalogue','online catalog'],
 ['ko','knowledge organization','knowledge organisation'],
 ['kos','knowledge organization system','knowledge organisation system'],
 ['ir','information retrieval'],['oa','open access'],
 ['lis','library and information science','library science'],
 ['ils','integrated library system','library management system'],
 ['lod','linked open data','linked data'],
 ['marc','machine readable cataloging','machine readable cataloguing'],
 ['rda','resource description and access'],
 ['frbr','functional requirements for bibliographic records'],
 ['isbn','international standard book number'],['doi','digital object identifier'],
 ['ddc','dewey decimal classification'],['udc','universal decimal classification'],
 ['lcsh','library of congress subject headings'],['lcc','library of congress classification'],
 ['sna','social network analysis'],['nlp','natural language processing'],
 ['ai','artificial intelligence'],['ml','machine learning'],['llm','large language model','large language models'],
 ['gen ai','generative ai','generative artificial intelligence'],
 ['ict','information and communication technology','information and communications technology','information communication technology'],
 ['ocr','optical character recognition'],['iot','internet of things'],['gis','geographic information system'],
 ['mooc','massive open online course'],['lms','learning management system'],
 ['bibliometrics','scientometrics','informetrics'],
 ['altmetrics','alternative metrics'],
 ['ebook','e book','electronic book'],['ejournal','e journal','electronic journal'],
 ['eresources','e resources','electronic resources'],
 ['covid','coronavirus','covid 19'],
 ['scholarly communication','scholarly publishing'],
 ['research data management','rdm']
];
let QTHES=null;
function qThesFor(ph){
  if(!QTHES){QTHES=new Map();for(const g of QTHES_SRC){const m=g.map(s=>norm(s).replace(/[^a-z0-9]+/g,' ').trim());for(const a of m){const k=m.length?a:'';(QTHES.get(k)||QTHES.set(k,[]).get(k)).push(...m.filter(b=>b!==a))}}}
  const out=(QTHES.get(ph)||[]).map(t=>({text:t,kind:'synonym'}));
  const key=ph.split(' ').map(qStem).join(' ');
  if(key!==ph)(QTHES.get(key)||[]).forEach(t=>out.push({text:t,kind:'synonym'}));
  const sp=ph.split(' ').map(qSpell);
  if(sp.some((v,i)=>v!==ph.split(' ')[i]))out.push({text:sp.join(' '),kind:'spelling'});
  return out;
}
const QSPELL_Z='organi|digiti|categori|standardi|utili|summari|visuali|personali|customi|optimi|minimi|maximi|normali|conceptuali|characteri|prioriti|recogni|synchroni|harmoni|globali|locali|institutionali|specifi';
const QSPELL_PAIRS=new Map([['behaviour','behavior'],['colour','color'],['labour','labor'],['favour','favor'],['neighbour','neighbor'],['centre','center'],['programme','program'],['licence','license'],['judgement','judgment'],['modelling','modeling'],['labelling','labeling'],['grey','gray'],['analyse','analyze'],['analysed','analyzed'],['analysing','analyzing'],['catalogue','catalog'],['catalogues','catalogs'],['cataloguing','cataloging'],['cataloguer','cataloger'],['dialogue','dialog']]);
const QSPELL_REV=new Map([...QSPELL_PAIRS].map(([a,b])=>[b,a]));
const QSPELL_RX_S=new RegExp('^('+QSPELL_Z+')s(ation|ations|e|ed|es|ing|er|ers)$'),QSPELL_RX_Z=new RegExp('^('+QSPELL_Z+')z(ation|ations|e|ed|es|ing|er|ers)$');
function qSpell(w){
  if(QSPELL_PAIRS.has(w))return QSPELL_PAIRS.get(w);
  if(QSPELL_REV.has(w))return QSPELL_REV.get(w);
  let m=QSPELL_RX_S.exec(w);if(m)return m[1]+'z'+m[2];
  m=QSPELL_RX_Z.exec(w);if(m)return m[1]+'s'+m[2];
  return w;
}
function qSynFor(ph){
  let raw=null;try{raw=typeof window.lisSemExpand==='function'?window.lisSemExpand(ph):null}catch(e){}
  raw=raw||[];
  const base=new Set(ph.split(' ').map(qStem)),seen=new Set([ph]),out=[];
  const push=(txt,kind,abbr)=>{
    const c=norm(txt).replace(/[^a-z0-9]+/g,' ').trim();
    if(!c||seen.has(c)||c.length<(abbr?3:2)||SRCH_STOP.has(c))return;
    const ws=c.split(' ');if(ws.length>6)return;
    const st=new Set(ws.map(qStem));
    if([...base].every(b=>st.has(b)))return;      // already matched by the original terms
    seen.add(c);out.push({text:c,kind,from:ph});
  };
  for(const e of raw){
    const main=String(e.text).replace(/\([^)]*\)/g,' ');
    push(main,e.kind);
    for(const m of String(e.text).matchAll(/\(([A-Za-z][A-Za-z0-9-]{1,9})\)/g))push(m[1],'abbreviation',true);
  }
  for(const t of qThesFor(ph))push(t.text,t.kind,t.text.indexOf(' ')<0&&t.text.length<=5&&t.kind==='synonym');
  return out.slice(0,6);
}
function qExpandKids(kids,exps){
  const out=[];let i=0;
  while(i<kids.length){
    const k=kids[i];
    if(k.k==='term'&&!k.wild){
      const run=[];for(let j=i;j<kids.length&&kids[j].k==='term'&&!kids[j].wild;j++)run.push(kids[j]);
      let used=0;
      for(let n=Math.min(3,run.length);n>=1&&!used;n--){
        const ph=run.slice(0,n).map(t=>t.text).join(' '),ex=qSynFor(ph);
        if(!ex.length)continue;
        const alts=ex.map(e=>{exps.push(e);return e.text.indexOf(' ')>=0?{k:'phrase',text:e.text,rx:srchPhraseRx(e.text),m:.45,exp:true,kind:e.kind,from:ph}:{k:'term',text:e.text,rx:srchTermRx(e.text),m:.45,exp:true,kind:e.kind,from:ph}});
        out.push({k:'or',exp:true,first:true,kids:[n===1?run[0]:{k:'and',kids:run.slice(0,n)},...alts]});
        i+=n;used=n;
      }
      if(!used){out.push(k);i++}
    }else{out.push(qExpandNode(k,exps));i++}
  }
  return out;
}
function qExpandNode(n,exps){
  if(!n)return n;
  if(n.k==='not'||n.k==='phrase')return n;
  if(n.k==='and')return {k:'and',kids:qExpandKids(n.kids,exps)};
  if(n.k==='or')return {k:'or',kids:n.kids.map(k=>qExpandKids([k],exps)[0])};
  return qExpandKids([n],exps)[0];
}
function qLeaves(n,acc,neg){
  if(!n||n.k==='not')return acc;
  if(n.k==='term'){
    const t=n.text,rx=n.wild?new RegExp('^'+qWild(t)+'$'):null;
    if(n.bn){acc.push({exp:!!n.exp,test:lw=>xlBnWordTest(norm(lw),t)});return acc}
    acc.push({exp:!!n.exp,test:n.wild?(lw=>rx.test(lw)):(lw=>lw===t||lw===t+'s'||lw===t+'es'||lw===t+'ed'||lw===t+'ing')});
  }else if(n.kids)n.kids.forEach(k=>qLeaves(k,acc,false));
  return acc;
}
function qCompile(q,expand){
  expand=!!expand;
  if(typeof xlNeedsXlate==='function'&&xlNeedsXlate(q))q=prepareSearchQuery(q).searchQ;
  if(QLAST&&QLAST.q===q&&QLAST.e===expand)return QLAST.c;
  const key=(expand?'1|':'0|')+q;let c=QCACHE.get(key);
  if(!c){
    const {T,special}=qLex(q);
    let ast=qParse(T,false);if(!qHasPos(ast))ast=qParse(T,true);
    c={q,ast0:ast,ast,special:special||qAnyWild(ast),classic:false,exps:[],desc:qDesc(ast),hasPos:qHasPos(ast),reqRx:qReq(ast)};
    if(expand&&ast&&c.hasPos){try{c.ast=qExpandNode(ast,c.exps)}catch(e){c.ast=ast;c.exps=[]}}
    c.classic=!ast||(!c.special&&!c.exps.length);
    c.hl=qLeaves(c.ast,[],false);
    if(QCACHE.size>300)QCACHE.clear();
    QCACHE.set(key,c);
  }
  QLAST={q,e:expand,c};
  return c;
}
const QF=[['title','t',12],['keywords','k',8],['authors','a',6],['journal/source','s',5],['abstract','b',2],['DOI','d',18]];
const QPF=[['exact title phrase','t',55],['keyword phrase','k',34],['author phrase','a',28],['journal/source phrase','s',20],['abstract phrase','b',10]];
function qNearHit(left,right,window,x){
  /* Proximity: both terms (or their expansions) must appear in the same field
     within `window` word tokens of each other. Uses the pre-built INDEX fields. */
  const texts=[];
  for(const [,f] of [['title','t'],['abstract','b'],['keywords','k']]){
    const v=x[f]; if(v)texts.push(v);
  }
  const L=left.k==='term'?[left]:(left.k==='and'?left.kids.filter(k=>k.k==='term'):[]);
  const R=right.k==='term'?[right]:(right.k==='and'?right.kids.filter(k=>k.k==='term'):[]);
  if(!L.length||!R.length)return false;
  for(const txt of texts){
    const toks=String(txt).toLowerCase().split(/[^a-z0-9\u0980-\u09ff]+/).filter(Boolean);
    const posL=[],posR=[];
    for(let i=0;i<toks.length;i++){
      const t=toks[i];
      for(const n of L){if(n.rx&&n.rx.test(t)||(n.text&&t===n.text))posL.push(i)}
      for(const n of R){if(n.rx&&n.rx.test(t)||(n.text&&t===n.text))posR.push(i)}
    }
    for(const a of posL)for(const b of posR)if(Math.abs(a-b)<=window&&a!==b)return true;
  }
  return false;
}
function qEval(n,x,why,mult){
  const L=why.length;
  switch(n.k){
    case 'term':{let s=0;const m=mult*(n.m||1);for(const [l,f,w] of QF){if(n.exp&&(f==='s'||f==='a'||f==='d'))continue;const v=x[f];if(v&&n.rx.test(v)){s+=w*m;why.push([(n.exp?'expanded ('+n.kind+': '+n.text+') · ':'')+l,w*m])}}return s>0?s:-1}
    case 'phrase':{let s=0;const m=mult*(n.m||1);for(const [l,f,w] of QPF){if(n.exp&&(f==='s'||f==='a'))continue;const v=x[f];if(v&&n.rx.test(v)){s+=w*m;why.push([(n.exp?'expanded ('+n.kind+': '+n.text+') · ':'')+l,w*m])}}return s>0?s:-1}
    case 'and':{let s=0;for(const k of n.kids){const v=qEval(k,x,why,mult);if(v<0){why.length=L;return -1}s+=v}return s}
    case 'or':{let s=-1;for(const k of n.kids){const v=qEval(k,x,why,mult);if(v>=0){s=(s<0?0:s)+v;if(n.first&&k===n.kids[0])break}}return s}
    case 'not':{const v=qEval(n.kid,x,why,mult);why.length=L;return v>=0?-1:0}
    case 'near':{
      const lv=qEval(n.left,x,why,mult);
      const rv=qEval(n.right,x,why,mult);
      if(lv<0||rv<0){why.length=L;return -1}
      if(!qNearHit(n.left,n.right,n.n||5,x)){why.length=L;return -1}
      why.push(['NEAR/'+(n.n||5)+' proximity',12*mult]);
      return lv+rv+12*mult;
    }
  }
  return -1;
}
function qRelevance(i,c){
  const r=R[i],x=INDEX[i],why=[];
  let s=qEval(c.ast,x,why,1);
  if(s<0)return {score:0,why:[]};
  if(c.reqRx.length&&x.t&&c.reqRx.every(rx=>rx.test(x.t))){s+=20;why.push(['all terms in title',20])}
  if(!c.hasPos&&s===0){why.push(['not excluded',0]);return {score:Math.log1p(r[0])*.2+.01,why}}
  if(s>0)s+=Math.min(5,Math.log1p(r[0])*.7);
  return {score:s,why};
}
function relevance(i,q,opt){
  if(!q||!String(q).trim())return relevanceClassic(i,q);
  const c=qCompile(q,!!(opt&&opt.expand));
  return c.classic?relevanceClassic(i,q):qRelevance(i,c);
}
function highlight(text,q){
  // Prefer the (possibly transliterated) search query so marks land on the English index terms
  let useQ=q||'';
  try{if(typeof LAST_LANG_INFO!=='undefined'&&LAST_LANG_INFO&&(LAST_LANG_INFO.transliterated||LAST_LANG_INFO.translated)&&LAST_LANG_INFO.searchQ&&(LAST_LANG_INFO.original===q||!q))useQ=LAST_LANG_INFO.searchQ}catch(e){}
  if(!useQ||!String(useQ).trim())return highlightClassic(text,q);
  const c=qCompile(useQ,state.expand!==false);
  if(c.classic)return highlightClassic(text,useQ);
  const s=esc(text||'');if(!c.hl.length)return s;
  return s.replace(/[A-Za-z0-9\u0980-\u09FF]+/g,w=>{const lw=w.toLowerCase(),l=c.hl.find(h=>h.test(lw));return l?'<mark class="match'+(l.exp?' exp':'')+'">'+w+'</mark>':w});
}
function qCountNote(){
  const q=(state.query||'').trim();if(!q)return '';
  const c=qCompile(q,state.expand!==false);
  if(c.special)return ' · query: '+esc(c.desc);
  const t=srchTerms(q);
  return t.length?' · every record contains: '+t.map(esc).join(', ')+(c.exps.length?' (or an expanded term)':''):'';
}
function qNote(){
  const q=(state.query||'').trim();let el=document.getElementById('queryNotes');
  if(!el){const rs=document.getElementById('resultSummary');if(!rs||!rs.parentNode)return;el=document.createElement('div');el.id='queryNotes';el.className='q-notes';rs.parentNode.insertBefore(el,rs)}
  if(!q){el.innerHTML='';el.style.display='none';return}
  const langInfo=LAST_LANG_INFO&&LAST_LANG_INFO.original===q?LAST_LANG_INFO:prepareSearchQuery(q);
  const searchQ=langInfo.searchQ||q;
  const c=qCompile(searchQ,state.expand!==false),parts=[];
  const xn=xlNoticeHtml(langInfo);if(xn)parts.push(xn);
  if(!xn&&langInfo.transliterated&&langInfo.note)parts.push('<div><b>Language:</b> '+(langInfo.lang==='bn'?'Bengali':'Mixed (Bengali + Latin)')+' · '+esc(langInfo.note)+'</div>');
  else if(!xn&&(langInfo.lang==='bn'||langInfo.lang==='mixed'))parts.push('<div><b>Language detected:</b> '+esc(langInfo.lang)+'</div>');
  if(c.special)parts.push('<div><b>Interpreted as:</b> <code>'+esc(c.desc)+'</code></div>');
  if(c.exps.length){
    const g=new Map();c.exps.forEach(e=>{(g.get(e.from)||g.set(e.from,[]).get(e.from)).push(e)});
    parts.push('<div><b>Auto-expanded:</b> '+[...g].map(([f,a])=>esc(f)+' → '+a.map(e=>'<span class="chip" title="'+esc(e.kind)+'">'+esc(e.text)+'</span>').join(' ')).join(' · ')+' <button class="ghost" type="button" data-qx="off">Search exactly as typed</button></div>');
  }
  el.innerHTML=parts.join('');el.style.display=parts.length?'':'none';
}

/*QE-END*/
function qInitUi(){
  try{state.expand=localStorage.getItem('lisExpandQ')!=='0'}catch(e){state.expand=true}
  const cb=document.getElementById('qExpand');
  const save=on=>{try{localStorage.setItem('lisExpandQ',on?'1':'0')}catch(e){}};
  if(cb){cb.checked=state.expand!==false;cb.addEventListener('change',()=>{state.expand=cb.checked;save(cb.checked);if(R&&(state.query||'').trim()){state.page=1;doSearch(false)}})}
  document.addEventListener('click',e=>{const b=e.target.closest&&e.target.closest('[data-qx="off"]');if(!b)return;state.expand=false;if(cb)cb.checked=false;save(false);state.page=1;doSearch(false)});
}
qInitUi();
function passesFacets(i){const r=R[i];if(state.savedOnly&&(!SEARCH_SAVED||!SEARCH_SAVED.has(i)))return false;if(state.yearSet.size&&!state.yearSet.has(r[3]))return false;if(state.yearFrom&&r[3]<state.yearFrom)return false;if(state.yearTo&&r[3]>state.yearTo)return false;if(state.source!==''&&r[4]!==Number(state.source))return false;if(state.publisher!==''&&r[5]!==Number(state.publisher))return false;if(state.country!==''){const set=countryIndicesForFilter(state.country);if(set&&!set.has(r[7]))return false}if(state.subject&& !norm(r[11]).includes(norm(state.subject)))return false;if(state.hasLink&&!r[8])return false;if(r[0]<(state.minCites||0))return false;if(!advancedMatch(i))return false;return true}
function doSearch(saveHist=true){
  const q=state.query.trim();
  // Language detection + Bengali→Latin transliteration (English index unchanged)
  const langInfo=prepareSearchQuery(q);
  LAST_LANG_INFO=langInfo;
  try{xlResolveUnknown(langInfo)}catch(e){}
  const searchQ=langInfo.searchQ; // used for ranking/matching; state.query stays as typed
  // Hide left filter panel while a text search is active
  document.body.classList.toggle('has-search', !!q);
let out=[];SEARCH_SAVED=state.savedOnly?savedSet():null;
  const useNeural=state.sort==='neural'&&!!searchQ;
  const qo={expand:state.expand!==false};
  // First pass: lexical relevance (required match when query present)
  const cand=[];
  for(let i=0;i<R.length;i++){
    if(!passesFacets(i))continue;
    if(!searchQ){cand.push({i,score:Math.log1p(R[i][0])*.2,why:[]});continue}
    let rel=relevance(i,searchQ,qo);let score=typeof rel==='number'?rel:rel.score;
    if(score<=0)continue;
    cand.push({i,score,why:typeof rel==='number'?[]:rel.why});
  }
  if(useNeural&&EMB.ready&&cand.length){
    const ns=neuralScores(searchQ,cand.map(x=>x.i));
    out=cand.map(h=>{
      const cos=ns.get(h.i)||0;
      // blend: keep lexical gate, rank primarily by embedding cosine
      const score=cos*100+h.score*0.15;
      const why=h.why.concat(cos>0?[['embedding cosine',+(cos*100).toFixed(2)]]:[]);
      return {i:h.i,score,why};
    });
  }else out=cand;
  if(state.sort==='cites')out.sort((a,b)=>R[b.i][0]-R[a.i][0]||b.score-a.score);else if(state.sort==='newest')out.sort((a,b)=>R[b.i][3]-R[a.i][3]||b.score-a.score);else if(state.sort==='oldest')out.sort((a,b)=>R[a.i][3]-R[b.i][3]||b.score-a.score);else if(state.sort==='title')out.sort((a,b)=>R[a.i][2].localeCompare(R[b.i][2]));else out.sort((a,b)=>b.score-a.score||R[b.i][0]-R[a.i][0]);
  currentResults=out; state.page=Math.min(state.page,Math.max(1,Math.ceil(out.length/PAGE_SIZE)));render(); updateRelatedPanel();
  const facetsEl=document.getElementById('facets');
  if(facetsEl){if(q){document.body.classList.add('has-search');facetsEl.style.display='none';}else{document.body.classList.remove('has-search');facetsEl.style.display='';}}
  if(q){requestAnimationFrame(()=>{const el=document.getElementById('resultCount')||document.getElementById('results');if(el)el.scrollIntoView({behavior:'smooth',block:'start'});});}
}
function highlightClassic(text,q){
  const ts=srchTerms(q),s=esc(text||'');if(!ts.length)return s;
  return s.replace(/[A-Za-z0-9]+/g,w=>{const lw=w.toLowerCase();return ts.some(t=>lw===t||lw===t+'s'||lw===t+'es'||lw===t+'ed'||lw===t+'ing')?'<mark class="match">'+w+'</mark>':w});
}

function renderSummary(){
  const el=document.getElementById('resultSummary'); if(!el)return;
  const recs=currentResults.filter(h=>typeof h.i==='number').map(h=>R[h.i]);
  if(!recs.length){el.innerHTML='';return}
  const n=recs.length, cites=recs.map(r=>+r[0]||0).sort((a,b)=>a-b);
  const years=recs.map(r=>+r[3]).filter(Boolean);
  const yMin=Math.min(...years), yMax=Math.max(...years);
  const mean=Math.round(cites.reduce((a,b)=>a+b,0)/n);
  const median=cites[Math.floor(n/2)];
  const jc=new Map(); recs.forEach(r=>{const j=S[r[4]]; if(j)jc.set(j,(jc.get(j)||0)+1)});
  const top=[...jc].sort((a,b)=>b[1]-a[1])[0];
  const links=recs.filter(r=>safeUrl(r[8])).length;
  const kpi=(v,l,m)=>`<div class="rc-kpi"><b>${v}</b><span>${l}</span><small>${m}</small></div>`;
  el.innerHTML=`<section class="rc-summary" aria-label="Summary of matching records">
    ${kpi(n.toLocaleString(),'Matching records','Records that satisfy the current search and filters')}
    ${kpi(years.length?(yMin===yMax?yMin:yMin+'–'+yMax):'—','Publication years','Earliest to latest year in these matches')}
    ${kpi(mean.toLocaleString(),'Average citations',`Median ${median.toLocaleString()} — less affected by a few highly cited outliers`)}
    ${kpi(jc.size.toLocaleString(),'Journals',top?`Most frequent: ${esc(top[0])} (${top[1].toLocaleString()})`:'No journal names')}
    ${kpi(links.toLocaleString(),'With article link',`${Math.round(links/n*100)}% of matches have a usable URL`)}
  </section>`;
}
function render(){
 $('#resultCount').textContent=`${currentResults.length.toLocaleString()} result${currentResults.length===1?'':'s'}`+(state.savedOnly?' in Saved items':'')+qCountNote();
 qNote();renderSummary();const list=$('#resultList');list.innerHTML='';let start=(state.page-1)*PAGE_SIZE,end=Math.min(start+PAGE_SIZE,currentResults.length);let saved=savedSet();
 if(!currentResults.length){list.innerHTML='<div class="panel empty"><b>No matching records</b><br>Search matches whole words and requires every term (stop words such as “the” are ignored). Use OR, NOT, brackets or wildcards (libr*) to widen or refine the query, check spelling, or clear one or more filters.</div>'} else for(let pos=start;pos<end;pos++){let hit=currentResults[pos],o=recObj(hit.i);let card=document.createElement('article');card.className='result-card';const cy=o.year||'n/a',cc=Number(o.cites)||0;card.innerHTML=`
   <div class="rc-head"><span class="rank-badge">${pos+1}</span><div class="rc-title"><h2 class="rtitle">${highlight(o.title,state.query)}</h2><div class="meta">${highlight(o.authors||'Author not listed',state.query)}</div></div></div>
   <div class="rc-stats">
     <div class="rc-stat"><span>Year</span><b>${esc(cy)}</b></div>
     <div class="rc-stat"><span>Citations</span><b>${cc.toLocaleString()}</b></div>
     <div class="rc-stat rc-wide"><span>Journal</span><b>${highlight(o.source||'Not listed',state.query)}</b></div>
     ${o.country?`<div class="rc-stat"><span>Country</span><b>${esc(o.country)}</b></div>`:''}
   </div>
   <div class="abstract rc-abs">${highlight(o.abstract||'No abstract supplied.',state.query)}</div>
   ${o.keywords?`<div class="tiny rc-kw"><b>Keywords:</b> ${highlight(o.keywords,state.query)}</div>`:''}
   <div class="actions">${safeUrl(o.url)?`<a class="full" href="${esc(safeUrl(o.url))}" target="_blank" rel="noopener">Open article ↗</a>`:''}<button data-act="detail" data-id="${hit.i}">Details</button><button data-act="save" data-id="${hit.i}">${saved.has(hit.i)?'★ Saved':'☆ Save'}</button><button data-act="cite" data-id="${hit.i}">Cite</button><button data-act="why" data-id="${hit.i}">Why this result?</button>
     <details class="rc-more"><summary>More actions</summary><div class="rc-menu"><button data-act="related" data-id="${hit.i}">Related papers</button><button data-act="graph" data-id="${hit.i}">Knowledge graph</button><button class="ri-ner" data-act="ner" data-id="${hit.i}">Named entities</button><button class="ri-hyp" data-act="hyp" data-id="${hit.i}">Hypotheses</button><button class="ri-gap" data-act="gap" data-id="${hit.i}">Research gaps</button><button data-act="xlate" data-id="${hit.i}">বাংলা / Translate</button><button data-act="export" data-id="${hit.i}">Export</button></div></details></div>
   <div class="why" id="why-${hit.i}">${whyText(hit,o)}</div>`;list.appendChild(card)}
 renderPager();renderActiveFilters();updateSavedCount();
}
function whyText(hit,o){if(!state.query)return `No text query is active. This record is ordered using the selected sort; its citation count is ${o.cites}.`;if(!hit.why.length)return 'The record passed filters but has no positive text contribution.';let grouped={};hit.why.forEach(([k,v])=>grouped[k]=(grouped[k]||0)+v);return `<b>Ranking score: ${hit.score.toFixed(1)}</b><br>`+Object.entries(grouped).sort((a,b)=>b[1]-a[1]).map(([k,v])=>`${esc(k)} +${v}`).join(' · ')+`<br><span class="tiny">Citation count adds only a small tie-breaking boost to text relevance.</span>`}
function renderPager(){let p=$('#pager'),pages=Math.ceil(currentResults.length/PAGE_SIZE);if(pages<=1){p.innerHTML='';return}p.innerHTML=`<button class="ghost" id="prevPage" ${state.page<=1?'disabled':''}>← Previous</button><span class="tiny">Page ${state.page.toLocaleString()} of ${pages.toLocaleString()}</span><button class="ghost" id="nextPage" ${state.page>=pages?'disabled':''}>Next →</button>`;$('#prevPage').onclick=()=>{state.page--;render();scrollToResults()};$('#nextPage').onclick=()=>{state.page++;render();scrollToResults()}}
function scrollToResults(){window.scrollTo({top:Math.max(0,$('#resultCount').getBoundingClientRect().top+scrollY-150),behavior:'smooth'})}
function renderActiveFilters(){let arr=[];if(state.query)arr.push(`Query: ${state.query}`);if(state.savedOnly)arr.push('Saved only');if(state.yearSet.size)arr.push('Years: '+[...state.yearSet].sort().join(', '));if(state.yearFrom||state.yearTo)arr.push(`Year ${state.yearFrom||'…'}–${state.yearTo||'…'}`);if(state.source!=='')arr.push('Source: '+S[Number(state.source)]);if(state.publisher!=='')arr.push('Publisher: '+PUB[Number(state.publisher)]);if(state.country!=='')arr.push('Country: '+CO[Number(state.country)]);if(state.subject)arr.push('Subject: '+state.subject);if(state.hasLink)arr.push('Link available');if(state.minCites)arr.push(`Citations ≥ ${state.minCites}`);if(state.advanced.length)arr.push('Advanced fields active');$('#activeFilters').innerHTML=arr.map(x=>`<span class="filtertag">${esc(x)}</span>`).join('')}
function clearFilters(skipSearch){state.yearSet.clear();state.yearFrom=null;state.yearTo=null;state.source='';state.publisher='';state.country='';state.subject='';state.hasLink=false;state.minCites=0;$$('[data-year]').forEach(x=>x.checked=false);$('#yearFrom').value='';$('#yearTo').value='';$('#sourceFilter').value='';$('#publisherFilter').value='';$('#countryFilter').value='';$('#subjectFilter').value='';$('#hasLink').checked=false;$('#minCites').value=0;state.savedOnly=false;state.advanced=[];if($('#advRows')){$('#advRows').innerHTML='';if(typeof addAdvRow==='function')addAdvRow();}if(!skipSearch)doSearch(false)}
function apa(o){let doi=o.doi?` https://doi.org/${o.doi.replace(/^https?:\/\/(dx\.)?doi\.org\//i,'')}`:'';return `${o.authors} (${o.year||'n.d.'}). ${o.title}. ${o.source}.${doi}`.replace(/\s+/g,' ').trim()}
function ris(o){let au=(o.authors||'').split(';').map(x=>`AU  - ${x.trim()}`).join('\n');let kw=(o.keywords||'').split(';').filter(Boolean).map(x=>`KW  - ${x.trim()}`).join('\n');return `TY  - JOUR\n${au}\nTI  - ${o.title}\nJO  - ${o.source}\nPY  - ${o.year}\nSN  - ${o.issn}\nDO  - ${o.doi}\nUR  - ${o.url}\n${kw}\nAB  - ${o.abstract}\nER  - `}
function bib(o){let first=(o.authors||'unknown').split(';')[0].trim().split(/\s+/).pop().replace(/\W/g,'')||'record';let key=`${first}${o.year||''}${(o.title.match(/[A-Za-z0-9]+/)||['item'])[0]}`;let authors=(o.authors||'').split(';').map(x=>x.trim()).join(' and ');return `@article{${key},\n  author = {${authors}},\n  title = {${o.title}},\n  journal = {${o.source}},\n  year = {${o.year}},\n  doi = {${o.doi}},\n  issn = {${o.issn}},\n  url = {${o.url}},\n  keywords = {${o.keywords}}\n}`}
function download(name,text,type='text/plain'){let a=document.createElement('a');a.href=URL.createObjectURL(new Blob([text],{type}));a.download=name;document.body.appendChild(a);a.click();setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove()},500)}
function csvCell(v){v=String(v??'');return /[",\n]/.test(v)?'"'+v.replace(/"/g,'""')+'"':v}
function exportHits(format,hits){let objs=hits.map(h=>recObj(h.i??h));if(format==='ris')download('library_export.ris',objs.map(ris).join('\n\n'),'application/x-research-info-systems');else if(format==='bib')download('library_export.bib',objs.map(bib).join('\n\n'),'application/x-bibtex');else{let head=['Cites','Authors','Title','Year','Source','Publisher','Place','Country','ArticleURL','DOI','ISSN','Keywords','Abstract'];let rows=[head,...objs.map(o=>[o.cites,o.authors,o.title,o.year,o.source,o.publisher,o.place,o.country,o.url,o.doi,o.issn,o.keywords,o.abstract])];download('library_export.csv',rows.map(r=>r.map(csvCell).join(',')).join('\n'),'text/csv;charset=utf-8')}}
function exportModal(hits,title='Export'){showModal(`<h2>${title}</h2><p>Choose a format. RIS can be imported by Zotero, Mendeley, EndNote and many library tools.</p><div class="actions"><button class="primary" data-exp="ris">RIS (Zotero/Mendeley)</button><button data-exp="bib">BibTeX</button><button data-exp="csv">CSV</button></div><p class="tiny">Records to export: ${hits.length.toLocaleString()}</p>`);$$('[data-exp]').forEach(b=>b.onclick=()=>{exportHits(b.dataset.exp,hits);toast('Export created')})}
function showModal(body){
  const m=$('#modal'), card=$('#modalCard');
  $('#modalBody').innerHTML=body;
  m.classList.add('open');
  m.setAttribute('aria-hidden','false');
  m.setAttribute('role','dialog');
  m.setAttribute('aria-modal','true');
  if(!m.getAttribute('aria-label')&&!m.getAttribute('aria-labelledby'))m.setAttribute('aria-label','Dialog');
  card.setAttribute('role','document');
  /* simple focus trap: keep focus inside modal while open */
  const focusables=()=>[...m.querySelectorAll('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])')].filter(el=>!el.disabled&&el.offsetParent!==null);
  const first=()=>focusables()[0], last=()=>{const f=focusables();return f[f.length-1]};
  m._trap=e=>{
    if(e.key!=='Tab'||!m.classList.contains('open'))return;
    const a=first(), z=last();
    if(e.shiftKey){if(document.activeElement===a||!m.contains(document.activeElement)){e.preventDefault();z&&z.focus()}}
    else{if(document.activeElement===z||!m.contains(document.activeElement)){e.preventDefault();a&&a.focus()}}
  };
  m.addEventListener('keydown',m._trap);
  setTimeout(()=>{const c=$('#modalClose');if(c)c.focus();else{const a=first();if(a)a.focus()}},30);
}
function closeModal(){
  const m=$('#modal');
  m.classList.remove('open');
  m.setAttribute('aria-hidden','true');
  m.removeAttribute('role');
  m.removeAttribute('aria-modal');
  if(m._trap){m.removeEventListener('keydown',m._trap);m._trap=null}
  $('#modalCard').classList.remove('graph-modal-card');
  if(window.KG&&KG.anim)cancelAnimationFrame(KG.anim);
}
function detail(i){
  let o=recObj(i);
  const authorsHtml=(o.authors||'').split(';').map(a=>a.trim()).filter(Boolean).map(a=>{
    const L=authLinksForAuthor(a);
    return `<span class="auth-person"><b>${esc(a)}</b> <span class="tiny">[${esc(L.localId)}]</span>
      <a class="tiny" target="_blank" rel="noopener" href="${esc(L.viaf)}">VIAF</a>
      <a class="tiny" target="_blank" rel="noopener" href="${esc(L.lcnaf)}">LCNAF</a>
      <a class="tiny" target="_blank" rel="noopener" href="${esc(L.orcid)}">ORCID</a></span>`;
  }).join('<br>')||esc('Author not listed');
  const kwHtml=(o.keywords||'').split(/[;,]|\|/ ).map(k=>k.trim()).filter(Boolean).map(k=>{
    const L=authLinksForSubject(k);
    return `<a class="chip" target="_blank" rel="noopener" href="${esc(L.lcsh)}" title="LCSH">${esc(k)}</a>`;
  }).join(' ')||esc('Not supplied');
  const countryDisp=o.country?(countryCanon(o.country)||o.country)+(countryCanon(o.country)&&countryCanon(o.country)!==o.country?' <span class="tiny">(raw: '+esc(o.country)+')</span>':''):'';
  showModal(`<h2>${esc(o.title)}</h2><div class="meta">${o.year} · ${esc(o.source)}</div>
<div class="detail-grid">
  <div class="detail-block"><b>Authors &amp; authority IDs</b>${authorsHtml}</div>
  <div class="detail-block"><b>Publisher</b>${esc(o.publisher||'Not supplied')}</div>
  <div class="detail-block"><b>Place / country</b>${countryDisp||esc([o.place,o.country].filter(Boolean).join(', ')||'Not supplied')}</div>
  <div class="detail-block"><b>DOI</b>${esc(o.doi||'Not supplied')}</div>
  <div class="detail-block"><b>ISSN</b>${esc(o.issn||'Not supplied')}</div>
  <div class="detail-block"><b>Citation count</b>${o.cites.toLocaleString()}</div>
  <div class="detail-block"><b>Access</b>${safeUrl(o.url)?`<a href="${esc(safeUrl(o.url))}" target="_blank" rel="noopener">Open supplied article/DOI link ↗</a>`:'No valid web URL supplied'}</div>
</div>
<h3>Keywords (LCSH links)</h3><p>${kwHtml}</p>
<h3>Abstract</h3><p>${esc(o.abstract||'Not supplied')}</p>`);
}
function citeModal(i){let o=recObj(i),txt=apa(o);showModal(`<h2>Cite this record</h2><label for="citeText"><b>APA-style citation (generated, read-only)</b></label><textarea id="citeText" readonly aria-readonly="true" style="width:100%;height:130px;margin-top:8px;border:1px solid var(--line);border-radius:9px;padding:10px">${esc(txt)}</textarea><div class="actions"><button class="primary" id="copyCite">Copy citation</button><button id="downloadRis">Download RIS</button><button id="downloadBib">Download BibTeX</button></div><p class="tiny">Citation formatting is generated from the fields supplied in the dataset; verify local style requirements before submission.</p>`);$('#copyCite').onclick=async()=>{let v=$('#citeText').value;try{if(navigator.clipboard&&window.isSecureContext){await navigator.clipboard.writeText(v)}else{let ta=$('#citeText');ta.focus();ta.select();document.execCommand('copy')}toast('Citation copied')}catch{toast('Select the citation and copy it manually')}};$('#downloadRis').onclick=()=>exportHits('ris',[i]);$('#downloadBib').onclick=()=>exportHits('bib',[i])}
function related(i){let base=recObj(i),bk=new Set(tokens(base.keywords).filter(x=>x.length>2)),ba=new Set((base.authors||'').split(';').map(norm));let arr=[];for(let j=0;j<R.length;j++){if(j===i)continue;let o=recObj(j),score=0;if(o.source===base.source)score+=3;let oa=(o.authors||'').split(';').map(norm);for(let a of oa)if(ba.has(a)&&a)score+=8;let ok=new Set(tokens(o.keywords).filter(x=>x.length>2));let overlap=0;for(let k of bk)if(ok.has(k))overlap++;score+=overlap*2;if(score>2)arr.push({i:j,score})}arr.sort((a,b)=>b.score-a.score||R[b.i][0]-R[a.i][0]);let top=arr.slice(0,12);showModal(`<h2>Related items</h2><p class="tiny">Ranked locally using shared authors, journal/source and keyword overlap.</p><div class="related-list">${top.map(x=>{let o=recObj(x.i);return `<button class="related-item" data-open-detail="${x.i}" style="text-align:left;background:#fff"><b>${esc(o.title)}</b><div class="tiny">${esc(o.authors)} · ${o.year} · ${esc(o.source)} · similarity ${x.score}</div></button>`}).join('')||'<div class="note">No strong related items found.</div>'}</div>`);$$('[data-open-detail]').forEach(b=>b.onclick=()=>detail(Number(b.dataset.openDetail)))}
function duplicatesModal(scope){
  const useResults=scope!=='all';
  const ids=useResults
    ? currentResults.filter(h=>typeof h.i==='number').map(h=>h.i)
    : null;
  if(useResults&&(!ids||!ids.length)){toast('Run a search first, or choose “Entire dataset”');return}
  showModal(`<h2>Duplicate &amp; near-duplicate detection</h2>
<p class="tiny">Exact matches: same DOI, or same normalised title + year. Near matches: high title similarity (token Jaccard ≥ 0.82), year within ±1, and author overlap when authors are present. Interface remains English; detection runs offline on the local index.</p>
<div class="actions" style="margin-bottom:10px">
  <button class="primary" type="button" id="dupScopeResults" ${useResults?'':'disabled'}>Current results (${useResults?ids.length:0})</button>
  <button class="ghost" type="button" id="dupScopeAll">Entire dataset (may take a moment)</button>
</div>
<div id="dupOut"><div class="note">Scanning…</div></div>`);
  const run=(which)=>{
    const list=which==='all'?null:ids;
    const out=$('#dupOut');if(!out)return;
    out.innerHTML='<div class="note">Scanning…</div>';
    // yield so the modal paints
    setTimeout(()=>{
      const clusters=findNearDuplicates(list||[]);
      if(!clusters.length){out.innerHTML='<div class="panel empty"><b>No duplicate clusters found</b><br>No exact DOI/title-year matches and no strong near-duplicates under the current thresholds.</div>';return}
      const kindLabel={ 'exact-doi':'Exact DOI','exact-title-year':'Exact title + year','near-title':'Near-duplicate (title similarity)' };
      out.innerHTML=`<p class="tiny"><b>${clusters.length}</b> cluster(s) · <b>${clusters.reduce((n,c)=>n+c.ids.length,0)}</b> records involved</p>`+
        clusters.slice(0,40).map((c,ci)=>{
          const rows=c.ids.map(i=>{const o=recObj(i);return `<button class="related-item" data-open-detail="${i}" style="text-align:left;background:#fff;width:100%"><b>${esc(o.title)}</b><div class="tiny">${esc(o.authors)} · ${o.year} · ${esc(o.source)} · DOI ${esc(o.doi||'—')} · cites ${Number(o.cites)||0}</div></button>`}).join('');
          return `<div class="card" style="margin:10px 0;padding:10px"><div class="tiny"><b>Cluster ${ci+1}</b> · ${kindLabel[c.kind]||c.kind} · ${c.ids.length} records</div>${rows}</div>`;
        }).join('')+(clusters.length>40?'<p class="tiny">Showing first 40 clusters.</p>':'');
      $$('[data-open-detail]').forEach(b=>b.onclick=()=>detail(Number(b.dataset.openDetail)));
    },30);
  };
  const bR=$('#dupScopeResults'),bA=$('#dupScopeAll');
  if(bR)bR.onclick=()=>run('results');
  if(bA)bA.onclick=()=>run('all');
  run(useResults?'results':'all');
}
let KG={nodes:[],edges:[],nodeMap:new Map(),canvas:null,ctx:null,scale:1,tx:0,ty:0,hover:null,selected:null,drag:null,pan:null,anim:0,steps:0,showEdgeLabels:false,mode:'results',baseHits:[],focusIndex:null};
const KG_COLORS={query:'#6d28d9',paper:'#184e77',author:'#c2410c',journal:'#047857',keyword:'#7c3aed',publisher:'#b45309',country:'#be123c',year:'#475569',nerRoot:'#0ea5e9',entity:'#0284c7',organization:'#0f766e',location:'#be185d',identifier:'#475569',place:'#be185d',doi:'#64748b',url:'#0369a1',method:'#db2777',hypRoot:'#7c3aed',hypothesis:'#8b5cf6',gapRoot:'#b7791f',gap:'#e59a12',context:'#0891b2',evidence:'#64748b',concept:'#2563eb'};
const KG_NAMES={query:'Search query',paper:'Title',author:'Author / Person',journal:'Journal / source',keyword:'Keyword',publisher:'Publisher',country:'Country',place:'Place',doi:'DOI',url:'URL',year:'Year',nerRoot:'NER analysis',entity:'Named entity',organization:'Organization',location:'Location',identifier:'Identifier',method:'Method / technology',hypRoot:'Hypothesis analysis',hypothesis:'Alternative hypothesis',gapRoot:'Research-gap analysis',gap:'Gap signal',context:'Context',evidence:'Evidence',concept:'Research concept'};
function splitAuthors(v){return (v||'').split(';').map(x=>x.trim()).filter(Boolean)}
function splitKeywords(v){return (v||'').split(';').map(x=>x.trim()).filter(Boolean)}
function nodeUrlFor(type,label,o){const enc=s=>encodeURIComponent(String(s||'').trim());if(type==='doi'){let d=String(label||'').trim().replace(/^https?:\/\/(dx\.)?doi\.org\//i,'');return d?'https://doi.org/'+d:''}if(type==='url')return safeUrl(label);if(type==='place')return 'https://www.google.com/maps/search/?api=1&query='+enc(label);if(type==='paper'&&o){let u=safeUrl(o.url);if(u)return u;let d=String(o.doi||'').replace(/^https?:\/\/(dx\.)?doi\.org\//i,'').trim();if(d)return 'https://doi.org/'+d;return ''}if(type==='author'){try{return authLinksForAuthor(label).viaf}catch(e){return 'https://viaf.org/viaf/search?query=local.personalNames+all+%22'+enc(label)+'%22'}}if(type==='journal')return 'https://www.worldcat.org/search?q='+enc(label);if(type==='publisher')return 'https://www.google.com/search?q='+enc(label+' publisher');if(type==='country'){const c=countryCanon(label)||label;return 'https://en.wikipedia.org/wiki/'+enc(String(c).replace(/ /g,'_'))}if(type==='year')return '';if(type==='keyword'||type==='concept'){try{return authLinksForSubject(label).lcsh}catch(e){return 'https://id.loc.gov/search/?q='+enc(label)+'&q=cs%3Ahttp%3A%2F%2Fid.loc.gov%2Fauthorities%2Fsubjects'}}if(type==='organization')return 'https://www.google.com/search?q='+enc(label);if(type==='location')return 'https://www.google.com/search?q='+enc(label);if(type==='identifier'){let m=String(label).match(/DOI:\s*(.+)/i);if(m)return 'https://doi.org/'+m[1].trim().replace(/^https?:\/\/(dx\.)?doi\.org\//i,'');return ''}if(type==='method')return 'https://scholar.google.com/scholar?q='+enc('"'+label+'"');if(type==='query')return '';return ''}
function kgNodeLinkHtml(n){let u=safeUrl(n&&n.url);if(!u)return '';return `<div class="tiny" style="margin:6px 0 4px"><b>URL:</b> <a href="${esc(u)}" target="_blank" rel="noopener" title="${esc(u)}">${esc(u.length>72?u.slice(0,70)+'…':u)}</a></div>`}
function kgAddNode(map,n){let key=n.type==='paper'?('paper|'+n.paperIndex):(n.type+'|'+norm(n.label));if(map.has(key)){let ex=map.get(key);ex.weight=(ex.weight||1)+1;if(n.paperIndex!==undefined&&ex.paperIndex===undefined)ex.paperIndex=n.paperIndex;if(!ex.url&&n.url)ex.url=n.url;if(n.cites!==undefined&&(ex.cites===undefined||n.cites>ex.cites))ex.cites=n.cites;return ex}n.id=key;n.weight=n.weight||1;n.x=n.x||0;n.y=n.y||0;n.vx=0;n.vy=0;n.fixed=false;if(!n.url)n.url=nodeUrlFor(n.type,n.label,n.paperIndex!==undefined?recObj(n.paperIndex):null)||'';map.set(key,n);return n}

/* ── Connected-relationship schema (from Connected_Relationships_for_different_Nodes.xlsx) ── */
const KG_ENTITY_TYPE={Author:'author',Title:'paper',Journal:'journal',Publisher:'publisher',Place:'place',Keywords:'keyword',Year:'year',DOI:'doi',URL:'url'};
const KG_REL_SCHEMA=[
{a:'Author',rel:'writes',b:'Title',rev:'is_written_by'},
{a:'Author',rel:'contributes_to',b:'Journal',rev:'has_contributor'},
{a:'Author',rel:'publishes_with',b:'Publisher',rev:'publishes_work_of'},
{a:'Author',rel:'publishes_in_place',b:'Place',rev:'hosts_publications_of'},
{a:'Author',rel:'uses',b:'Keywords',rev:'associated_with'},
{a:'Author',rel:'publishes_in_year',b:'Year',rev:'has_publication_by'},
{a:'Author',rel:'linked_by',b:'DOI',rev:'linked_work_of'},
{a:'Author',rel:'accessible_via',b:'URL',rev:'links_to_work_of'},
{a:'Title',rel:'published_in',b:'Journal',rev:'contains'},
{a:'Title',rel:'published_by',b:'Publisher',rev:'publishes'},
{a:'Title',rel:'published_at',b:'Place',rev:'hosts_publication'},
{a:'Title',rel:'described_by',b:'Keywords',rev:'describes'},
{a:'Title',rel:'appears_in',b:'Year',rev:'includes_title'},
{a:'Title',rel:'identified_by',b:'DOI',rev:'represents'},
{a:'Title',rel:'available_at',b:'URL',rev:'links_to'},
{a:'Journal',rel:'issued_by',b:'Publisher',rev:'issues'},
{a:'Journal',rel:'published_at',b:'Place',rev:'hosts_journal'},
{a:'Journal',rel:'indexed_by',b:'Keywords',rev:'used_in'},
{a:'Journal',rel:'active_in',b:'Year',rev:'includes_journal'},
{a:'Journal',rel:'represented_by',b:'DOI',rev:'represents_journal'},
{a:'Journal',rel:'accessible_at',b:'URL',rev:'links_to_journal'},
{a:'Publisher',rel:'located_in',b:'Place',rev:'hosts_publisher'},
{a:'Publisher',rel:'connected_with',b:'Keywords',rev:'connected_by'},
{a:'Publisher',rel:'operates_in',b:'Year',rev:'has_published_by'},
{a:'Publisher',rel:'assigns',b:'DOI',rev:'assigned_by'},
{a:'Publisher',rel:'provides',b:'URL',rev:'from_publisher'},
{a:'Place',rel:'associated_with',b:'Keywords',rev:'linked_to_place'},
{a:'Place',rel:'active_in',b:'Year',rev:'includes_place'},
{a:'Keywords',rel:'relevant_in',b:'Year',rev:'has_keywords'}
];
/* Which schema rows each model draws. Title is the hub and is always present. */
const KG_MODEL_SCOPE={
  bibliographic:{},
  coauthorship:{focus:'Author'},
  concept:{focus:'Keywords'},
  ecosystem:{within:['Publisher','Journal','Place']},
  temporal:{focus:'Year'},
  ner:{within:['Author','Journal','Publisher','Place','Keywords','DOI']}
};
function kgModelRows(modelId){
  const sc=KG_MODEL_SCOPE[modelId]||{};
  return KG_REL_SCHEMA.filter(r=>{
    if(sc.focus) return r.a===sc.focus||r.b===sc.focus;
    if(sc.within) return [r.a,r.b].every(x=>x==='Title'||sc.within.includes(x));
    return true;
  });
}
function kgLegendFor(modelId){
  const lines=kgModelRows(modelId).map(r=>`<b>${esc(r.rel)}</b> — ${esc(r.a)} → ${esc(r.b)} <span style="color:var(--muted)">(reverse: ${esc(r.rev)})</span>`);
  return lines.join('<br>');
}

/* ── Multiple Knowledge-Graph construction models (views of the schema above) ── */
const KG_MODELS = {
  bibliographic: {
    id: 'bibliographic',
    label: 'Bibliographic Metadata Model',
    desc: 'Full connected-relationship schema: every relationship in the sheet is drawn between the Title, Author, Journal, Publisher, Place, Keywords, Year, DOI and URL nodes of each record.',
    relations: kgLegendFor('bibliographic')
  },
  coauthorship: {
    id: 'coauthorship',
    label: 'Co-Authorship / Collaboration Network',
    desc: 'Author-centred view: only relationships where Author is one end are drawn (writes, contributes_to, publishes_with, uses, and so on).',
    relations: kgLegendFor('coauthorship')
  },
  concept: {
    id: 'concept',
    label: 'Concept / Keyword Co-occurrence Model',
    desc: 'Keyword-centred view: only relationships that involve Keywords are drawn (described_by, uses, indexed_by, connected_with, associated_with, relevant_in).',
    relations: kgLegendFor('concept')
  },
  ecosystem: {
    id: 'ecosystem',
    label: 'Publishing Ecosystem Model',
    desc: 'Publisher, Journal and Place relationships only (issued_by, published_at, located_in, published_by, published_in, and their Title links).',
    relations: kgLegendFor('ecosystem')
  },
  temporal: {
    id: 'temporal',
    label: 'Temporal Impact Model',
    desc: 'Year-centred view: only relationships that involve Year are drawn (appears_in, publishes_in_year, active_in, operates_in, relevant_in).',
    relations: kgLegendFor('temporal')
  },
  ner: {
    id: 'ner',
    label: 'NER Entity-Relation Model',
    desc: 'Entities extracted from titles, abstracts and metadata are attached to their records with the same schema: persons as Author, organisations as Publisher, locations as Place, methods and concepts as Keywords, identifiers as DOI, journals as Journal.',
    relations: kgLegendFor('ner')
  }
};

/* Generic builder. items: [{key, rank, score, o:{title,year,source,publisher,place,doi,url,cites}, authors:[], keywords:[]}] */
function kgSchemaBuild(items, modelId='bibliographic', opts={}){
  const model = KG_MODELS[modelId] || KG_MODELS.bibliographic;
  const active = new Set(opts.types ? [...opts.types] : ['author','journal','publisher','place','keyword','year','doi','url']);
  const isOn = name => KG_ENTITY_TYPE[name]==='paper' || active.has(KG_ENTITY_TYPE[name]);
  const rows = kgModelRows(model.id).filter(r => isOn(r.a) && isOn(r.b));
  const used = new Set(rows.flatMap(r => [r.a, r.b]));
  const map = new Map(), edges = [], edgeSeen = new Set();
  const addEdge = (a, b, relation, detail='', rev='') => {
    if(!a || !b || a === b) return;
    const ek = [a.id, b.id, relation].sort().join('§');
    if(edgeSeen.has(ek)) return;
    edgeSeen.add(ek);
    edges.push({a, b, relation, detail, rev});
  };
  // Model views relate each record only to its own entities (no query hub, no "matched search" edges)
  const qn = null;

  const perPaper = [];
  items.forEach((it, rank) => {
    const o = it.o;
    const pn = kgAddNode(map, {type:'paper', label: o.title || 'Untitled', paperIndex: it.key, cites: o.cites || 0,
      year: o.year, source: o.source, rank: rank + 1, score: it.score || 0, weight: 1 + Math.log1p(o.cites || 0), url: o.url || ''});
    const ents = {Title: [pn]};
    const add = (name, node) => { if(node) (ents[name] = ents[name] || []).push(node); };
    if(used.has('Author')) it.authors.slice(0, 8).forEach(a => add('Author', kgAddNode(map, {type:'author', label:a})));
    if(used.has('Journal') && o.source) add('Journal', kgAddNode(map, {type:'journal', label:o.source}));
    if(used.has('Publisher') && o.publisher) add('Publisher', kgAddNode(map, {type:'publisher', label:o.publisher}));
    if(used.has('Place') && o.place) add('Place', kgAddNode(map, {type:'place', label:o.place}));
    if(used.has('Keywords')) it.keywords.slice(0, 8).forEach(k => add('Keywords', kgAddNode(map, {type:'keyword', label:k})));
    if(used.has('Year') && o.year) add('Year', kgAddNode(map, {type:'year', label:String(o.year)}));
    const doi = String(o.doi || '').replace(/^https?:\/\/(dx\.)?doi\.org\//i, '').trim();
    if(used.has('DOI') && doi) add('DOI', kgAddNode(map, {type:'doi', label:doi}));
    const pageUrl = safeUrl(o.url);
    if(used.has('URL') && pageUrl) add('URL', kgAddNode(map, {type:'url', label:pageUrl.replace(/^https?:\/\//, ''), url:pageUrl}));
    perPaper.push({key: pn.id, ents});
  });

  // NER-extracted entities are attached to the records they were found in, using the same schema names
  if(modelId === 'ner' && opts.nerHits && typeof riNER === 'function'){
    const ner = riNER(opts.nerHits);
    const catMap = {person:'Author', organization:'Publisher', location:'Place', method:'Keywords', concept:'Keywords', identifier:'DOI', journal:'Journal'};
    Object.keys(catMap).forEach(cat => {
      const name = catMap[cat];
      if(!used.has(name)) return;
      const m = ner[cat];
      if(!m) return;
      const entries = m instanceof Map ? [...m.values()] : [];
      entries.slice(0, 20).forEach(e => {
        const node = kgAddNode(map, {type: KG_ENTITY_TYPE[name], label: e.label, weight: e.count || 1});
        (e.papers || []).forEach(pi => {
          const pp = perPaper.find(p => p.key === 'paper|' + pi);
          if(pp) (pp.ents[name] = pp.ents[name] || []).push(node);
        });
      });
    });
  }

  // Every edge comes from the schema: A --rel--> B, with the reverse name shown from the B end
  perPaper.forEach(pp => {
    rows.forEach(r => {
      const A = pp.ents[r.a] || [];
      const B = pp.ents[r.b] || [];
      A.forEach(x => B.forEach(y => addEdge(x, y, r.rel, `${r.a} → ${r.b}`, r.rev)));
    });
  });

  return {nodes: [...map.values()], edges, model};
}

function kgBuildByModel(hits, modelId='bibliographic', opts={}){
  const limit = Number(opts.limit || 20);
  const chosen = hits.slice(0, limit);
  const items = chosen.map((h, rank) => {
    const idx = h.i ?? h, o = recObj(idx);
    const doiText = String(o.doi || '').replace(/^https?:\/\/(dx\.)?doi\.org\//i, '').trim();
    const url = safeUrl(o.url) || (doiText ? 'https://doi.org/' + doiText : '');
    return {
      key: idx, rank, score: h.score || 0,
      o: {title:o.title, year:o.year, source:o.source, publisher:o.publisher, place:o.place, doi:o.doi, url, cites:o.cites},
      authors: splitAuthors(o.authors),
      keywords: splitKeywords(o.keywords)
    };
  });
  const q = (state.query || '').trim();
  return kgSchemaBuild(items, modelId, {
    types: opts.types,
    includeSearchRoot: opts.includeSearchRoot !== false,
    rootLabel: q ? `Query: ${q}` : 'Current result set',
    nerHits: chosen.map(h => ({i: h.i ?? h}))
  });
}

function kgBuild(hits,opts={}){let limit=Number(opts.limit||20),types=opts.types||new Set(['author','journal','keyword','publisher','country','year']);let chosen=hits.slice(0,limit);let map=new Map(),edges=[],edgeSeen=new Set();let qn=null;if(opts.includeSearchRoot!==false){let queryLabel=state.query.trim()?`Query: ${state.query.trim()}`:'Current result set';qn=kgAddNode(map,{type:'query',label:queryLabel,weight:Math.max(1,chosen.length)})}
 const addEdge=(a,b,relation,detail='')=>{if(!a||!b)return;let ek=[a.id,b.id,relation].sort().join('§');if(edgeSeen.has(ek))return;edgeSeen.add(ek);edges.push({a,b,relation,detail})};
 chosen.forEach((h,rank)=>{let idx=h.i??h,o=recObj(idx);let pn=kgAddNode(map,{type:'paper',label:o.title,paperIndex:idx,cites:o.cites,year:o.year,source:o.source,rank:rank+1,score:h.score||0,weight:1,url:nodeUrlFor('paper',o.title,o)});if(qn)addEdge(qn,pn,'matched search',state.query?`rank ${rank+1}`:'current ordering');
   if(types.has('author'))splitAuthors(o.authors).slice(0,6).forEach(a=>addEdge(pn,kgAddNode(map,{type:'author',label:a,url:nodeUrlFor('author',a)}),'authored by'));
   if(types.has('journal')&&o.source)addEdge(pn,kgAddNode(map,{type:'journal',label:o.source,url:nodeUrlFor('journal',o.source)}),'published in');
   if(types.has('keyword'))splitKeywords(o.keywords).slice(0,7).forEach(k=>addEdge(pn,kgAddNode(map,{type:'keyword',label:k,url:nodeUrlFor('keyword',k)}),'has keyword'));
   if(types.has('publisher')&&o.publisher)addEdge(pn,kgAddNode(map,{type:'publisher',label:o.publisher,url:nodeUrlFor('publisher',o.publisher)}),'published by');
   if(types.has('country')&&o.country)addEdge(pn,kgAddNode(map,{type:'country',label:o.country,url:nodeUrlFor('country',o.country)}),'associated country');
   if(types.has('year')&&o.year)addEdge(pn,kgAddNode(map,{type:'year',label:String(o.year),url:nodeUrlFor('year',String(o.year))}),'published in year');
 });
 let nodes=[...map.values()];
 // Shared entity nodes already reveal paper-paper relationships. Add explicit paper links only for strong relationships.
 let papers=nodes.filter(n=>n.type==='paper');
 for(let a=0;a<papers.length;a++)for(let b=a+1;b<papers.length;b++){let oa=recObj(papers[a].paperIndex),ob=recObj(papers[b].paperIndex),rels=[];let aa=new Set(splitAuthors(oa.authors).map(norm)),ab=splitAuthors(ob.authors).map(norm);let sharedA=ab.filter(x=>aa.has(x)&&x);if(sharedA.length)rels.push('shared author');let ka=new Set(splitKeywords(oa.keywords).map(norm)),kb=splitKeywords(ob.keywords).map(norm);let sharedK=kb.filter(x=>ka.has(x)&&x);if(sharedK.length>=2)rels.push(`${sharedK.length} shared keywords`);if(oa.source&&oa.source===ob.source)rels.push('same journal');if(sharedA.length||sharedK.length>=3){addEdge(papers[a],papers[b],'related paper',rels.join(', '))}}
 return {nodes,edges,chosen};}
function kgInitPositions(){let W=1100,H=640,papers=KG.nodes.filter(n=>n.type==='paper'),root=KG.nodes.find(n=>n.type==='query'||n.root),entities=KG.nodes.filter(n=>n.type!=='paper'&&n!==root);if(root){root.x=W/2;root.y=H/2;root.fixed=true}papers.forEach((n,k)=>{let a=(Math.PI*2*k/Math.max(1,papers.length))-Math.PI/2,r=130+35*(k%3);n.x=W/2+r*Math.cos(a);n.y=H/2+r*Math.sin(a)});entities.forEach((n,k)=>{let a=(Math.PI*2*k/Math.max(1,entities.length))+0.37,r=285+55*(k%4);n.x=W/2+r*Math.cos(a);n.y=H/2+r*Math.sin(a)});KG.steps=0}
function kgRadius(n){if(n.type==='paper')return 8+Math.min(7,Math.log1p(n.cites||0)*1.15);if(n.type==='query'||n.root)return 18;if(n.type==='journal')return 11;if(n.type==='author')return 9;if(n.type==='keyword')return 7+Math.min(4,Math.log1p(n.weight||1));return 7+Math.min(3,Math.log1p(n.weight||1))}
function kgResize(){if(!KG.canvas)return;let rect=KG.canvas.getBoundingClientRect(),dpr=Math.min(2,window.devicePixelRatio||1);KG.canvas.width=Math.max(300,Math.floor(rect.width*dpr));KG.canvas.height=Math.max(300,Math.floor(rect.height*dpr));KG.ctx.setTransform(dpr,0,0,dpr,0,0);kgDraw()}
function kgStep(){let ns=KG.nodes,es=KG.edges,N=ns.length;let rep=N>180?4200:6000;for(let i=0;i<N;i++){let a=ns[i];if(a.fixed)continue;let fx=0,fy=0;for(let j=0;j<N;j++){if(i===j)continue;let b=ns[j],dx=a.x-b.x,dy=a.y-b.y,d2=dx*dx+dy*dy+90;let f=rep/d2;fx+=dx*f;fy+=dy*f}a.vx=(a.vx+fx*.012)*.86;a.vy=(a.vy+fy*.012)*.86}
 es.forEach(e=>{let a=e.a,b=e.b,dx=b.x-a.x,dy=b.y-a.y,d=Math.sqrt(dx*dx+dy*dy)||1;let target=e.relation==='matched search'?145:(e.relation==='related paper'?115:88);let f=(d-target)*.006,fx=dx/d*f,fy=dy/d*f;if(!a.fixed){a.vx+=fx;a.vy+=fy}if(!b.fixed){b.vx-=fx;b.vy-=fy}});
 ns.forEach(n=>{if(n.fixed)return;n.vx+=(550-n.x)*.00055;n.vy+=(320-n.y)*.00055;n.x+=n.vx;n.y+=n.vy});KG.steps++}
function kgWorldToScreen(x,y){return{x:x*KG.scale+KG.tx,y:y*KG.scale+KG.ty}}
function kgScreenToWorld(x,y){return{x:(x-KG.tx)/KG.scale,y:(y-KG.ty)/KG.scale}}
function kgDraw(){
 if(!KG.ctx||!KG.canvas)return;
 const ctx=KG.ctx,rect=KG.canvas.getBoundingClientRect();
 ctx.clearRect(0,0,rect.width,rect.height);
 // Subtle graph-paper background helps distinguish the canvas from an empty panel.
 ctx.save();
 ctx.fillStyle='#ffffff';ctx.fillRect(0,0,rect.width,rect.height);
 ctx.strokeStyle='rgba(148,163,184,.10)';ctx.lineWidth=1;
 const grid=32;
 for(let x=0;x<rect.width;x+=grid){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,rect.height);ctx.stroke()}
 for(let y=0;y<rect.height;y+=grid){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(rect.width,y);ctx.stroke()}
 ctx.restore();
 ctx.save();ctx.translate(KG.tx,KG.ty);ctx.scale(KG.scale,KG.scale);ctx.lineCap='round';
 // Edges first, so nodes remain above them. Use distinct relation colours and line widths.
 KG.edges.forEach(e=>{
   const rel=String(e.relation||'related');
   ctx.beginPath();ctx.moveTo(e.a.x,e.a.y);ctx.lineTo(e.b.x,e.b.y);
   ctx.strokeStyle=rel==='related paper'?'rgba(109,40,217,.62)':rel==='matched search'?'rgba(24,78,119,.48)':'rgba(15,118,110,.52)';
   ctx.lineWidth=(rel==='related paper'?2.2:1.5)/Math.max(.7,KG.scale);
   ctx.stroke();
   // Direction indicator makes subject–predicate–object flow easier to read.
   const dx=e.b.x-e.a.x,dy=e.b.y-e.a.y,d=Math.hypot(dx,dy)||1;
   const rr=kgRadius(e.b)+2,ax=e.b.x-dx/d*rr,ay=e.b.y-dy/d*rr;
   const ang=Math.atan2(dy,dx),ah=5/Math.max(.7,KG.scale);
   ctx.beginPath();ctx.moveTo(ax,ay);
   ctx.lineTo(ax-ah*Math.cos(ang-.48),ay-ah*Math.sin(ang-.48));
   ctx.moveTo(ax,ay);ctx.lineTo(ax-ah*Math.cos(ang+.48),ay-ah*Math.sin(ang+.48));
   ctx.strokeStyle='rgba(71,85,105,.75)';ctx.lineWidth=1.25/Math.max(.7,KG.scale);ctx.stroke();
   if(KG.showEdgeLabels&&KG.scale>.42){
     const mx=(e.a.x+e.b.x)/2,my=(e.a.y+e.b.y)/2,txt=rel;
     ctx.font='600 10px system-ui';const w=ctx.measureText(txt).width;
     ctx.fillStyle='rgba(255,255,255,.96)';ctx.fillRect(mx-w/2-4,my-8,w+8,15);
     ctx.strokeStyle='rgba(203,213,225,.9)';ctx.lineWidth=.7;ctx.strokeRect(mx-w/2-4,my-8,w+8,15);
     ctx.fillStyle='#334155';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(txt,mx,my-.5);
   }
 });
 // Draw every entity as a substantial node and label every node by default.
 KG.nodes.forEach(n=>{
   const r=Math.max(8,kgRadius(n)+(n.type==='paper'?2:3));
   const col=KG_COLORS[n.type]||'#64748b';
   ctx.beginPath();ctx.arc(n.x,n.y,r,0,Math.PI*2);
   ctx.fillStyle=col;ctx.fill();
   ctx.strokeStyle=KG.selected===n?'#111827':(KG.hover===n?'#ffffff':'rgba(255,255,255,.98)');
   ctx.lineWidth=(KG.selected===n?4:2.5)/Math.max(.65,KG.scale);ctx.stroke();
   if(KG.selected===n){ctx.beginPath();ctx.arc(n.x,n.y,r+5,0,Math.PI*2);ctx.strokeStyle='#f59e0b';ctx.lineWidth=2/Math.max(.65,KG.scale);ctx.stroke()}
   const raw=n.type==='paper'?((n.rank?n.rank+'. ':'')+n.label):n.label;
   const label=String(raw||KG_NAMES[n.type]||n.type);
   // Always label nodes at normal zoom; shorten only long titles to avoid obscuring the graph.
   if(KG.scale>.34){
     const maxChars=n.type==='paper'?30:24;
     const shown=label.length>maxChars?label.slice(0,maxChars-1)+'…':label;
     const fs=n.type==='query'||n.root?12:(n.type==='paper'?10.5:10.5);
     ctx.font=(n.type==='query'||n.root?'700 ':'600 ')+fs+'px system-ui';
     ctx.textAlign='center';ctx.textBaseline='top';
     const tw=ctx.measureText(shown).width,ly=n.y+r+4,pad=4;
     ctx.fillStyle='rgba(255,255,255,.97)';
     ctx.fillRect(n.x-tw/2-pad,ly-2,tw+pad*2,15);
     ctx.strokeStyle='rgba(203,213,225,.9)';ctx.lineWidth=.7;ctx.strokeRect(n.x-tw/2-pad,ly-2,tw+pad*2,15);
     ctx.fillStyle='#172b45';ctx.fillText(shown,n.x,ly);
   }
 });
 ctx.restore();
}
function kgAnimate(){kgStep();kgDraw();if(KG.steps<260||KG.drag)KG.anim=requestAnimationFrame(kgAnimate)}
function kgFit(){if(!KG.nodes.length)return;let xs=KG.nodes.map(n=>n.x),ys=KG.nodes.map(n=>n.y),minx=Math.min(...xs)-60,maxx=Math.max(...xs)+60,miny=Math.min(...ys)-60,maxy=Math.max(...ys)+60,rect=KG.canvas.getBoundingClientRect();let sc=Math.min(rect.width/(maxx-minx),rect.height/(maxy-miny),1.35);KG.scale=Math.max(.22,sc);KG.tx=(rect.width-(minx+maxx)*KG.scale)/2;KG.ty=(rect.height-(miny+maxy)*KG.scale)/2;kgDraw()}
function kgHit(sx,sy){let w=kgScreenToWorld(sx,sy),best=null,bd=1e9;for(let n of KG.nodes){let dx=w.x-n.x,dy=w.y-n.y,d=Math.sqrt(dx*dx+dy*dy);if(d<kgRadius(n)+8/KG.scale&&d<bd){best=n;bd=d}}return best}
function kgSelectionHtml(n){if(!n)return '<div class="tiny">Click a node to inspect its metadata relationships. Drag nodes to reposition them; drag empty space to pan; use the mouse wheel or trackpad to zoom.</div>';let links=KG.edges.filter(e=>e.a===n||e.b===n).slice(0,30);if(!n.url)n.url=nodeUrlFor(n.type,n.label,n.paperIndex!==undefined?recObj(n.paperIndex):null)||'';let body=`<div class="kg-node-title">${esc(n.label)}</div><div class="badges"><span class="badge">${esc(KG_NAMES[n.type]||n.type)}</span>${n.type==='paper'?`<span class="badge cites">Cited ${Number(n.cites||0).toLocaleString()}×</span>`:''}${KG.edges.filter(e=>e.a===n||e.b===n).length>1?`<span class="badge">${KG.edges.filter(e=>e.a===n||e.b===n).length} links</span>`:''}${safeUrl(n.url)?'<span class="badge access">URL</span>':''}</div>`;
 body+=kgNodeLinkHtml(n);if(n.description)body+=`<div class="evidence-quote">${esc(n.description)}</div>`;if(n.type==='paper'){let o=recObj(n.paperIndex);body+=`<div class="tiny">${esc(o.authors)} · ${o.year} · ${esc(o.source)}</div><div class="actions"><button class="primary" id="kgDetails">Record details</button><button id="kgSingle">Focus graph</button>${safeUrl(n.url)?`<a class="full" href="${esc(safeUrl(n.url))}" target="_blank" rel="noopener">Open URL ↗</a>`:''}</div>`}else if(['journal','publisher','place','year','keyword','author'].includes(n.type)){body+=`<div class="actions"><button class="ghost kg-search-node" id="kgSearchNode">Search / filter by this ${esc(KG_NAMES[n.type]||n.type).toLowerCase()}</button>${safeUrl(n.url)?`<a class="full" href="${esc(safeUrl(n.url))}" target="_blank" rel="noopener">Open URL ↗</a>`:''}</div>`}else if(safeUrl(n.url)){body+=`<div class="actions"><a class="full" href="${esc(safeUrl(n.url))}" target="_blank" rel="noopener">Open URL ↗</a></div>`}
 body+=`<h4>Relationships (${links.length}${KG.edges.filter(e=>e.a===n||e.b===n).length>30?'+':''})</h4><div class="kg-rel-list">`+links.map(e=>{let other=e.a===n?e.b:e.a;if(!other.url)other.url=nodeUrlFor(other.type,other.label,other.paperIndex!==undefined?recObj(other.paperIndex):null)||'';return `<div class="kg-rel"><b>${esc(e.rev&&e.b===n?e.rev:e.relation)}</b>${esc(other.label)}${e.detail?`<div class="tiny">${esc(e.detail)}</div>`:''}${safeUrl(other.url)?`<div class="tiny"><a href="${esc(safeUrl(other.url))}" target="_blank" rel="noopener">URL ↗</a></div>`:''}</div>`}).join('')+'</div>';return body}
function kgSelect(n){KG.selected=n;$('#kgSelection').innerHTML=kgSelectionHtml(n);if(n&&n.type==='paper'){$('#kgDetails').onclick=()=>detail(n.paperIndex);$('#kgSingle').onclick=()=>graph(n.paperIndex)}else if(n&&['journal','publisher','place','year','keyword','author'].includes(n.type)&&$('#kgSearchNode')){$('#kgSearchNode').onclick=()=>kgSearchByNode(n)}kgDraw()}
function kgSearchByNode(n){closeModal();state.savedOnly=false;state.advanced=[];$('#advRows').innerHTML='';addAdvRow();if(n.type==='journal'){let idx=S.findIndex(x=>norm(x)===norm(n.label));if(idx>=0){state.source=String(idx);$('#sourceFilter').value=state.source}}else if(n.type==='publisher'){let idx=PUB.findIndex(x=>norm(x)===norm(n.label));if(idx>=0){state.publisher=String(idx);$('#publisherFilter').value=state.publisher}}else if(n.type==='place'){state.query='"'+n.label+'"';$('#q').value=state.query}else if(n.type==='year'){state.yearSet=new Set([Number(n.label)]);$$('[data-year]').forEach(x=>x.checked=Number(x.dataset.year)===Number(n.label))}else if(n.type==='keyword'){state.query='"'+n.label+'"';$('#q').value=state.query}else if(n.type==='author'){state.query='"'+n.label+'"';$('#q').value=state.query}state.page=1;doSearch()}
function kgBindCanvas(){let c=KG.canvas,tip=$('#kgTooltip');const pos=e=>{let r=c.getBoundingClientRect();return{x:e.clientX-r.left,y:e.clientY-r.top}};c.onpointerdown=e=>{let p=pos(e),n=kgHit(p.x,p.y);c.setPointerCapture(e.pointerId);if(n){KG.drag={n,p};n.fixed=true;kgSelect(n)}else KG.pan={x:p.x,y:p.y,tx:KG.tx,ty:KG.ty};c.classList.add('dragging')};c.onpointermove=e=>{let p=pos(e);if(KG.drag){let w=kgScreenToWorld(p.x,p.y);KG.drag.n.x=w.x;KG.drag.n.y=w.y;KG.drag.n.vx=KG.drag.n.vy=0;kgDraw();return}if(KG.pan){KG.tx=KG.pan.tx+(p.x-KG.pan.x);KG.ty=KG.pan.ty+(p.y-KG.pan.y);kgDraw();return}let n=kgHit(p.x,p.y);KG.hover=n;if(n){tip.style.display='block';tip.style.left=Math.min(p.x+12,c.clientWidth-290)+'px';tip.style.top=Math.max(6,p.y-8)+'px';if(!n.url)n.url=nodeUrlFor(n.type,n.label,n.paperIndex!==undefined?recObj(n.paperIndex):null)||'';tip.innerHTML=`<b>${esc(KG_NAMES[n.type]||n.type)}</b><br>${esc(n.label)}${n.type==='paper'?`<br>Cited ${Number(n.cites||0).toLocaleString()}×`:''}${safeUrl(n.url)?`<br><span style="opacity:.9">URL: ${esc(n.url.length>60?n.url.slice(0,58)+'…':n.url)}</span>`:''}`}else tip.style.display='none';kgDraw()};c.onpointerup=e=>{if(KG.drag){if(KG.drag.n.type!=='query')KG.drag.n.fixed=false;KG.drag=null}KG.pan=null;c.classList.remove('dragging');KG.steps=Math.min(KG.steps,220);if(KG.steps<260){cancelAnimationFrame(KG.anim);KG.anim=requestAnimationFrame(kgAnimate)}};c.onpointerleave=()=>{KG.hover=null;tip.style.display='none';kgDraw()};c.ondblclick=e=>{let p=pos(e),n=kgHit(p.x,p.y);if(n){kgSelect(n);if(n.type==='paper')detail(n.paperIndex)}};c.onwheel=e=>{e.preventDefault();let p=pos(e),before=kgScreenToWorld(p.x,p.y),factor=e.deltaY<0?1.12:.89;KG.scale=Math.max(.18,Math.min(3.2,KG.scale*factor));KG.tx=p.x-before.x*KG.scale;KG.ty=p.y-before.y*KG.scale;kgDraw()}}
function kgStats(){let counts={};KG.nodes.forEach(n=>counts[n.type]=(counts[n.type]||0)+1);return `<div class="kg-statgrid"><div class="kg-stat"><b>${KG.nodes.length}</b><span>nodes</span></div><div class="kg-stat"><b>${KG.edges.length}</b><span>relationships</span></div><div class="kg-stat"><b>${counts.paper||0}</b><span>papers</span></div><div class="kg-stat"><b>${KG.edges.filter(e=>e.relation==='related paper').length}</b><span>paper links</span></div></div>`}
function kgLegend(){return Object.entries(KG_NAMES).filter(([k])=>k!=='query').map(([k,v])=>`<div class="kg-leg"><span class="kg-dot" style="background:${KG_COLORS[k]}"></span>${esc(v)}</div>`).join('')}
function kgOpen(hits,mode='results',focusIndex=null){if(!hits.length){toast('No results available for graph');return}KG.mode=mode;KG.baseHits=hits;KG.focusIndex=focusIndex;let isSingle=mode==='single';let defaultLimit=isSingle?Math.min(12,hits.length):Math.min(20,hits.length);$('#modalCard').classList.add('graph-modal-card');showModal(`<h2>${isSingle?'Record knowledge graph':'Search Results Knowledge Graph'}</h2><p class="tiny">Select a <b>Knowledge Graph construction model</b> from the toolbar. Each model applies a different appropriate schema and edge rules (bibliographic metadata, co-authorship network, concept co-occurrence, publishing ecosystem, temporal impact, or NER entities). Citation-reference edges are not shown because individual reference lists are not present in the dataset.</p><div class="kg-toolbar"><label>KG Model <select id="kgModel">${Object.values(KG_MODELS).map(m=>`<option value="${m.id}">${m.label}</option>`).join('')}</select></label>${isSingle?'':`<label>Top results <select id="kgLimit"><option>10</option><option selected>20</option><option>30</option><option>40</option></select></label>`}<label><input type="checkbox" class="kgType" value="author" checked>Authors</label><label><input type="checkbox" class="kgType" value="journal" checked>Journals</label><label><input type="checkbox" class="kgType" value="keyword" checked>Keywords</label><label><input type="checkbox" class="kgType" value="publisher" checked>Publishers</label><label><input type="checkbox" class="kgType" value="place" checked>Places</label><label><input type="checkbox" class="kgType" value="year" checked>Years</label><label><input type="checkbox" class="kgType" value="doi" checked>DOIs</label><label><input type="checkbox" class="kgType" value="url" checked>URLs</label><label><input type="checkbox" id="kgEdgeLabels">Edge labels</label><span class="spacer"></span><button class="ghost" id="kgFit">Fit</button><button class="ghost" id="kgReset">Re-layout</button><button class="ghost" id="kgPng">Save PNG</button></div><div class="kg-layout"><div class="kg-stage"><canvas id="kgCanvas" aria-label="Interactive bibliographic knowledge graph"></canvas><div class="kg-tooltip" id="kgTooltip"></div></div><aside class="kg-side"><h3>Graph summary</h3><div id="kgStats"></div><h4>Selected node</h4><div id="kgSelection"></div><h4>Node types</h4><div class="kg-legend">${kgLegend()}</div><h4>Model description</h4><div class="kg-edge-key" id="kgModelDesc" style="font-size:12px;color:var(--muted);margin-bottom:8px"></div><h4>Relationship meanings</h4><div class="kg-edge-key" id="kgEdgeKey"><b>matched search</b> — paper is in the selected search result set<br><b>authored by</b> — author metadata<br><b>published in</b> — journal/source metadata<br><b>has keyword</b> — keyword metadata<br><b>published by</b> — publisher metadata<br><b>associated country</b> — country field<br><b>published in year</b> — year field<br><b>related paper</b> — strong overlap through shared author and/or multiple shared keywords</div><div class="kg-note">The graph does not claim that metadata proximity is a citation relationship.</div></aside></div>`);
 const rebuild=()=>{
  const modelId = ($('#kgModel')&&$('#kgModel').value) || 'bibliographic';
  const model = KG_MODELS[modelId] || KG_MODELS.bibliographic;
  let types = new Set($$('.kgType:checked').map(x=>x.value));
  const limit = isSingle ? hits.length : Number($('#kgLimit')?.value||defaultLimit);
  const g = kgBuildByModel(hits, modelId, {limit, types, includeSearchRoot:!isSingle});
  KG.nodes = g.nodes; KG.edges = g.edges;
  KG.nodeMap = new Map(KG.nodes.map(n=>[n.id,n]));
  KG.canvas = $('#kgCanvas'); KG.ctx = KG.canvas.getContext('2d');
  KG.scale=1; KG.tx=0; KG.ty=0; KG.selected=null;
  // Update dynamic help panels
  const keyEl = document.getElementById('kgEdgeKey');
  const descEl = document.getElementById('kgModelDesc');
  if(keyEl) keyEl.innerHTML = model.relations;
  if(descEl) descEl.textContent = model.desc;
  kgInitPositions(); kgResize();
  $('#kgStats').innerHTML = kgStats();
  $('#kgSelection').innerHTML = kgSelectionHtml(null);
  kgBindCanvas();
  cancelAnimationFrame(KG.anim);
  KG.anim = requestAnimationFrame(kgAnimate);
  setTimeout(()=>kgFit(),160);
};
 rebuild();
 $$('.kgType').forEach(x=>x.onchange=rebuild);
 if($('#kgLimit')) $('#kgLimit').onchange=rebuild;
 if($('#kgModel')) $('#kgModel').onchange=rebuild;
 $('#kgEdgeLabels').onchange=e=>{KG.showEdgeLabels=e.target.checked;kgDraw()};
 $('#kgFit').onclick=kgFit;
 $('#kgReset').onclick=()=>{kgInitPositions();cancelAnimationFrame(KG.anim);KG.anim=requestAnimationFrame(kgAnimate);setTimeout(()=>kgFit(),200)};$('#kgPng').onclick=()=>{kgDraw();let a=document.createElement('a');a.download='library_knowledge_graph.png';a.href=KG.canvas.toDataURL('image/png');a.click()};window.onresize=()=>{if($('#modal').classList.contains('open')&&KG.canvas)kgResize()}}
function graphResults(){if(!currentResults.length){toast('Run a search first');return}kgOpen(currentResults,'results')}
function graph(i){let base=recObj(i),bk=new Set(splitKeywords(base.keywords).map(norm)),ba=new Set(splitAuthors(base.authors).map(norm));let rel=[{i,score:999}];for(let j=0;j<R.length;j++){if(j===i)continue;let o=recObj(j),score=0;if(o.source&&o.source===base.source)score+=2;let oa=splitAuthors(o.authors).map(norm);for(let a of oa)if(ba.has(a)&&a)score+=10;let ok=splitKeywords(o.keywords).map(norm),over=ok.filter(k=>bk.has(k)&&k).length;score+=over*3;if(score>=5)rel.push({i:j,score})}rel.sort((a,b)=>b.score-a.score||R[b.i][0]-R[a.i][0]);kgOpen(rel.slice(0,15),'single',i)}

/* ===== Local Research Intelligence: NER, Hypotheses & Research Gaps ===== */
const RI_METHODS=[
 ['systematic review',/\bsystematic review\b/i],['literature review',/\bliterature review\b/i],['bibliometric analysis',/\bbibliometric|scientometric\b/i],['survey',/\bsurvey|questionnaire\b/i],['interview',/\binterviews?\b/i],['case study',/\bcase stud(?:y|ies)\b/i],['content analysis',/\bcontent analysis\b/i],['thematic analysis',/\bthematic analysis\b/i],['qualitative',/\bqualitative\b/i],['quantitative',/\bquantitative\b/i],['mixed methods',/\bmixed[- ]methods?\b/i],['experiment',/\bexperiment(?:al|s)?\b/i],['machine learning',/\bmachine learning\b/i],['deep learning',/\bdeep learning\b/i],['natural language processing',/\bnatural language processing|\bNLP\b/i],['network analysis',/\bnetwork analysis\b/i],['regression',/\bregression\b/i],['SEM',/\bstructural equation model(?:ing|ling)?|\bSEM\b/i],['focus group',/\bfocus groups?\b/i],['ethnography',/\bethnograph(?:y|ic)\b/i],['simulation',/\bsimulation\b/i]
];
const RI_GAP_CUES=[/\bresearch gap\b/i,/\black of\b/i,/\blacks?\b/i,/\blimited (?:research|evidence|knowledge|studies|understanding)\b/i,/\bfew studies\b/i,/\blittle (?:research|evidence|attention|is known)\b/i,/\bscarce\b/i,/\bunderexplor(?:ed|ation)\b/i,/\bunderstud(?:ied|y)\b/i,/\bremains? (?:unclear|unknown|unexplored|poorly understood)\b/i,/\bnot (?:yet )?been (?:examined|studied|investigated|explored)\b/i,/\bfuture research\b/i,/\bfurther research\b/i,/\bneed(?:s|ed)? for (?:more|further|additional|future) (?:research|study|studies|investigation)\b/i,/\binsufficient (?:research|evidence|attention|knowledge)\b/i,/\bpoorly understood\b/i,/\bhas received little attention\b/i];
const RI_HYP_CUES=[/\bhypothes(?:is|es|ize|ised|ized)\b/i,/\bwe (?:expect|predict|propose)\b/i,/\bit is (?:expected|hypothesized|hypothesised)\b/i,/\bwe test(?:ed)? whether\b/i];
const RI_ORG_CUES=/\b(?:university|institute|institution|department|centre|center|association|college|school|academy|ministry|council|laboratory|laboratories|agency|foundation|library|libraries|corporation|society)\b/i;
function riScopeHits(focusIndex=null){if(focusIndex!==null&&focusIndex!==undefined)return [{i:Number(focusIndex),score:999,why:[]}];let n=Number($('#riScope')?.value||20);return currentResults.slice(0,n)}
function riSentenceSplit(text){return String(text||'').replace(/\s+/g,' ').split(/(?<=[.!?])\s+(?=[A-Z0-9])/).map(x=>x.trim()).filter(x=>x.length>25)}
function riTopKeywords(hits,max=14){let m=new Map();for(let h of hits){let o=recObj(h.i);for(let k of splitKeywords(o.keywords)){let nk=norm(k);if(!nk||nk.length<3)continue;let e=m.get(nk)||{label:k,count:0,papers:new Set()};if(!e.papers.has(h.i)){e.count++;e.papers.add(h.i)}m.set(nk,e)}}return [...m.values()].sort((a,b)=>b.count-a.count||a.label.localeCompare(b.label)).slice(0,max)}
function riMethodsFor(o){let text=(o.title+' '+o.abstract+' '+o.keywords);return RI_METHODS.filter(([,re])=>re.test(text)).map(([name])=>name)}
function riCapOrgCandidates(text){let out=[];for(let sent of riSentenceSplit(text)){if(!RI_ORG_CUES.test(sent))continue;let words=sent.replace(/[(),;:]/g,' ').split(/\s+/);for(let i=0;i<words.length;i++){if(!RI_ORG_CUES.test(words[i]))continue;let a=Math.max(0,i-5),b=Math.min(words.length,i+2),p=words.slice(a,b).join(' ').replace(/^[^A-Z]+/,'').trim();if(p.length>=5&&p.length<=100)out.push(p)}}return [...new Set(out)].slice(0,8)}
function riNER(hits){let cats={person:new Map(),organization:new Map(),location:new Map(),journal:new Map(),identifier:new Map(),concept:new Map(),method:new Map()};let add=(cat,label,pi,source='metadata')=>{label=String(label||'').trim();if(!label)return;let key=norm(label),m=cats[cat],e=m.get(key)||{label,count:0,papers:new Set(),source};e.count++;e.papers.add(pi);m.set(key,e)};
 for(let h of hits){let o=recObj(h.i);splitAuthors(o.authors).forEach(x=>add('person',x,h.i));if(o.publisher)add('organization',o.publisher,h.i);if(o.country)add('location',o.country,h.i);if(o.place)add('location',o.place,h.i);if(o.source)add('journal',o.source,h.i);if(o.doi)add('identifier','DOI: '+o.doi,h.i);if(o.issn)add('identifier','ISSN: '+o.issn,h.i);splitKeywords(o.keywords).slice(0,14).forEach(x=>add('concept',x,h.i));riMethodsFor(o).forEach(x=>add('method',x,h.i));riCapOrgCandidates((o.title||'')+' '+(o.abstract||'')).forEach(x=>add('organization',x,h.i,'heuristic text'))}
 let sorted={};for(let [k,m] of Object.entries(cats))sorted[k]=[...m.values()].sort((a,b)=>b.papers.size-a.papers.size||a.label.localeCompare(b.label));return sorted}
function riNERGraph(hits,ner){let root={id:'ner-root',type:'nerRoot',label:'Named Entity Recognition',root:true,weight:hits.length,description:'Entity graph derived from structured bibliographic metadata plus conservative local text patterns.'},nodes=[root],edges=[],map=new Map([[root.id,root]]),seen=new Set();let addNode=(id,type,label,extra={})=>{if(map.has(id))return map.get(id);let n={id,type,label,weight:1,...extra,x:0,y:0,vx:0,vy:0,fixed:false};map.set(id,n);nodes.push(n);return n},edge=(a,b,relation,detail='')=>{let k=a.id+'|'+b.id+'|'+relation;if(seen.has(k))return;seen.add(k);edges.push({a,b,relation,detail})};
 for(let h of hits){let o=recObj(h.i),p=addNode('paper|'+h.i,'paper',o.title,{paperIndex:h.i,cites:o.cites,year:o.year,source:o.source,rank:nodes.filter(x=>x.type==='paper').length+1,url:nodeUrlFor('paper',o.title,o)});edge(root,p,'analyzes paper');splitAuthors(o.authors).slice(0,5).forEach(v=>edge(p,addNode('author|'+norm(v),'author',v),'mentions person'));if(o.publisher)edge(p,addNode('org|'+norm(o.publisher),'organization',o.publisher),'published by');if(o.country)edge(p,addNode('loc|'+norm(o.country),'location',o.country),'associated location');if(o.source)edge(p,addNode('journal|'+norm(o.source),'journal',o.source),'published in');splitKeywords(o.keywords).slice(0,7).forEach(v=>edge(p,addNode('concept|'+norm(v),'concept',v),'mentions concept'));riMethodsFor(o).slice(0,4).forEach(v=>edge(p,addNode('method|'+norm(v),'method',v),'uses / mentions method'))}
 return {nodes,edges}}
function riPairs(hits,limitConcepts=12){let tops=riTopKeywords(hits,limitConcepts),allowed=new Map(tops.map(x=>[norm(x.label),x.label])),pairs=new Map();for(let h of hits){let ks=[...new Set(splitKeywords(recObj(h.i).keywords).map(norm).filter(k=>allowed.has(k)))];for(let a=0;a<ks.length;a++)for(let b=a+1;b<ks.length;b++){let x=ks[a]<ks[b]?ks[a]+'§'+ks[b]:ks[b]+'§'+ks[a],e=pairs.get(x)||{a:allowed.get(ks[a]),b:allowed.get(ks[b]),count:0,papers:[]};e.count++;e.papers.push(h.i);pairs.set(x,e)}}return {tops,pairs:[...pairs.values()].sort((a,b)=>b.count-a.count)}}
function riExplicitHypotheses(hits){let out=[];for(let h of hits){let o=recObj(h.i);for(let s of riSentenceSplit(o.abstract)){if(RI_HYP_CUES.some(re=>re.test(s)))out.push({paper:h.i,text:s})}}return out.slice(0,10)}
function riHypotheses(hits){let {tops,pairs}=riPairs(hits),explicit=riExplicitHypotheses(hits),hyps=[];if(hits.length===1){let ks=splitKeywords(recObj(hits[0].i).keywords).filter(Boolean).slice(0,5);for(let j=1;j<Math.min(ks.length,4);j++)hyps.push({type:'Single-record concept proposition',statement:`A future empirical study can test whether “${ks[0]}” is associated with “${ks[j]}” in a clearly defined population and context.`,null:`No statistically detectable association exists between “${ks[0]}” and “${ks[j]}” in the defined target context.`,concepts:[ks[0],ks[j]],papers:[hits[0].i],support:1,confidence:'low'});}else{for(let p of pairs.filter(x=>x.count>=2).slice(0,5)){hyps.push({type:'Association',statement:`There is a testable association between “${p.a}” and “${p.b}” in the research context represented by the selected literature.`,null:`There is no statistically detectable association between “${p.a}” and “${p.b}” in the target empirical context.`,concepts:[p.a,p.b],papers:p.papers.slice(0,6),support:p.count,confidence:p.count>=4?'high':'medium'})}if(tops.length){let k=tops[0];hyps.push({type:'Temporal / corpus pattern',statement:`The prominence of “${k.label}” differs across publication years within the selected bibliographic corpus.`,null:`The prominence of “${k.label}” does not differ meaningfully across publication years in the selected corpus.`,concepts:[k.label],papers:[...k.papers].slice(0,6),support:k.count,confidence:'medium'})}}return {hyps:hyps.slice(0,6),explicit,tops}}
function riHypGraph(hits,data){let root={id:'hyp-root',type:'hypRoot',label:'Hypothesis Generator',root:true,description:'Alternative hypotheses generated from keyword co-occurrence. They are proposals for testing, not findings.'},nodes=[root],edges=[],map=new Map([[root.id,root]]),seen=new Set();let add=(id,type,label,extra={})=>{if(map.has(id))return map.get(id);let n={id,type,label,weight:1,...extra,x:0,y:0,vx:0,vy:0,fixed:false};map.set(id,n);nodes.push(n);return n},edge=(a,b,r,d='')=>{let k=a.id+'|'+b.id+'|'+r;if(seen.has(k))return;seen.add(k);edges.push({a,b,relation:r,detail:d})};data.hyps.forEach((h,ix)=>{let hn=add('hyp|'+ix,'hypothesis','H'+(ix+1)+': '+h.statement,{description:h.null});edge(root,hn,'generates candidate');h.concepts.forEach(c=>edge(hn,add('concept|'+norm(c),'concept',c),'tests concept'));h.papers.forEach(pi=>{let o=recObj(pi),p=add('paper|'+pi,'paper',o.title,{paperIndex:pi,cites:o.cites,year:o.year,source:o.source,url:nodeUrlFor('paper',o.title,o)});edge(hn,p,'grounded in co-occurrence',h.support+' supporting records')})});return {nodes,edges}}
function riExplicitGaps(hits){let out=[];for(let h of hits){let o=recObj(h.i);for(let s of riSentenceSplit(o.abstract)){let cues=RI_GAP_CUES.filter(re=>re.test(s));if(cues.length)out.push({paper:h.i,text:s,score:cues.length+(s.length<260?1:0)})}}out.sort((a,b)=>b.score-a.score);let ded=[],seen=new Set();for(let x of out){let k=norm(x.text).slice(0,130);if(seen.has(k))continue;seen.add(k);ded.push(x);if(ded.length>=12)break}return ded}
function riGapAnalysis(hits){let explicit=riExplicitGaps(hits),{tops,pairs}=riPairs(hits,10),gaps=[];
 explicit.slice(0,6).forEach((e,ix)=>{let o=recObj(e.paper);gaps.push({type:'Explicit gap statement',statement:e.text,papers:[e.paper],concepts:splitKeywords(o.keywords).slice(0,3),confidence:'high',basis:'Gap-indicating language found directly in the source abstract.'})});
 // Underexplored intersections: individually visible concepts with rare co-occurrence
 let freq=new Map(tops.map(x=>[norm(x.label),x]));let co=new Map(pairs.map(p=>[[norm(p.a),norm(p.b)].sort().join('§'),p]));for(let a=0;a<tops.length;a++)for(let b=a+1;b<tops.length;b++){let A=tops[a],B=tops[b];if(A.count<3||B.count<3)continue;let p=co.get([norm(A.label),norm(B.label)].sort().join('§')),c=p?.count||0;if(c<=1)gaps.push({type:'Underexplored concept intersection',statement:`“${A.label}” and “${B.label}” are each visible in the selected corpus but rarely occur together (${c} co-occurring record${c===1?'':'s'}). This is a candidate intersection for targeted investigation.`,papers:[...(A.papers)].slice(0,2).concat([...(B.papers)].slice(0,2)),concepts:[A.label,B.label],confidence:'medium',basis:'Corpus co-occurrence signal; not proof of a global literature gap.'})}
 let methodCounts=new Map();for(let h of hits)for(let m of riMethodsFor(recObj(h.i)))methodCounts.set(m,(methodCounts.get(m)||0)+1);let methods=[...methodCounts].sort((a,b)=>b[1]-a[1]);if(hits.length>=8&&methods.length){let rare=methods.filter(x=>x[1]<=Math.max(1,Math.floor(hits.length*.08))).slice(0,2),dominant=methods[0];rare.forEach(([m,c])=>gaps.push({type:'Methodological opportunity',statement:`The selected corpus is led by “${dominant[0]}” mentions (${dominant[1]} records), while “${m}” appears in only ${c}. A study using or comparing this less-represented method could test whether conclusions are method-sensitive.`,papers:hits.filter(h=>riMethodsFor(recObj(h.i)).includes(m)).slice(0,4).map(h=>h.i),concepts:[m,dominant[0]],confidence:'medium',basis:'Method-term distribution in titles, abstracts and keywords.'}))}
 let countries=new Map();for(let h of hits){let c=recObj(h.i).country;if(c)countries.set(c,(countries.get(c)||0)+1)}let cs=[...countries].sort((a,b)=>b[1]-a[1]);if(hits.length>=10&&cs.length&&cs[0][1]/hits.length>=.55)gaps.push({type:'Geographic concentration signal',statement:`${cs[0][1]} of ${hits.length} analyzed records carry “${cs[0][0]}” in the dataset country field. Comparative work across less-represented geographic contexts may strengthen external validity.`,papers:hits.filter(h=>recObj(h.i).country===cs[0][0]).slice(0,4).map(h=>h.i),concepts:[cs[0][0]],confidence:'medium',basis:'Bibliographic country metadata; it may describe publication metadata rather than the empirical study location.'});
 let seen=new Set();gaps=gaps.filter(g=>{let k=norm(g.statement).slice(0,150);if(seen.has(k))return false;seen.add(k);return true});return {gaps:gaps.slice(0,10),explicit,tops,methods,countries:cs}}
function riGapGraph(hits,data){let root={id:'gap-root',type:'gapRoot',label:'Research Gap Finder',root:true,description:'Gap signals are grounded in abstract wording or corpus coverage patterns; they require researcher validation.'},nodes=[root],edges=[],map=new Map([[root.id,root]]),seen=new Set();let add=(id,type,label,extra={})=>{if(map.has(id))return map.get(id);let n={id,type,label,weight:1,...extra,x:0,y:0,vx:0,vy:0,fixed:false};map.set(id,n);nodes.push(n);return n},edge=(a,b,r,d='')=>{let k=a.id+'|'+b.id+'|'+r;if(seen.has(k))return;seen.add(k);edges.push({a,b,relation:r,detail:d})};data.gaps.forEach((g,ix)=>{let gn=add('gap|'+ix,'gap',(ix+1)+'. '+g.type,{description:g.statement});edge(root,gn,'identifies signal',g.confidence+' confidence');g.concepts.slice(0,4).forEach(c=>edge(gn,add('concept|'+norm(c),'concept',c),'concerns concept'));g.papers.slice(0,5).forEach(pi=>{let o=recObj(pi),p=add('paper|'+pi,'paper',o.title,{paperIndex:pi,cites:o.cites,year:o.year,source:o.source,url:nodeUrlFor('paper',o.title,o)});edge(gn,p,'evidenced by')})});return {nodes,edges}}
function riCombinedGraph(hits){let ner=riNER(hits),hyp=riHypotheses(hits),gap=riGapAnalysis(hits),root={id:'ri-root',type:'query',label:'Research Intelligence: '+(state.query||'Current Results'),root:true,description:'Combined exploratory graph: papers, bibliographic entities, generated hypotheses and corpus-supported gap signals.'},nodes=[root],edges=[],map=new Map([[root.id,root]]),seen=new Set();let add=(id,type,label,extra={})=>{if(map.has(id))return map.get(id);let n={id,type,label,weight:1,...extra,x:0,y:0,vx:0,vy:0,fixed:false};map.set(id,n);nodes.push(n);return n},edge=(a,b,r,d='')=>{let k=a.id+'|'+b.id+'|'+r;if(seen.has(k))return;seen.add(k);edges.push({a,b,relation:r,detail:d})};
 hits.slice(0,20).forEach((h,rank)=>{let o=recObj(h.i),p=add('paper|'+h.i,'paper',o.title,{paperIndex:h.i,cites:o.cites,year:o.year,source:o.source,rank:rank+1,url:nodeUrlFor('paper',o.title,o)});edge(root,p,'analyzes paper');splitAuthors(o.authors).slice(0,3).forEach(v=>edge(p,add('author|'+norm(v),'author',v),'authored by'));splitKeywords(o.keywords).slice(0,4).forEach(v=>edge(p,add('concept|'+norm(v),'concept',v),'has concept'));riMethodsFor(o).slice(0,2).forEach(v=>edge(p,add('method|'+norm(v),'method',v),'mentions method'))});
 hyp.hyps.slice(0,4).forEach((h,i)=>{let hn=add('hyp|'+i,'hypothesis','H'+(i+1)+': '+h.statement,{description:h.null});edge(root,hn,'generates hypothesis');h.concepts.forEach(c=>edge(hn,add('concept|'+norm(c),'concept',c),'tests concept'))});gap.gaps.slice(0,5).forEach((g,i)=>{let gn=add('gap|'+i,'gap','Gap '+(i+1)+': '+g.type,{description:g.statement});edge(root,gn,'identifies gap signal');g.concepts.slice(0,3).forEach(c=>edge(gn,add('concept|'+norm(c),'concept',c),'concerns concept'));g.papers.slice(0,3).forEach(pi=>{let o=recObj(pi),p=add('paper|'+pi,'paper',o.title,{paperIndex:pi,cites:o.cites,year:o.year,source:o.source,url:nodeUrlFor('paper',o.title,o)});edge(gn,p,'evidenced by')})});return {nodes,edges,ner,hyp,gap}}
function riGenericGraph(g,title,description,relations){if(!g.nodes?.length)return;$('#modalCard').classList.add('graph-modal-card');showModal(`<h2>${esc(title)}</h2><p class="tiny">${description}</p><div class="kg-toolbar"><label><input type="checkbox" id="kgEdgeLabels" checked> Relationship labels</label><span class="spacer"></span><button class="ghost" id="kgFit">Fit</button><button class="ghost" id="kgReset">Re-layout</button><button class="ghost" id="kgPng">Save PNG</button></div><div class="kg-layout"><div class="kg-stage"><canvas id="kgCanvas" aria-label="Interactive research intelligence knowledge graph"></canvas><div class="kg-tooltip" id="kgTooltip"></div></div><aside class="kg-side"><h3>Graph summary</h3><div id="kgStats"></div><h4>Selected node</h4><div id="kgSelection"></div><h4>Node types</h4><div class="kg-legend">${kgLegend()}</div><h4>Relationship meanings</h4><div class="kg-edge-key">${relations}</div><div class="kg-note">Automatic outputs are research-assistance signals. Validate hypotheses and gap interpretations against the cited papers and, where needed, a wider systematic literature search.</div></aside></div>`);KG.nodes=g.nodes;KG.edges=g.edges;KG.nodeMap=new Map(KG.nodes.map(n=>[n.id,n]));KG.canvas=$('#kgCanvas');KG.ctx=KG.canvas.getContext('2d');KG.scale=1;KG.tx=0;KG.ty=0;KG.selected=null;KG.showEdgeLabels=true;kgInitPositions();kgResize();$('#kgStats').innerHTML=kgStats();$('#kgSelection').innerHTML=kgSelectionHtml(null);kgBindCanvas();cancelAnimationFrame(KG.anim);KG.anim=requestAnimationFrame(kgAnimate);setTimeout(()=>kgFit(),180);$('#kgEdgeLabels').onchange=e=>{KG.showEdgeLabels=e.target.checked;kgDraw()};$('#kgFit').onclick=kgFit;$('#kgReset').onclick=()=>{kgInitPositions();cancelAnimationFrame(KG.anim);KG.anim=requestAnimationFrame(kgAnimate);setTimeout(()=>kgFit(),200)};$('#kgPng').onclick=()=>{kgDraw();let a=document.createElement('a');a.download='research_intelligence_graph.png';a.href=KG.canvas.toDataURL('image/png');a.click()};window.onresize=()=>{if($('#modal').classList.contains('open')&&KG.canvas)kgResize()}}
function riEntityCount(ner){return Object.values(ner).reduce((a,x)=>a+x.length,0)}
function riEntitySection(title,arr,max=18){if(!arr?.length)return '';return `<div class="ri-section"><h3>${esc(title)}</h3><div class="entity-grid">${arr.slice(0,max).map(e=>`<span class="entity-chip"><b>${esc(e.label)}</b> <span class="tiny">${e.papers.size} paper${e.papers.size===1?'':'s'}</span></span>`).join('')}</div></div>`}
function riNERModal(focusIndex=null,graphOnly=false){let hits=riScopeHits(focusIndex);if(!hits.length){toast('Run a search first');return}let ner=riNER(hits),g=riNERGraph(hits,ner);if(graphOnly){riGenericGraph(g,'NER Knowledge Graph','Named entities are linked to the papers in which they occur. Structured bibliographic fields are treated as high-confidence entities; selected organization patterns from text are heuristic.','<b>analyzes paper</b> — record included in NER scope<br><b>mentions person / concept / method</b> — entity occurs in bibliographic text<br><b>published by / published in</b> — explicit metadata relationship<br><b>associated location</b> — dataset place/country metadata');return}showModal(`<div class="ri-modal-title"><h2>◈ Named Entity Recognition</h2><span class="ri-badge heuristic">Local bibliographic NER</span></div><div class="ri-warning"><b>Method note:</b> Authors, journal, publisher, place/country, DOI/ISSN and keywords come directly from structured dataset fields. Method/technology terms and selected organization phrases are extracted locally with conservative rules; they should be treated as candidate entities.</div><div class="ri-summary"><div class="ri-kpi"><b>${hits.length}</b><span>papers analyzed</span></div><div class="ri-kpi"><b>${riEntityCount(ner)}</b><span>unique entities</span></div><div class="ri-kpi"><b>${ner.person.length}</b><span>persons/authors</span></div><div class="ri-kpi"><b>${ner.concept.length}</b><span>concepts/keywords</span></div></div><div class="ri-actions"><button class="primary ner" id="nerGraphBtn">Open NER knowledge graph</button></div>${riEntitySection('Persons / Authors',ner.person)}${riEntitySection('Organizations / Publishers',ner.organization)}${riEntitySection('Locations',ner.location)}${riEntitySection('Journals / Sources',ner.journal)}${riEntitySection('Research concepts',ner.concept)}${riEntitySection('Methods / Technologies',ner.method)}${riEntitySection('Identifiers',ner.identifier,12)}`);$('#nerGraphBtn').onclick=()=>riNERModal(focusIndex,true)}
function riHypModal(focusIndex=null,graphOnly=false){let hits=riScopeHits(focusIndex);if(!hits.length){toast('Run a search first');return}let d=riHypotheses(hits),g=riHypGraph(hits,d);if(graphOnly){riGenericGraph(g,'Hypothesis Knowledge Graph','Alternative hypotheses are linked to concepts and the records whose keyword co-occurrence generated them.','<b>generates candidate</b> — locally generated testable proposition<br><b>tests concept</b> — variable/concept used in the hypothesis<br><b>grounded in co-occurrence</b> — papers where the concepts co-occur');return}showModal(`<div class="ri-modal-title"><h2>H₁ Hypothesis Generator</h2><span class="ri-badge heuristic">Alternative hypotheses</span></div><div class="ri-warning"><b>Interpretation:</b> These are testable research propositions generated from patterns in the selected bibliographic records. Co-occurrence does not establish causality, effect direction, significance, or theoretical validity. Refine variables, population and measures before using a hypothesis in a study.</div><div class="ri-summary"><div class="ri-kpi"><b>${hits.length}</b><span>papers analyzed</span></div><div class="ri-kpi"><b>${d.hyps.length}</b><span>generated hypotheses</span></div><div class="ri-kpi"><b>${d.explicit.length}</b><span>explicit hypothesis cues</span></div><div class="ri-kpi"><b>${d.tops.length}</b><span>core concepts</span></div></div><div class="ri-actions"><button class="primary hyp" id="hypGraphBtn">Open hypothesis knowledge graph</button></div>${d.hyps.map((h,i)=>hypCardHtml(h,i))||'<div class="note">Not enough repeated keyword relationships were found to generate a useful hypothesis from this scope.</div>'}${d.explicit.length?`<div class="ri-section"><h3>Explicit hypothesis cues found in abstracts</h3>${d.explicit.slice(0,5).map(e=>`<div class="evidence-card"><b>${esc(recObj(e.paper).title)}</b><div class="evidence-quote">${esc(e.text)}</div><div class="actions"><button data-ri-detail="${e.paper}">Open record</button></div></div>`).join('')}</div>`:''}`);$('#hypGraphBtn').onclick=()=>riHypModal(focusIndex,true);$$('[data-ri-detail]').forEach(b=>b.onclick=()=>detail(Number(b.dataset.riDetail)))}
function riGapModal(focusIndex=null,graphOnly=false){let hits=riScopeHits(focusIndex);if(!hits.length){toast('Run a search first');return}let d=riGapAnalysis(hits),g=riGapGraph(hits,d);if(graphOnly){riGenericGraph(g,'Research Gap Knowledge Graph','Gap nodes connect to concepts and evidence papers. High-confidence signals quote explicit gap language; medium-confidence signals are corpus-level opportunities.','<b>identifies signal</b> — automatic gap candidate<br><b>concerns concept</b> — topic/context associated with the gap<br><b>evidenced by</b> — record supporting the gap signal');return}showModal(`<div class="ri-modal-title"><h2>⌁ Research Gap Finder</h2><span class="ri-badge heuristic">Evidence-linked gap signals</span></div><div class="ri-warning"><b>Important:</b> A gap in this dataset is not automatically a gap in the entire scholarly literature. High-confidence items come from explicit gap wording in abstracts. Other items identify underrepresented combinations or methods within the current search corpus and should be validated with a systematic search.</div><div class="ri-summary"><div class="ri-kpi"><b>${hits.length}</b><span>papers analyzed</span></div><div class="ri-kpi"><b>${d.gaps.length}</b><span>gap signals</span></div><div class="ri-kpi"><b>${d.explicit.length}</b><span>explicit gap sentences</span></div><div class="ri-kpi"><b>${d.methods.length}</b><span>methods detected</span></div></div><div class="ri-actions"><button class="primary gap" id="gapGraphBtn">Open research-gap knowledge graph</button></div>${d.gaps.map((g,i)=>`<div class="gap-card"><div class="confidence ${g.confidence}">${esc(g.type)} · ${g.confidence} confidence</div><h3>Gap ${i+1}</h3><div>${esc(g.statement)}</div><div class="evidence-quote"><b>Basis:</b> ${esc(g.basis)}</div><div class="ri-tagrow">${g.concepts.map(c=>`<span class="ri-tag">${esc(c)}</span>`).join('')}</div>${g.papers.length?`<div class="tiny" style="margin-top:6px">Evidence: ${g.papers.slice(0,3).map(pi=>esc(recObj(pi).title)).join(' • ')}</div>`:''}</div>`).join('')||'<div class="note">No defensible gap signal was detected in this analysis scope. Increase the scope or refine the search.</div>'}`);$('#gapGraphBtn').onclick=()=>riGapModal(focusIndex,true)}
function riAllGraph(){let hits=riScopeHits();if(!hits.length){toast('Run a search first');return}let g=riCombinedGraph(hits);riGenericGraph(g,'Integrated Research Intelligence Knowledge Graph','This combined graph links the current papers to extracted entities/concepts, generated alternative hypotheses and evidence-linked research-gap signals.','<b>analyzes paper</b> — paper in analysis scope<br><b>authored by / has concept / mentions method</b> — bibliographic entity relationship<br><b>generates hypothesis</b> — candidate testable proposition<br><b>identifies gap signal</b> — explicit or corpus-level gap indicator<br><b>evidenced by</b> — source paper supporting the signal')}
/* ── Online Web Resource Search (OpenAlex, Crossref, Wikipedia, DBpedia) ── */
const ONLINE_SOURCES = {
  openalex: { id:'openalex', label:'OpenAlex', desc:'Scholarly works, authors, concepts (open scholarly graph)' },
  crossref: { id:'crossref', label:'Crossref', desc:'DOI registry – bibliographic metadata for journal articles & books' },
  wikipedia: { id:'wikipedia', label:'Wikipedia', desc:'Encyclopedic articles & summaries' },
  dbpedia: { id:'dbpedia', label:'DBpedia', desc:'Structured knowledge base extracted from Wikipedia' }
};

async function onlineFetchJson(url, opts={}){
  const ctrl = new AbortController();
  const t = setTimeout(()=>ctrl.abort(), opts.timeout || 12000);
  try{
    const r = await fetch(url, { signal: ctrl.signal, headers: opts.headers || {} });
    clearTimeout(t);
    if(!r.ok) throw new Error(r.status + ' ' + r.statusText);
    return await r.json();
  }catch(e){
    clearTimeout(t);
    throw e;
  }
}

async function searchOpenAlex(q, limit=8){
  q=xlPlain(q);
  const url = `https://api.openalex.org/works?search=${encodeURIComponent(q)}&per_page=${limit}&mailto=research-explorer@example.com`;
  const data = await onlineFetchJson(url);
  return (data.results || []).map(w=>{
    const authors = (w.authorships || []).slice(0,6).map(a=>a.author?.display_name).filter(Boolean).join('; ');
    const doi = (w.doi || '').replace('https://doi.org/','');
    const year = w.publication_year || '';
    const cites = w.cited_by_count || 0;
    const abstract = w.abstract_inverted_index ? invertOpenAlexAbstract(w.abstract_inverted_index) : '';
    const concepts = (w.concepts || []).slice(0,5).map(c=>c.display_name).join('; ');
    return {
      source:'OpenAlex', sourceId:'openalex',
      title: w.title || w.display_name || 'Untitled',
      authors, year, doi, cites,
      url: w.primary_location?.landing_page_url || w.id || (doi ? 'https://doi.org/'+doi : ''),
      abstract: abstract.slice(0,400),
      keywords: concepts,
      type: w.type || 'work',
      openAccess: !!(w.open_access && w.open_access.is_oa)
    };
  });
}

function invertOpenAlexAbstract(inv){
  if(!inv || typeof inv !== 'object') return '';
  const words = [];
  for(const [word, positions] of Object.entries(inv)){
    for(const p of positions) words[p] = word;
  }
  return words.filter(Boolean).join(' ');
}

async function searchCrossref(q, limit=8){
  q=xlPlain(q);
  const url = `https://api.crossref.org/works?query=${encodeURIComponent(q)}&rows=${limit}`;
  const data = await onlineFetchJson(url);
  return (data.message?.items || []).map(w=>{
    const authors = (w.author || []).slice(0,6).map(a=>[a.given,a.family].filter(Boolean).join(' ')).filter(Boolean).join('; ');
    const year = (w.published?.['date-parts']?.[0]?.[0]) || (w.created?.['date-parts']?.[0]?.[0]) || '';
    const doi = w.DOI || '';
    const title = Array.isArray(w.title) ? w.title[0] : (w.title || 'Untitled');
    const abstract = (w.abstract || '').replace(/<[^>]+>/g,' ').slice(0,400);
    return {
      source:'Crossref', sourceId:'crossref',
      title, authors, year, doi, cites: w['is-referenced-by-count'] || 0,
      url: doi ? 'https://doi.org/'+doi : (w.URL || ''),
      abstract,
      keywords: (w.subject || []).slice(0,5).join('; '),
      type: w.type || 'journal-article',
      openAccess: false
    };
  });
}

async function searchWikipedia(q, limit=5){
  const wl=/[\u0980-\u09FF]/.test(q)?'bn':'en'; // Bengali queries search Bengali Wikipedia directly
  const wq=wl==='en'?xlPlain(q):q;
  const searchUrl = `https://${wl}.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(wq)}&srlimit=${limit}&format=json&origin=*`;
  const data = await onlineFetchJson(searchUrl);
  const hits = data.query?.search || [];
  if(!hits.length) return [];
  const titles = hits.map(h=>h.title).join('|');
  const extractUrl = `https://${wl}.wikipedia.org/w/api.php?action=query&prop=extracts|info&exintro=1&explaintext=1&inprop=url&titles=${encodeURIComponent(titles)}&format=json&origin=*`;
  let extracts = {};
  try{
    const exData = await onlineFetchJson(extractUrl);
    const pages = exData.query?.pages || {};
    for(const p of Object.values(pages)){
      extracts[p.title] = { extract: (p.extract||'').slice(0,450), url: p.fullurl || `https://${wl}.wikipedia.org/wiki/${encodeURIComponent(p.title.replace(/ /g,'_'))}` };
    }
  }catch(e){}
  return hits.map(h=>{
    const ex = extracts[h.title] || {};
    return {
      source:'Wikipedia', sourceId:'wikipedia',
      title: h.title,
      authors: '', year: '', doi: '', cites: 0,
      url: ex.url || `https://${wl}.wikipedia.org/wiki/${encodeURIComponent(h.title.replace(/ /g,'_'))}`,
      abstract: ex.extract || (h.snippet||'').replace(/<[^>]+>/g,'') || '',
      keywords: '',
      type: 'encyclopedia-article',
      openAccess: true
    };
  });
}

async function searchDBpedia(q, limit=5){
  q=xlPlain(q);
  const url = `https://lookup.dbpedia.org/api/search?query=${encodeURIComponent(q)}&maxResults=${limit}&format=json`;
  try{
    const data = await onlineFetchJson(url, { timeout: 10000 });
    const docs = data.docs || data.results || (Array.isArray(data) ? data : []);
    return docs.slice(0,limit).map(d=>{
      const label = d.label || (d.label && d.label[0]) || d.refLabel || 'Untitled';
      const comment = (d.comment || (d.comment && d.comment[0]) || d.description || '').toString().slice(0,400);
      const resource = (d.resource && d.resource[0]) || d.uri || d.ref || '';
      return {
        source:'DBpedia', sourceId:'dbpedia',
        title: Array.isArray(label) ? label[0] : label,
        authors: '', year: '', doi: '', cites: 0,
        url: resource || `https://dbpedia.org/page/${encodeURIComponent(String(label).replace(/ /g,'_'))}`,
        abstract: Array.isArray(comment) ? comment[0] : comment,
        keywords: (d.categories || d.type || []).slice ? (d.categories || d.type || []).slice(0,4).join('; ') : '',
        type: 'structured-entity',
        openAccess: true
      };
    });
  }catch(e){
    throw new Error('DBpedia lookup unavailable or blocked by CORS. Try Wikipedia or OpenAlex.');
  }
}

function onlineResultCard(r, idx){
  const badges = [];
  badges.push(`<span class="badge">${esc(r.source)}</span>`);
  if(r.openAccess) badges.push(`<span class="badge access">Open Access</span>`);
  if(r.cites) badges.push(`<span class="badge cites">${Number(r.cites).toLocaleString()} cites</span>`);
  if(r.year) badges.push(`<span class="badge">${r.year}</span>`);
  if(r.type) badges.push(`<span class="badge">${esc(r.type)}</span>`);
  const meta = [r.authors, r.year].filter(Boolean).join(' · ');
  const link = safeUrl(r.url);
  return `<article class="result-card online-card" data-online="${idx}">
    <h3 class="rtitle">${link ? `<a href="${esc(link)}" target="_blank" rel="noopener">${esc(r.title)}</a>` : esc(r.title)}</h3>
    <div class="meta">${esc(meta)}</div>
    <div class="badges">${badges.join('')}</div>
    ${r.abstract ? `<div class="abstract">${esc(r.abstract)}${r.abstract.length>=400?'…':''}</div>` : ''}
    ${r.keywords ? `<div class="tiny" style="margin-top:6px"><b>Concepts:</b> ${esc(r.keywords)}</div>` : ''}
    <div class="actions">
      ${link ? `<a class="ghost" href="${esc(link)}" target="_blank" rel="noopener">Open resource ↗</a>` : ''}
      ${r.doi ? `<a class="ghost" href="https://doi.org/${esc(r.doi)}" target="_blank" rel="noopener">DOI</a>` : ''}
    </div>
  </article>`;
}

async function runOnlineSearch(query, selectedSources){
  const q = (query || '').trim();
  if(!q){ toast('Enter a search query first'); return; }
  if(!selectedSources.length){ toast('Select at least one online source'); return; }
  const status = $('#onlineStatus');
  const list = $('#onlineResults');
  if(status) status.innerHTML = '<span class="spinner" style="width:14px;height:14px;display:inline-block;border-width:2px"></span> Searching online sources…';
  if(list) list.innerHTML = '';
  const tasks = [];
  if(selectedSources.includes('openalex')) tasks.push(searchOpenAlex(q).then(r=>({src:'openalex',r})).catch(e=>({src:'openalex',err:e.message})));
  if(selectedSources.includes('crossref')) tasks.push(searchCrossref(q).then(r=>({src:'crossref',r})).catch(e=>({src:'crossref',err:e.message})));
  if(selectedSources.includes('wikipedia')) tasks.push(searchWikipedia(q).then(r=>({src:'wikipedia',r})).catch(e=>({src:'wikipedia',err:e.message})));
  if(selectedSources.includes('dbpedia')) tasks.push(searchDBpedia(q).then(r=>({src:'dbpedia',r})).catch(e=>({src:'dbpedia',err:e.message})));

  const settled = await Promise.all(tasks);
  let all = [], errors = [];
  settled.forEach(s=>{
    if(s.err) errors.push(`${(ONLINE_SOURCES[s.src]&&ONLINE_SOURCES[s.src].label)||s.src}: ${s.err}`);
    else if(Array.isArray(s.r)) all = all.concat(s.r);
  });
  if(status){
    status.innerHTML = all.length
      ? `<b>${all.length}</b> web resource${all.length===1?'':'s'} found` + (errors.length ? ` · <span style="color:var(--warn)">${errors.length} source error(s)</span>` : '')
      : (errors.length ? `<span style="color:var(--warn)">${errors.join(' · ')}</span>` : 'No results from selected sources');
  }
  if(list){
    if(!all.length){
      list.innerHTML = `<div class="note">${errors.length ? errors.map(e=>esc(e)).join('<br>') : 'No matching web resources. Try different keywords or other sources.'}</div>`;
    } else {
      list.innerHTML = all.map((r,i)=>onlineResultCard(r,i)).join('');
    }
  }
  window.__lastOnlineResults = all;
  // Enable Build Knowledge Graph button
  const kgBtn = document.getElementById('buildOnlineKgBtn');
  if(kgBtn){
    kgBtn.disabled = !all.length;
    kgBtn.style.opacity = all.length ? '1' : '0.5';
    kgBtn.onclick = () => {
      if(!all.length){ toast('No online results to graph'); return; }
      const q = ($('#onlineQuery') && $('#onlineQuery').value) || state.query || '';
      kgOpenOnline(all, q);
    };
  }
}

/* ── Knowledge Graph construction from Online Web Search results ── */
function onlineToPseudoHits(results){
  // Convert online result objects into a lightweight hit list the graph layer can use.
  // We do not inject them into the local DATA array; we only build graphs from them.
  return (results || []).map((r, i) => ({ i: 'online|' + i, online: r, score: 1 }));
}

function onlineRecObj(key){
  // key is 'online|N'
  const idx = Number(String(key).replace(/^online\|/, ''));
  const r = (window.__lastOnlineResults || [])[idx];
  if(!r) return { index: key, cites: 0, authors: '', title: '', year: '', source: '', publisher: '', place: '', country: '', url: '', doi: '', issn: '', keywords: '', abstract: '' };
  return {
    index: key,
    cites: r.cites || 0,
    authors: r.authors || '',
    title: r.title || '',
    year: r.year || '',
    source: r.source || '',
    publisher: r.publisher || '',
    place: r.place || '',
    country: r.country || '',
    url: r.url || '',
    doi: r.doi || '',
    issn: '',
    keywords: r.keywords || '',
    abstract: r.abstract || '',
    _online: true,
    _provider: r.sourceId || r.source
  };
}

function kgBuildFromOnline(results, modelId='bibliographic', opts={}){
  const limit = Number(opts.limit || 20);
  const chosen = (results || []).slice(0, limit);
  const items = chosen.map((r, rank) => {
    const url = safeUrl(r.url) || (r.doi ? 'https://doi.org/' + r.doi : '');
    return {
      key: 'online|' + rank, rank, score: 1,
      o: {title: r.title || 'Untitled', year: r.year || '', source: r.source || '', publisher: '', place: '', doi: r.doi || '', url, cites: r.cites || 0},
      authors: String(r.authors || '').split(/;| and |,/).map(x => x.trim()).filter(Boolean),
      keywords: String(r.keywords || '').split(/;|,/).map(x => x.trim()).filter(x => x.length > 2)
    };
  });
  const q = (opts.query || state.query || '').trim();
  return kgSchemaBuild(items, modelId, {
    types: opts.types,
    includeSearchRoot: opts.includeSearchRoot !== false,
    rootLabel: q ? `Online query: ${q}` : 'Online web results'
  });
}

function kgOpenOnline(results, query){
  if(!results || !results.length){
    toast('No online results available for graph');
    return;
  }
  // Close the search modal first so the graph modal can take over cleanly
  if(typeof closeModal === 'function') closeModal();

  const isSingle = false;
  const defaultLimit = Math.min(20, results.length);
  const modelOptions = Object.values(KG_MODELS).map(m => `<option value="${m.id}">${m.label}</option>`).join('');

  $('#modalCard').classList.add('graph-modal-card');
  showModal(`<h2>Online Web Results Knowledge Graph</h2>
    <p class="tiny">Graph built from <b>live online results</b> (OpenAlex, Crossref, Wikipedia, DBpedia). Choose a construction model. Nodes link to the original web resources when available.</p>
    <div class="kg-toolbar">
      <label>KG Model <select id="kgModel">${modelOptions}</select></label>
      <label>Top results <select id="kgLimit"><option>10</option><option selected>20</option><option>30</option><option>40</option></select></label>
      <label><input type="checkbox" id="kgEdgeLabels">Edge labels</label>
      <span class="spacer"></span>
      <button class="ghost" id="kgFit">Fit</button>
      <button class="ghost" id="kgReset">Re-layout</button>
      <button class="ghost" id="kgPng">Save PNG</button>
    </div>
    <div class="kg-layout">
      <div class="kg-stage">
        <canvas id="kgCanvas" aria-label="Knowledge graph from online web results"></canvas>
        <div class="kg-tooltip" id="kgTooltip"></div>
      </div>
      <aside class="kg-side">
        <h3>Graph summary</h3>
        <div id="kgStats"></div>
        <h4>Selected node</h4>
        <div id="kgSelection"></div>
        <h4>Node types</h4>
        <div class="kg-legend">${typeof kgLegend === 'function' ? kgLegend() : ''}</div>
        <h4>Model description</h4>
        <div class="kg-edge-key" id="kgModelDesc" style="font-size:12px;color:var(--muted);margin-bottom:8px"></div>
        <h4>Relationship meanings</h4>
        <div class="kg-edge-key" id="kgEdgeKey">Select a model to see relationship definitions.</div>
        <div class="kg-note" style="margin-top:10px;font-size:12px;color:var(--muted)">Online graphs use metadata returned by the selected web sources. Citation networks require full reference lists, which these APIs do not always provide.</div>
      </aside>
    </div>`);

  const rebuild = () => {
    const modelId = ($('#kgModel') && $('#kgModel').value) || 'bibliographic';
    const model = KG_MODELS[modelId] || KG_MODELS.bibliographic;
    const limit = Number($('#kgLimit')?.value || defaultLimit);
    const g = kgBuildFromOnline(results, modelId, { limit, includeSearchRoot: true, query: query || state.query });
    KG.nodes = g.nodes;
    KG.edges = g.edges;
    KG.nodeMap = new Map(KG.nodes.map(n => [n.id, n]));
    KG.canvas = $('#kgCanvas');
    KG.ctx = KG.canvas.getContext('2d');
    KG.scale = 1; KG.tx = 0; KG.ty = 0; KG.selected = null;
    const keyEl = document.getElementById('kgEdgeKey');
    const descEl = document.getElementById('kgModelDesc');
    if(keyEl) keyEl.innerHTML = model.relations;
    if(descEl) descEl.textContent = model.desc + ' (built from online web results)';
    kgInitPositions();
    kgResize();
    $('#kgStats').innerHTML = kgStats();
    $('#kgSelection').innerHTML = kgSelectionHtml(null);
    kgBindCanvas();
    cancelAnimationFrame(KG.anim);
    KG.anim = requestAnimationFrame(kgAnimate);
    setTimeout(() => kgFit(), 160);
  };

  rebuild();
  if($('#kgLimit')) $('#kgLimit').onchange = rebuild;
  if($('#kgModel')) $('#kgModel').onchange = rebuild;
  $('#kgEdgeLabels').onchange = e => { KG.showEdgeLabels = e.target.checked; kgDraw(); };
  $('#kgFit').onclick = kgFit;
  $('#kgReset').onclick = () => { kgInitPositions(); cancelAnimationFrame(KG.anim); KG.anim = requestAnimationFrame(kgAnimate); };
  if($('#kgPng')) $('#kgPng').onclick = () => {
    try {
      const a = document.createElement('a');
      a.download = 'online-knowledge-graph.png';
      a.href = KG.canvas.toDataURL('image/png');
      a.click();
    } catch(e) { toast('Could not export PNG'); }
  };
}


function onlineSearchModal(){
  const q = ($('#q') && $('#q').value) || state.query || '';
  showModal(`<h2>🌐 Online Web Resource Search</h2>
    <p class="tiny">Search live scholarly and knowledge bases when you are connected to the internet. Results open on the original sites. Local library search remains available offline.</p>
    <div class="db-form" style="margin:12px 0">
      <label>Query <input id="onlineQuery" value="${esc(q)}" placeholder="e.g. knowledge graphs in digital libraries"></label>
      <div style="margin-top:10px"><b>Sources</b></div>
      <div class="checklist" style="margin-top:6px;max-height:none">
        ${Object.values(ONLINE_SOURCES).map(s=>`
          <label class="check"><input type="checkbox" class="onlineSrc" value="${s.id}" ${s.id!=='dbpedia'?'checked':''}>
            <span><b>${esc(s.label)}</b> — ${esc(s.desc)}</span>
          </label>`).join('')}
      </div>
    </div>
    <div class="actions" style="margin:12px 0">
      <button class="primary" id="runOnlineSearchBtn">Search selected sources</button>
      <button class="ghost" id="buildOnlineKgBtn" disabled style="opacity:0.5" title="Build a knowledge graph from the online results">⌘ Build Knowledge Graph</button>
      <button class="ghost" id="closeOnlineModal">Close</button>
    </div>
    <div id="onlineStatus" class="tiny" style="margin-bottom:8px;color:var(--muted)"></div>
    <div id="onlineResults" class="result-list" style="max-height:55vh;overflow:auto"></div>
    <p class="note" style="margin-top:12px">OpenAlex &amp; Crossref return scholarly metadata (DOI, citations, abstracts). Wikipedia &amp; DBpedia return encyclopedic / structured knowledge. DBpedia lookup may be blocked by some browsers (CORS); Wikipedia is a reliable alternative. No API keys required for basic use. Please respect the providers’ rate limits.</p>`);
  $('#runOnlineSearchBtn').onclick = ()=>{
    const query = $('#onlineQuery').value.trim();
    const selected = $$('.onlineSrc:checked').map(c=>c.value);
    runOnlineSearch(query, selected);
  };
  $('#closeOnlineModal').onclick = closeModal;
  if(q.trim()){
    setTimeout(()=>$('#runOnlineSearchBtn').click(), 200);
  }
}


function dataInfo(){showModal(`<h2>Semantic KG Explorer — Capabilities &amp; Help</h2>
<p class="tiny">This application delivers an intelligent, user-centred, multilingual and scalable search system for Library &amp; Information Science bibliographic knowledge graphs. All core facilities remain fully functional offline once the dataset is loaded.</p>

<div class="detail-grid" style="margin:12px 0">
  <div class="detail-block"><b>Records</b>${M.recordCount.toLocaleString()}</div>
  <div class="detail-block"><b>Years</b>${M.minYear}–${M.maxYear}</div>
  <div class="detail-block"><b>Journals/sources</b>${M.sourceCounts.length}</div>
  <div class="detail-block"><b>Publishers</b>${M.publisherCounts.length}</div>
  <div class="detail-block"><b>Missing abstracts</b>${(M.missing.Abstract||0).toLocaleString()}</div>
  <div class="detail-block"><b>Missing DOI</b>${(M.missing.DOI||0).toLocaleString()}</div>
</div>

<h3>1. Advanced Search &amp; Retrieval</h3>
<p>Boolean operators (<code>AND</code> implied, <code>OR</code>, <code>NOT</code> / <code>-</code>), phrase searching with quotes, truncation (<code>*</code>), single-character wildcards (<code>?</code>), parentheses for grouping, and relevance-based ranking. Automatic query expansion adds abbreviations, LIS synonyms, and British/American spelling variants (toggle with “Auto-expand query”). Expanded terms are ranked lower than exact matches and highlighted.</p>

<h3>2. Semantic Search</h3>
<p>Use the <b>✦ Semantic AI</b> button for natural-language, concept-based retrieval that goes beyond keyword matching. Local TF-IDF / embedding-style ranking and optional online LLM assistance (when configured) help interpret query intent.</p>

<h3>3. Metadata Quality &amp; Authority Control</h3>
<p>Author and subject consistency is supported via the <b>⚖ Authorities</b> tool. Links open live lookups in <b>VIAF</b>, <b>LCNAF</b>, <b>LCSH</b>, <b>ORCID</b> and <b>Wikidata</b>. Country names are normalised. Persistent local author IDs are derived from normalised names.</p>

<h3>4. Advanced Filtering &amp; Faceted Navigation</h3>
<p>Left-hand facets provide year range, subject/keyword, journal/source, publisher, country, link availability and minimum citation count. Advanced Search lets you build fielded queries (title, abstract, keywords, authors, …) with match types including “ends with” and “contains”. Active filters appear as removable tags.</p>

<h3>5. User Interface &amp; Accessibility</h3>
<p>Responsive layout adapts to mobile and desktop. Keyboard focus outlines, skip links, ARIA labels, and high-contrast focus styles are present. Voice search (English / বাংলা) is available. The interface works across modern browsers. The <b>♿ Accessibility</b> button offers text size, high-contrast, link underline and reduced-motion settings.</p>

<h3>6. Performance &amp; Scalability</h3>
<p>Search, ranking, graph construction and Research Intelligence run entirely in the browser after a single dataset load. The full-stack edition serves the compressed dataset over HTTP with gzip. Regular evaluation of response time and result quality is supported by the built-in Evaluation Lab and by <b>Study Lab → Maintenance &amp; audit</b> (response-time test, metadata audit, backup/restore, server-side deployment checklist).</p>

<h3>7. Multilingual Information Retrieval</h3>
<p>Hindi (हिंदी / Devanagari), Bengali (বাংলা) and Banglish (romanised Bengali) queries are translated offline via curated LIS bilingual glossaries + transliteration, with optional online fallback. Mixed-language queries are supported. English queries can also match Bengali-script records when present in an uploaded collection. Cross-language mode is selectable under the search box.</p>

<h3>8. External Resource Integration</h3>
<p>The <b>🌐 Linked Open Data</b> button searches Wikipedia, OpenAlex, Crossref and DBpedia. SPARQL endpoints (Wikidata, DBpedia, optional GraphDB) are available. DOI and article links open external sources. Database connectors for Neo4j and GraphDB are provided for advanced users.</p>

<h3>9. Intelligent Search Assistance</h3>
<p>Auto-expand (synonyms / abbreviations / spelling variants), “Why this result?” explanations, related-papers recommendations, subject suggestions, duplicate detection, saved searches, and optional AI-assisted query formulation, and a “Did you mean…?” spelling suggestion built from the collection vocabulary (edit-distance matching). Search history is retained in the browser session via the Saved panel and URL hash state.</p>

<h3>10. Systematic Performance &amp; Usability Evaluation</h3>
<p>Open the Evaluation tools (toolbar) for precision, recall, F-measure (F1), PR curves, batch metrics and heuristic grading. Export results as CSV. The <b>👥 Study Lab</b> adds task completion time, task success rate, ease ratings, satisfaction, an automatic search success rate, and a blind comparison with a keyword-only baseline (P@10, pooled recall, F1). These indicators support comparative assessment of retrieval effectiveness.</p>

<h3>Available bibliographic fields</h3>
<p>Cites, Authors, Title, Year, Source, Publisher, Place, Country, ArticleURL, DOI, ISSN, Keywords, Abstract.</p>
<h3>Not present in this dataset</h3>
<p>Verified Open Access status, formal document-type codes, individual reference lists / cited-by links, library holdings identifiers.</p>
<h3>Online / offline behaviour</h3>
<p><b>Works fully offline:</b> search, Boolean &amp; semantic ranking, facets, knowledge graphs, Research Intelligence, export, saved items, authorities (local IDs), Bengali glossary &amp; transliteration. <b>Optional online features:</b> live VIAF/LCSH/OpenAlex/Crossref/Wikidata lookups, DOI links, Neo4j/GraphDB live queries, MyMemory translation fallback, three.js Journal Map fonts.</p>
<p class="tiny" style="margin-top:14px">Overall goal achieved: a more intelligent, user-centred, multilingual and scalable search system that significantly improves information discovery effectiveness and user experience for LIS literature.</p>`)}
function addAdvRow(data={bool:'AND',field:'title',op:'contains',value:''}){let div=document.createElement('div');div.className='advrow';div.innerHTML=`<select class="bool" aria-label="Boolean operator"><option>AND</option><option>OR</option></select><select class="field" aria-label="Search field"><option value="title">Title</option><option value="authors">Author</option><option value="keywords">Keyword</option><option value="source">Journal/source</option><option value="publisher">Publisher</option><option value="country">Country</option><option value="abstract">Abstract</option><option value="doi">DOI</option><option value="year">Year</option></select><select class="op" aria-label="Match operator"><option value="contains">contains</option><option value="exact">is exactly</option><option value="starts">starts with</option><option value="ends">ends with</option><option value="substr">contains text anywhere</option><option value="not">does not contain</option></select><input class="value" aria-label="Search value" placeholder="Enter value"><button class="ghost remove" aria-label="Remove field">×</button>`;div.querySelector('.bool').value=data.bool;div.querySelector('.field').value=data.field;div.querySelector('.op').value=data.op;div.querySelector('.value').value=data.value;div.querySelector('.remove').onclick=()=>div.remove();$('#advRows').appendChild(div)}
function collectAdvanced(){state.advanced=$$('#advRows .advrow').map((r,k)=>({bool:k===0?'AND':r.querySelector('.bool').value,field:r.querySelector('.field').value,op:r.querySelector('.op').value,value:r.querySelector('.value').value.trim()})).filter(x=>x.value)}
function fillStats(){const f=n=>Number(n).toLocaleString();const v={records:f(M.recordCount||R.length),sources:f((S||[]).length),countries:f((CO||[]).length),maxcites:f(M.maxCites||0),years:(M.minYear&&M.maxYear)?M.minYear+'\u2013'+M.maxYear:''};document.querySelectorAll('[data-stat]').forEach(e=>{if(v[e.dataset.stat]!==undefined)e.textContent=v[e.dataset.stat]})}
/* ===== Voice search (Web Speech API) — English or Bengali ===== */
let VOICE={rec:null,listening:false,lang:'en-US'};
function voiceSupported(){
  return !!(window.SpeechRecognition||window.webkitSpeechRecognition);
}
function voiceSetUi(on){
  const b=$('#voiceBtn');if(!b)return;
  b.classList.toggle('listening',!!on);
  b.setAttribute('aria-pressed',on?'true':'false');
  b.title=on?'Listening… click to stop':'Voice search (English or Bengali)';
  b.setAttribute('aria-label',on?'Stop voice search':'Start voice search');
}
function voiceStop(){
  try{if(VOICE.rec)VOICE.rec.stop()}catch(e){}
  VOICE.listening=false;voiceSetUi(false);
}
function voiceStart(){
  if(!voiceSupported()){
    toast('Voice search needs Chrome, Edge or Safari with microphone access');
    return;
  }
  if(VOICE.listening){voiceStop();return}
  const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
  const rec=new SR();
  const sel=$('#voiceLang');
  VOICE.lang=(sel&&sel.value)||'en-US';
  try{localStorage.setItem('lisVoiceLang',VOICE.lang)}catch(e){}
  rec.lang=VOICE.lang;
  rec.interimResults=true;
  rec.continuous=false;
  rec.maxAlternatives=1;
  let finalText='';
  rec.onstart=()=>{VOICE.listening=true;voiceSetUi(true);toast(VOICE.lang.startsWith('bn')?'শুনছি… (Listening)':'Listening…')};
  rec.onerror=e=>{
    VOICE.listening=false;voiceSetUi(false);
    const map={
      'not-allowed':'Microphone permission denied',
      'no-speech':'No speech detected — try again',
      'audio-capture':'No microphone found',
      'network':'Speech service network error',
      'aborted':'Voice search cancelled'
    };
    toast(map[e.error]||('Voice error: '+(e.error||'unknown')));
  };
  rec.onend=()=>{
    VOICE.listening=false;voiceSetUi(false);
    const q=$('#q');
    if(finalText.trim()&&q){
      q.value=finalText.trim();
      // Auto-run search so spoken queries behave like typed ones
      if($('#searchForm')){
        state.query=q.value;
        state.page=1;
        doSearch();
        toast(VOICE.lang.startsWith('bn')?'অনুসন্ধান চলছে…':'Searching…');
      }
    }
  };
  rec.onresult=ev=>{
    let interim='';
    for(let i=ev.resultIndex;i<ev.results.length;i++){
      const t=ev.results[i][0].transcript;
      if(ev.results[i].isFinal)finalText+=(finalText?' ':'')+t;
      else interim+=t;
    }
    const q=$('#q');
    if(q)q.value=(finalText+(interim?(' '+interim):'')).trim();
  };
  VOICE.rec=rec;
  try{rec.start()}catch(e){toast('Could not start microphone: '+(e.message||e));voiceSetUi(false)}
}
function voiceInit(){
  const b=$('#voiceBtn'),sel=$('#voiceLang');
  if(!b)return;
  try{
    const saved=localStorage.getItem('lisVoiceLang');
    if(saved&&sel){sel.value=saved;VOICE.lang=saved}
  }catch(e){}
  if(!voiceSupported()){
    b.disabled=true;
    b.title='Voice search not supported in this browser';
    b.style.opacity='.45';
    return;
  }
  b.onclick=e=>{e.preventDefault();voiceStart()};
  if(sel)sel.onchange=()=>{try{localStorage.setItem('lisVoiceLang',sel.value)}catch(e){}};
}
function bind(){

 $('#searchForm').onsubmit=e=>{e.preventDefault();const qv=$('#q').value;if(typeof clearFilters==='function')clearFilters(true);state.query=qv;$('#q').value=qv;state.savedOnly=false;state.page=1;if(qv&&qv.trim())document.body.classList.add('has-search');else document.body.classList.remove('has-search');doSearch()};
 $('#sort').onchange=e=>{state.sort=e.target.value;state.page=1;doSearch(false)};
 $$('[data-year]').forEach(c=>c.onchange=e=>{let y=Number(e.target.dataset.year);e.target.checked?state.yearSet.add(y):state.yearSet.delete(y);state.page=1;doSearch(false)});
 ['yearFrom','yearTo','minCites'].forEach(id=>$('#'+id).onchange=e=>{state[id==='minCites'?'minCites':id]=e.target.value?Number(e.target.value):null;state.page=1;doSearch(false)});
 $('#sourceFilter').onchange=e=>{state.source=e.target.value;state.page=1;doSearch(false)};$('#publisherFilter').onchange=e=>{state.publisher=e.target.value;state.page=1;doSearch(false)};$('#countryFilter').onchange=e=>{state.country=e.target.value;state.page=1;doSearch(false)};$('#subjectFilter').onchange=e=>{state.subject=e.target.value;state.page=1;doSearch(false)};$('#hasLink').onchange=e=>{state.hasLink=e.target.checked;state.page=1;doSearch(false)};
 $('#clearFilters').onclick=clearFilters;$('#advancedBtn').onclick=()=>$('#advanced').classList.toggle('open');$('#addAdvRow').onclick=()=>addAdvRow();$('#runAdvanced').onclick=()=>{collectAdvanced();state.page=1;doSearch()};$('#clearAdvanced').onclick=()=>{state.advanced=[];$('#advRows').innerHTML='';addAdvRow();doSearch(false)};
 $('#resultList').onclick=e=>{let b=e.target.closest('[data-act]');if(!b)return;let i=Number(b.dataset.id),act=b.dataset.act;if(act==='xlate')xlRecordModal(i);if(act==='detail')detail(i);if(act==='save'){let s=savedSet();s.has(i)?s.delete(i):s.add(i);setSaved(s);render()}if(act==='cite')citeModal(i);if(act==='export')exportModal([i],'Export record');if(act==='related')related(i);if(act==='graph')graph(i);if(act==='ner')riNERModal(i);if(act==='hyp')riHypModal(i);if(act==='gap')riGapModal(i);if(act==='why')$('#why-'+i).classList.toggle('open')};
 $('#savedBtn').onclick=()=>{state.savedOnly=!state.savedOnly;state.page=1;doSearch(false)};$('#exportResultsBtn').onclick=()=>exportModal(currentResults,'Export current results');$('#dupDetectBtn')&&($('#dupDetectBtn').onclick=()=>duplicatesModal('results'));$('#authFilesBtn')&&($('#authFilesBtn').onclick=()=>authorityModal());$('#graphResultsBtn').onclick=graphResults;$('#onlineSearchBtn').onclick=onlineSearchModal;$('#dbIntegrationBtn').onclick=dbIntegrationModal;$('#dataInfoBtn').onclick=dataInfo;
 $('#modalClose').onclick=closeModal;$('#modal').onclick=e=>{if(e.target===$('#modal'))closeModal()};document.addEventListener('keydown',e=>{if(e.key==='Escape'){closeModal();$('#facets').classList.remove('mobile-open')}});
 $('#riNER').onclick=()=>riNERModal();$('#riHyp').onclick=()=>riHypModal();$('#riGap').onclick=()=>riGapModal();$('#riAll').onclick=()=>riAllGraph();
 $('#mobileFilterBtn').onclick=()=>$('#facets').classList.add('mobile-open');$('#closeFilters').onclick=()=>$('#facets').classList.remove('mobile-open');
 voiceInit();
}
(async()=>{try{DATA=await unpack();M=DATA.m;R=DATA.r;S=M.sources;PUB=M.publishers;PLC=M.places;CO=M.countries;buildIndex();populateFacets();addAdvRow();updateSavedCount();bind();if(typeof bindDatasetUpload==='function')bindDatasetUpload();doSearch(false);fillStats();$('#loading').remove()}catch(err){$('#loading').innerHTML=`<div><h2>Could not load the local dataset</h2><p>${esc(err.message)}</p></div>`;console.error(err)}})();



/* ===== Dataset upload tab (all features preserved) ===== */
function datasetFieldMap(headers){
  const map={};
  headers.forEach((h,i)=>{
    const k=norm(h).replace(/[^a-z0-9]+/g,'');
    if(['cites','citations','citationcount','citedby','timescited'].includes(k)) map.cites=i;
    else if(['authors','author','creator','creators'].includes(k)) map.authors=i;
    else if(['title','articletitle','name'].includes(k)) map.title=i;
    else if(['year','publicationyear','pubyear','date'].includes(k)) map.year=i;
    else if(['source','journal','journalsource','publication','venue'].includes(k)) map.source=i;
    else if(['publisher','pub'].includes(k)) map.publisher=i;
    else if(['place','city','location'].includes(k)) map.place=i;
    else if(['country','nation'].includes(k)) map.country=i;
    else if(['articleurl','url','link','fulltexturl'].includes(k)) map.url=i;
    else if(['doi'].includes(k)) map.doi=i;
    else if(['issn'].includes(k)) map.issn=i;
    else if(['keywords','keyword','subjects','subject','tags'].includes(k)) map.keywords=i;
    else if(['abstract','summary','description'].includes(k)) map.abstract=i;
  });
  return map;
}
function parseCSVText(text){
  const rows=[]; let row=[], cell='', inQ=false;
  for(let i=0;i<text.length;i++){
    const ch=text[i], nx=text[i+1];
    if(inQ){
      if(ch==='"'&&nx==='"'){cell+='"';i++;}
      else if(ch==='"') inQ=false;
      else cell+=ch;
    }else{
      if(ch==='"') inQ=true;
      else if(ch===','){row.push(cell);cell='';}
      else if(ch==='\n'||(ch==='\r'&&nx==='\n')){if(ch==='\r')i++;row.push(cell);rows.push(row);row=[];cell='';}
      else if(ch==='\r'){row.push(cell);rows.push(row);row=[];cell='';}
      else cell+=ch;
    }
  }
  if(cell.length||row.length){row.push(cell);rows.push(row)}
  return rows.filter(r=>r.some(c=>String(c||'').trim()!==''));
}
function uniqIndex(list, value){
  value=String(value||'').trim();
  if(!value) return 0;
  let i=list.indexOf(value);
  if(i>=0) return i;
  list.push(value); return list.length-1;
}
function buildMetaFromRecords(rawRows, opts={}){
  const sources=[''], publishers=[''], places=[''], countries=[''];
  const yearCounts=new Map(), sourceCounts=new Map(), publisherCounts=new Map(), countryCounts=new Map(), keywordCounts=new Map();
  let missing={DOI:0,Keywords:0,Abstract:0,ArticleURL:0}, minYear=null, maxYear=null, maxCites=0;
  const r=[];
  for(const item of rawRows){
    let cites,authors,title,year,source,publisher,place,country,url,doi,issn,keywords,abstract;
    if(Array.isArray(item) && item.length>=13 && typeof item[4]==='number'){
      cites=+item[0]||0; authors=item[1]||''; title=item[2]||''; year=+item[3]||0;
      const si=item[4], pi=item[5], pli=item[6], ci=item[7];
      source=(opts.sources&&opts.sources[si])||''; publisher=(opts.publishers&&opts.publishers[pi])||'';
      place=(opts.places&&opts.places[pli])||''; country=(opts.countries&&opts.countries[ci])||'';
      url=item[8]||''; doi=item[9]||''; issn=item[10]||''; keywords=item[11]||''; abstract=item[12]||'';
    }else if(Array.isArray(item)){
      cites=+item[0]||0; authors=item[1]||''; title=item[2]||''; year=+item[3]||0;
      source=item[4]||''; publisher=item[5]||''; place=item[6]||''; country=item[7]||'';
      url=item[8]||''; doi=item[9]||''; issn=item[10]||''; keywords=item[11]||''; abstract=item[12]||'';
    }else{
      const o=item||{};
      cites=+(o.cites??o.citations??o.citation_count??0)||0;
      authors=o.authors||o.author||'';
      title=o.title||'';
      year=+(o.year||String(o.date||'').slice(0,4)||0)||0;
      source=o.source||o.journal||'';
      publisher=o.publisher||'';
      place=o.place||o.city||'';
      country=o.country||'';
      url=o.url||o.articleUrl||o.ArticleURL||'';
      doi=o.doi||o.DOI||'';
      issn=o.issn||o.ISSN||'';
      keywords=o.keywords||o.keyword||o.subjects||'';
      abstract=o.abstract||o.summary||'';
    }
    if(Array.isArray(authors)) authors=authors.join('; ');
    if(Array.isArray(keywords)) keywords=keywords.join('; ');
    const sIdx=uniqIndex(sources, source);
    const pIdx=uniqIndex(publishers, publisher);
    const plIdx=uniqIndex(places, place);
    const cIdx=uniqIndex(countries, country);
    r.push([cites, String(authors||''), String(title||''), year, sIdx, pIdx, plIdx, cIdx, String(url||''), String(doi||''), String(issn||''), String(keywords||''), String(abstract||'')]);
    if(year){yearCounts.set(year,(yearCounts.get(year)||0)+1); minYear=minYear==null?year:Math.min(minYear,year); maxYear=maxYear==null?year:Math.max(maxYear,year)}
    if(source) sourceCounts.set(sIdx,(sourceCounts.get(sIdx)||0)+1);
    if(publisher) publisherCounts.set(pIdx,(publisherCounts.get(pIdx)||0)+1);
    if(country) countryCounts.set(cIdx,(countryCounts.get(cIdx)||0)+1);
    maxCites=Math.max(maxCites,cites);
    if(!doi) missing.DOI++;
    if(!keywords) missing.Keywords++;
    if(!abstract) missing.Abstract++;
    if(!url) missing.ArticleURL++;
    String(keywords||'').split(/[;,|]/).map(x=>x.trim()).filter(x=>x.length>1).forEach(k=>{
      const key=k.toLowerCase();
      let e=keywordCounts.get(key)||{label:k,c:0}; e.c++; keywordCounts.set(key,e);
    });
  }
  const topKeywords=[...keywordCounts.values()].sort((a,b)=>b.c-a.c).slice(0,200).map(x=>[x.label,x.c]);
  const m={
    sources, publishers, places, countries,
    yearCounts:[...yearCounts.entries()].sort((a,b)=>b[0]-a[0]),
    sourceCounts:[...sourceCounts.entries()].sort((a,b)=>b[1]-a[1]),
    publisherCounts:[...publisherCounts.entries()].sort((a,b)=>b[1]-a[1]),
    countryCounts:[...countryCounts.entries()].sort((a,b)=>b[1]-a[1]),
    topKeywords, recordCount:r.length, missing,
    minYear:minYear??2020, maxYear:maxYear??2025, maxCites
  };
  return {m,r};
}
function normalizeUploadedPayload(raw){
  if(!raw||typeof raw!=='object') throw new Error('JSON must be an object or array of records');
  if(Array.isArray(raw.r) && raw.m && Array.isArray(raw.m.sources)){
    const m=Object.assign({
      yearCounts:[], sourceCounts:[], publisherCounts:[], countryCounts:[], topKeywords:[],
      recordCount:raw.r.length, missing:{DOI:0,Keywords:0,Abstract:0,ArticleURL:0},
      minYear:2020, maxYear:2025, maxCites:0
    }, raw.m);
    if(!m.recordCount) m.recordCount=raw.r.length;
    return {m, r:raw.r};
  }
  let rows=null;
  if(Array.isArray(raw)) rows=raw;
  else if(Array.isArray(raw.records)) rows=raw.records;
  else if(Array.isArray(raw.data)) rows=raw.data;
  else if(Array.isArray(raw.r)){
    return buildMetaFromRecords(raw.r, {
      sources:raw.m?.sources, publishers:raw.m?.publishers, places:raw.m?.places, countries:raw.m?.countries
    });
  }
  if(!rows||!rows.length) throw new Error('No records found. Use {m,r}, {records:[...]}, or CSV with headers.');
  return buildMetaFromRecords(rows);
}
function updateCollectionMetrics(){
  try{
    const cards=document.querySelectorAll('.metric-grid .metric-card b');
    if(cards[0]) cards[0].textContent=(M.recordCount||R.length).toLocaleString();
    if(cards[1]) cards[1].textContent=String((M.sourceCounts||[]).length || (S||[]).filter(Boolean).length);
    if(cards[2]) cards[2].textContent=String((M.countryCounts||[]).length || (CO||[]).filter(Boolean).length);
    if(cards[3]){
      const a=M.minYear, b=M.maxYear;
      cards[3].textContent=(a&&b)?(a===b?String(a):`${a}–${b}`):'—';
    }
    const insightStats=document.querySelectorAll('.insights .stat b');
    if(insightStats[0]) insightStats[0].textContent=(M.recordCount||R.length).toLocaleString();
    if(insightStats[1]) insightStats[1].textContent=String((M.sourceCounts||[]).length || (S||[]).filter(Boolean).length);
    if(insightStats[2]) insightStats[2].textContent=String((M.countryCounts||[]).length || (CO||[]).filter(Boolean).length);
    if(insightStats[3]) insightStats[3].textContent=Number(M.maxCites||0).toLocaleString();
  }catch(e){console.warn(e)}
}
function resetFacetsUI(){
  const yc=$('#yearChecks'); if(yc) yc.innerHTML='';
  const keepFirst=sel=>{if(!sel)return; const first=sel.querySelector('option'); sel.innerHTML=''; if(first) sel.appendChild(first);};
  keepFirst($('#sourceFilter')); keepFirst($('#publisherFilter')); keepFirst($('#countryFilter')); keepFirst($('#subjectFilter'));
}
function applyDataset(payload, label='Uploaded dataset'){
  DATA=payload; M=payload.m; R=payload.r; try{setTimeout(fillStats,0)}catch(e){}
  S=M.sources||['']; PUB=M.publishers||['']; PLC=M.places||['']; CO=M.countries||[''];
  try{ localStorage.removeItem('libSaved'); }catch(e){}
  state={query:'',page:1,sort:'relevance',savedOnly:false,yearSet:new Set(),yearFrom:null,yearTo:null,source:'',publisher:'',country:'',subject:'',hasLink:false,minCites:0,advanced:[]};
  currentResults=[]; SEARCH_SAVED=null;
  document.body.classList.remove('has-search');
  const qe=$('#q'); if(qe) qe.value='';
  if($('#sort')) $('#sort').value='relevance';
  if($('#yearFrom')) $('#yearFrom').value='';
  if($('#yearTo')) $('#yearTo').value='';
  if($('#minCites')) $('#minCites').value=0;
  if($('#hasLink')) $('#hasLink').checked=false;
  if($('#advRows')){ $('#advRows').innerHTML=''; if(typeof addAdvRow==='function') addAdvRow(); }
  resetFacetsUI();
  buildIndex();
  populateFacets();
  updateCollectionMetrics();
  updateSavedCount();
  doSearch(false);
  toast(`${label}: ${R.length.toLocaleString()} records loaded`);
  const loadEl=$('#loading'); if(loadEl) loadEl.remove();
}
async function handleDatasetFile(file){
  if(!file) return;
  const name=(file.name||'').toLowerCase();
  const text=await file.text();
  let payload;
  if(name.endsWith('.csv') || (file.type||'').includes('csv')){
    const rows=parseCSVText(text);
    if(rows.length<2) throw new Error('CSV needs a header row and at least one data row');
    const headers=rows[0];
    const fmap=datasetFieldMap(headers);
    if(fmap.title===undefined) throw new Error('CSV must include a Title column (or equivalent)');
    const objects=rows.slice(1).map(cols=>{
      const get=k=>fmap[k]!==undefined?cols[fmap[k]]:'';
      let year=String(get('year')||'').trim();
      const ym=year.match(/(20\d{2}|19\d{2})/);
      year=ym?Number(ym[1]):0;
      return {
        cites:get('cites'), authors:get('authors'), title:get('title'), year,
        source:get('source'), publisher:get('publisher'), place:get('place'), country:get('country'),
        url:get('url'), doi:get('doi'), issn:get('issn'), keywords:get('keywords'), abstract:get('abstract')
      };
    }).filter(o=>String(o.title||'').trim());
    payload=buildMetaFromRecords(objects);
  }else{
    let raw;
    try{ raw=JSON.parse(text); }catch(e){ throw new Error('Invalid JSON: '+e.message); }
    payload=normalizeUploadedPayload(raw);
  }
  if(!payload.r?.length) throw new Error('Dataset contains zero records');
  applyDataset(payload, file.name||'Uploaded dataset');
}
function uploadDatasetModal(){
  showModal(`<div class="db-modal-title"><span class="db-mark">⇧</span><h2>Upload Dataset</h2><span class="badge">JSON / CSV</span></div>
  <div class="db-banner"><b>Replace the library data</b> while keeping every feature: search, filters, knowledge graph, Research Intelligence, export, Neo4j &amp; GraphDB.</div>
  <div class="detail-grid">
    <div class="detail-block"><b>JSON formats</b>App format <code>{m, r}</code>, <code>{records:[...]}</code>, or an array of paper objects.</div>
    <div class="detail-block"><b>CSV columns</b>Title (required), Authors, Year, Source/Journal, Publisher, Place, Country, URL, DOI, ISSN, Keywords, Abstract, Cites.</div>
  </div>
  <div class="note" style="margin:12px 0">Saved items are cleared when a new dataset is loaded (record indexes change). Everything runs in your browser — no server upload.</div>
  <div class="actions">
    <button class="primary" id="pickDatasetFile" style="background:#0b9f6e;border-color:#0b9f6e">Choose JSON or CSV file…</button>
    <button class="ghost" id="reloadEmbeddedDataset">Reload original embedded library</button>
  </div>
  <p class="tiny" id="uploadDatasetStatus" style="margin-top:10px">Current library: ${(M&&M.recordCount)|| (R&&R.length) || 0} records</p>`);
  $('#pickDatasetFile').onclick=()=>$('#datasetFileInput').click();
  $('#reloadEmbeddedDataset').onclick=async()=>{
    try{
      const st=$('#uploadDatasetStatus'); if(st) st.textContent='Reloading embedded library…';
      const payload=await unpack();
      applyDataset(payload, 'Original embedded library');
      closeModal();
    }catch(e){ toast('Could not reload embedded data: '+e.message); }
  };
}
function bindDatasetUpload(){
  const btn=$('#uploadDatasetBtn');
  const input=$('#datasetFileInput');
  if(btn) btn.onclick=uploadDatasetModal;
  if(!input) return;
  input.onchange=async e=>{
    const file=e.target.files&&e.target.files[0];
    input.value='';
    if(!file) return;
    try{
      closeModal();
      let ov=document.createElement('div'); ov.id='uploadOverlay'; ov.className='loading'; ov.style.zIndex=250;
      ov.innerHTML='<div><div class="spinner"></div><strong>Loading dataset…</strong><div class="tiny" style="margin-top:6px">'+esc(file.name)+'</div></div>';
      document.body.appendChild(ov);
      await new Promise(r=>setTimeout(r,30));
      await handleDatasetFile(file);
    }catch(err){
      console.error(err);
      toast(err.message||'Upload failed');
      showModal(`<h2>Upload failed</h2><p>${esc(err.message||String(err))}</p><div class="actions"><button class="primary" id="uploadRetryBtn">Try again</button></div>`);
      const rb=$('#uploadRetryBtn'); if(rb) rb.onclick=uploadDatasetModal;
    }finally{
      const ov=document.getElementById('uploadOverlay'); if(ov) ov.remove();
    }
  };
}

/* ===== Neo4j + GraphDB live integration ===== */
Object.assign(KG_COLORS,{dbPaper:'#0f4c81',dbAuthor:'#ea580c',dbJournal:'#059669',dbConcept:'#7c3aed',dbNode:'#2563eb',dbLiteral:'#64748b',dbClass:'#be185d'});
Object.assign(KG_NAMES,{dbPaper:'Database paper',dbAuthor:'Database author',dbJournal:'Database journal',dbConcept:'Database concept',dbNode:'RDF / graph node',dbLiteral:'Literal value',dbClass:'RDF class'});
const DB_DEFAULTS={neoBase:'http://localhost:7474',neoDb:'neo4j',neoUser:'neo4j',graphRepo:'http://localhost:7200/repositories/library'};
let DB_LAST_NEO=null,DB_LAST_RDF=null;
function dbAuth(user,pass){if(!user)return{};try{return{'Authorization':'Basic '+btoa(user+':'+pass)}}catch{return{}}}
function dbShort(v){v=String(v||'');if(v.length<=58)return v;let h=v.replace(/[#\/]$/,'').split(/[#\/]/).pop();return h&&h.length<45?h:v.slice(0,25)+'…'+v.slice(-22)}
function dbJsonCell(v){if(v===null||v===undefined)return'';if(typeof v==='string'||typeof v==='number'||typeof v==='boolean')return String(v);try{return JSON.stringify(v)}catch{return String(v)}}
function dbSetStatus(id,kind,msg){let el=$('#'+id);if(!el)return;el.className='db-status '+kind;el.innerHTML='<i></i><span>'+esc(msg)+'</span>'}
function dbCfg(){return{
 mode:$('#dbMode')?.value||'direct',
 neoBase:($('#neoBase')?.value||DB_DEFAULTS.neoBase).trim().replace(/\/$/,''),neoDb:($('#neoDb')?.value||'neo4j').trim(),neoUser:($('#neoUser')?.value||'').trim(),neoPass:$('#neoPass')?.value||'',neoProxy:($('#neoProxy')?.value||'http://localhost:8000/api/neo4j/query').trim(),
 graphRepo:($('#graphRepo')?.value||DB_DEFAULTS.graphRepo).trim().replace(/\/$/,''),graphUser:($('#graphUser')?.value||'').trim(),graphPass:$('#graphPass')?.value||'',graphProxy:($('#graphProxy')?.value||'http://localhost:8000/api/graphdb/query').trim()
}}
async function dbNeoFetch(statement){let c=dbCfg();if(c.mode==='proxy'){let r=await fetch(c.neoProxy,{method:'POST',headers:{'Content-Type':'application/json','Accept':'application/json'},body:JSON.stringify({query:statement,parameters:{}})});let t=await r.text();if(!r.ok)throw new Error('Proxy '+r.status+': '+t.slice(0,250));return JSON.parse(t)}let url=c.neoBase+'/db/'+encodeURIComponent(c.neoDb)+'/query/v2';let r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json','Accept':'application/json',...dbAuth(c.neoUser,c.neoPass)},body:JSON.stringify({statement,parameters:{}})});let t=await r.text();if(!r.ok)throw new Error('Neo4j '+r.status+': '+t.slice(0,300));return JSON.parse(t)}
async function dbGraphFetch(query){let c=dbCfg();if(c.mode==='proxy'){let r=await fetch(c.graphProxy,{method:'POST',headers:{'Content-Type':'application/json','Accept':'application/json'},body:JSON.stringify({query})});let t=await r.text();if(!r.ok)throw new Error('Proxy '+r.status+': '+t.slice(0,250));return JSON.parse(t)}let body=new URLSearchParams({query});let r=await fetch(c.graphRepo,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8','Accept':'application/sparql-results+json',...dbAuth(c.graphUser,c.graphPass)},body});let t=await r.text();if(!r.ok)throw new Error('GraphDB '+r.status+': '+t.slice(0,300));return JSON.parse(t)}
function dbNeoRows(json){if(json?.data?.fields&&Array.isArray(json.data.values))return{fields:json.data.fields,values:json.data.values};if(Array.isArray(json?.records)){let keys=json.records.length?Object.keys(json.records[0]):[];return{fields:keys,values:json.records.map(r=>keys.map(k=>r[k]))}}return{fields:[],values:[]}}
function dbNeoTable(json){let x=dbNeoRows(json);if(!x.fields.length)return'<div class="note">Query completed, but no tabular rows were returned.</div>';return `<div class="db-tablewrap"><table class="db-table"><thead><tr>${x.fields.map(f=>`<th>${esc(f)}</th>`).join('')}</tr></thead><tbody>${x.values.slice(0,300).map(row=>`<tr>${row.map(v=>`<td>${esc(dbJsonCell(v))}</td>`).join('')}</tr>`).join('')}</tbody></table></div><div class="db-mini">Showing up to 300 returned rows.</div>`}
function dbRdfTable(json){let vars=json?.head?.vars||[],rows=json?.results?.bindings||[];if(!vars.length)return'<div class="note">No SPARQL SELECT bindings were returned.</div>';return `<div class="db-tablewrap"><table class="db-table"><thead><tr>${vars.map(f=>`<th>${esc(f)}</th>`).join('')}</tr></thead><tbody>${rows.slice(0,300).map(row=>`<tr>${vars.map(v=>`<td>${esc(row[v]?.value||'')}</td>`).join('')}</tr>`).join('')}</tbody></table></div><div class="db-mini">Showing up to 300 returned bindings.</div>`}
function dbNeoType(labels=[]){let x=labels.map(norm).join(' ');if(/paper|publication|article/.test(x))return'dbPaper';if(/author|person|researcher/.test(x))return'dbAuthor';if(/journal|source/.test(x))return'dbJournal';if(/keyword|concept|subject|topic/.test(x))return'dbConcept';return'dbNode'}
function dbNeoGraph(json){let x=dbNeoRows(json),nodes=[],edges=[],map=new Map(),rels=[];let addNode=o=>{let id=String(o.elementId??o.id??('node-'+map.size));if(map.has(id))return map.get(id);let p=o.properties||{},labels=o.labels||[];let label=p.title||p.name||p.label||p.doi||p.recordId||labels[0]||dbShort(id);let n={id:'neo|'+id,type:dbNeoType(labels),label:String(label),description:(labels.length?'Labels: '+labels.join(', ')+' · ':'')+Object.entries(p).slice(0,8).map(([k,v])=>k+'='+dbJsonCell(v)).join(' · '),weight:2,x:0,y:0,vx:0,vy:0,fixed:false};map.set(id,n);nodes.push(n);return n};
 let walk=v=>{if(!v||typeof v!=='object')return;if(Array.isArray(v)){v.forEach(walk);return}if(Array.isArray(v.labels)&&(v.elementId!==undefined||v.id!==undefined)){addNode(v);return}if(v.type&&(v.startNodeElementId!==undefined||v.startNode!==undefined)&&(v.endNodeElementId!==undefined||v.endNode!==undefined)){rels.push(v);return}if(Array.isArray(v.nodes))v.nodes.forEach(walk);if(Array.isArray(v.relationships))v.relationships.forEach(walk);for(let z of Object.values(v))if(z&&typeof z==='object')walk(z)};x.values.forEach(walk);
 for(let r of rels){let aId=String(r.startNodeElementId??r.startNode),bId=String(r.endNodeElementId??r.endNode),a=map.get(aId),b=map.get(bId);if(!a){a={id:'neo|'+aId,type:'dbNode',label:dbShort(aId),weight:2,x:0,y:0,vx:0,vy:0,fixed:false};map.set(aId,a);nodes.push(a)}if(!b){b={id:'neo|'+bId,type:'dbNode',label:dbShort(bId),weight:2,x:0,y:0,vx:0,vy:0,fixed:false};map.set(bId,b);nodes.push(b)}edges.push({a,b,relation:String(r.type||'RELATED_TO').replace(/_/g,' ').toLowerCase(),detail:dbJsonCell(r.properties||{})})}
 return{nodes:nodes.slice(0,350),edges:edges.slice(0,700)}}
function dbGraphDbGraph(json){let rows=json?.results?.bindings||[],nodes=[],edges=[],map=new Map(),labels=new Map();for(let row of rows){let s=row.s,p=row.p,o=row.o;if(s&&p&&o&&/label$/i.test(p.value)&&o.type==='literal')labels.set(s.value,o.value)}let add=(b,isObj=false)=>{if(!b)return null;let id=(b.type||'x')+'|'+b.value;if(map.has(id))return map.get(id);let isLit=b.type==='literal'||b.type==='typed-literal';let val=labels.get(b.value)||dbShort(b.value);let type=isLit?'dbLiteral':(/class|type/i.test(b.value)?'dbClass':'dbNode');let n={id:'rdf|'+id,type,label:val,description:(b.type||'value')+': '+b.value,weight:2,x:0,y:0,vx:0,vy:0,fixed:false};map.set(id,n);nodes.push(n);return n};for(let row of rows){if(!row.s||!row.p||!row.o)continue;let a=add(row.s),b=add(row.o,true);if(!a||!b)continue;let rel=dbShort(row.p.value);edges.push({a,b,relation:rel,detail:row.p.value})}return{nodes:nodes.slice(0,350),edges:edges.slice(0,700)}}
function dbOpenGenericGraph(g,title,desc){if(!g.nodes.length){toast('No graph-shaped data returned');return}riGenericGraph(g,title,desc,'Relationships come directly from the connected database query result. For Neo4j, return nodes and relationships together (for example <b>RETURN n,r,m</b>). For GraphDB, return <b>?s ?p ?o</b> bindings for graph visualization.')}
async function dbTestNeo(){dbSetStatus('neoStatus','busy','Testing Neo4j…');try{let j=await dbNeoFetch('RETURN 1 AS ok');DB_LAST_NEO=j;let x=dbNeoRows(j);dbSetStatus('neoStatus','ok','Connected. Query API responded'+(x.values.length?' successfully.':'.'))}catch(e){dbSetStatus('neoStatus','bad',e.message+' — if this is a browser CORS restriction, use Backend proxy mode.')}}
async function dbRunNeo(){let q=$('#neoQuery').value.trim();if(!q)return;dbSetStatus($('#neoStatus2')?'neoStatus2':'neoStatus','busy','Running Cypher…');try{let j=await dbNeoFetch(q);DB_LAST_NEO=j;$('#neoResult').innerHTML=dbNeoTable(j);let g=dbNeoGraph(j);$('#neoGraphBtn').disabled=!g.nodes.length;dbSetStatus($('#neoStatus2')?'neoStatus2':'neoStatus','ok','Cypher completed. '+dbNeoRows(j).values.length+' row(s) returned.')}catch(e){dbSetStatus($('#neoStatus2')?'neoStatus2':'neoStatus','bad',e.message)}}
async function dbTestGraph(){dbSetStatus('graphStatus','busy','Testing GraphDB…');try{let j=await dbGraphFetch('SELECT (COUNT(*) AS ?triples) WHERE { ?s ?p ?o }');DB_LAST_RDF=j;let v=j?.results?.bindings?.[0]?.triples?.value;dbSetStatus('graphStatus','ok','Connected to SPARQL endpoint'+(v?' · '+Number(v).toLocaleString()+' triples.':'.'))}catch(e){dbSetStatus('graphStatus','bad',e.message+' — if this is a browser CORS restriction, use Backend proxy mode.')}}
async function dbRunGraph(){let q=$('#graphQuery').value.trim();if(!q)return;dbSetStatus($('#graphStatus2')?'graphStatus2':'graphStatus','busy','Running SPARQL…');try{let j=await dbGraphFetch(q);DB_LAST_RDF=j;$('#graphResult').innerHTML=dbRdfTable(j);let g=dbGraphDbGraph(j);$('#graphGraphBtn').disabled=!g.nodes.length;dbSetStatus($('#graphStatus2')?'graphStatus2':'graphStatus','ok','SPARQL completed. '+(j?.results?.bindings?.length||0)+' binding row(s) returned.')}catch(e){dbSetStatus($('#graphStatus2')?'graphStatus2':'graphStatus','bad',e.message)}}
function dbCyEsc(v){return String(v??'').replace(/\\/g,'\\\\').replace(/'/g,"\\'").replace(/[\r\n]+/g,' ')}
function dbTtlEsc(v){return String(v??'').replace(/\\/g,'\\\\').replace(/"/g,'\\"').replace(/\r?\n/g,'\\n')}
function dbSlug(v){let s=norm(v).replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'').slice(0,70);return s||'item'}
function dbScopeHits(){let val=$('#dbExportScope')?.value||'100',n=val==='all'?currentResults.length:Number(val);return currentResults.slice(0,n)}
function dbNeoExportText(hits){let lines=['// Academic Library -> Neo4j import script','// Generated from the active ranked result set','CREATE CONSTRAINT paper_record IF NOT EXISTS FOR (p:Paper) REQUIRE p.recordId IS UNIQUE;','CREATE INDEX author_name IF NOT EXISTS FOR (n:Author) ON (n.name);','CREATE INDEX keyword_name IF NOT EXISTS FOR (n:Keyword) ON (n.name);',''];for(let h of hits){let o=recObj(h.i),pid='local-'+h.i;lines.push(`MERGE (p:Paper {recordId:'${dbCyEsc(pid)}'}) SET p.title='${dbCyEsc(o.title)}', p.year=${Number(o.year)||'null'}, p.cites=${Number(o.cites)||0}, p.doi='${dbCyEsc(o.doi)}', p.url='${dbCyEsc(o.url)}', p.issn='${dbCyEsc(o.issn)}', p.abstract='${dbCyEsc(o.abstract)}';`);for(let a of splitAuthors(o.authors))lines.push(`MATCH (p:Paper {recordId:'${dbCyEsc(pid)}'}) MERGE (a:Author {name:'${dbCyEsc(a)}'}) MERGE (p)-[:AUTHORED_BY]->(a);`);if(o.source)lines.push(`MATCH (p:Paper {recordId:'${dbCyEsc(pid)}'}) MERGE (j:Journal {name:'${dbCyEsc(o.source)}'}) MERGE (p)-[:PUBLISHED_IN]->(j);`);for(let k of splitKeywords(o.keywords))lines.push(`MATCH (p:Paper {recordId:'${dbCyEsc(pid)}'}) MERGE (k:Keyword {name:'${dbCyEsc(k)}'}) MERGE (p)-[:HAS_KEYWORD]->(k);`);if(o.publisher)lines.push(`MATCH (p:Paper {recordId:'${dbCyEsc(pid)}'}) MERGE (x:Publisher {name:'${dbCyEsc(o.publisher)}'}) MERGE (p)-[:PUBLISHED_BY]->(x);`);if(o.country)lines.push(`MATCH (p:Paper {recordId:'${dbCyEsc(pid)}'}) MERGE (c:Country {name:'${dbCyEsc(o.country)}'}) MERGE (p)-[:ASSOCIATED_COUNTRY]->(c);`);if(o.year)lines.push(`MATCH (p:Paper {recordId:'${dbCyEsc(pid)}'}) MERGE (y:Year {value:${Number(o.year)}}) MERGE (p)-[:PUBLISHED_IN_YEAR]->(y);`);lines.push('')}return lines.join('\n')}
function dbTurtleExportText(hits){let L=['@prefix lib: <https://example.org/academic-library/> .','@prefix dcterms: <http://purl.org/dc/terms/> .','@prefix bibo: <http://purl.org/ontology/bibo/> .','@prefix foaf: <http://xmlns.com/foaf/0.1/> .','@prefix xsd: <http://www.w3.org/2001/XMLSchema#> .',''];let declared=new Set();let entity=(kind,label)=>'lib:'+kind+'-'+dbSlug(label);for(let h of hits){let o=recObj(h.i),p='lib:paper-'+h.i,props=[`a bibo:AcademicArticle`,`dcterms:title "${dbTtlEsc(o.title)}"`];if(o.year)props.push(`dcterms:issued "${o.year}"^^xsd:gYear`);if(o.doi)props.push(`bibo:doi "${dbTtlEsc(o.doi)}"`);if(o.issn)props.push(`bibo:issn "${dbTtlEsc(o.issn)}"`);if(o.url)props.push(`dcterms:identifier <${o.url.replace(/>/g,'%3E')}>`);if(o.abstract)props.push(`dcterms:abstract "${dbTtlEsc(o.abstract)}"`);for(let a of splitAuthors(o.authors)){let u=entity('author',a);props.push(`dcterms:creator ${u}`);if(!declared.has(u)){L.push(`${u} a foaf:Person ; foaf:name "${dbTtlEsc(a)}" .`);declared.add(u)}}if(o.source){let u=entity('journal',o.source);props.push(`dcterms:isPartOf ${u}`);if(!declared.has(u)){L.push(`${u} a bibo:Journal ; dcterms:title "${dbTtlEsc(o.source)}" .`);declared.add(u)}}for(let k of splitKeywords(o.keywords)){let u=entity('concept',k);props.push(`dcterms:subject ${u}`);if(!declared.has(u)){L.push(`${u} a lib:ResearchConcept ; dcterms:title "${dbTtlEsc(k)}" .`);declared.add(u)}}if(o.publisher){let u=entity('publisher',o.publisher);props.push(`dcterms:publisher ${u}`);if(!declared.has(u)){L.push(`${u} a foaf:Organization ; foaf:name "${dbTtlEsc(o.publisher)}" .`);declared.add(u)}}if(o.country){let u=entity('country',o.country);props.push(`lib:associatedCountry ${u}`);if(!declared.has(u)){L.push(`${u} a lib:Country ; dcterms:title "${dbTtlEsc(o.country)}" .`);declared.add(u)}}L.push(`${p} ${props.join(' ;\n  ')} .\n`)}return L.join('\n')}
function dbDownloadNeo(){let hits=dbScopeHits();if(!hits.length){toast('Run a search first');return}download('academic_library_neo4j.cypher',dbNeoExportText(hits),'text/plain;charset=utf-8');toast('Neo4j Cypher export created')}
function dbDownloadRdf(){let hits=dbScopeHits();if(!hits.length){toast('Run a search first');return}download('academic_library_graphdb.ttl',dbTurtleExportText(hits),'text/turtle;charset=utf-8');toast('GraphDB Turtle export created')}
function dbTemplate(kind,name){let map={neo:{sample:'MATCH (n)-[r]->(m) RETURN n,r,m LIMIT 75',papers:"MATCH (p:Paper) RETURN p ORDER BY coalesce(p.cites,0) DESC LIMIT 50",authors:'MATCH (p:Paper)-[r:AUTHORED_BY]->(a:Author) RETURN p,r,a LIMIT 100',concepts:'MATCH (p:Paper)-[r:HAS_KEYWORD]->(k:Keyword) RETURN p,r,k LIMIT 120'},rdf:{sample:'SELECT ?s ?p ?o WHERE { ?s ?p ?o } LIMIT 100',papers:'PREFIX bibo: <http://purl.org/ontology/bibo/>\nPREFIX dcterms: <http://purl.org/dc/terms/>\nSELECT ?s ?p ?o WHERE { ?s a bibo:AcademicArticle . ?s ?p ?o } LIMIT 120',authors:'PREFIX dcterms: <http://purl.org/dc/terms/>\nSELECT ?s ?p ?o WHERE { ?s dcterms:creator ?o . BIND(dcterms:creator AS ?p) } LIMIT 120',concepts:'PREFIX dcterms: <http://purl.org/dc/terms/>\nSELECT ?s ?p ?o WHERE { ?s dcterms:subject ?o . BIND(dcterms:subject AS ?p) } LIMIT 120'}};return map[kind][name]||map[kind].sample}
function dbBindTabs(){$$('.db-tab').forEach(b=>b.onclick=()=>{$$('.db-tab').forEach(x=>x.classList.remove('active'));$$('.db-pane').forEach(x=>x.classList.remove('active'));b.classList.add('active');$('#dbPane-'+b.dataset.tab).classList.add('active')})}
function dbIntegrationModal(){showModal(`<div class="db-modal-title"><span class="db-mark">⬡</span><h2>Neo4j + GraphDB Integration Center</h2><span class="badge">Local / server connector</span></div><div class="db-banner"><b>Purpose:</b> connect this academic search portal to a property graph (Neo4j) and/or semantic RDF graph (GraphDB), query them, and visualize returned relationships. Password fields stay only in page memory and are never written to localStorage.</div><div class="db-architecture"><div class="db-archbox"><b>Academic Search UI</b><br><span class="db-mini">27,825 local records</span></div><div class="db-arrow">⇄</div><div class="db-archbox"><b>Neo4j</b><br><span class="db-mini">Cypher property graph</span></div><div class="db-arrow">+</div><div class="db-archbox"><b>GraphDB</b><br><span class="db-mini">SPARQL / RDF semantics</span></div></div><div class="db-tabs"><button class="db-tab active" data-tab="connect">Connections</button><button class="db-tab" data-tab="neo">Cypher Console</button><button class="db-tab" data-tab="rdf">SPARQL Console</button><button class="db-tab" data-tab="export">Build Graph Data</button><button class="db-tab" data-tab="schema">Relationship Model</button></div>
<div class="db-pane active" id="dbPane-connect"><div class="db-card"><h3>Connection mode</h3><p>Direct mode is useful on a local trusted machine. Backend proxy mode is recommended when you publish the website because credentials must not be embedded in public browser code.</p><div class="db-form"><label>Mode<select id="dbMode"><option value="direct">Direct browser → local databases</option><option value="proxy">Backend proxy → databases (recommended for web)</option></select></label><div class="db-security"><b>Security:</b> Do not save production database passwords in this HTML. Enter them only at runtime. A public website should send queries to your own authenticated backend API.</div></div></div><div class="db-links"><div class="db-link-card infra"><b>InfraNodus</b><span>Text-network analysis and knowledge-graph visualisation for research text</span><a href="https://infranodus.com" target="_blank" rel="noopener noreferrer">Open InfraNodus ↗</a></div><div class="db-link-card"><b>Neo4j</b><span>Official website for the Neo4j property-graph database</span><a href="https://neo4j.com" target="_blank" rel="noopener noreferrer">Visit neo4j.com ↗</a></div><div class="db-link-card"><b>GraphDB</b><span>Official website for Ontotext GraphDB (RDF and SPARQL)</span><a href="https://graphdb.ontotext.com" target="_blank" rel="noopener noreferrer">Visit GraphDB ↗</a></div></div><div class="db-grid" style="margin-top:12px"><div class="db-card neo"><h3>Connect to Neo4j</h3><p>Uses the Neo4j HTTP Query API in direct mode.</p><div class="db-form"><label>Neo4j base URL<input id="neoBase" value="${DB_DEFAULTS.neoBase}"></label><div class="db-row"><label>Database<input id="neoDb" value="${DB_DEFAULTS.neoDb}"></label><label>Username<input id="neoUser" value="${DB_DEFAULTS.neoUser}"></label></div><label>Password<input id="neoPass" type="password" autocomplete="off" placeholder="Enter at runtime"></label><label>Proxy endpoint<input id="neoProxy" value="http://localhost:8000/api/neo4j/query"></label></div><div class="db-actions"><button class="primary" id="neoTest">Test Neo4j</button></div><div class="db-status" id="neoStatus"><i></i><span>Not tested</span></div></div><div class="db-card rdf"><h3>Connect to GraphDB</h3><p>Uses the repository SPARQL endpoint in direct mode.</p><div class="db-form"><label>Repository endpoint<input id="graphRepo" value="${DB_DEFAULTS.graphRepo}"></label><div class="db-row"><label>Username (optional)<input id="graphUser" autocomplete="off"></label><label>Password (optional)<input id="graphPass" type="password" autocomplete="off"></label></div><label>Proxy endpoint<input id="graphProxy" value="http://localhost:8000/api/graphdb/query"></label></div><div class="db-actions"><button class="primary" id="graphTest">Test GraphDB</button></div><div class="db-status" id="graphStatus"><i></i><span>Not tested</span></div></div></div></div>
<div class="db-pane" id="dbPane-neo"><div class="db-card neo"><h3>Cypher Query</h3><p>For graph visualization, return nodes and relationships together, e.g. <code>RETURN n,r,m</code>.</p><div class="db-template-row"><button class="ghost" data-neo-t="sample">Sample network</button><button class="ghost" data-neo-t="papers">Top papers</button><button class="ghost" data-neo-t="authors">Author network</button><button class="ghost" data-neo-t="concepts">Concept network</button></div><textarea class="db-query" id="neoQuery">MATCH (n)-[r]->(m) RETURN n,r,m LIMIT 75</textarea><div class="db-actions"><button class="primary" id="neoRun">Run Cypher</button><button class="ghost" id="neoGraphBtn" disabled>Visualize returned graph</button></div><div class="db-status" id="neoStatus2"><i></i><span>Use the Connections tab to test connectivity first.</span></div><div class="db-result" id="neoResult"></div></div></div>
<div class="db-pane" id="dbPane-rdf"><div class="db-card rdf"><h3>SPARQL Query</h3><p>For visualization, use a SELECT query that returns <code>?s ?p ?o</code>.</p><div class="db-template-row"><button class="ghost" data-rdf-t="sample">Sample triples</button><button class="ghost" data-rdf-t="papers">Paper graph</button><button class="ghost" data-rdf-t="authors">Creator links</button><button class="ghost" data-rdf-t="concepts">Subject links</button></div><textarea class="db-query" id="graphQuery">SELECT ?s ?p ?o WHERE { ?s ?p ?o } LIMIT 100</textarea><div class="db-actions"><button class="primary" id="graphRun">Run SPARQL</button><button class="ghost" id="graphGraphBtn" disabled>Visualize returned graph</button></div><div class="db-status" id="graphStatus2"><i></i><span>Use the Connections tab to test connectivity first.</span></div><div class="db-result" id="graphResult"></div></div></div>
<div class="db-pane" id="dbPane-export"><div class="db-card"><h3>Build graph data from the active library search</h3><p>Export a subset of the current ranked results into database-ready graph formats. This is the safest way to populate your databases before enabling live queries.</p><label class="db-mini">Export scope<select id="dbExportScope" style="margin-left:8px;border:1px solid var(--line);border-radius:8px;padding:7px"><option value="20">Top 20 results</option><option value="100" selected>Top 100 results</option><option value="500">Top 500 results</option><option value="1000">Top 1,000 results</option><option value="all">All current results (large)</option></select></label><div class="db-export-grid" style="margin-top:12px"><div class="db-export-card"><h3>Neo4j property graph</h3><p class="db-mini">Creates Paper, Author, Journal, Keyword, Publisher, Country and Year nodes with explicit bibliographic relationships.</p><button class="primary" id="dbExportNeo">Download .cypher</button></div><div class="db-export-card"><h3>GraphDB semantic graph</h3><p class="db-mini">Creates RDF/Turtle using BIBO, Dublin Core Terms, FOAF and a small project namespace.</p><button class="primary" id="dbExportRdf">Download .ttl</button></div></div><div class="db-security">For your complete 27,825-record corpus, the generated file may be large. Import the file using Neo4j/GraphDB administration tools rather than pasting the whole export into the query console.</div></div></div>
<div class="db-pane" id="dbPane-schema"><div class="db-grid"><div class="db-card neo"><h3>Neo4j relationship model</h3><div class="db-schema"><code>(Paper)-[:AUTHORED_BY]→(Author)</code><br><code>(Paper)-[:PUBLISHED_IN]→(Journal)</code><br><code>(Paper)-[:HAS_KEYWORD]→(Keyword)</code><br><code>(Paper)-[:PUBLISHED_BY]→(Publisher)</code><br><code>(Paper)-[:ASSOCIATED_COUNTRY]→(Country)</code><br><code>(Paper)-[:PUBLISHED_IN_YEAR]→(Year)</code><br><code>(Author)-[:COLLABORATES_WITH]→(Author)</code><br><code>(Keyword)-[:CO_OCCURS_WITH]→(Keyword)</code><br><br>Client-side KG models available: Bibliographic, Co-authorship, Concept co-occurrence, Publishing ecosystem, Temporal impact, NER entity-relation. Later, true citation data can add <code>(Paper)-[:CITES]→(Paper)</code>.</div></div><div class="db-card rdf"><h3>GraphDB semantic model</h3><div class="db-schema"><code>bibo:AcademicArticle</code><br><code>dcterms:creator</code> → <code>foaf:Person</code><br><code>dcterms:isPartOf</code> → <code>bibo:Journal</code><br><code>dcterms:subject</code> → <code>lib:ResearchConcept</code><br><code>dcterms:publisher</code> → <code>foaf:Organization</code><br><code>lib:associatedCountry</code> → <code>lib:Country</code><br><br>NER, research gaps and hypotheses can later be formalized as additional RDF classes and predicates.</div></div></div></div>`);
 dbBindTabs();$('#neoTest').onclick=dbTestNeo;$('#graphTest').onclick=dbTestGraph;$('#neoRun').onclick=dbRunNeo;$('#graphRun').onclick=dbRunGraph;$('#neoGraphBtn').onclick=()=>dbOpenGenericGraph(dbNeoGraph(DB_LAST_NEO),'Neo4j Live Knowledge Graph','Nodes and relationships returned by your Cypher query.');$('#graphGraphBtn').onclick=()=>dbOpenGenericGraph(dbGraphDbGraph(DB_LAST_RDF),'GraphDB Live Semantic Graph','RDF subject–predicate–object bindings returned by your SPARQL query.');$$('[data-neo-t]').forEach(b=>b.onclick=()=>$('#neoQuery').value=dbTemplate('neo',b.dataset.neoT));$$('[data-rdf-t]').forEach(b=>b.onclick=()=>$('#graphQuery').value=dbTemplate('rdf',b.dataset.rdfT));$('#dbExportNeo').onclick=dbDownloadNeo;$('#dbExportRdf').onclick=dbDownloadRdf;
}


/* ===== Related Papers (local, content-based) ===== */
const RP_STOP=new Set('the and for with from into over under using based study studies analysis approach between among about their this that these those toward towards effect effects review case new use used'.split(' '));
function rpTerms(s){return [...new Set(tokens(s||'').filter(w=>w.length>3&&!RP_STOP.has(w)))]}
function relatedPapers(seed,limit=10){
  const base=recObj(seed);
  const bAuth=new Set((base.authors||'').split(';').map(norm).filter(Boolean));
  const bKey=new Set(tokens(base.keywords||'').filter(x=>x.length>2));
  const bTit=new Set(rpTerms(base.title));
  const out=[];
  for(let j=0;j<R.length;j++){
    if(j===seed)continue;
    const o=recObj(j);let score=0;const reasons=[];
    if(o.source&&o.source===base.source){score+=3;reasons.push('same journal')}
    const sh=(o.authors||'').split(';').map(norm).filter(a=>a&&bAuth.has(a));
    if(sh.length){score+=8*sh.length;reasons.push('shared author')}
    const kov=new Set(tokens(o.keywords||'').filter(x=>x.length>2&&bKey.has(x)));
    if(kov.size){score+=2*kov.size;reasons.push('shared keywords')}
    const tov=rpTerms(o.title).filter(t=>bTit.has(t));
    if(tov.length){score+=1.5*tov.length;reasons.push('title terms')}
    if(score>=3)out.push({i:j,score,reasons});
  }
  out.sort((a,b)=>b.score-a.score||(R[b.i][0]-R[a.i][0]));
  return out.slice(0,limit);
}
function rpSeed(){return (currentResults&&currentResults.length)?currentResults[0].i:null}
function rpDraw(seed){
  const base=recObj(seed),list=relatedPapers(seed,12),max=(list[0]&&list[0].score)||1;
  showModal(`<h2>◇ Related papers</h2>
    <p class="tiny">Based on <b>${esc(base.title||'Untitled')}</b>. Ranked locally by shared authors, journal, keywords and title terms, so it works offline.</p>
    <div class="related-list">${list.map(x=>{const o=recObj(x.i);return `<div class="related-item rp-item"><button class="rp-open" type="button" data-open-detail="${x.i}"><b>${esc(o.title||'Untitled')}</b><div class="tiny">${esc(o.authors||'')} · ${o.year||'n/a'} · ${esc(o.source||'')}</div><div class="rp-tags">${x.reasons.map(r=>`<span class="badge">${r}</span>`).join('')}</div><div class="bar"><i style="width:${Math.max(4,x.score/max*100).toFixed(0)}%"></i></div></button><div class="actions"><button type="button" data-rp-seed="${x.i}">Use as seed</button></div></div>`}).join('')||'<div class="note">No strongly related papers found for this record.</div>'}</div>`);
  $$('[data-open-detail]').forEach(b=>b.onclick=()=>detail(Number(b.dataset.openDetail)));
  $$('[data-rp-seed]').forEach(b=>b.onclick=()=>rpDraw(Number(b.dataset.rpSeed)));
}
function relatedPapersModal(){
  const seed=rpSeed();
  if(seed===null){showModal('<h2>◇ Related papers</h2><div class="note">Run a search first. Related papers are ranked from the top result, and you can switch the seed paper from inside this window.</div>');return}
  rpDraw(seed);
}
function updateRelatedPanel(){
  const el=document.getElementById('relatedPanelList');if(!el)return;
  const seed=rpSeed();
  if(seed===null){el.innerHTML='<div class="tiny">Run a search to see related papers.</div>';return}
  const list=relatedPapers(seed,5);
  el.innerHTML=list.length?list.map(x=>{const o=recObj(x.i);return `<button class="rp-rec" type="button" data-open-detail="${x.i}"><strong>${esc(o.title||'Untitled')}</strong><span class="tiny">${esc(o.authors||'')}</span></button>`}).join(''):'<div class="tiny">No strongly related papers for the top result.</div>';
  el.querySelectorAll('[data-open-detail]').forEach(b=>b.onclick=()=>detail(Number(b.dataset.openDetail)));
}
;
/* ---- kg-eval-v4-js ---- */
(()=>{
const E=s=>esc(s),Q=s=>document.querySelector(s),QA=s=>[...document.querySelectorAll(s)];
const LS={get(k,d){try{const v=JSON.parse(localStorage.getItem(k));return v==null?d:v}catch(e){return d}},set(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}}};
const ST=w=>{w=w.replace(/ies$/,'y');return w.length>3&&/s$/.test(w)&&!/ss$/.test(w)?w.slice(0,-1):w};
window.KG_LEVEL=1;window.KG_ANY=false;const META=new WeakMap();
/* ---------- 1. Query-aware relationships ---------- */
const CORE={bibliographic:['Author → Title','Title → Journal','Title → Keywords','Title → Year','Title → Publisher'],coauthorship:['Author → Title','Author → Journal','Author → Keywords','Author → Publisher'],concept:['Title → Keywords','Author → Keywords','Journal → Keywords'],ecosystem:['Title → Journal','Journal → Publisher','Publisher → Place','Title → Publisher'],temporal:['Title → Year','Keywords → Year','Journal → Year'],ner:['Title → Keywords','Author → Title','Title → Journal','Title → Place']};
function prof(){const q=state.query||'';return{ph:exactPhrases(q),tk:tokens(q.replace(/"[^"]*"/g,' ')).filter(t=>t.length>2).map(ST),yrs:q.match(/\b(19|20)\d{2}\b/g)||[]}}
function hitNode(n,p){if(n.type==='query'||n.type==='paper')return false;const L=norm(n.label);if(n.type==='year')return p.yrs.includes(n.label);if(p.ph.some(x=>L.includes(x)))return true;if(!p.tk.length)return false;const ws=(L.match(/[a-z0-9][a-z0-9.+#-]*/g)||[]).map(ST);const m=p.tk.filter(t=>ws.some(w=>w===t||(t.length>3&&w.startsWith(t)))).length;return window.KG_ANY?m>0:m>=Math.max(1,Math.ceil(p.tk.length*.6))}
function relevant(g,id,lvl,single){const p=prof(),hasQ=p.ph.length||p.tk.length;g.nodes.forEach(n=>n.hit=single?(n.type!=='paper'&&n.type!=='query'&&n.weight>1):hitNode(n,p));g.edges.forEach(e=>e.hit=!!(e.a.hit||e.b.hit));const core=new Set(CORE[id]||[]),total=g.edges.length;let used=lvl,note='';const pick=l=>g.edges.filter(e=>l>=3||e.hit||(l>=2&&core.has(e.detail)));let ed=pick(lvl);if(lvl===1&&!ed.length){used=2;ed=pick(2);note=single?'No entity is shared between these records, so core relations are shown.':hasQ?'No entity in this model matches the search terms, so the model’s core relations are shown instead.':'No search term entered, so the model’s core relations are shown.'}const live=new Set();ed.forEach(e=>{live.add(e.a);live.add(e.b)});g.nodes=g.nodes.filter(n=>n.type==='query'||n.type==='paper'||live.has(n));g.edges=ed;META.set(ed,{total,used,note,hasQ});return g}
const _b=window.kgBuildByModel;
window.kgBuildByModel=function(h,id,o){const g=_b(h,id,o),single=!!(o&&o.includeSearchRoot===false);return relevant(g,id,+window.KG_LEVEL,single)};
function comps(ns,es){const p=new Map(ns.map(n=>[n,n]));const f=x=>{while(p.get(x)!==x){p.set(x,p.get(p.get(x)));x=p.get(x)}return x};es.forEach(e=>{if(p.has(e.a)&&p.has(e.b))p.set(f(e.a),f(e.b))});return new Set(ns.map(f)).size}
/* ---------- 2. Edge direction, labels, highlighting ---------- */
window.kgDraw=function(){if(!KG.ctx||!KG.canvas)return;KG.__lbl=[];const ctx=KG.ctx,rect=KG.canvas.getBoundingClientRect();ctx.clearRect(0,0,rect.width,rect.height);ctx.save();ctx.translate(KG.tx,KG.ty);ctx.scale(KG.scale,KG.scale);ctx.lineCap='round';const foc=KG.selected||KG.hover,off=KG.hiddenRel||new Set(),nb=new Set();
KG.edges.forEach(e=>{if(foc&&(e.a===foc||e.b===foc)){nb.add(e.a);nb.add(e.b)}});
KG.edges.forEach(e=>{if(off.has(e.relation))return;const act=foc&&(e.a===foc||e.b===foc),dim=foc&&!act,col=e.relation==='related paper'?'109,40,217':e.relation==='matched search'?'24,78,119':e.hit?'217,119,6':'116,129,148';ctx.strokeStyle=`rgba(${col},${dim?.08:act?.95:e.hit?.7:.32})`;ctx.lineWidth=(act?2.4:e.hit?1.9:1)/Math.sqrt(KG.scale);ctx.beginPath();ctx.moveTo(e.a.x,e.a.y);ctx.lineTo(e.b.x,e.b.y);ctx.stroke();
const dx=e.b.x-e.a.x,dy=e.b.y-e.a.y,d=Math.hypot(dx,dy)||1,r=kgRadius(e.b)+2,ux=dx/d,uy=dy/d,tx=e.b.x-ux*r,ty=e.b.y-uy*r;if(!dim&&d>r*3){ctx.fillStyle=ctx.strokeStyle;ctx.beginPath();ctx.moveTo(tx,ty);ctx.lineTo(tx-ux*7-uy*3.5,ty-uy*7+ux*3.5);ctx.lineTo(tx-ux*7+uy*3.5,ty-uy*7-ux*3.5);ctx.fill()}
if((KG.showEdgeLabels||act)&&KG.scale>.5&&!dim){let ang=Math.atan2(dy,dx);if(ang>Math.PI/2||ang<-Math.PI/2)ang+=Math.PI;ctx.save();ctx.translate((e.a.x+e.b.x)/2,(e.a.y+e.b.y)/2);ctx.rotate(ang);ctx.font='600 9px system-ui';const w=ctx.measureText(e.relation).width;ctx.fillStyle='rgba(255,255,255,.93)';ctx.fillRect(-w/2-3,-7,w+6,12);ctx.fillStyle=e.hit?'#b45309':'#475569';ctx.textAlign='center';ctx.fillText(e.relation,0,2);ctx.restore()}});
KG.nodes.forEach(n=>{const r=kgRadius(n);ctx.globalAlpha=foc&&n!==foc&&!nb.has(n)?.25:1;ctx.beginPath();ctx.arc(n.x,n.y,r,0,Math.PI*2);ctx.fillStyle=KG_COLORS[n.type]||'#64748b';ctx.fill();const lw=3/Math.max(.55,KG.scale);if(n.hit){ctx.strokeStyle='#f59e0b';ctx.lineWidth=lw;ctx.stroke()}if(KG.selected===n){ctx.strokeStyle='#111827';ctx.lineWidth=lw;ctx.stroke()}else if(KG.hover===n){ctx.strokeStyle='#fff';ctx.lineWidth=lw;ctx.stroke()}
if(n.type==='query'||n.root||n.type==='paper'||n.weight>1||n.hit){let l=n.type==='paper'?((n.rank?n.rank+'. ':'')+n.label):n.label;l=l.length>34?l.slice(0,32)+'…':l;(KG.__lbl=KG.__lbl||[]).push({x:n.x,y:n.y,r:r,l:l,pri:(n.type==='query'||n.root||n.hit)?0:(n.type==='paper'?1:2),col:n.hit?'#b45309':'#243247'})}});ctx.globalAlpha=1;ctx.restore();kgDrawLabels()};
/* ---------- 3. Live legend + relevance audit ---------- */
const _s=window.kgStats;
window.kgStats=function(){const base=_s(),m=META.get(KG.edges),el=Q('#kgEdgeKey'),cnt={};KG.edges.forEach(e=>{const c=cnt[e.relation]=cnt[e.relation]||{n:0,h:0};c.n++;if(e.hit)c.h++});KG.hiddenRel=new Set();
if(el&&m){el.innerHTML='<div class="kgl-h">Relationships in this graph (tick to show)</div>'+(Object.entries(cnt).sort((a,b)=>b[1].n-a[1].n).map(([r,c])=>`<label class="kgl"><input type="checkbox" checked data-rel="${E(r)}"><i class="${c.h?'hit':''}"></i><b>${E(r)}</b><span>${c.n} edge${c.n>1?'s':''}${c.h?' · '+c.h+' on search terms':''}</span></label>`).join('')||'none')+'<div class="tiny" style="margin-top:6px">Arrows run from the first entity to the second. Amber = touches your search terms.</div>';QA('#kgEdgeKey input').forEach(x=>x.onchange=()=>{x.checked?KG.hiddenRel.delete(x.dataset.rel):KG.hiddenRel.add(x.dataset.rel);kgDraw()})}
if(!m)return base;const rel=KG.edges.filter(e=>e.relation!=='matched search'),hit=rel.filter(e=>e.hit).length,pc=rel.length?Math.round(100*hit/rel.length):0,deg=KG.nodes.length?(2*KG.edges.length/KG.nodes.length).toFixed(1):0;
return base+`<div class="kg-audit"><b>Relevance audit</b><br>Level ${m.used} · showing ${KG.edges.length} of ${m.total} schema relationships<div class="kg-meter"><i style="width:${pc}%"></i></div>${pc}% of relationships touch the search terms · ${comps(KG.nodes,KG.edges)} component(s) · avg degree ${deg}${m.note?`<div class="note">${E(m.note)}</div>`:''}</div>`};
const _o=window.kgOpen;
window.kgOpen=function(){const r=_o.apply(this,arguments),tb=Q('.kg-toolbar');if(tb&&!Q('#kgLevel')){const s=document.createElement('span');s.className='kg-level';s.innerHTML='<label>Relationship level <select id="kgLevel"><option value="1">1 · Search-term matches</option><option value="2">2 · + model core</option><option value="3">3 · Full model schema</option></select></label><label>Term match <select id="kgMatch"><option value="all">Most terms</option><option value="any">Any term</option></select></label><button class="ghost" id="kgAudit" type="button">⚖ Compare models</button>';tb.insertBefore(s,tb.children[1]||null);Q('#kgLevel').value=window.KG_LEVEL;Q('#kgMatch').value=window.KG_ANY?'any':'all';const re=()=>{const m=Q('#kgModel');if(m&&m.onchange)m.onchange()};Q('#kgLevel').onchange=e=>{window.KG_LEVEL=+e.target.value;re()};Q('#kgMatch').onchange=e=>{window.KG_ANY=e.target.value==='any';re()};Q('#kgAudit').onclick=()=>evalModal('kg')}return r};
/* ---------- 4. Evaluation Lab ---------- */
const EV={j:LS.get('are_judg',{}),log:[],sus:LS.get('are_sus',null),tab:'judge',depth:LS.get('are_depth',20)};
const _d=window.doSearch;window.doSearch=function(){const t=performance.now(),r=_d.apply(this,arguments),q=(state.query||'').trim();if(q)EV.log.push({q,n:currentResults.length,ms:+(performance.now()-t).toFixed(1),f:[state.source,state.publisher,state.country,state.subject].filter(Boolean).length+state.yearSet.size+state.advanced.length+(state.hasLink?1:0)+(state.minCites?1:0),t:new Date().toLocaleTimeString()});return r};
const TABS=[['judge','Relevance judgments'],['diag','Result diagnostics'],['lab','Query lab'],['kg','KG model audit'],['sess','Session log'],['sus','Usability (SUS)']];
const pct=x=>Math.round(x*100)+'%',card=(v,l,c='')=>`<div class="ev-card ${c}"><b>${v}</b><span>${l}</span></div>`,grade=v=>v>=.7?'good':v>=.4?'warn':'bad';
window.evalModal=function(t){t=t||EV.tab;EV.tab=t;Q('#modalCard').classList.remove('graph-modal-card');showModal(`<h2>Evaluation Lab</h2><p class="tiny">Measure how well this interface finds, ranks and relates records for the current search. Judgments and scores stay in this browser.</p><div class="ev-tabs">${TABS.map(([k,l])=>`<button class="ev-tab ${k===t?'on':''}" data-t="${k}" type="button">${l}</button>`).join('')}</div><div id="evBody"></div>`);QA('.ev-tab').forEach(b=>b.onclick=()=>evalModal(b.dataset.t));({judge:tJudge,diag:tDiag,lab:tLab,kg:tKg,sess:tSess,sus:tSus})[t]()};
const csv=a=>a.map(r=>r.map(c=>'"'+String(c).replace(/"/g,'""')+'"').join(',')).join('\n');
function tJudge(){const q=state.query.trim(),B=Q('#evBody');if(!q||!currentResults.length){B.innerHTML='<p>Run a search first. The top 20 ranked results can then be judged here.</p>';return}const J=EV.j[q]=EV.j[q]||{},top=currentResults.slice(0,EV.depth||20);
const dcg=a=>a.reduce((s,r,i)=>s+r/Math.log2(i+2),0);
const met=()=>{const rl=top.map(h=>+J[h.i]||0),rel=x=>x>0,k=n=>rl.slice(0,n).filter(rel).length/n,TOT=Object.values(J).filter(v=>+v>0).length,rc=n=>TOT?rl.slice(0,n).filter(rel).length/TOT:null,f1=n=>{const p=k(n),r=rc(n);return r==null||p+r===0?null:2*p*r/(p+r)},id=[...rl].sort((a,b)=>b-a),nd=dcg(id.slice(0,10))?dcg(rl.slice(0,10))/dcg(id.slice(0,10)):0,R_=rl.filter(rel).length;let hits=0,ap=0;rl.forEach((r,i)=>{if(r>0){hits++;ap+=hits/(i+1)}});const fr=rl.findIndex(rel),judged=top.filter(h=>J[h.i]!==undefined&&J[h.i]!=='').length,V=v=>v==null?'–':pct(v),G=v=>grade(v==null?0:v),row=n=>`<tr><th>Top ${n}</th><td>${V(k(n))}<div class="ev-meter"><i style="width:${Math.round(k(n)*100)}%"></i></div></td><td>${V(rc(n))}<div class="ev-meter rc"><i style="width:${Math.round((rc(n)||0)*100)}%"></i></div></td><td>${V(f1(n))}</td></tr>`;
return `<div class="ev-sec"><h4>Precision and recall for “${E(q)}”</h4><table class="ev-table pr-table"><tr><th>Cutoff</th><th>Precision</th><th>Recall</th><th>F1</th></tr>${[5,10,20].map(row).join('')}</table><p class="tiny">Precision = relevant results in the top k ÷ k. Recall = relevant results in the top k ÷ all ${TOT} relevant records judged for this query${TOT?'':' (judge some results as 1 or 2 to enable recall)'}. Unjudged results count as not relevant.</p></div><div class="ev-sec"><h4>Ranking quality</h4><div class="ev-grid">${card(nd.toFixed(2),'nDCG@10',G(nd))}${card(R_?(ap/R_).toFixed(2):'0.00','Average precision (MAP)',G(R_?ap/R_:0))}${card(fr>=0?(1/(fr+1)).toFixed(2):'0.00','Reciprocal rank',G(fr>=0?1/(fr+1):0))}${card(TOT,'Relevant judged for query')}${card(judged+'/'+top.length,'Judged in pool')}</div></div>`};
B.innerHTML=`<div class="ev-row"><b>Query: “${E(q)}”</b><span class="tiny">Grade each result: 2 = highly relevant, 1 = partly, 0 = not relevant.</span><label class="tiny">Judge pool <select id="evDepth">${[10,20,30,50].map(v=>`<option value="${v}" ${v===(EV.depth||20)?'selected':''}>Top ${v}</option>`).join('')}</select></label><button class="ghost" id="evX" type="button">⇩ Export judgments (CSV)</button></div><div id="evM">${met()}</div><table class="ev-table"><tr><th>#</th><th>Result and why it matched</th><th>Grade</th></tr>${top.map((h,k)=>{const o=recObj(h.i);return `<tr><td>${k+1}</td><td><b>${E(o.title)}</b><div class="tiny">${E(o.source)} · ${o.year} · matched in: ${E((h.why||[]).map(w=>w[0]).join(', ')||'—')}</div></td><td><select data-j="${h.i}"><option value="">–</option>${[2,1,0].map(v=>`<option value="${v}" ${String(J[h.i])===String(v)?'selected':''}>${v}</option>`).join('')}</select></td></tr>`}).join('')}</table>`;
QA('[data-j]').forEach(s=>s.onchange=()=>{if(s.value==='')delete J[s.dataset.j];else J[s.dataset.j]=+s.value;LS.set('are_judg',EV.j);Q('#evM').innerHTML=met()});
Q('#evDepth').onchange=e=>{EV.depth=+e.target.value;LS.set('are_depth',EV.depth);evalModal('judge')};
Q('#evX').onclick=()=>download('relevance_judgments.csv',csv([['query','rank','record_index','title','grade'],...top.map((h,i)=>[q,i+1,h.i,recObj(h.i).title,J[h.i]??''])]),'text/csv')}
function tDiag(){const B=Q('#evBody'),top=currentResults.slice(0,20),n=top.length;if(!n){B.innerHTML='<p>Run a search first.</p>';return}const f=x=>Math.round(100*top.filter(x).length/n)+'%',fm={},js={};top.forEach(h=>{(h.why||[]).forEach(w=>fm[w[0]]=(fm[w[0]]||0)+1);const s=recObj(h.i).source;js[s]=(js[s]||0)+1});const H=-Object.values(js).reduce((a,c)=>a+c/n*Math.log2(c/n),0),Hn=n>1?H/Math.log2(n):0,ys=top.map(h=>R[h.i][3]),cs=top.map(h=>R[h.i][0]).sort((a,b)=>a-b),last=EV.log[EV.log.length-1],mx=Math.max(1,...Object.values(fm));
B.innerHTML=`<div class="ev-grid">${card(currentResults.length.toLocaleString(),'Total results')}${card(Object.keys(js).length,'Journals in top 20')}${card(Hn.toFixed(2),'Journal diversity (0–1)',grade(Hn))}${card(Math.min(...ys)+'–'+Math.max(...ys),'Year span in top 20')}${card(f(h=>R[h.i][8]||R[h.i][9]),'Have DOI / link',grade(top.filter(h=>R[h.i][8]||R[h.i][9]).length/n))}${card(f(h=>R[h.i][12]),'Have abstract')}${card(cs[Math.floor(n/2)],'Median citations')}${card(last?last.ms+' ms':'–','Last search time',last&&last.ms<200?'good':'warn')}</div><h3>Where the query terms matched (top 20)</h3>${Object.entries(fm).sort((a,b)=>b[1]-a[1]).map(([k,v])=>`<div class="ev-bar"><span>${E(k)}</span><i style="width:${100*v/mx}%"></i><b>${v}</b></div>`).join('')||'<p class="tiny">No field information.</p>'}`}
const rank=q=>{const o=[];for(let i=0;i<R.length;i++){const r=relevance(i,q),s=typeof r==='number'?r:r.score;if(s>0)o.push({i,s})}return o.sort((a,b)=>b.s-a.s||R[b.i][0]-R[a.i][0])};
const ov=(a,b,k)=>{const A=new Set(a.slice(0,k).map(x=>x.i));return b.slice(0,k).filter(x=>A.has(x.i)).length/k};
function tLab(){const B=Q('#evBody');B.innerHTML=`<p class="tiny">Compare two phrasings, and see which term in your query drives the ranking.</p><div class="ev-row"><input type="text" id="qa" placeholder="Query A" value="${E(state.query)}"><input type="text" id="qb" placeholder="Query B (e.g. a synonym)"><button class="primary" id="qgo" type="button">Compare</button></div><div id="qout"></div>`;Q('#qgo').onclick=()=>{const a=Q('#qa').value.trim(),b=Q('#qb').value.trim();if(!a)return;const ra=rank(a),out=[];let h='';if(b){const rb=rank(b),A=new Set(ra.map(x=>x.i)),sh=rb.filter(x=>A.has(x.i)).length;h+=`<div class="ev-grid">${card(ra.length.toLocaleString(),'Results for A')}${card(rb.length.toLocaleString(),'Results for B')}${card(pct(ov(ra,rb,10)),'Top-10 overlap')}${card(pct(ov(ra,rb,20)),'Top-20 overlap')}${card(pct(sh/Math.max(1,ra.length+rb.length-sh)),'Jaccard (all results)')}</div>`}
const tk=[...new Set(tokens(a.replace(/"[^"]*"/g,' ')).filter(t=>t.length>2))].slice(0,6);if(tk.length>1){h+='<h3>Term influence on ranking</h3><table class="ev-table"><tr><th>Dropped term</th><th>Results</th><th>Top-10 kept</th><th>Influence</th></tr>'+tk.map(t=>{const r2=rank(a.replace(new RegExp('\\b'+t.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+'\\b','i'),' ')),o=ov(ra,r2,10);return `<tr><td>${E(t)}</td><td>${r2.length.toLocaleString()}</td><td>${pct(o)}</td><td>${o<.4?'High':o<.8?'Medium':'Low'}</td></tr>`}).join('')+'</table>'}Q('#qout').innerHTML=h||'<p class="tiny">Add a second query or a multi-word query A.</p>'}}
function tKg(){const B=Q('#evBody'),hits=currentResults;if(!hits.length){B.innerHTML='<p>Run a search first.</p>';return}B.innerHTML=`<div class="ev-row"><label>Relationship level <select id="evLv">${[1,2,3].map(v=>`<option value="${v}" ${v==window.KG_LEVEL?'selected':''}>${v}</option>`).join('')}</select></label><span class="tiny">Same top-20 results, six construction models. “On search terms” is the share of relationships that touch an entity matching “${E(state.query)}”.</span></div><div id="evK"></div>`;const run=()=>{const lv=+Q('#evLv').value,keep=window.KG_LEVEL;window.KG_LEVEL=lv;const rows=Object.values(KG_MODELS).map(m=>{const g=kgBuildByModel(hits,m.id,{limit:20}),mt=META.get(g.edges),rel=g.edges.filter(e=>e.relation!=='matched search'),h=rel.filter(e=>e.hit).length,rs=new Set(rel.map(e=>e.relation)).size;return `<tr><td><b>${E(m.label)}</b>${mt.note?`<div class="tiny">${E(mt.note)}</div>`:''}</td><td>${g.nodes.length}</td><td>${g.edges.length}<span class="tiny"> of ${mt.total}</span></td><td>${rs}</td><td>${rel.length?pct(h/rel.length):'–'}</td><td>${comps(g.nodes,g.edges)}</td></tr>`}).join('');window.KG_LEVEL=keep;Q('#evK').innerHTML=`<table class="ev-table"><tr><th>Model</th><th>Nodes</th><th>Edges shown</th><th>Relation types</th><th>On search terms</th><th>Components</th></tr>${rows}</table>`};Q('#evLv').onchange=run;run()}
function tSess(){const L=EV.log,B=Q('#evBody');if(!L.length){B.innerHTML='<p>No searches logged in this session yet.</p>';return}const ms=L.map(x=>x.ms).sort((a,b)=>a-b),z=L.filter(x=>!x.n).length;B.innerHTML=`<div class="ev-grid">${card(L.length,'Searches')}${card(ms[Math.floor(ms.length/2)]+' ms','Median time')}${card(pct(z/L.length),'Zero-result rate',z?'warn':'good')}${card(new Set(L.map(x=>x.q)).size,'Distinct queries')}</div><div class="ev-row"><button class="ghost" id="lx" type="button">⇩ Export log (CSV)</button></div><table class="ev-table"><tr><th>Time</th><th>Query</th><th>Results</th><th>ms</th><th>Filters</th></tr>${L.slice().reverse().map(x=>`<tr><td>${x.t}</td><td>${E(x.q)}</td><td>${x.n.toLocaleString()}</td><td>${x.ms}</td><td>${x.f}</td></tr>`).join('')}</table>`;Q('#lx').onclick=()=>download('search_session_log.csv',csv([['time','query','results','ms','filters'],...L.map(x=>[x.t,x.q,x.n,x.ms,x.f])]),'text/csv')}
const SUS=['I would like to use this search interface frequently.','I found it unnecessarily complex.','It was easy to use.','I would need technical support to use it.','Its functions were well integrated.','There was too much inconsistency.','Most people would learn it quickly.','It was cumbersome to use.','I felt confident using it.','I needed to learn a lot before I could get going.'];
function tSus(){const B=Q('#evBody'),v=EV.sus||Array(10).fill(0),sc=()=>v.every(x=>x)?v.reduce((s,x,i)=>s+(i%2?5-x:x-1),0)*2.5:null,show=()=>{const s=sc();return s==null?card('–','SUS score (answer all 10)'):card(s.toFixed(1),'SUS score · '+(s>=80.3?'excellent':s>=68?'good':s>=51?'OK':'poor'),s>=68?'good':s>=51?'warn':'bad')};B.innerHTML=`<p class="tiny">System Usability Scale: 1 = strongly disagree, 5 = strongly agree. 68+ is above average.</p><div class="ev-grid" id="susS">${show()}</div><div class="ev-sus">${SUS.map((t,i)=>`<label><span>${i+1}. ${t}</span><select data-s="${i}"><option value="0">–</option>${[1,2,3,4,5].map(x=>`<option ${v[i]===x?'selected':''}>${x}</option>`).join('')}</select></label>`).join('')}</div>`;QA('[data-s]').forEach(s=>s.onchange=()=>{v[+s.dataset.s]=+s.value;EV.sus=v;LS.set('are_sus',v);Q('#susS').innerHTML=show()})}
const existingEval=Q('#evalBtn');if(existingEval){existingEval.onclick=()=>evalModal();}else{const nav=Q('.toolbar .nav-spacer');if(nav){const b=document.createElement('button');b.className='ghost';b.id='evalBtn';b.type='button';b.innerHTML='✓ <span>Evaluate</span>';b.onclick=()=>evalModal();nav.parentNode.insertBefore(b,nav)}}
})();
;
/* ---- dashboard-v3-evaluate-js ---- */
/* ===== Shared styles and helpers (dashboard v3 + evaluation lab) ===== */
(()=>{
const st=document.createElement('style');
st.textContent=`
:root{--d3-ink:#111827;--d3-muted:#4b5563;--d3-line:#d1d5db;--d3-bar:#1f4e79;--d3-bar-on:#7c2d12;--d3-focus:#1d4ed8;--d3-paper:#ffffff;--d3-wash:#f9fafb}
#modalCard.x2-wide{width:min(1180px,96vw);max-height:94vh;overflow:auto}
#modalCard .d3-root{color:var(--d3-ink);font-size:14px;line-height:1.5}
#modalCard .d3-root h2{margin:0 0 6px;font-size:20px}
.d3-tabs{display:flex;gap:4px;flex-wrap:wrap;border-bottom:2px solid var(--d3-bar);margin:8px 0 12px}
.d3-tab{border:0;background:transparent;padding:9px 14px;border-radius:8px 8px 0 0;font-weight:700;font-size:14px;color:var(--d3-bar);cursor:pointer;font:inherit;font-weight:700}
.d3-tab[aria-selected="true"]{background:var(--d3-bar);color:#fff}
.d3-tab:focus-visible,.d3-bar:focus-visible,.d3-btn:focus-visible,.d3-link:focus-visible,.d3-root select:focus-visible,.d3-root input:focus-visible,.d3-root summary:focus-visible,[role="button"]:focus-visible{outline:3px solid var(--d3-focus);outline-offset:2px}
.d3-filters{background:var(--d3-wash);border:1px solid var(--d3-line);border-radius:10px;padding:10px 12px;margin-bottom:12px}
.d3-row{display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin:4px 0}
.d3-row label,.d3-filters label{font-size:13px;color:var(--d3-muted);display:inline-flex;gap:6px;align-items:center}
.d3-root select,.d3-root input[type=number]{border:1px solid #9ca3af;border-radius:6px;padding:5px 7px;background:#fff;color:var(--d3-ink);font:inherit;font-size:13px}
.d3-btn{border:1px solid #6b7280;background:#fff;color:var(--d3-ink);border-radius:6px;padding:6px 11px;cursor:pointer;font:inherit;font-size:13px}
.d3-btn:hover{background:#f3f4f6}
.d3-btn.primary{background:var(--d3-bar);color:#fff;border-color:var(--d3-bar)}
.d3-btn.primary:hover{background:#173d61}
.d3-chips{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-top:8px;min-height:28px}
.d3-chip{display:inline-flex;align-items:center;gap:6px;background:#fff;border:1px solid #9ca3af;border-radius:999px;padding:3px 4px 3px 10px;font-size:13px}
.d3-chip button{border:0;background:#e5e7eb;border-radius:999px;width:22px;height:22px;cursor:pointer;font-size:14px;line-height:1}
.d3-muted{color:var(--d3-muted)}
.d3-prov{font-size:13px;color:var(--d3-muted);background:#fff;border-left:4px solid var(--d3-bar);padding:6px 10px;margin:0 0 12px}
.d3-prov p{margin:2px 0}
.d3-prov summary{cursor:pointer;color:var(--d3-bar);font-weight:600;margin-top:4px}
.d3-prov ol{margin:6px 0 2px 18px;padding:0}
.d3-prov li{margin:3px 0}
.d3-kpis{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:8px;margin:0 0 14px}
.d3-kpi{border:1px solid var(--d3-line);border-radius:8px;padding:9px 11px;background:#fff;margin:0}
.d3-kpi dt{font-size:12.5px;color:var(--d3-muted)}
.d3-kpi dd{margin:2px 0 0;font-size:20px;font-weight:700;color:var(--d3-ink)}
.d3-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}
.d3-card{border:1px solid var(--d3-line);border-radius:10px;padding:12px 14px;background:#fff;min-width:0}
.d3-card.wide{grid-column:1/-1}
.d3-card h3{margin:0 0 4px;font-size:15px;color:var(--d3-ink)}
.d3-desc{margin:0 0 8px;font-size:13px;color:var(--d3-muted)}
.d3-foot{margin:8px 0 0;font-size:12.5px;color:var(--d3-muted)}
.d3-bars{list-style:none;margin:0;padding:0}
.d3-bars li{margin:0}
.d3-bar{display:grid;grid-template-columns:minmax(120px,38%) 1fr auto;gap:10px;align-items:center;width:100%;border:0;background:transparent;padding:4px 6px;margin:0;font:inherit;font-size:13px;text-align:left;color:var(--d3-ink);cursor:pointer;border-radius:6px}
.d3-bar:hover{background:#f3f4f6}
.d3-bar[aria-pressed="true"]{background:#fff7ed;outline:1px solid var(--d3-bar-on)}
.d3-bar.d3-static{cursor:default}
.d3-bar.d3-static:hover{background:transparent}
.d3-lbl{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.d3-track{height:12px;background:#e5e7eb;border-radius:3px;overflow:hidden;display:block}
.d3-fill{display:block;height:100%;background:var(--d3-bar)}
.d3-bar[aria-pressed="true"] .d3-fill{background:var(--d3-bar-on)}
.d3-val{font-variant-numeric:tabular-nums;color:var(--d3-muted);white-space:nowrap;font-size:12.5px}
.d3-tbl{margin-top:8px;font-size:13px}
.d3-tbl summary{cursor:pointer;color:var(--d3-bar);font-weight:600}
.d3-root table{width:100%;border-collapse:collapse;font-size:13px}
.d3-root th{text-align:left;background:#f3f4f6;padding:6px 8px;border-bottom:1px solid #9ca3af;font-size:12.5px;color:var(--d3-ink)}
.d3-root td{padding:6px 8px;border-bottom:1px solid var(--d3-line);vertical-align:top;font-variant-numeric:tabular-nums}
.d3-root caption{text-align:left;font-weight:600;padding:4px 0}
.d3-root tr.d3-sel td{background:#fff7ed}
.d3-scroll{overflow-x:auto}
.d3-link{border:0;background:none;color:var(--d3-bar);text-decoration:underline;cursor:pointer;font:inherit;padding:0;text-align:left}
.d3-svg{width:100%;height:auto;display:block;background:#fff;border:1px solid var(--d3-line);border-radius:8px}
.d3-svg g{cursor:pointer}
.d3-svg g:focus{outline:none}
.d3-svg g:focus circle{stroke:var(--d3-focus);stroke-width:3}
.d3-legend{list-style:none;padding:0;margin:8px 0 0;display:flex;flex-wrap:wrap;gap:6px 14px;font-size:12.5px;color:var(--d3-muted)}
.d3-sw{display:inline-block;width:11px;height:11px;border-radius:50%;margin-right:5px;vertical-align:middle}
.d3-sr{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0);white-space:nowrap}
.d3-status{font-size:12.5px;color:var(--d3-muted);margin-top:10px}
@media (max-width:820px){.d3-grid{grid-template-columns:1fr}.d3-bar{grid-template-columns:1fr auto}.d3-bar .d3-track{grid-column:1/-1}}
@media (prefers-reduced-motion:reduce){*{transition:none!important;animation:none!important}}
/* evaluation lab helpers (unchanged look, kept for the Evaluate tabs) */
.x2-kpis{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:10px;margin:8px 0 14px}
.x2-kpi{border:1px solid var(--d3-line);border-radius:10px;padding:10px 12px;background:#fff}
.x2-kpi b{display:block;font-size:20px;color:var(--d3-bar)}
.x2-kpi span{font-size:12px;color:var(--d3-muted)}
.x2-note{font-size:12.5px;color:var(--d3-muted);margin:4px 0 10px}
.x2-tbl{width:100%;border-collapse:collapse;font-size:12.5px}
.x2-tbl th{text-align:left;background:#f3f4f6;padding:7px;border-bottom:1px solid #9ca3af;font-size:12px;color:var(--d3-ink)}
.x2-tbl td{padding:7px;border-bottom:1px solid var(--d3-line);vertical-align:top}
.x2-bar{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin:6px 0}
.x2-badge{display:inline-block;font-size:11px;border-radius:999px;padding:1px 8px;background:#eef5fa;color:var(--d3-bar);border:1px solid #d3e5f0}
.x2-svg{width:100%;height:auto;display:block;background:#fbfcfe;border:1px solid var(--d3-line);border-radius:10px}
.x2-root{}
`;
document.head.appendChild(st);
const fmt=n=>Number(n||0).toLocaleString();
const pc=(x,d=1)=>x==null?'–':(100*x).toFixed(d)+'%';
const kpi=(v,l)=>`<div class="x2-kpi"><b>${v}</b><span>${l}</span></div>`;
const inc=(m,k)=>{if(k===''||k==null||k===0)return;m.set(k,(m.get(k)||0)+1)};
const topN=(m,n)=>[...m.entries()].sort((a,b)=>b[1]-a[1]||String(a[0]).localeCompare(String(b[0]))).slice(0,n).map(([name,count])=>({name:String(name),count}));
const csvOf=rows=>rows.map(r=>r.map(c=>'"'+String(c??'').replace(/"/g,'""')+'"').join(',')).join('\n');

/* ===== Dashboard v3: calculated results with provenance, interactive filters, accessible markup ===== */
const D={otherOpen:false,tab:'overview',scope:'all',from:'',to:'',topN:10,minKw:3,model:'bibliographic',limit:20,filters:[],resRef:null,memo:new Map(),snap:{},hubs:[],computed:null};
const DTABS=[['overview','Overview'],['query','Query explorer'],['kg','Knowledge graph'],['export','Export']];
const BANDS=[['Below 10',0,10],['10 to 24',10,25],['25 to 49',25,50],['50 to 99',50,100],['100 or more',100,Infinity]];
const FIELD_ORDER=['Title','Authors','Keywords','Journal','Abstract','DOI'];
const METHOD=[
  'Counts: a record is counted for a journal, publisher, country, year, keyword or author only when that field has a value. Records without a value are reported as missing, not as zero.',
  'Keywords and authors are grouped case- and accent-insensitively, the same way search matches them. The most frequent spelling is displayed.',
  'Share = records in a row ÷ records in the base (the active scope and filters).',
  'Citations: mean = total citations ÷ records; median = middle value, or the mean of the two middle values when the count is even.',
  'Term match: a term matches when it occurs as a substring of the normalised text, the same rule search scoring uses. For example, “literacy” also matches “illiteracy”.',
  'Term coverage = matches containing the term ÷ matches. Collection share = collection records containing the term ÷ all collection records. Enrichment = coverage ÷ collection share.',
  'Related keyword lift = share of matches with the keyword ÷ share of the whole collection with it. Only keywords with at least the minimum number of matching records are listed.',
  'Knowledge graph: nodes are merged by type and normalised label; links come from the selected model schema. Density = 2E ÷ (N(N−1)). Components are connected groups found on undirected links. The graph is built from the top-ranked matches, and the number used is shown.',
  'Hub map: nodes sit on a circle for readability, so distances carry no meaning. Circle size grows with the number of links.',
  'Average precision, ROC-AUC and nDCG are reported on the Evaluate tabs, not here.'
];

const NUM=n=>Number(n||0).toLocaleString();
const PCT=(x,d=1)=>(x==null||!isFinite(x))?'n/a':(100*x).toFixed(d)+'%';
const DEC=(x,d=2)=>(x==null||!isFinite(x))?'n/a':Number(x).toFixed(d);

/* memoised per result set: invalidated when a new search replaces currentResults */
function memo(kind,key,fn){
  if(D.resRef!==currentResults){D.memo.clear();D.resRef=currentResults}
  const k=kind+'|'+key;
  if(!D.memo.has(k)){if(D.memo.size>80)D.memo.clear();D.memo.set(k,fn())}
  return D.memo.get(k);
}
const allIds=()=>memo('all','',()=>R.map((_,i)=>i));
const filterKey=()=>JSON.stringify([D.from,D.to,D.filters]);

function matchFilter(i,f){
  const r=R[i];
  switch(f.field){
    case 'journal':   return (S[r[4]]||'')===f.value;
    case 'publisher': return (PUB[r[5]]||'')===f.value;
    case 'country':   return (CO[r[7]]||'')===f.value;
    case 'year':      return r[3]===Number(f.value);
    case 'keyword':   return splitKeywords(r[11]).some(k=>norm(k)===f.key);
    case 'author':    return splitAuthors(r[1]).some(a=>norm(a)===f.key);
  }
  return true;
}
function applyFilters(ids){
  let out=ids;
  if(D.from||D.to)out=out.filter(i=>(!D.from||R[i][3]>=Number(D.from))&&(!D.to||R[i][3]<=Number(D.to)));
  for(const f of D.filters)out=out.filter(i=>matchFilter(i,f));
  return out;
}
/* Base of the overview: whole collection or current results, then the year range and dashboard filters */
const baseIds=()=>memo('base',D.scope+'|'+filterKey(),()=>applyFilters(D.scope==='results'?currentResults.map(h=>h.i):allIds()));
/* Matches of the current query, ranked order kept */
const matchIds=()=>memo('match',filterKey(),()=>applyFilters(currentResults.map(h=>h.i)));

/* grouping helpers */
function plainAdd(map,key){if(key==='')return;map.set(key,(map.get(key)||0)+1)}
function groupAdd(map,names){
  const seen=new Set();
  for(const name of names){
    const k=norm(name).trim();
    if(!k||seen.has(k))continue;
    seen.add(k);
    let e=map.get(k);if(!e){e={count:0,forms:new Map()};map.set(k,e)}
    e.count++;e.forms.set(name,(e.forms.get(name)||0)+1);
  }
}
function groupName(e){let best=null,bc=-1;for(const [f,c] of e.forms){if(c>bc||(c===bc&&f<best)){best=f;bc=c}}return best}
function rowsFrom(entries,n,topN){
  return entries.sort((a,b)=>b.count-a.count||a.name.localeCompare(b.name)).slice(0,topN).map(e=>({...e,share:n?e.count/n:null}));
}

/* Core statistics for any set of record indices. Every number is computed from the records; nothing is estimated. */
function computeStats(ids){
  const n=ids.length;
  const miss={journal:0,publisher:0,country:0,year:0,keywords:0,authors:0,doi:0,abstract:0,url:0};
  const js=new Map(),pb=new Map(),co=new Map(),yr=new Map(),kw=new Map(),au=new Map(),cit=[];
  let sum=0,zero=0,max=0;
  for(const i of ids){
    const r=R[i],c=Number(r[0])||0;
    cit.push(c);sum+=c;if(c===0)zero++;if(c>max)max=c;
    const j=S[r[4]]||'';if(j)plainAdd(js,j);else miss.journal++;
    const p=PUB[r[5]]||'';if(p)plainAdd(pb,p);else miss.publisher++;
    const cc=CO[r[7]]||'';if(cc)plainAdd(co,cc);else miss.country++;
    if(r[3]>0)plainAdd(yr,r[3]);else miss.year++;
    const ks=splitKeywords(r[11]);if(!ks.length)miss.keywords++;groupAdd(kw,ks);
    const as=splitAuthors(r[1]);if(!as.length)miss.authors++;groupAdd(au,as);
    if(!r[9])miss.doi++;if(!r[12])miss.abstract++;if(!r[8])miss.url++;
  }
  cit.sort((a,b)=>a-b);
  const median=n?(n%2?cit[(n-1)/2]:(cit[n/2-1]+cit[n/2])/2):null;
  const years=[...yr.keys()];
  const ylo=years.length?Math.min(...years):null,yhi=years.length?Math.max(...years):null;
  const series=[];if(ylo!=null)for(let y=ylo;y<=yhi;y++)series.push({year:y,count:yr.get(y)||0,share:n?(yr.get(y)||0)/n:null});
  const buckets=[['0 citations',0,0],['1 to 4',1,4],['5 to 9',5,9],['10 to 24',10,24],['25 to 49',25,49],['50 to 99',50,99],['100 or more',100,Infinity]]
    .map(([label,a,b])=>{const c=cit.filter(x=>x>=a&&x<=b).length;return {label,count:c,share:n?c/n:null}});
  const most=[...ids].sort((a,b)=>(R[b][0]-R[a][0])||(a-b)).slice(0,10);
  return {n,miss,sum,mean:n?sum/n:null,median,max:n?max:null,zero,buckets,series,
    ylo,yhi,
    distinct:{journals:js.size,publishers:pb.size,countries:co.size,keywords:kw.size,authors:au.size},
    journals:rowsFrom([...js].map(([k,c])=>({name:k,count:c})),n,D.topN),
    publishers:rowsFrom([...pb].map(([k,c])=>({name:k,count:c})),n,D.topN),
    countries:rowsFrom([...co].map(([k,c])=>({name:k,count:c})),n,D.topN),
    keywords:rowsFrom([...kw.values()].map(e=>({name:groupName(e),count:e.count,key:norm(groupName(e))})),n,D.topN),
    authors:rowsFrom([...au.values()].map(e=>({name:groupName(e),count:e.count,key:norm(groupName(e))})),n,D.topN),
    most:most.map(i=>({i,title:R[i][2],year:R[i][3],source:S[R[i][4]]||'',cites:R[i][0]||0}))};
}
const overviewStats=()=>memo('ov',D.scope+'|'+filterKey()+'|'+D.topN,()=>computeStats(baseIds()));

/* Query explorer: what the current query finds */
let FIELD_TEXT=null;
function fieldTexts(){if(!FIELD_TEXT)FIELD_TEXT=INDEX.map(x=>x.t+' '+x.a+' '+x.k+' '+x.s+' '+x.b);return FIELD_TEXT}
function fieldOf(label){
  if(/DOI/.test(label))return 'DOI';
  if(/keyword/.test(label))return 'Keywords';
  if(/author/.test(label))return 'Authors';
  if(/journal/.test(label))return 'Journal';
  if(/abstract/.test(label))return 'Abstract';
  return 'Title';
}
function queryStats(){
  return memo('q',filterKey()+'|'+D.minKw+'|'+D.topN+'|'+state.query.trim(),()=>{
    const q=state.query.trim(),ids=matchIds(),M=ids.length,N=R.length;
    const toks=[...new Set(tokens(q.replace(/"[^"]*"/g,' ')))];
    const phr=[...q.matchAll(/"([^"]+)"/g)].map(m=>norm(m[1])).filter(Boolean);
    const hitOf=new Map(currentResults.map(h=>[h.i,h]));
    const txt=fieldTexts(),ttl=INDEX;
    const fieldCount=new Map(),bandCount=BANDS.map(()=>0),scores=[];
    let allTitle=0,anyTerm=0;
    for(const i of ids){
      const h=hitOf.get(i);
      scores.push(h.score);
      new Set((h.why||[]).map(w=>fieldOf(w[0]))).forEach(f=>plainAdd(fieldCount,f));
      const b=BANDS.findIndex(([,lo,hi])=>h.score>=lo&&h.score<hi);if(b>=0)bandCount[b]++;
      if(toks.every(t=>ttl[i].t.includes(t))&&phr.every(p=>ttl[i].t.includes(p)))allTitle++;
      if(toks.some(t=>txt[i].includes(t)))anyTerm++;
    }
    scores.sort((a,b)=>a-b);
    const medScore=M?(M%2?scores[(M-1)/2]:(scores[M/2-1]+scores[M/2])/2):null;
    const meanScore=M?scores.reduce((s,x)=>s+x,0)/M:null;
    const collTerm=memo('termcoll',toks.join('|'),()=>toks.map(t=>{let c=0;for(let i=0;i<N;i++)if(txt[i].includes(t))c++;return c}));
    const terms=toks.map((t,k)=>{
      const inM=ids.filter(i=>txt[i].includes(t)).length,inT=ids.filter(i=>ttl[i].t.includes(t)).length;
      const cov=M?inM/M:null,cs=collTerm[k]/N;
      return {term:t,inMatches:inM,inTitle:inT,inCollection:collTerm[k],coverage:cov,collectionShare:cs,enrichment:(cs&&cov!=null)?cov/cs:null};
    });
    const collKw=memo('kwcoll','',()=>{const m=new Map();for(let i=0;i<N;i++)groupAdd(m,splitKeywords(R[i][11]));return m});
    const mkw=new Map();ids.forEach(i=>groupAdd(mkw,splitKeywords(R[i][11])));
    const qSet=new Set(toks.map(t=>norm(t)));
    const related=[];
    for(const [key,e] of mkw){
      if(e.count<D.minKw||qSet.has(key))continue;
      const cc=(collKw.get(key)||{count:e.count}).count;
      const cov=e.count/M,cs=cc/N;
      related.push({name:groupName(e),key,count:e.count,share:cov,lift:cs?cov/cs:null,collection:cc});
    }
    related.sort((a,b)=>(b.lift-a.lift)||(b.count-a.count)||a.name.localeCompare(b.name));
    const st=computeStats(ids);
    return {q,M,N,share:N?M/N:null,toks,phr,allTitle,anyTerm,topScore:scores.length?scores[scores.length-1]:null,medScore,meanScore,
      fields:FIELD_ORDER.filter(f=>fieldCount.has(f)).map(f=>({name:f,count:fieldCount.get(f),share:M?fieldCount.get(f)/M:null})),
      bands:BANDS.map((b,k)=>({label:b[0],count:bandCount[k],share:M?bandCount[k]/M:null})),
      terms,related:related.slice(0,D.topN),relatedTotal:related.length,st};
  });
}

/* Knowledge graph for the top-ranked matches */
const KG_COL={paper:'#1f4e79',author:'#2f6f8f',journal:'#6b46c1',publisher:'#92400e',keyword:'#166534',year:'#4b5563',place:'#0f766e',doi:'#9f1239',url:'#374151',country:'#9d174d'};
function graphStats(g){
  const N=g.nodes.length,E=g.edges.length,adj=new Map(),deg=new Map();
  g.nodes.forEach(n=>{adj.set(n,[]);deg.set(n,0)});
  g.edges.forEach(e=>{if(!adj.has(e.a)||!adj.has(e.b))return;adj.get(e.a).push(e.b);adj.get(e.b).push(e.a);deg.set(e.a,deg.get(e.a)+1);deg.set(e.b,deg.get(e.b)+1)});
  const seen=new Set();let comps=0,largest=0;
  g.nodes.forEach(n=>{
    if(seen.has(n))return;comps++;let size=0;const stack=[n];seen.add(n);
    while(stack.length){const x=stack.pop();size++;adj.get(x).forEach(y=>{if(!seen.has(y)){seen.add(y);stack.push(y)}})}
    largest=Math.max(largest,size);
  });
  const types=new Map(),rels=new Map();
  g.nodes.forEach(n=>plainAdd(types,n.type));
  g.edges.forEach(e=>plainAdd(rels,e.relation));
  const hubs=[...g.nodes].sort((a,b)=>deg.get(b)-deg.get(a)||String(a.label).localeCompare(String(b.label)));
  return {N,E,comps,largest,density:N>1?2*E/(N*(N-1)):null,avgDeg:N?2*E/N:null,maxDeg:hubs.length?deg.get(hubs[0]):0,
    isolatedPapers:g.nodes.filter(n=>n.type==='paper'&&deg.get(n)===0).length,
    types:[...types].map(([name,count])=>({name,count})).sort((a,b)=>b.count-a.count),
    rels:[...rels].map(([name,count])=>({name,count})).sort((a,b)=>b.count-a.count),
    hubs,deg};
}
function graphData(){
  return memo('graph',D.model+'|'+D.limit+'|'+filterKey(),()=>{
    const ids=matchIds(),L=Math.min(D.limit,ids.length);
    const hits=ids.slice(0,L).map(i=>({i}));
    const sel=KG_MODELS[D.model]||KG_MODELS.bibliographic;
    const g=kgBuildByModel(hits,sel.id,{limit:L});
    const s=graphStats(g);
    const cmp=Object.values(KG_MODELS).map(m=>{const x=graphStats(kgBuildByModel(hits,m.id,{limit:L}));return {id:m.id,label:m.label,N:x.N,E:x.E,comps:x.comps,density:x.density,avgDeg:x.avgDeg}});
    return {model:sel,L,M:ids.length,s,cmp,edges:g.edges};
  });
}

/* ---------- presentation helpers ---------- */
const attr=s=>esc(s);
function kpiHTML(items){return `<dl class="d3-kpis">${items.map(([v,l,title])=>`<div class="d3-kpi"><dt>${esc(l)}</dt><dd title="${attr(title||'')}">${v}</dd></div>`).join('')}</dl>`}
function barCard({title,desc,rows,field,base,missing,label='Value',interactive=true,unitNote,valueFn}){
  const mx=Math.max(1,...rows.map(r=>r.count));
  const active=r=>D.filters.some(f=>f.field===field&&(field==='keyword'||field==='author'?f.key===r.key:f.value===r.name));
  const items=rows.map((r,k)=>{
    const val=valueFn?valueFn(r):`${NUM(r.count)} · ${PCT(r.share)}`;
    const lab=`${title}: ${r.name}, ${NUM(r.count)} records, ${PCT(r.share)} of base`;
    const inner=`<span class="d3-lbl">${esc(r.name||'(blank)')}</span><span class="d3-track" aria-hidden="true"><span class="d3-fill" style="width:${(100*r.count/mx).toFixed(2)}%"></span></span><span class="d3-val">${esc(val)}</span>`;
    return interactive&&field?`<li><button type="button" class="d3-bar" aria-pressed="${active(r)}" aria-label="${attr(lab)}. ${active(r)?'Filter active; press to remove.':'Press to filter the dashboard.'}" data-d3f="${field}" data-d3v="${attr(r.name)}" data-d3k="${attr(r.key||'')}">${inner}</button></li>`
                    :`<li><div class="d3-bar d3-static" role="text" aria-label="${attr(lab)}">${inner}</div></li>`;
  }).join('');
  const tbl=`<table><caption>${esc(title)} (data table)</caption><thead><tr><th scope="col">${esc(label)}</th><th scope="col">Records</th><th scope="col">Share of base</th></tr></thead><tbody>${rows.map(r=>`<tr><td>${esc(r.name||'(blank)')}</td><td>${NUM(r.count)}</td><td>${PCT(r.share)}</td></tr>`).join('')}</tbody></table>`;
  return `<section class="d3-card" aria-labelledby="h-${esc(title.replace(/\W+/g,'-'))}">
    <h3 id="h-${esc(title.replace(/\W+/g,'-'))}">${esc(title)}</h3>
    <p class="d3-desc">${esc(desc)}</p>
    ${rows.length?`<ul class="d3-bars">${items}</ul>`:'<p class="d3-muted">No values in this base.</p>'}
    <p class="d3-foot">${NUM(base-missing)} of ${NUM(base)} records have a value${missing?`; ${NUM(missing)} missing and excluded`:''}.${unitNote?' '+esc(unitNote):''}</p>
    <details class="d3-tbl"><summary>Show as data table</summary>${tbl}</details>
  </section>`;
}
function tableCard({title,desc,head,rows,foot}){
  return `<section class="d3-card wide" aria-labelledby="h-${esc(title.replace(/\W+/g,'-'))}"><h3 id="h-${esc(title.replace(/\W+/g,'-'))}">${esc(title)}</h3><p class="d3-desc">${esc(desc)}</p>
    <div class="d3-scroll"><table><thead><tr>${head.map(h=>`<th scope="col">${esc(h)}</th>`).join('')}</tr></thead><tbody>${rows}</tbody></table></div>${foot?`<p class="d3-foot">${foot}</p>`:''}</section>`;
}
function provHTML(base,extra){
  const scopeTxt=D.scope==='results'?(state.query.trim()?`current search results for “${esc(state.query.trim())}”`:'current results (no query, so all records passing the search facets)'):'whole collection';
  const filt=[D.from?`year ≥ ${D.from}`:'',D.to?`year ≤ ${D.to}`:'',...D.filters.map(f=>`${FIELD_LABEL[f.field]}: ${f.value}`)].filter(Boolean);
  return `<div class="d3-prov" role="note">
    <p><b>Source:</b> embedded bibliographic dataset, ${NUM(R.length)} records. <b>Base:</b> ${NUM(base)} records from ${scopeTxt}${filt.length?`; filters: ${filt.map(esc).join('; ')}`:''}.
    ${extra?esc(extra)+' ':''}<b>Computed:</b> ${D.computed?D.computed.toLocaleString():'—'}.</p>
    <details><summary>Method and definitions</summary><ol>${METHOD.map(m=>`<li>${esc(m)}</li>`).join('')}</ol></details>
  </div>`;
}
const FIELD_LABEL={journal:'Journal',publisher:'Publisher',country:'Country',year:'Year',keyword:'Keyword',author:'Author'};
function filterBarHTML(){
  const chips=D.filters.map((f,k)=>`<span class="d3-chip">${FIELD_LABEL[f.field]}: ${esc(f.value)} <button type="button" data-d3rm="${k}" aria-label="Remove filter ${attr(FIELD_LABEL[f.field]+': '+f.value)}">×</button></span>`).join('');
  return `<div class="d3-filters" role="region" aria-label="Dashboard controls">
    <div class="d3-row">
      <label>Base <select data-d3scope><option value="all" ${D.scope==='all'?'selected':''}>Whole collection</option><option value="results" ${D.scope==='results'?'selected':''}>Current search results</option></select></label>
      <label>Year from <input type="number" inputmode="numeric" data-d3from value="${attr(D.from)}" style="width:84px"></label>
      <label>to <input type="number" inputmode="numeric" data-d3to value="${attr(D.to)}" style="width:84px"></label>
      <label>Show top <select data-d3topn>${[10,20,50].map(v=>`<option value="${v}" ${D.topN===v?'selected':''}>${v}</option>`).join('')}</select></label>
      <button type="button" class="d3-btn" data-d3reset>Reset controls</button>
    </div>
    <div class="d3-chips" aria-label="Active dashboard filters">${chips||'<span class="d3-muted">No filters. Press any bar or year to filter every panel on this tab.</span>'}
      ${D.filters.length?`<button type="button" class="d3-btn" data-d3clear>Clear all filters</button><button type="button" class="d3-btn primary" data-d3apply title="Copies these filters into the search facets and runs the search">Apply to search</button>`:''}
    </div>
  </div>`;
}

/* ---------- tab bodies ---------- */
/* ---------- Publishing share (pie chart) ---------- */
const PIE_COL=['#1f4e79','#b45309','#166534','#6b46c1','#9f1239','#0f766e','#7c2d12','#1d4ed8','#86198f','#4d7c0f'];
const PIE_OTHER='#6b7280';
function pubShareData(ids){
  return memo('pubshare',D.scope+'|'+filterKey()+'|'+D.topN,()=>{
    const m=new Map();let known=0;
    for(const i of ids){const p=PUB[R[i][5]]||'';if(p){plainAdd(m,p);known++}}
    const all=[...m].map(([name,count])=>({name,count})).sort((a,b)=>b.count-a.count||a.name.localeCompare(b.name));
    const k=Math.min(D.topN,10),slices=all.slice(0,k).map(e=>({...e,share:known?e.count/known:null,other:false}));
    const rest=all.slice(k),rc=rest.reduce((t,e)=>t+e.count,0);
    if(rc)slices.push({name:`Other publishers (${NUM(rest.length)})`,count:rc,share:known?rc/known:null,other:true,rest:rest.map(e=>({name:e.name,count:e.count}))});
    return {known,distinct:all.length,slices,missing:ids.length-known};
  });
}
function pubShareCard(ids,n){
  const d=pubShareData(ids),sl=d.slices,cx=110,cy=110,r=100;
  const col=(e,k)=>e.other?PIE_OTHER:PIE_COL[k%PIE_COL.length];
  const active=e=>!e.other&&D.filters.some(f=>f.field==='publisher'&&f.value===e.name);
  let a0=-Math.PI/2,paths='';
  if(sl.length===1){
    const e=sl[0];
    paths=`<circle cx="${cx}" cy="${cy}" r="${r}" fill="${col(e,0)}" stroke="${active(e)?'#111827':'#fff'}" stroke-width="${active(e)?3:1.5}" class="d3-slice click" data-d3pie="0"><title>${attr(e.name)}: ${NUM(e.count)} records, ${PCT(e.share)}</title></circle><text class="d3-pie-lbl" x="${cx}" y="${cy+4}" text-anchor="middle">100%</text>`;
  }else{
    sl.forEach((e,k)=>{
      const a1=a0+2*Math.PI*(e.count/d.known),x0=cx+r*Math.cos(a0),y0=cy+r*Math.sin(a0),x1=cx+r*Math.cos(a1),y1=cy+r*Math.sin(a1),big=(a1-a0)>Math.PI?1:0;
      paths+=`<path d="M${cx} ${cy}L${x0.toFixed(2)} ${y0.toFixed(2)}A${r} ${r} 0 ${big} 1 ${x1.toFixed(2)} ${y1.toFixed(2)}Z" fill="${col(e,k)}" stroke="${active(e)?'#111827':'#fff'}" stroke-width="${active(e)?3:1.5}" class="d3-slice click" data-d3pie="${k}"><title>${attr(e.name)}: ${NUM(e.count)} records, ${PCT(e.share)}</title></path>`;
      if(e.share>=0.06){const am=(a0+a1)/2;paths+=`<text class="d3-pie-lbl" x="${(cx+r*.64*Math.cos(am)).toFixed(1)}" y="${(cy+r*.64*Math.sin(am)+4).toFixed(1)}" text-anchor="middle">${PCT(e.share,0)}</text>`}
      a0=a1;
    });
  }
  const leg=sl.map((e,k)=>{
    const inner=`<span class="sw" style="background:${col(e,k)}" aria-hidden="true"></span><span class="nm" title="${attr(e.name)}">${esc(e.name)}</span><span class="vl">${NUM(e.count)} &middot; ${PCT(e.share)}</span>`;
    return e.other?`<li><button type="button" class="d3-pieb" aria-expanded="${D.otherOpen?'true':'false'}" aria-controls="d3OtherList" title="Show every smaller publisher" data-d3other="1" data-d3pieb="${k}">${inner}</button></li>`
      :`<li><button type="button" class="d3-pieb" aria-pressed="${active(e)}" aria-label="${attr(`Publisher ${e.name}, ${NUM(e.count)} records, ${PCT(e.share)} of records with a publisher. ${active(e)?'Filter active; press to remove.':'Press to filter the dashboard.'}`)}" data-d3f="publisher" data-d3v="${attr(e.name)}" data-d3k="" data-d3pieb="${k}">${inner}</button></li>`;
  }).join('');
  const tbl=`<table><caption>Publishing share (data table)</caption><thead><tr><th scope="col">Publisher</th><th scope="col">Records</th><th scope="col">Share of records with a publisher</th></tr></thead><tbody>${sl.map(e=>`<tr><td>${esc(e.name)}</td><td>${NUM(e.count)}</td><td>${PCT(e.share)}</td></tr>`).join('')}</tbody></table>`;
  const rest=d.distinct>Math.min(D.topN,10)?` The ${NUM(d.distinct-Math.min(D.topN,10))} smaller publishers are grouped as Other.`:'';
  const oth=sl.find(e=>e.other);
  const otherPanel=oth&&D.otherOpen?`<div id="d3OtherList" class="d3-other" role="region" aria-label="All smaller publishers"><div class="d3-other-h"><b>All other publishers (${NUM(oth.rest.length)})</b><button type="button" class="d3-btn" data-d3other="1">Close</button></div><p class="d3-muted">Select a publisher to filter every panel on this tab. Select it again to remove the filter.</p><ul>${oth.rest.map(e=>`<li><button type="button" class="d3-pieb" aria-pressed="${D.filters.some(f=>f.field==='publisher'&&f.value===e.name)}" data-d3f="publisher" data-d3v="${attr(e.name)}" data-d3k=""><span class="sw" style="background:${PIE_OTHER}"></span><span class="nm">${esc(e.name)}</span><span class="vl">${NUM(e.count)}</span></button></li>`).join('')}</ul></div>`:'';
  return `<section class="d3-card" aria-labelledby="h-Publishing-share">
    <h3 id="h-Publishing-share">Publishing share</h3>
    <p class="d3-desc">Each slice is one publisher's share of the records that name a publisher. Select a slice or a legend row to filter every panel.</p>
    ${d.known?`<div class="d3-pie"><svg viewBox="0 0 220 220" role="img" aria-label="Pie chart of publishing share. ${attr(sl.slice(0,3).map(e=>e.name+' '+PCT(e.share)).join(', '))}${sl.length>3?' and others':''}.">${paths}</svg><ul class="d3-pie-leg">${leg}</ul></div>`:'<p class="d3-muted">No publisher values in this base.</p>'}
    <p class="d3-foot">${NUM(d.known)} of ${NUM(n)} records have a publisher${d.missing?`; ${NUM(d.missing)} missing and excluded`:''}.${rest}</p>
    ${otherPanel}
    <details class="d3-tbl"><summary>Show as data table</summary>${tbl}</details>
  </section>`;
}

function htmlOverview(){
  const ids=baseIds(),st=overviewStats(),n=st.n;
  if(!n)return `${provHTML(0)}<p class="d3-muted" role="status">No records in this base. Remove a filter or widen the year range.</p>`;
  const kp=kpiHTML([
    [NUM(n),'Records in base','Records after scope, year range and filters'],
    [st.ylo!=null?`${st.ylo}–${st.yhi}`:'n/a','Year span','Earliest and latest known year (records with no year are excluded)'],
    [NUM(st.distinct.journals),'Journals','Distinct non-blank journal names'],
    [NUM(st.distinct.publishers),'Publishers','Distinct non-blank publisher names'],
    [NUM(st.distinct.countries),'Countries','Distinct non-blank countries'],
    [NUM(st.distinct.authors),'Distinct authors','Authors grouped case- and accent-insensitively'],
    [NUM(st.distinct.keywords),'Distinct keywords','Keywords grouped case- and accent-insensitively'],
    [NUM(st.sum),'Total citations','Sum of citation counts in the base'],
    [DEC(st.mean,1),'Mean citations','Total citations ÷ records'],
    [st.median==null?'n/a':NUM(st.median),'Median citations','Middle value of citation counts'],
    [NUM(st.zero),'Uncited records','Records with zero citations']
  ]);
  const cov=[['DOI',st.miss.doi],['Abstract',st.miss.abstract],['Article link',st.miss.url],['Keywords',st.miss.keywords],['Authors',st.miss.authors],['Journal',st.miss.journal],['Publisher',st.miss.publisher],['Country',st.miss.country],['Year',st.miss.year]];
  const covRows=cov.map(([f,m])=>`<tr><td>${f}</td><td>${NUM(n-m)}</td><td>${NUM(m)}</td><td>${PCT((n-m)/n)}</td></tr>`).join('');
  D.snap.overview={scope:D.scope,filters:D.filters.map(f=>({field:f.field,value:f.value})),yearFrom:D.from||null,yearTo:D.to||null,base:n,missing:st.miss,distinct:st.distinct,totalCitations:st.sum,meanCitations:st.mean,medianCitations:st.median,years:st.series,journals:st.journals,keywords:st.keywords,authors:st.authors,countries:st.countries,publishers:st.publishers,publishingShare:pubShareData(ids).slices.map(e=>({publisher:e.name,records:e.count,share:e.share,groupedOther:!!e.other}))};
  const yearRows=st.series.map(y=>({name:String(y.year),count:y.count,share:y.share}));
  const yearCard=barCard({title:'Records per publication year',desc:'Each bar is one publication year. Select a year to filter every panel.',rows:yearRows,field:'year',base:n,missing:st.miss.year,label:'Year',unitNote:'Years run from the earliest to the latest known year, so gap years show zero.'});
  const cit=barCard({title:'Citation distribution',desc:'Records grouped by citation count. Not a filter.',rows:st.buckets.map(b=>({name:b.label,count:b.count,share:b.share})),field:null,base:n,missing:0,label:'Citations',interactive:false});
  return `${provHTML(n)}${kp}
    <div class="d3-grid">
      ${yearCard}
      ${barCard({title:'Top journals',desc:`Journals by record count, top ${D.topN}.`,rows:st.journals,field:'journal',base:n,missing:st.miss.journal,label:'Journal'})}
      ${barCard({title:'Top keywords',desc:`Keywords by record count (grouped case- and accent-insensitively), top ${D.topN}.`,rows:st.keywords,field:'keyword',base:n,missing:st.miss.keywords,label:'Keyword'})}
      ${barCard({title:'Top countries',desc:`Countries by record count, top ${D.topN}.`,rows:st.countries,field:'country',base:n,missing:st.miss.country,label:'Country'})}
      ${barCard({title:'Top publishers',desc:`Publishers by record count, top ${D.topN}.`,rows:st.publishers,field:'publisher',base:n,missing:st.miss.publisher,label:'Publisher'})}
      ${pubShareCard(ids,n)}
      ${barCard({title:'Top authors',desc:`Authors by record count (grouped case- and accent-insensitively), top ${D.topN}.`,rows:st.authors,field:'author',base:n,missing:st.miss.authors,label:'Author'})}
      ${cit}
      ${tableCard({title:'Field completeness',desc:'How many records in the base have each field. Missing values are excluded from every other figure.',head:['Field','Records with value','Missing','Completeness'],rows:covRows})}
      ${tableCard({title:`Most cited records (top 10)`,desc:'Ranked by citation count, then by dataset order. Select a title to open its detail view.',head:['#','Title','Year','Journal','Citations'],rows:st.most.map((m,k)=>`<tr><td>${k+1}</td><td><button type="button" class="d3-link" data-d3open="${m.i}">${esc(m.title)}</button></td><td>${m.year||'n/a'}</td><td>${esc(m.source)}</td><td>${NUM(m.cites)}</td></tr>`).join('')})}
    </div>`;
}

function htmlQuery(){
  if(!state.query.trim())return `${provHTML(0)}<p class="d3-muted" role="status">No active search. Enter a query in the search box, then return here. This tab explores the records that match it.</p>`;
  if(!currentResults.length)return `${provHTML(0)}<p class="d3-muted" role="status">No records match “${esc(state.query.trim())}”.</p>`;
  const q=queryStats(),M=q.M;
  if(!M)return `${provHTML(0)}<p class="d3-muted" role="status">No matches remain after the year range and filters. Widen them to see results.</p>`;
  const kp=kpiHTML([
    [NUM(M),'Matches in base','Ranked search results after year range and filters'],
    [PCT(q.share,2),'Share of collection','Matches ÷ all records'],
    [NUM(q.allTitle),'All terms in title','Matches whose title contains every term and phrase'],
    [NUM(q.anyTerm),'At least one term','Matches whose title, authors, keywords, journal or abstract contains a term'],
    [DEC(q.topScore,1),'Top relevance score','Highest search score among matches'],
    [DEC(q.medScore,1),'Median relevance score','Median search score among matches']
  ]);
  D.snap.query={query:q.q,matches:M,collectionRecords:q.N,shareOfCollection:q.share,terms:q.terms,related:q.related,allTermsInTitle:q.allTitle,atLeastOneTerm:q.anyTerm,fields:q.fields,scoreBands:q.bands};
  const fieldRows=q.fields.map(f=>({name:f.name,count:f.count,share:f.share,key:f.name}));
  const termRows=q.terms.map(t=>`<tr><td>${esc(t.term)}</td><td>${NUM(t.inMatches)}</td><td>${NUM(t.inTitle)}</td><td>${PCT(t.coverage)}</td><td>${PCT(t.collectionShare)}</td><td>${t.enrichment==null?'n/a':t.enrichment.toFixed(2)+'×'}</td></tr>`).join('');
  const relRows=q.related.map(r=>({name:r.name,key:r.key,count:r.count,share:r.share}));
  const relCard=barCard({title:'Related keywords',desc:`Keywords over-represented in the matches (at least ${D.minKw} matches). The value shows the lift: match share ÷ collection share. Select a keyword to filter.`,rows:relRows,field:'keyword',base:M,missing:0,label:'Keyword',valueFn:r=>`${NUM(r.count)} · lift ${DEC(q.related.find(x=>x.key===r.key).lift,2)}`,unitNote:`${NUM(q.relatedTotal)} keywords meet the minimum; the top ${D.topN} are shown.`});
  const fieldCard=barCard({title:'Fields that matched',desc:'Number of matches in which each field contributed to the score. A record can match in more than one field.',rows:fieldRows,field:null,base:M,missing:0,label:'Field',interactive:false});
  const bandCard=barCard({title:'Relevance score bands',desc:'Matches grouped by search score. Not a filter.',rows:q.bands.map(b=>({name:b.label,count:b.count,share:b.share})),field:null,base:M,missing:0,label:'Score',interactive:false});
  const stM=q.st;
  return `${provHTML(M,`Query terms: ${q.toks.map(esc).join(', ')||'none'}${q.phr.length?`; quoted phrases: ${q.phr.length}`:''}.`)}${kp}
    <div class="d3-grid">
      <section class="d3-card wide" aria-labelledby="h-terms"><h3 id="h-terms">Query term coverage</h3>
        <p class="d3-desc">How each term appears in the matches, compared with the whole collection. Enrichment above 1× means the term is more common among matches than in the collection.</p>
        <div class="d3-scroll"><table><thead><tr><th scope="col">Term</th><th scope="col">Matches containing it</th><th scope="col">Titles containing it</th><th scope="col">Coverage of matches</th><th scope="col">Collection share</th><th scope="col">Enrichment</th></tr></thead><tbody>${termRows||'<tr><td colspan="6">No searchable terms (phrase-only query).</td></tr>'}</tbody></table></div>
        <p class="d3-foot">Matching is a substring test, the same rule search scoring uses.</p></section>
      ${fieldCard}
      ${bandCard}
      ${relCard}
      <section class="d3-card" aria-labelledby="h-minkw"><h3 id="h-minkw">Keyword threshold</h3><p class="d3-desc">Keywords appear in the related list only when they occur in at least this many matches.</p>
        <label>Minimum matches <select data-d3minkw>${[2,3,5,10].map(v=>`<option value="${v}" ${D.minKw===v?'selected':''}>${v}</option>`).join('')}</select></label></section>
      ${barCard({title:'Matches per year',desc:'Each bar is a publication year among the matches. Select a year to filter.',rows:stM.series.map(y=>({name:String(y.year),count:y.count,share:y.share})),field:'year',base:M,missing:stM.miss.year,label:'Year'})}
      ${barCard({title:'Top journals in matches',desc:`Journals among the matches, top ${D.topN}.`,rows:stM.journals,field:'journal',base:M,missing:stM.miss.journal,label:'Journal'})}
    </div>`;
}

function htmlGraph(){
  if(!state.query.trim())return `${provHTML(0)}<p class="d3-muted" role="status">Run a search to build a knowledge graph from its matches.</p>`;
  if(!currentResults.length)return `${provHTML(0)}<p class="d3-muted" role="status">No matches, so there is no graph to build.</p>`;
  const gd=graphData();
  if(!gd.L)return `${provHTML(gd.M)}<p class="d3-muted" role="status">No matches remain after filters.</p>`;
  const s=gd.s,hubs=s.hubs.slice(0,30);
  D.hubs=hubs;
  const cx=260,cy=205,Rr=160,pos=new Map();
  hubs.forEach((n,i)=>{const a=-Math.PI/2+2*Math.PI*i/hubs.length;pos.set(n,{x:cx+Rr*Math.cos(a),y:cy+Rr*Math.sin(a)})});
  const svgEdges=(gd.edges).filter(e=>pos.has(e.a)&&pos.has(e.b)).map(e=>{const A=pos.get(e.a),B=pos.get(e.b);return `<line x1="${A.x.toFixed(1)}" y1="${A.y.toFixed(1)}" x2="${B.x.toFixed(1)}" y2="${B.y.toFixed(1)}" stroke="#aab7c6" stroke-width="1"/>`}).join('');
  const svgNodes=hubs.map((n,i)=>{
    const p=pos.get(n),d=s.deg.get(n),r=4+Math.min(9,Math.sqrt(d)*1.6),col=KG_COL[n.type]||'#4b5563',right=p.x>=cx;
    const lab=i<14?`<text x="${(p.x+(right?r+4:-r-4)).toFixed(1)}" y="${(p.y+3).toFixed(1)}" font-size="10" text-anchor="${right?'start':'end'}" fill="#111827">${esc(String(n.label).slice(0,28))}</text>`:'';
    return `<g role="button" tabindex="0" data-d3hub="${i}" aria-label="${attr(`${n.label}, ${n.type}, ${d} links. Press to explore.`)}"><circle cx="${p.x.toFixed(1)}" cy="${p.y.toFixed(1)}" r="${r.toFixed(1)}" fill="${col}"/>${lab}</g>`;
  }).join('');
  const legend=s.types.map(t=>`<li><span class="d3-sw" style="background:${KG_COL[t.name]||'#4b5563'}" aria-hidden="true"></span>${esc(t.name)}: ${NUM(t.count)} nodes</li>`).join('');
  const hubRows=s.hubs.slice(0,15).map((n,i)=>`<tr><td><button type="button" class="d3-link" data-d3hub="${i}">${esc(n.label)}</button></td><td>${esc(n.type)}</td><td>${NUM(s.deg.get(n))}</td></tr>`).join('');
  const cmpRows=gd.cmp.map(c=>`<tr ${c.id===gd.model.id?'class="d3-sel"':''}><td>${esc(c.label)}${c.id===gd.model.id?' <span class="d3-muted">(shown)</span>':''}</td><td>${NUM(c.N)}</td><td>${NUM(c.E)}</td><td>${NUM(c.comps)}</td><td>${DEC(c.density,3)}</td><td>${DEC(c.avgDeg,1)}</td></tr>`).join('');
  D.snap.graph={model:gd.model.id,recordsUsed:gd.L,matches:gd.M,nodes:s.N,edges:s.E,components:s.comps,largestComponent:s.largest,density:s.density,avgDegree:s.avgDeg,maxDegree:s.maxDeg,isolatedPapers:s.isolatedPapers,nodeTypes:s.types,relations:s.rels,topHubs:s.hubs.slice(0,15).map(n=>({label:n.label,type:n.type,links:s.deg.get(n)})),models:gd.cmp};
  return `${provHTML(gd.M,`Graph built from the top ${NUM(gd.L)} ranked matches of ${NUM(gd.M)}.`)}
    <div class="d3-row">
      <label>Model <select data-d3model>${Object.values(KG_MODELS).map(m=>`<option value="${m.id}" ${m.id===gd.model.id?'selected':''}>${esc(m.label)}</option>`).join('')}</select></label>
      <label>Records <select data-d3limit>${[20,50,100].map(v=>`<option value="${v}" ${D.limit===v?'selected':''}>${v}</option>`).join('')}</select></label>
      <button type="button" class="d3-btn primary" data-d3kg>Open full knowledge graph</button>
    </div>
    ${kpiHTML([
      [NUM(s.N),'Nodes','Distinct entities and records in the graph'],
      [NUM(s.E),'Edges','Relationships from the model schema'],
      [NUM(s.comps),'Connected components','Groups that are linked internally but not to each other'],
      [NUM(s.largest),'Largest component','Nodes in the biggest connected group'],
      [DEC(s.density,3),'Density','2E ÷ (N(N−1)); 1 means every pair is linked'],
      [DEC(s.avgDeg,1),'Average links per node','2E ÷ N'],
      [NUM(s.maxDeg),'Largest hub (links)','Highest number of links on any node'],
      [NUM(s.isolatedPapers),'Records with no links','Matched records with no entity links in this model']
    ])}
    <div class="d3-grid">
      <section class="d3-card" aria-labelledby="h-map"><h3 id="h-map">Hub map</h3>
        <p class="d3-desc">The 30 most-linked nodes. Select a node to explore it. Keyboard: Tab to a node, then press Enter.</p>
        <svg viewBox="0 0 520 420" class="d3-svg" role="img" aria-labelledby="map-t map-d"><title id="map-t">Knowledge graph hub map</title><desc id="map-d">${hubs.length} most-linked nodes, with links between them. Full list in the table beside it.</desc>${svgEdges}${svgNodes}</svg>
        <ul class="d3-legend">${legend}</ul></section>
      <section class="d3-card" aria-labelledby="h-hubs"><h3 id="h-hubs">Top hubs</h3><p class="d3-desc">Most-linked nodes in the graph, by number of links.</p>
        <div class="d3-scroll"><table><thead><tr><th scope="col">Entity</th><th scope="col">Type</th><th scope="col">Links</th></tr></thead><tbody>${hubRows}</tbody></table></div></section>
      <section class="d3-card" aria-labelledby="h-rel"><h3 id="h-rel">Relations in the graph</h3><p class="d3-desc">Edges counted by relation type.</p>
        <table><thead><tr><th scope="col">Relation</th><th scope="col">Edges</th></tr></thead><tbody>${s.rels.map(r=>`<tr><td>${esc(r.name)}</td><td>${NUM(r.count)}</td></tr>`).join('')}</tbody></table></section>
      <section class="d3-card wide" aria-labelledby="h-cmp"><h3 id="h-cmp">Compare the six models (same ${NUM(gd.L)} records)</h3>
        <p class="d3-desc">The same records built under each model. Differences show how the schema changes the structure.</p>
        <div class="d3-scroll"><table><thead><tr><th scope="col">Model</th><th scope="col">Nodes</th><th scope="col">Edges</th><th scope="col">Components</th><th scope="col">Density</th><th scope="col">Avg links</th></tr></thead><tbody>${cmpRows}</tbody></table></div></section>
    </div>`;
}

/* ---------- Evaluation Lab extension ---------- */
const EV_OLD=[['judge','Relevance judgments'],['diag','Result diagnostics'],['lab','Query lab'],['kg','KG model audit'],['sess','Session log'],['sus','Usability (SUS)']];
/* ---- Precision, Recall and F1 (pool-based: relevant = judged grade 1 or 2; unjudged results count as not relevant) ---- */
let PRF_K=10,PRF_ROWS=[];
function prfAt(ranking,J,K){
  const total=Object.values(J).filter(v=>+v>0).length;
  const top=ranking.slice(0,K);
  const tp=top.filter(x=>(+J[x.i]||0)>0).length;
  const judged=top.filter(x=>J[x.i]!==undefined).length;
  const P=top.length?tp/top.length:null,Rc=total?tp/total:null;
  const F1=(P!=null&&Rc!=null&&P+Rc>0)?2*P*Rc/(P+Rc):null;
  return {K,retrieved:top.length,tp,relevant:total,P,R:Rc,F1,judgedShare:top.length?judged/top.length:null};
}
function prfBody(){
  const all=judgments(),q=state.query.trim(),qs=Object.keys(all).filter(x=>Object.keys(all[x]).length);
  if(!qs.length)return `<p class="x2-note">No judged queries yet. Grade results in “Relevance judgments” first, then return here.</p>`;
  const Ks=[...new Set([5,10,20,depth()])].sort((a,b)=>a-b);
  if(!Ks.includes(PRF_K))PRF_K=10;
  const rows=[];
  qs.forEach(qq=>{const rk=rankFor(qq);rows.push(...Ks.map(K=>({q:qq,...prfAt(rk,all[qq],K)})))});
  PRF_ROWS=rows;
  const at=rows.filter(r=>r.K===PRF_K);
  const mean=(arr,k)=>{const v=arr.map(r=>r[k]).filter(x=>x!=null);return v.length?v.reduce((a,b)=>a+b,0)/v.length:null};
  const P=mean(at,'P'),Rc=mean(at,'R'),F=mean(at,'F1');
  const cur=q&&all[q]?prfAt(rankFor(q),all[q],PRF_K):null;
  const sweep=Ks.map(K=>{const a=rows.filter(r=>r.K===K);return {K,P:mean(a,'P'),R:mean(a,'R'),F1:mean(a,'F1')}});
  const f=x=>x==null?'–':x.toFixed(3),pc=x=>x==null?'–':(100*x).toFixed(1)+'%';
  return `<div class="x2-note">Precision = relevant results in the top K ÷ K. Recall = relevant results in the top K ÷ all relevant records judged for the query. F1 = 2 · P · R ÷ (P + R). Unjudged results count as not relevant, so grade the top K before reading precision.</div>
  <div class="x2-bar"><label>K <select id="x2PrfK">${Ks.map(K=>`<option value="${K}" ${K===PRF_K?'selected':''}>${K}</option>`).join('')}</select></label><button class="ghost" id="x2PrfCsv" type="button">⇩ Export (CSV)</button></div>
  <div class="x2-kpis">${[[f(P),'Mean precision@'+PRF_K],[f(Rc),'Mean recall@'+PRF_K],[f(F),'Mean F1@'+PRF_K],[at.length,'Queries']].map(([v,l])=>`<div class="x2-kpi"><b>${v}</b><span>${l}</span></div>`).join('')}</div>
  ${cur?`<div class="x2-note"><b>Current query “${esc(q)}” at K = ${PRF_K}:</b> precision ${f(cur.P)} · recall ${f(cur.R)} · F1 ${f(cur.F1)} (${cur.tp} relevant in top ${cur.retrieved} of ${cur.relevant} relevant judged)</div>`:''}
  <table class="x2-tbl"><tr><th>Query</th><th>Retrieved (K)</th><th>Relevant retrieved</th><th>Relevant judged</th><th>Precision</th><th>Recall</th><th>F1</th><th>Top K judged</th></tr>
  ${at.map(r=>`<tr><td>${esc(r.q)}</td><td>${r.retrieved}</td><td>${r.tp}</td><td>${r.relevant}</td><td>${f(r.P)}</td><td>${f(r.R)}</td><td>${f(r.F1)}</td><td>${pc(r.judgedShare)}</td></tr>`).join('')}
  <tr><td><b>Macro average</b></td><td></td><td></td><td></td><td><b>${f(P)}</b></td><td><b>${f(Rc)}</b></td><td><b>${f(F)}</b></td><td></td></tr></table>
  <h4 style="margin:14px 0 6px;font-size:12px;color:var(--brand);text-transform:uppercase;letter-spacing:.05em">Macro averages by cutoff K</h4>
  <table class="x2-tbl"><tr><th>K</th><th>Precision</th><th>Recall</th><th>F1</th></tr>${sweep.map(s=>`<tr><td>${s.K}</td><td>${f(s.P)}</td><td>${f(s.R)}</td><td>${f(s.F1)}</td></tr>`).join('')}</table>`;
}
const EV_NEW=[['batch','Batch metrics'],['curve','PR curve & AUC'],['prf','Precision, Recall & F1'],['auto','Heuristic grading']];
const judgments=()=>{try{return JSON.parse(localStorage.getItem('are_judg')||'{}')}catch{return{}}};
const autoGrades=()=>{try{return JSON.parse(localStorage.getItem('are_auto')||'{}')}catch{return{}}};
const saveJudgments=j=>localStorage.setItem('are_judg',JSON.stringify(j));
const depth=()=>Number(localStorage.getItem('are_depth'))||20;
const rankCache=new Map();
/* Ranking identical to the app's default relevance order (score, then citations), no facet filters. */
function rankFor(q){
  if(rankCache.has(q))return rankCache.get(q);
  const o=[];
  for(let i=0;i<R.length;i++){const r=relevance(i,q),s=typeof r==='number'?r:r.score;if(s>0)o.push({i,s})}
  o.sort((a,b)=>b.s-a.s||R[b.i][0]-R[a.i][0]);
  rankCache.set(q,o);return o;
}
function queryMetrics(ranking,J){
  const TOT=Object.values(J).filter(v=>+v>0).length;
  const gains=ranking.map(x=>+J[x.i]||0),top10=gains.slice(0,10),top20=gains.slice(0,20);
  const p10=top10.filter(x=>x>0).length/10;
  const r10=TOT?top10.filter(x=>x>0).length/TOT:null;
  const dcg=a=>a.reduce((s,r,i)=>s+r/Math.log2(i+2),0);
  const ideal=Object.values(J).map(Number).filter(x=>x>0).sort((a,b)=>b-a);
  const idcg=dcg(ideal.slice(0,10));
  const ndcg=idcg?dcg(top10)/idcg:null;
  let seen=0,ap=0;top20.forEach((x,k)=>{if(x>0){seen++;ap+=seen/(k+1)}});
  return {judged:Object.keys(J).length,TOT,p10,r10,ndcg,ap:TOT?ap/TOT:null};
}
function batchBody(){
  const all=judgments(),qs=Object.keys(all).filter(q=>Object.keys(all[q]).length);
  if(!qs.length)return `<p class="x2-note">No judged queries yet. Run searches and grade results in “Relevance judgments”. Every judged query appears here.</p>`;
  const rows=qs.map(q=>({q,...queryMetrics(rankFor(q),all[q])}));
  const mean=k=>{const v=rows.map(r=>r[k]).filter(x=>x!=null);return v.length?v.reduce((a,b)=>a+b,0)/v.length:null};
  const m={p10:mean('p10'),r10:mean('r10'),ndcg:mean('ndcg'),ap:mean('ap')};
  batchRows=rows;
  return `<div class="x2-kpis">${kpi(rows.length,'Judged queries')}${kpi(pc(m.p10),'Mean P@10')}${kpi(pc(m.r10),'Mean R@10')}${kpi(m.ndcg==null?'–':m.ndcg.toFixed(2),'Mean nDCG@10')}${kpi(m.ap==null?'–':m.ap.toFixed(2),'MAP')}</div>
    <p class="x2-note">Macro averages over judged queries. Ranking uses the default relevance order without facet filters. Unjudged results count as not relevant. Judge pool depth: top ${depth()}.</p>
    <table class="x2-tbl"><tr><th>Query</th><th>Judged</th><th>Relevant</th><th>P@10</th><th>R@10</th><th>nDCG@10</th><th>AP</th></tr>
    ${rows.map(r=>`<tr><td>${esc(r.q)}</td><td>${r.judged}</td><td>${r.TOT}</td><td>${pc(r.p10,0)}</td><td>${pc(r.r10,0)}</td><td>${r.ndcg==null?'–':r.ndcg.toFixed(2)}</td><td>${r.ap==null?'–':r.ap.toFixed(2)}</td></tr>`).join('')}</table>
    <div class="x2-bar" style="margin-top:10px"><button class="ghost" id="x2BatchCsv" type="button">⇩ Export batch metrics (CSV)</button></div>`;
}
let batchRows=[];

function curveBody(){
  const q=state.query.trim();
  if(!q||!currentResults.length)return `<p class="x2-note">Run a search and judge some results first.</p>`;
  const J=judgments()[q]||{},TOT=Object.values(J).filter(v=>+v>0).length;
  if(!TOT)return `<p class="x2-note">Mark at least one result as relevant (grade 1 or 2) in “Relevance judgments” to draw the precision–recall curve.</p>`;
  const top=currentResults.slice(0,50);
  let relSeen=0;
  const pts=top.map((h,k)=>{if((+J[h.i]||0)>0)relSeen++;return {r:relSeen/TOT,p:relSeen/(k+1)}});
  let prev=0,ap=0;pts.forEach(pt=>{if(pt.r>prev){ap+=(pt.r-prev)*pt.p;prev=pt.r}});
  const score=i=>{const r=relevance(i,q);return typeof r==='number'?r:r.score};
  const pos=[],neg=[];
  Object.entries(J).forEach(([i,v])=>(+v>0?pos:neg).push(score(+i)));
  let wins=0;pos.forEach(p=>neg.forEach(n=>{wins+=p>n?1:p===n?0.5:0}));
  const auc=pos.length&&neg.length?wins/(pos.length*neg.length):null;
  const W=560,H=340,m=44,X=r=>m+r*(W-2*m),Y=p=>H-m-p*(H-2*m);
  const grid=[0,.25,.5,.75,1].map(t=>`<line x1="${X(t)}" y1="${m}" x2="${X(t)}" y2="${H-m}" stroke="#eef1f5"/><line x1="${m}" y1="${Y(t)}" x2="${W-m}" y2="${Y(t)}" stroke="#eef1f5"/><text x="${X(t)}" y="${H-m+16}" font-size="10" text-anchor="middle" fill="#687386">${t}</text><text x="${m-8}" y="${Y(t)+3}" font-size="10" text-anchor="end" fill="#687386">${t}</text>`).join('');
  const line=[[0,1],...pts.map(pt=>[pt.r,pt.p])].map(([r,p])=>`${X(r).toFixed(1)},${Y(p).toFixed(1)}`).join(' ');
  const dots=pts.map(pt=>`<circle cx="${X(pt.r).toFixed(1)}" cy="${Y(pt.p).toFixed(1)}" r="2.6" fill="#d97706"/>`).join('');
  const p10=pts[9]?pts[9].p:null;
  return `<div class="x2-kpis">${kpi(ap.toFixed(3),'Average precision (top 50)')}${kpi(auc==null?'–':auc.toFixed(3),'Score ROC-AUC')}${kpi(pc(p10),'Precision@10')}${kpi(fmt(TOT),'Relevant judged')}${kpi(fmt(pts.filter((_,k)=>top[k]&&(+J[top[k].i]||0)>0).length),'Relevant in top 50')}</div>
    <svg viewBox="0 0 ${W} ${H}" class="x2-svg" role="img" aria-label="Precision recall curve">${grid}<line x1="${m}" y1="${H-m}" x2="${W-m}" y2="${H-m}" stroke="#9aa6b8"/><line x1="${m}" y1="${m}" x2="${m}" y2="${H-m}" stroke="#9aa6b8"/>
      <polyline points="${line}" fill="none" stroke="#184e77" stroke-width="2.5"/>${dots}
      <text x="${W/2}" y="${H-8}" font-size="11" text-anchor="middle" fill="#334">Recall</text>
      <text x="14" y="${H/2}" font-size="11" text-anchor="middle" fill="#334" transform="rotate(-90 14 ${H/2})">Precision</text></svg>
    <p class="x2-note">Each dot is one rank of the current results (top 50). Precision = relevant ÷ rank. Recall = relevant so far ÷ all relevant judged for this query. ROC-AUC is the chance that a relevant record scores above a non-relevant one, using the relevance score (0.5 = random).</p>`;
}

function autoBody(){
  const q=state.query.trim();
  if(!q||!currentResults.length)return `<p class="x2-note">Run a search first.</p>`;
  const top=currentResults.slice(0,depth());
  const qt=[...new Set(tokens(q.replace(/"[^"]*"/g,' ')))];
  const ph=[...q.matchAll(/"([^"]+)"/g)].map(m=>norm(m[1])).filter(Boolean);
  const grade=i=>{
    const x=INDEX[i];
    const inTitle=qt.filter(t=>x.t.includes(t)).length;
    const inAny=qt.filter(t=>(x.t+' '+x.k+' '+x.b).includes(t)).length;
    if((ph.length&&ph.every(p=>x.t.includes(p)))||(qt.length&&inTitle===qt.length))return {g:2,why:'all terms in title'};
    if(qt.length&&inAny>=Math.ceil(qt.length/2))return {g:1,why:'half or more terms in title, keywords or abstract'};
    return {g:0,why:'few or no terms'};
  };
  const auto=autoGrades();auto[q]={};
  const human=judgments()[q]||{};
  const rows=top.map((h,k)=>{const a=grade(h.i);auto[q][h.i]=a.g;return {k,i:h.i,a,h:human[h.i]}});
  localStorage.setItem('are_auto',JSON.stringify(auto));
  const both=rows.filter(r=>typeof r.h==='number');
  let agree=null,kappa=null;
  if(both.length){
    const n=both.length,po=both.filter(r=>r.a.g===r.h).length/n;
    const pe=[0,1,2].reduce((s,c)=>s+(both.filter(r=>r.a.g===c).length/n)*(both.filter(r=>r.h===c).length/n),0);
    agree=po;kappa=(po-pe)/((1-pe)||1);
  }
  const unjudged=rows.filter(r=>typeof r.h!=='number').length;
  return `<div class="x2-kpis">${kpi(fmt(rows.length),'Results graded')}${kpi(fmt(both.length),'Also human-judged')}${kpi(pc(agree),'Agreement with human')}${kpi(kappa==null?'–':kappa.toFixed(2),'Cohen’s κ')}</div>
    <p class="x2-note">Automatic grades are a baseline, not ground truth: 2 = all query terms in the title, 1 = at least half in title, keywords or abstract, 0 = otherwise. Compare them with human grades before relying on them.</p>
    <table class="x2-tbl"><tr><th>#</th><th>Result</th><th>Auto</th><th>Reason</th><th>Human</th></tr>
    ${rows.map(r=>`<tr><td>${r.k+1}</td><td>${esc(R[r.i][2])}</td><td><span class="x2-badge">${r.a.g}</span></td><td>${esc(r.a.why)}</td><td>${typeof r.h==='number'?r.h:'–'}</td></tr>`).join('')}</table>
    <div class="x2-bar" style="margin-top:10px"><button class="primary" id="x2Accept" type="button">Accept suggestions for ${fmt(unjudged)} unjudged results</button><button class="ghost" id="x2AutoCsv" type="button">⇩ Export (CSV)</button></div>`;
}

const EV_BODY={batch:batchBody,curve:curveBody,prf:prfBody,auto:autoBody};
function bindEV(t){
  if(t==='prf'){const k=$('#x2PrfK');if(k)k.onchange=e=>{PRF_K=+e.target.value;evalModal('prf')};const c=$('#x2PrfCsv');if(c)c.onclick=()=>download('precision-recall-f1.csv',csvOf([['query','k','retrieved','relevant_retrieved','relevant_judged','precision','recall','f1','judged_share'],...PRF_ROWS.map(r=>[r.q,r.K,r.retrieved,r.tp,r.relevant,r.P,r.R,r.F1,r.judgedShare])]),'text/csv')}
  if(t==='batch'){const b=$('#x2BatchCsv');if(b)b.onclick=()=>download('batch-metrics.csv',csvOf([['query','judged','relevant','p10','r10','ndcg10','ap'],...batchRows.map(r=>[r.q,r.judged,r.TOT,r.p10,r.r10??'',r.ndcg??'',r.ap??''])]),'text/csv')}
  if(t==='auto'){
    const q=state.query.trim();
    const a=$('#x2Accept');
    if(a)a.onclick=()=>{
      const auto=autoGrades()[q]||{},human=judgments();human[q]=human[q]||{};
      Object.entries(auto).forEach(([i,g])=>{if(human[q][i]===undefined)human[q][i]=g});
      saveJudgments(human);toast('Suggestions accepted as judgments');evalModal('auto');
    };
    const c=$('#x2AutoCsv');
    if(c)c.onclick=()=>{const human=judgments()[q]||{},auto=autoGrades()[q]||{};download('heuristic-grades.csv',csvOf([['record_index','title','auto','human'],...Object.keys(auto).map(i=>[i,R[i][2],auto[i],human[i]??''])]),'text/csv')};
  }
}
function evShell(t){
  $('#modalCard').classList.add('x2-wide');
  showModal(`<h2>Evaluation Lab</h2><p class="x2-note">Measure how well this interface finds, ranks and relates records for the current search. Judgments and scores stay in this browser.</p><div class="ev-tabs">${[...EV_OLD,...EV_NEW].map(([k,l])=>`<button class="ev-tab ${k===t?'on':''}" data-t="${k}" type="button">${l}</button>`).join('')}</div><div id="evBody"></div>`);
  $$('.ev-tab').forEach(b=>b.onclick=()=>window.evalModal(b.dataset.t));
  $('#evBody').innerHTML=EV_BODY[t]();
  bindEV(t);
}


/* ---------- wire up: wrap the existing Evaluate and Dashboard entry points ---------- */
const _evalOld=window.evalModal;
window.evalModal=function(t){
  if(EV_BODY[t])return evShell(t);
  _evalOld.call(this,t);
  const tabs=$('.ev-tabs');
  if(tabs&&!tabs.querySelector('[data-t="batch"]'))EV_NEW.forEach(([k,l])=>{
    const b=document.createElement('button');b.className='ev-tab';b.dataset.t=k;b.type='button';b.textContent=l;
    b.onclick=()=>window.evalModal(k);tabs.appendChild(b);
  });
};
const _closeOld=window.closeModal;
window.closeModal=function(){$('#modalCard').classList.remove('x2-wide');return _closeOld.apply(this,arguments)};


/* ---------- export (every figure comes from the same computed snapshot) ---------- */
function exportPayload(){
  const base=baseIds().length;
  return {
    schema:'academic-explorer-dashboard/v3',
    generated:new Date().toISOString(),
    dataset:{records:R.length,description:'embedded bibliographic dataset'},
    scope:{base:D.scope,yearFrom:D.from||null,yearTo:D.to||null,filters:D.filters.map(f=>({field:f.field,value:f.value}))},
    recordsInBase:base,
    query:state.query.trim()||null,
    method:METHOD,
    overview:D.snap.overview||null,
    query_explorer:D.snap.query||null,
    knowledge_graph:D.snap.graph||null
  };
}
function exportCsv(kind){
  const o=D.snap.overview,qq=D.snap.query,g=D.snap.graph;
  const map={
    years:()=>o&&[['year','records','share_of_base'],...o.years.map(y=>[y.year,y.count,y.share])],
    journals:()=>o&&[['journal','records','share_of_base'],...o.journals.map(r=>[r.name,r.count,r.share])],
    keywords:()=>o&&[['keyword','records','share_of_base'],...o.keywords.map(r=>[r.name,r.count,r.share])],
    authors:()=>o&&[['author','records','share_of_base'],...o.authors.map(r=>[r.name,r.count,r.share])],
    countries:()=>o&&[['country','records','share_of_base'],...o.countries.map(r=>[r.name,r.count,r.share])],
    terms:()=>qq&&[['term','matches_containing','titles_containing','coverage','collection_share','enrichment'],...qq.terms.map(t=>[t.term,t.inMatches,t.inTitle,t.coverage,t.collectionShare,t.enrichment])],
    related:()=>qq&&[['keyword','matches','share_of_matches','collection_records','lift'],...qq.related.map(r=>[r.name,r.count,r.share,r.collection,r.lift])],
    hubs:()=>g&&[['entity','type','links'],...g.topHubs.map(h=>[h.label,h.type,h.links])],
    models:()=>g&&[['model','nodes','edges','components','density','avg_links'],...g.models.map(m=>[m.label,m.N,m.E,m.comps,m.density,m.avgDeg])]
  };
  const rows=map[kind]&&map[kind]();
  if(!rows)return toast('Open the matching tab first, so the figures are computed');
  download(`dashboard-${kind}.csv`,csvOf(rows),'text/csv');
}

/* ---------- controller ---------- */
const TAB_IDS={overview:'d3tab-overview',query:'d3tab-query',kg:'d3tab-kg',export:'d3tab-export'};
function setStatus(msg){const s=$('#d3Status');if(s)s.textContent=msg}
function renderDash(){
  const panel=$('#d3Panel');if(!panel)return;
  setStatus('Computing…');
  setTimeout(()=>{
    let html;
    try{
      D.computed=new Date();
      if(D.tab==='overview')html=htmlOverview();
      else if(D.tab==='query')html=htmlQuery();
      else if(D.tab==='kg')html=htmlGraph();
      else html=htmlExport();
    }catch(e){
      console.error(e);
      html=`<p role="alert" class="d3-muted">The dashboard could not compute this view: ${esc(e.message)}</p>`;
    }
    $('#d3Filters').innerHTML=D.tab==='export'?'':filterBarHTML();
    panel.innerHTML=html;
    $$('.d3-tab').forEach(b=>{b.setAttribute('aria-selected',String(b.dataset.d3tab===D.tab));b.tabIndex=b.dataset.d3tab===D.tab?0:-1});
    panel.setAttribute('aria-labelledby',TAB_IDS[D.tab]);
    if(D.tab==='export')setStatus(`Updated ${D.computed.toLocaleTimeString()}.`);
    else if(D.tab==='query')setStatus(`Matches: ${NUM(matchIds().length)}. Updated ${D.computed.toLocaleTimeString()}.`);
    else setStatus(`Records in base: ${NUM(baseIds().length)}. Updated ${D.computed.toLocaleTimeString()}.`);
  },0);
}
function htmlExport(){
  const have=k=>!!D.snap[k];
  const payloadNote=`${provHTML(baseIds().length)}`;
  const csvBtn=(k,label,ok)=>`<button type="button" class="d3-btn" data-d3csv="${k}" ${ok?'':'aria-describedby="exp-note"'}>${label}</button>`;
  return `${payloadNote}
    <section class="d3-card wide" aria-labelledby="h-exp"><h3 id="h-exp">Export</h3>
      <p class="d3-desc">Downloads contain the figures exactly as shown. The JSON file also contains the scope, filters, query and method notes, so a figure can be traced back to its definition. CSV files exist only for sections you have opened in this session.</p>
      <div class="d3-row"><button type="button" class="d3-btn primary" data-d3json>Download full summary (JSON)</button></div>
      <div class="d3-row" role="group" aria-label="CSV downloads">
        ${csvBtn('years','Years (CSV)',have('overview'))}${csvBtn('journals','Journals (CSV)',have('overview'))}${csvBtn('keywords','Keywords (CSV)',have('overview'))}${csvBtn('authors','Authors (CSV)',have('overview'))}${csvBtn('countries','Countries (CSV)',have('overview'))}
        ${csvBtn('terms','Query terms (CSV)',have('query'))}${csvBtn('related','Related keywords (CSV)',have('query'))}
        ${csvBtn('hubs','Graph hubs (CSV)',have('graph'))}${csvBtn('models','Model comparison (CSV)',have('graph'))}
      </div>
      <p id="exp-note" class="d3-foot">Buttons stay available; if a file is missing, open its tab first.</p>
    </section>`;
}
function openDash(){
  if(!R||!R.length){toast('Dataset is still loading…');return}
  $('#modalCard').classList.add('x2-wide');
  showModal(`<div id="d3Root" class="d3-root">
    <h2>Dashboard</h2>
    <div class="d3-tabs" role="tablist" aria-label="Dashboard sections">${DTABS.map(([k,l])=>`<button type="button" role="tab" id="${TAB_IDS[k]}" class="d3-tab" data-d3tab="${k}" aria-selected="${D.tab===k}" aria-controls="d3Panel" tabindex="${D.tab===k?0:-1}">${l}</button>`).join('')}</div>
    <div id="d3Filters"></div>
    <div id="d3Panel" role="tabpanel" aria-labelledby="${TAB_IDS[D.tab]}"></div>
    <div id="d3Status" class="d3-status" role="status" aria-live="polite"></div>
  </div>`);
  const root=$('#d3Root');
  root.addEventListener('click',onDashClick);
  root.addEventListener('change',onDashChange);
  root.addEventListener('keydown',onDashKey);
  renderDash();
}
function setTab(t){D.tab=t;renderDash();const b=document.getElementById(TAB_IDS[t]);if(b)b.focus()}
function toggleFilter(field,value,key){
  const idx=D.filters.findIndex(f=>f.field===field&&(field==='keyword'||field==='author'?f.key===key:f.value===value));
  if(idx>=0)D.filters.splice(idx,1);
  else D.filters.push({field,value:String(value),key:key||norm(value)});
  renderDash();
}
function onDashClick(e){
  const pp=e.target.closest('[data-d3pie]');
  if(pp){const pb=document.querySelector('[data-d3pieb="'+pp.dataset.d3pie+'"]');if(pb)pb.click();return}
  const t=e.target.closest('button,[role="button"]');
  if(!t)return;
  if(t.dataset.d3other!==undefined){D.otherOpen=!D.otherOpen;renderDash();const ol=document.getElementById('d3OtherList');if(ol)ol.scrollIntoView({block:'nearest'});return}
  if(t.dataset.d3tab){setTab(t.dataset.d3tab);return}
  if(t.dataset.d3f){toggleFilter(t.dataset.d3f,t.dataset.d3v,t.dataset.d3k);return}
  if(t.dataset.d3rm!==undefined){D.filters.splice(Number(t.dataset.d3rm),1);renderDash();return}
  if('d3clear' in t.dataset){D.filters=[];renderDash();return}
  if('d3reset' in t.dataset){D.scope='all';D.from='';D.to='';D.topN=10;D.minKw=3;D.filters=[];D.limit=20;renderDash();return}
  if('d3apply' in t.dataset){applyToSearch();return}
  if(t.dataset.d3hub!==undefined){openHub(D.hubs[Number(t.dataset.d3hub)]);return}
  if(t.dataset.d3open!==undefined){closeModal();detail(Number(t.dataset.d3open));return}
  if('d3kg' in t.dataset){closeModal();kgOpen(currentResults.slice(0,D.limit),'results');return}
  if('d3json' in t.dataset){download('dashboard-summary.json',JSON.stringify(exportPayload(),null,2),'application/json');return}
  if(t.dataset.d3csv){exportCsv(t.dataset.d3csv);return}
}
function onDashChange(e){
  const t=e.target;
  if('d3scope' in t.dataset){D.scope=t.value;renderDash();return}
  if('d3from' in t.dataset){D.from=t.value.trim();renderDash();return}
  if('d3to' in t.dataset){D.to=t.value.trim();renderDash();return}
  if('d3topn' in t.dataset){D.topN=Number(t.value);renderDash();return}
  if('d3minkw' in t.dataset){D.minKw=Number(t.value);renderDash();return}
  if('d3model' in t.dataset){D.model=t.value;renderDash();return}
  if('d3limit' in t.dataset){D.limit=Number(t.value);renderDash();return}
}
function onDashKey(e){
  const tab=e.target.closest('.d3-tab');
  if(tab&&(e.key==='ArrowRight'||e.key==='ArrowLeft')){
    const order=DTABS.map(d=>d[0]);
    const k=(order.indexOf(tab.dataset.d3tab)+(e.key==='ArrowRight'?1:order.length-1))%order.length;
    e.preventDefault();setTab(order[k]);return;
  }
  const hub=e.target.closest('[data-d3hub][role="button"]');
  if(hub&&(e.key==='Enter'||e.key===' ')){e.preventDefault();openHub(D.hubs[Number(hub.dataset.d3hub)])}
}
function openHub(n){
  if(!n)return;
  if(n.type==='paper'){closeModal();detail(n.paperIndex);return}
  if(n.type==='country'){closeModal();const idx=CO.findIndex(x=>x===n.label);if(idx>=0){state.country=String(idx);$('#countryFilter').value=state.country}state.page=1;doSearch();return}
  if(['journal','publisher','keyword','author','year','place'].includes(n.type)){kgSearchByNode(n);return}
  toast('Use the search box to look up this '+n.type);
}
/* Copies dashboard filters into the search facets, then runs the search */
function applyToSearch(){
  closeModal();
  const jf=D.filters.find(f=>f.field==='journal');
  const pf=D.filters.find(f=>f.field==='publisher');
  const cf=D.filters.find(f=>f.field==='country');
  const yf=D.filters.filter(f=>f.field==='year');
  const kf=D.filters.find(f=>f.field==='keyword'||f.field==='author');
  if(jf){state.source=String(S.indexOf(jf.value));$('#sourceFilter').value=state.source}
  if(pf){state.publisher=String(PUB.indexOf(pf.value));$('#publisherFilter').value=state.publisher}
  if(cf){state.country=String(CO.indexOf(cf.value));$('#countryFilter').value=state.country}
  if(yf.length){state.yearSet=new Set(yf.map(f=>Number(f.value)));$$('[data-year]').forEach(x=>x.checked=state.yearSet.has(Number(x.dataset.year)))}
  if(D.from)state.yearFrom=Number(D.from);
  if(D.to)state.yearTo=Number(D.to);
  if(kf){state.query=`"${kf.value}"`;$('#q').value=state.query}
  state.page=1;doSearch();
  toast('Dashboard filters applied to the search');
}

/* ---------- wire up (dashboard entry point) ---------- */
window.openDashboard=openDash;
let dbBtn=document.getElementById('dashBtn');
if(!dbBtn){
  dbBtn=document.createElement('button');
  dbBtn.className='ghost';dbBtn.id='dashBtn';dbBtn.type='button';
  dbBtn.innerHTML='▦ <span>Dashboard</span>';
  const anchor=document.getElementById('evalBtn')||document.querySelector('.toolbar .nav-spacer');
  if(anchor&&anchor.parentNode)anchor.parentNode.insertBefore(dbBtn,anchor);
  else document.querySelector('.toolbar')?.appendChild(dbBtn);
}
dbBtn.onclick=openDash;

})();
;
/* ---- x3-mind-semantic-lod ---- */
/* ===== Mind Mapping + Semantic Layer + Linked Open Data (added; existing features untouched) ===== */
(()=>{
'use strict';
const Q=s=>document.querySelector(s),QA=s=>[...document.querySelectorAll(s)];
const st=document.createElement('style');st.textContent=`
.x3 .tabs{display:flex;gap:4px;flex-wrap:wrap;border-bottom:2px solid var(--brand);margin:8px 0 12px}
.x3 .tabs button{border:0;background:none;padding:8px 13px;border-radius:8px 8px 0 0;font-weight:700;color:var(--brand)}
.x3 .tabs button.on{background:var(--brand);color:#fff}
.x3 .row{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin:8px 0}
.x3 select,.x3 input[type=text],.x3 input[type=number],.x3 textarea{border:1px solid var(--line);border-radius:8px;padding:6px 8px;background:#fff;font:inherit}
.x3 textarea{width:100%;font-family:ui-monospace,Consolas,monospace;font-size:12px}
.x3 table{width:100%;border-collapse:collapse;font-size:12.5px}.x3 th,.x3 td{text-align:left;padding:6px;border-bottom:1px solid var(--line);vertical-align:top}
.x3 .chip{display:inline-block;border:1px solid var(--line);background:#f3f8fb;border-radius:999px;padding:2px 9px;font-size:12px;margin:2px;cursor:pointer}
.x3 .card{border:1px solid var(--line);border-radius:10px;padding:10px;margin:8px 0;background:#fff}
.x3 .mmwrap{display:grid;grid-template-columns:minmax(0,1fr) 250px;gap:10px}
.x3 .mmstage{border:1px solid var(--line);border-radius:10px;background:#fff;height:600px;overflow:hidden}
.x3 .mmstage svg{width:100%;height:100%;cursor:grab;touch-action:none}
.x3 .mmside{border:1px solid var(--line);border-radius:10px;padding:10px;font-size:12.5px;max-height:600px;overflow:auto}
.x3 .mmside button{margin:2px}.x3 .bad{color:#b42318}.x3 .ok{color:var(--ok)}
.sample-header .toolbar #mmBtn{background:#e6f6ee!important;color:#0f6b46!important}
.sample-header .toolbar #semBtn{background:#eaf0fb!important;color:#1f4e8c!important}
.sample-header .toolbar #lodBtn{background:#fdeeee!important;color:#a12b2b!important}
@media(max-width:800px){.x3 .mmwrap{grid-template-columns:1fr}}`;
document.head.appendChild(st);

/* ---------- shared helpers ---------- */
const H=(t,b)=>{$('#modalCard').classList.add('x2-wide');showModal(`<div class="x3"><h2>${t}</h2>${b}</div>`)};
const SC=`<label>Scope <select id="x3n"><option>20</option><option selected>50</option><option>100</option><option>200</option><option>500</option></select> top results</label>`;
const hits=()=>{const n=+(Q('#x3n')?.value||50);let a=currentResults.map(h=>h.i).filter(i=>typeof i==='number');if(!a.length)a=[...Array(Math.min(n,R.length)).keys()];return a.slice(0,n)};
const slug=s=>norm(s).replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'')||'x';
const stem=s=>norm(s).replace(/\([^)]*\)/g,' ').replace(/[-_\/]/g,' ').replace(/[^a-z0-9 ]/g,'').split(/\s+/).filter(Boolean).map(w=>w.length>3?w.replace(/ies$/,'y').replace(/([^s])s$/,'$1'):w).join(' ');
function tabbed(title,names,render,start){let cur=start||names[0][0];H(title,`<div class="tabs">${names.map(([k,l])=>`<button data-t="${k}">${l}</button>`).join('')}</div><div id="x3b"></div>`);const go=k=>{cur=k;QA('.x3 .tabs button').forEach(b=>b.classList.toggle('on',b.dataset.t===k));render(k,Q('#x3b'))};QA('.x3 .tabs button').forEach(b=>b.onclick=()=>go(b.dataset.t));go(cur)}
const lsGet=(k,d)=>{try{return JSON.parse(localStorage.getItem(k))||d}catch{return d}};

/* =====================  1. MIND MAPPING  ===================== */
const MM={t:null,sel:null,k:1,x:0,y:0,id:0,nodes:[]};
const MC={root:'#14213d',keyword:'#7c3aed',author:'#c2410c',journal:'#047857',publisher:'#b45309',country:'#be123c',year:'#475569',paper:'#184e77',custom:'#0f766e'};
const BR={keyword:'Keywords',author:'Authors',journal:'Journals',publisher:'Publishers',country:'Countries',year:'Years'};
const mn=(label,ctype,o)=>Object.assign({id:++MM.id,label:String(label),ctype,kids:[],col:false,note:''},o);
const FS=12,RH=28,wd=n=>Math.min(n.label.length,40)*6.6+22,vis=n=>n.col?[]:n.kids;
const lh=n=>n._h=vis(n).length?vis(n).reduce((a,c)=>a+lh(c),0):1;
const mmFind=(id,n=MM.t)=>{if(n.id===id)return n;for(const c of n.kids){const f=mmFind(id,c);if(f)return f}return null};
const mmParent=(id,n=MM.t)=>{for(const c of n.kids){if(c.id===id)return n;const f=mmParent(id,c);if(f)return f}return null};
function mmBuild(ix,br,per,deep,label){
 const root=mn(label||state.query||'Research results','root'),objs=ix.map(i=>recObj(i));
 const get={keyword:o=>splitKeywords(o.keywords),author:o=>splitAuthors(o.authors),journal:o=>[o.source],publisher:o=>[o.publisher],country:o=>[o.country],year:o=>[String(o.year||'')]};
 br.forEach(b=>{const m=new Map();objs.forEach(o=>new Set(get[b](o).map(x=>(x||'').trim()).filter(Boolean)).forEach(l=>{const k=norm(l),e=m.get(k)||{l,p:[]};e.p.push(o);m.set(k,e)}));
  const B=mn(BR[b],b,{branch:1});
  [...m.values()].sort((a,c)=>c.p.length-a.p.length).slice(0,per).forEach(e=>{const L=mn(e.l+' ('+e.p.length+')',b,{term:e.l,pids:e.p.map(o=>o.index)});
   if(deep){e.p.slice().sort((a,c)=>c.cites-a.cites).slice(0,4).forEach(o=>L.kids.push(mn(o.title,'paper',{pi:o.index})));L.col=true}B.kids.push(L)});
  if(B.kids.length)root.kids.push(B)});
 return root}
function mmLayout(){const r=MM.t,k=vis(r);k.forEach(lh);const tot=k.reduce((a,c)=>a+c._h,0);let acc=0;const Ra=[],La=[];k.forEach(c=>{(acc<tot/2?Ra:La).push(c);acc+=c._h});
 const place=(n,x,top,s)=>{n.x=x;n.y=top+n._h*RH/2;let t=top;vis(n).forEach(c=>{place(c,x+s*(wd(n)/2+46+wd(c)/2),t,s);t+=c._h*RH})};
 r.x=0;r.y=0;const side=(arr,s)=>{const h=arr.reduce((a,c)=>a+c._h,0);let t=-h*RH/2;arr.forEach(c=>{place(c,s*(wd(r)/2+46+wd(c)/2),t,s);t+=c._h*RH})};side(Ra,1);side(La,-1)}
function mmDraw(){mmLayout();const nodes=[],edges=[];(function walk(n,p){nodes.push(n);if(p)edges.push([p,n]);vis(n).forEach(c=>walk(c,n))})(MM.t,null);
 const col=n=>MC[n.ctype]||MC.custom;
 const e=edges.map(([p,c])=>{const s=c.x>p.x?1:-1,x1=p.x+s*wd(p)/2,x2=c.x-s*wd(c)/2,mx=(x1+x2)/2;return `<path d="M${x1},${p.y}C${mx},${p.y} ${mx},${c.y} ${x2},${c.y}" fill="none" stroke="${col(c)}" stroke-opacity=".55" stroke-width="${p===MM.t?2.4:1.4}"/>`}).join('');
 const nd=nodes.map(n=>{const w=wd(n),dark=n.ctype==='root'||n.branch,lab=n.label.length>40?n.label.slice(0,39)+'…':n.label;
  return `<g data-id="${n.id}" style="cursor:pointer"><title>${esc(n.label+(n.note?'\n'+n.note:''))}</title><rect x="${n.x-w/2}" y="${n.y-11}" width="${w}" height="22" rx="${n.ctype==='root'?11:6}" fill="${dark?col(n):'#fff'}" stroke="${col(n)}" stroke-width="${MM.sel===n.id?3.2:1.4}"/><text x="${n.x}" y="${n.y+4}" text-anchor="middle" font-size="${FS}" font-family="Segoe UI,Arial,sans-serif" fill="${dark?'#fff':'#162033'}">${esc(lab)}</text>${n.kids.length&&n!==MM.t?`<text x="${n.x+(n.x>=0?w/2+9:-w/2-9)}" y="${n.y+4}" text-anchor="middle" font-size="12" fill="${col(n)}" data-tg="1">${n.col?'⊕':'⊖'}</text>`:''}${n.note?`<circle cx="${n.x+w/2-3}" cy="${n.y-11}" r="4" fill="#f59e0b"/>`:''}</g>`}).join('');
 Q('#mmg').innerHTML=e+nd;MM.nodes=nodes;mmSide()}
const bounds=()=>{const ns=MM.nodes;return{x0:Math.min(...ns.map(n=>n.x-wd(n)/2))-40,x1:Math.max(...ns.map(n=>n.x+wd(n)/2))+40,y0:Math.min(...ns.map(n=>n.y))-30,y1:Math.max(...ns.map(n=>n.y))+30}};
const mmApply=()=>Q('#mmg').setAttribute('transform',`translate(${MM.x},${MM.y}) scale(${MM.k})`);
function mmFit(){const b=bounds(),s=Q('#mmstage'),W=s.clientWidth,Hh=s.clientHeight;MM.k=Math.min(W/(b.x1-b.x0),Hh/(b.y1-b.y0),1.4);MM.x=W/2-(b.x0+b.x1)/2*MM.k;MM.y=Hh/2-(b.y0+b.y1)/2*MM.k;mmApply()}
function mmSide(){const n=MM.sel&&mmFind(MM.sel),el=Q('#mmside');if(!n){el.innerHTML='<b>Mind map</b><p>Click a node to select it. ⊕/⊖ expands or collapses a branch. Drag the background to pan and use the wheel to zoom.</p><p>Branches are built from the current search results; add your own nodes and notes, then save or export.</p>';return}
 const can=!!n.term;
 el.innerHTML=`<b>${esc(n.label)}</b><div class="tiny">${esc(n.ctype)}</div>${n.note?`<p>📝 ${esc(n.note)}</p>`:''}<div><button class="ghost" data-a="add">＋ Child</button><button class="ghost" data-a="ren">✎ Rename</button><button class="ghost" data-a="note">📝 Note</button>${n.kids.length?`<button class="ghost" data-a="tog">${n.col?'Expand':'Collapse'}</button>`:''}${n!==MM.t?'<button class="ghost" data-a="del">🗑 Delete</button>':''}${can?'<button class="primary" data-a="srch">⌕ Search this</button><button class="ghost" data-a="sub">Map this topic</button>':''}${n.ctype==='paper'&&n.pi!==undefined?'<button class="primary" data-a="det">Open record</button>':''}</div>`}
function mmSearch(n){const t=n.term;closeModal();state.savedOnly=false;if(typeof clearFilters==='function')clearFilters(true);state.advanced=[];$('#advRows').innerHTML='';addAdvRow();state.query='';
 if(n.ctype==='keyword'||n.ctype==='author')state.query='"'+t+'"';
 else if(n.ctype==='journal'){state.source=String(S.indexOf(t));$('#sourceFilter').value=state.source}
 else if(n.ctype==='publisher'){state.publisher=String(PUB.indexOf(t));$('#publisherFilter').value=state.publisher}
 else if(n.ctype==='country'){state.country=String(CO.indexOf(t));$('#countryFilter').value=state.country}
 else if(n.ctype==='year'){state.yearSet=new Set([+t]);$$('[data-year]').forEach(x=>x.checked=x.dataset.year===t)}
 $('#q').value=state.query;state.page=1;document.body.classList.add('has-search');doSearch();toast('Search: '+t)}
const mdOut=(n,d=0)=>'  '.repeat(d)+'- '+n.label+(n.note?' — '+n.note:'')+'\n'+n.kids.map(c=>mdOut(c,d+1)).join('');
const fmOut=n=>`<node TEXT="${esc(n.label)}">${n.note?`<node TEXT="${esc(n.note)}" COLOR="#b45309"/>`:''}${n.kids.map(fmOut).join('')}</node>`;
function mmSvg(){const b=bounds(),w=b.x1-b.x0,h=b.y1-b.y0;return{w,h,s:`<svg xmlns="http://www.w3.org/2000/svg" viewBox="${b.x0} ${b.y0} ${w} ${h}" width="${w}" height="${h}"><rect x="${b.x0}" y="${b.y0}" width="${w}" height="${h}" fill="#fff"/>${Q('#mmg').innerHTML}</svg>`}}
function mmPng(){const {s,w,h}=mmSvg(),img=new Image(),sc=Math.min(2,8000/Math.max(w,h));img.onload=()=>{const c=document.createElement('canvas');c.width=w*sc;c.height=h*sc;const x=c.getContext('2d');x.scale(sc,sc);x.drawImage(img,0,0,w,h);c.toBlob(b=>{const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download='mindmap.png';a.click()})};img.src='data:image/svg+xml;charset=utf-8,'+encodeURIComponent(s)}
function mmOpen(){
 H('✺ Mind Map',`<div class="row">${SC}${Object.keys(BR).map(b=>`<label><input type="checkbox" class="mmb" value="${b}" ${['keyword','author','journal','year'].includes(b)?'checked':''}> ${BR[b]}</label>`).join('')}<label>Items per branch <input type="number" id="mmper" value="6" min="2" max="25" style="width:60px"></label><label><input type="checkbox" id="mmdeep" checked> Show top papers</label><button class="primary" id="mmgo">Build map</button></div>
 <div class="row"><button class="ghost" id="mmfit">⤢ Fit</button><button class="ghost" id="mmexp">Expand all</button><button class="ghost" id="mmcol">Collapse all</button><button class="ghost" id="mmsave">💾 Save</button><select id="mmload"><option value="">Load saved map…</option>${Object.keys(lsGet('x3Maps',{})).map(k=>`<option>${esc(k)}</option>`).join('')}</select><span class="nav-spacer"></span><button class="ghost" data-x="md">Markdown</button><button class="ghost" data-x="mm">FreeMind</button><button class="ghost" data-x="json">JSON</button><button class="ghost" data-x="svg">SVG</button><button class="ghost" data-x="png">PNG</button></div>
 <div class="mmwrap"><div class="mmstage" id="mmstage"><svg id="mmsvg"><g id="mmg"></g></svg></div><div class="mmside" id="mmside"></div></div>`);
 const build=()=>{MM.id=0;MM.sel=null;MM.t=mmBuild(hits(),QA('.mmb:checked').map(x=>x.value),+Q('#mmper').value||6,Q('#mmdeep').checked);mmDraw();mmFit()};
 Q('#mmgo').onclick=build;if(MM.t){mmDraw();mmFit()}else build();
 const all=(n,v)=>{n.kids.length&&(n.col=v);n.kids.forEach(c=>all(c,v))};
 Q('#mmfit').onclick=mmFit;Q('#mmexp').onclick=()=>{all(MM.t,false);MM.t.col=false;mmDraw();mmFit()};Q('#mmcol').onclick=()=>{MM.t.kids.forEach(c=>all(c,true));mmDraw();mmFit()};
 Q('#mmsave').onclick=()=>{const n=prompt('Name for this mind map');if(!n)return;const m=lsGet('x3Maps',{});m[n]=MM.t;try{localStorage.setItem('x3Maps',JSON.stringify(m));toast('Saved “'+n+'”');mmOpen()}catch{toast('Could not save (storage full)')}};
 Q('#mmload').onchange=e=>{const m=lsGet('x3Maps',{})[e.target.value];if(!m)return;MM.t=m;let mx=0;(function w(n){mx=Math.max(mx,n.id);n.kids.forEach(w)})(m);MM.id=mx;MM.sel=null;mmDraw();mmFit()};
 QA('[data-x]').forEach(b=>b.onclick=()=>{const x=b.dataset.x,nm='mindmap';if(x==='md')download(nm+'.md',mdOut(MM.t),'text/markdown');if(x==='mm')download(nm+'.mm','<map version="1.0.1">'+fmOut(MM.t)+'</map>','application/xml');if(x==='json')download(nm+'.json',JSON.stringify(MM.t,null,1),'application/json');if(x==='svg')download(nm+'.svg',mmSvg().s,'image/svg+xml');if(x==='png')mmPng()});
 const sv=Q('#mmsvg');let drag=null;
 sv.onpointerdown=e=>{if(e.target.closest('[data-id]'))return;drag={x:e.clientX-MM.x,y:e.clientY-MM.y};sv.setPointerCapture(e.pointerId)};
 sv.onpointermove=e=>{if(drag){MM.x=e.clientX-drag.x;MM.y=e.clientY-drag.y;mmApply()}};sv.onpointerup=()=>drag=null;
 sv.onwheel=e=>{e.preventDefault();const r=sv.getBoundingClientRect(),px=e.clientX-r.left,py=e.clientY-r.top,nk=Math.min(3,Math.max(.15,MM.k*(e.deltaY<0?1.12:.89)));MM.x=px-(px-MM.x)*nk/MM.k;MM.y=py-(py-MM.y)*nk/MM.k;MM.k=nk;mmApply()};
 sv.onclick=e=>{const g=e.target.closest('[data-id]');if(!g)return;const n=mmFind(+g.dataset.id);if(e.target.dataset.tg)n.col=!n.col;else MM.sel=n.id;mmDraw()};
 Q('#mmside').onclick=e=>{const a=e.target.dataset.a,n=MM.sel&&mmFind(MM.sel);if(!a||!n)return;
  if(a==='add'){const l=prompt('New node text');if(l){n.kids.push(mn(l,'custom'));n.col=false}}
  if(a==='ren'){const l=prompt('Rename node',n.label);if(l)n.label=l}
  if(a==='note')n.note=prompt('Note',n.note)||'';
  if(a==='tog')n.col=!n.col;
  if(a==='del'&&confirm('Delete this node and everything below it?')){const p=mmParent(n.id);p.kids=p.kids.filter(c=>c!==n);MM.sel=p.id}
  if(a==='det'){detail(n.pi);return}
  if(a==='srch'){mmSearch(n);return}
  if(a==='sub'){MM.id=0;MM.sel=null;MM.t=mmBuild(n.pids.slice(0,300),QA('.mmb:checked').map(x=>x.value).filter(x=>x!==n.ctype),+Q('#mmper').value||6,Q('#mmdeep').checked,n.term);mmDraw();mmFit();return}
  mmDraw()}}

/* =====================  2. SEMANTIC LAYER  ===================== */
const SEM={};
function semIndex(){if(SEM.kw&&SEM.R===R)return SEM.kw;const kw=new Map(),ab=new Map();
 for(let i=0;i<R.length;i++){const seen=new Set();for(const k0 of splitKeywords(R[i][11])){const k=k0.trim(),key=stem(k);if(!key||seen.has(key))continue;seen.add(key);let e=kw.get(key);if(!e)kw.set(key,e={key,alts:new Map(),p:[]});e.p.push(i);e.alts.set(k,(e.alts.get(k)||0)+1);const m=k.match(/\(([A-Za-z][A-Za-z0-9-]{1,9})\)/);if(m)ab.set(stem(m[1]),key)}}
 for(const [a,t] of ab){const A=kw.get(a),T=kw.get(t);if(A&&T&&A!==T){const have=new Set(T.p);A.p.forEach(i=>have.has(i)||T.p.push(i));A.alts.forEach((v,k)=>T.alts.set(k,(T.alts.get(k)||0)+v));kw.delete(a)}else ab.delete(a)}
 kw.forEach(e=>e.label=[...e.alts].sort((a,b)=>b[1]-a[1])[0][0]);SEM.al=ab;SEM.R=R;return SEM.kw=kw}
function semRel(key){const kw=semIndex(),c=kw.get(key);if(!c)return null;if(c.rel)return c.rel;const co=new Map(),P=c.p.slice(0,3000),n=P.length;
 P.forEach(i=>{const seen=new Set();splitKeywords(R[i][11]).forEach(k=>{let kk=stem(k);kk=SEM.al.get(kk)||kk;if(kk!==key&&!seen.has(kk)&&kw.has(kk)){seen.add(kk);co.set(kk,(co.get(kk)||0)+1)}})});
 const rel={broader:[],narrower:[],related:[]};
 co.forEach((v,k)=>{if(v<2)return;const m=kw.get(k).p.length,a=v/n,b=v/m;if(a>=.6&&m>=1.5*n)rel.broader.push([k,v,a]);else if(b>=.6&&n>=1.5*m)rel.narrower.push([k,v,b]);else{const j=v/(n+m-v);if(j>=.03)rel.related.push([k,v,j])}});
 Object.values(rel).forEach(a=>{a.sort((x,y)=>y[2]-x[2]||y[1]-x[1]);a.length=Math.min(a.length,10)});return c.rel=rel}
function semSearch(q){const kw=semIndex(),qs=stem(q),qt=qs.split(' ').filter(Boolean),tk=tokens(q).filter(t=>t.length>2),seeds=[],ex=kw.get(SEM.al.get(qs)||qs);if(ex)seeds.push(ex);
 qt.length&&[...kw.values()].filter(e=>e!==ex&&qt.every(t=>(' '+e.key).includes(' '+t))).sort((a,b)=>b.p.length-a.p.length).slice(0,4).forEach(e=>seeds.push(e));
 const w=new Map(),why=new Map(),exp=[],add=(e,wt,role)=>e.p.forEach(i=>{w.set(i,(w.get(i)||0)+wt);(why.get(i)||why.set(i,new Set()).get(i)).add(e.label+' · '+role)});
 seeds.forEach((e,k)=>{add(e,k?2:3,k?'contains':'concept');if(k<2){const r=semRel(e.key);r.narrower.slice(0,5).forEach(([x])=>{const d=kw.get(x);add(d,1.5,'narrower');exp.push(['narrower',d.label])});r.related.slice(0,5).forEach(([x])=>{const d=kw.get(x);add(d,1,'related');exp.push(['related',d.label])})}});
 if(tk.length)INDEX.forEach((x,i)=>{if(tk.every(t=>x.t.includes(t))){w.set(i,(w.get(i)||0)+2.5);(why.get(i)||why.set(i,new Set()).get(i)).add('title match')}});
 return{seeds,exp,why,out:[...w].map(([i,s])=>[i,s+.15*Math.log1p(R[i][0])]).sort((a,b)=>b[1]-a[1]).slice(0,30)}}
/* query expansion hook used by the main search: keyword variants, abbreviations from the data, and imported synonyms */
window.lisSemExpand=function(phrase){try{const kw=semIndex(),k0=stem(phrase);if(!k0)return[];const key=SEM.al.get(k0)||k0,out=[],e=kw.get(key);
 if(e){[...e.alts.keys()].forEach(l=>out.push({text:l,kind:'variant'}))}
 const sy=lsGet('x4Syn',{}),syn=sy[k0]||sy[key];if(syn)(syn.alts||[]).forEach(l=>out.push({text:l,kind:'synonym'}));return out}catch(err){return[]}};
const ONT=[['Paper','dcterms:creator','Author'],['Paper','schema:isPartOf','Journal'],['Paper','dcterms:publisher','Publisher'],['Paper','dcterms:subject','Concept'],['Paper','dcterms:issued','Year'],['Journal','schema:publisher','Publisher'],['Publisher','schema:location','Country'],['Concept','skos:broader / narrower / related','Concept']];
const ONC={Paper:['schema:ScholarlyArticle','bibo:AcademicArticle'],Author:['foaf:Person'],Journal:['schema:Periodical'],Publisher:['foaf:Organization'],Concept:['skos:Concept'],Country:['schema:Country'],Year:['xsd:gYear']};
function semOv(el){el.innerHTML='<p class="tiny">Building semantic index…</p>';setTimeout(()=>{const au=new Set();R.forEach(r=>splitAuthors(r[1]).forEach(a=>au.add(norm(a))));
 const cnt={Paper:R.length,Author:au.size,Journal:S.length,Publisher:PUB.length,Country:CO.length,Year:new Set(R.map(r=>r[3])).size,Concept:semIndex().size};
 const pos={Paper:[330,130],Author:[80,40],Journal:[330,25],Concept:[580,40],Year:[580,225],Publisher:[80,225],Country:[330,245]};
 const ln=ONT.filter(x=>x[0]!==x[2]).map(([a,p,b])=>{const [x1,y1]=pos[a],[x2,y2]=pos[b];return `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="#94a3b8" stroke-width="1.5"/><text x="${(x1+x2)/2}" y="${(y1+y2)/2-3}" font-size="10" text-anchor="middle" fill="#1f4e8c">${esc(p)}</text>`}).join('');
 const bx=Object.entries(pos).map(([k,[x,y]])=>`<rect x="${x-55}" y="${y-17}" width="110" height="34" rx="8" fill="${k==='Paper'?'#184e77':'#fff'}" stroke="#184e77"/><text x="${x}" y="${y-2}" text-anchor="middle" font-size="12" font-weight="700" fill="${k==='Paper'?'#fff':'#184e77'}">${k}</text><text x="${x}" y="${y+11}" text-anchor="middle" font-size="9.5" fill="${k==='Paper'?'#dbeafe':'#687386'}">${cnt[k].toLocaleString()} instances</text>`).join('');
 el.innerHTML=`<div class="note">The semantic layer models the bibliographic data as an ontology (classes + relations) mapped to Schema.org, Dublin Core, FOAF, BIBO and SKOS. Keywords become SKOS concepts with synonym merging and broader/narrower/related links inferred from co-occurrence.</div><svg viewBox="0 0 660 270" style="width:100%;max-height:300px">${ln}${bx}</svg>
 <table><tr><th>Class</th><th>Mapped to</th><th>Instances</th></tr>${Object.keys(pos).map(k=>`<tr><td><b>${k}</b></td><td>${ONC[k].join(', ')}</td><td>${cnt[k].toLocaleString()}</td></tr>`).join('')}</table>
 <table style="margin-top:10px"><tr><th>Domain</th><th>Property</th><th>Range</th></tr>${ONT.map(r=>`<tr><td>${r[0]}</td><td>${esc(r[1])}</td><td>${r[2]}</td></tr>`).join('')}</table>`},30)}
function semCn(el){el.innerHTML='<div class="row"><input type="text" id="x3cq" placeholder="Find a concept…" size="32"><button class="ghost" id="x3cg">Find</button></div><div id="x3cl"></div><div id="x3cd"></div>';const kw=semIndex();
 const list=q=>{const t=stem(q);Q('#x3cl').innerHTML=[...kw.values()].filter(e=>!t||e.key.includes(t)).sort((x,y)=>y.p.length-x.p.length).slice(0,40).map(e=>`<span class="chip" data-c="${esc(e.key)}">${esc(e.label)} <b>${e.p.length}</b></span>`).join('')||'<span class="tiny">No matching concept</span>'};
 const show=k=>{const e=kw.get(SEM.al.get(k)||k);if(!e)return;const r=semRel(e.key),ch=a=>a.map(([x,v])=>`<span class="chip" data-c="${esc(x)}">${esc(kw.get(x).label)} <small>${v}</small></span>`).join('')||'—';
  Q('#x3cd').innerHTML=`<div class="card"><h3 style="margin:0 0 4px">${esc(e.label)}</h3><div class="tiny">skos:Concept · ${e.p.length} papers</div><p><b>Alternative labels:</b> ${[...e.alts.keys()].filter(a=>a!==e.label).slice(0,8).map(esc).join('; ')||'—'}</p><p><b>Broader</b> ${ch(r.broader)}</p><p><b>Narrower</b> ${ch(r.narrower)}</p><p><b>Related</b> ${ch(r.related)}</p><b>Top cited papers</b><ol>${e.p.slice().sort((a,b)=>R[b][0]-R[a][0]).slice(0,8).map(i=>`<li><a href="#" data-p="${i}">${esc(R[i][2])}</a> <span class="tiny">(${R[i][3]}, ${R[i][0]} cites)</span></li>`).join('')}</ol></div>`};
 Q('#x3cg').onclick=()=>list(Q('#x3cq').value);Q('#x3cq').onkeydown=e=>{if(e.key==='Enter')list(e.target.value)};list('');
 Q('#x3b').onclick=e=>{const c=e.target.closest('[data-c]'),p=e.target.closest('[data-p]');if(c)show(c.dataset.c);if(p){e.preventDefault();detail(+p.dataset.p)}}}
function semSs(el){el.innerHTML='<div class="note">Concept-aware search: your query is matched to concepts, expanded with narrower and related concepts, and records are ranked by how strongly they match.</div><div class="row"><input type="text" id="x3sq" placeholder="e.g. information literacy" size="40" value="'+esc(state.query||'')+'"><button class="primary" id="x3sg">Semantic search</button></div><div id="x3sr"></div>';
 const run=q=>{if(!q.trim())return;const r=semSearch(q);Q('#x3sr').innerHTML=(r.seeds.length?`<p><b>Matched concepts:</b> ${r.seeds.map(e=>`<span class="chip" data-q="${esc(e.label)}">${esc(e.label)} · ${e.p.length}</span>`).join('')}</p>`:'<p class="tiny">No concept matched; using title matches only.</p>')+(r.exp.length?`<p><b>Expanded with:</b> ${r.exp.map(([t,l])=>`<span class="chip" data-q="${esc(l)}">${esc(l)} <small>${t}</small></span>`).join('')}</p>`:'')+`<p class="tiny">${r.out.length} top results</p>`+r.out.map(([i,s])=>`<div class="card"><a href="#" data-p="${i}"><b>${esc(R[i][2])}</b></a><div class="tiny">${esc(R[i][1])} · ${R[i][3]} · ${esc(S[R[i][4]]||'')} · ${R[i][0]} cites · score ${s.toFixed(2)}</div><div>${[...(r.why.get(i)||[])].slice(0,6).map(w=>`<span class="chip">${esc(w)}</span>`).join('')}</div></div>`).join('')};
 Q('#x3sg').onclick=()=>run(Q('#x3sq').value);Q('#x3sq').onkeydown=e=>{if(e.key==='Enter')run(e.target.value)};
 Q('#x3b').onclick=e=>{const c=e.target.closest('[data-q]'),p=e.target.closest('[data-p]');if(c){Q('#x3sq').value=c.dataset.q;run(c.dataset.q)}if(p){e.preventDefault();detail(+p.dataset.p)}}}

/* ---- RDF building blocks (shared by Semantic export and Linked Open Data) ---- */
let BASE=localStorage.getItem('x3Base')||'https://example.org/are/';
const PFX={rdf:'http://www.w3.org/1999/02/22-rdf-syntax-ns#',rdfs:'http://www.w3.org/2000/01/rdf-schema#',owl:'http://www.w3.org/2002/07/owl#',xsd:'http://www.w3.org/2001/XMLSchema#',dcterms:'http://purl.org/dc/terms/',schema:'https://schema.org/',foaf:'http://xmlns.com/foaf/0.1/',bibo:'http://purl.org/ontology/bibo/',skos:'http://www.w3.org/2004/02/skos/core#',prism:'http://prismstandard.org/namespaces/basic/2.0/'};
const pfx=()=>({...PFX,ex:BASE+'ontology#'});
const X=n=>{const m=n.match(/^([a-z]+):(.*)$/),p=m&&pfx()[m[1]];return p&&!/^\/\//.test(m[2])?p+m[2]:n};
const C=iri=>{for(const[k,v]of Object.entries(pfx()))if(iri.startsWith(v)&&/^[\w.-]+$/.test(iri.slice(v.length)))return k+':'+iri.slice(v.length);return '<'+iri+'>'};
const lit=s=>'"'+String(s).replace(/\\/g,'\\\\').replace(/"/g,'\\"').replace(/\r?\n/g,'\\n')+'"';
const PFXT=()=>Object.entries(pfx()).map(([k,v])=>`@prefix ${k}: <${v}> .`).join('\n')+'\n\n';
const cid=k=>BASE+'concept/'+slug(k);
function ontTtl(){let t=PFXT()+`<${BASE}ontology> a owl:Ontology ; rdfs:label "Academic Research Explorer bibliographic ontology" .\n\n`;
 Object.entries(ONC).forEach(([c,sup])=>t+=`ex:${c} a owl:Class ; rdfs:label ${lit(c)} ; rdfs:subClassOf ${sup.join(', ')} .\n`);
 const P={Author:'creator',Journal:'isPartOf',Publisher:'publisher',Concept:'subject',Year:'issued',Country:'location'},M={creator:'dcterms:creator',isPartOf:'schema:isPartOf',publisher:'dcterms:publisher',subject:'dcterms:subject',issued:'dcterms:issued',location:'schema:location'};
 ONT.filter(r=>M[P[r[2]]]&&r[1]===M[P[r[2]]]).forEach(([a,p,b])=>t+=`ex:has${b} a owl:ObjectProperty ; rdfs:subPropertyOf ${p} ; rdfs:domain ex:${a} ; rdfs:range ex:${b} .\n`);
 return t}
function skosTtl(N=150){const kw=semIndex(),top=[...kw.values()].sort((a,b)=>b.p.length-a.p.length).slice(0,N);let t=PFXT()+`<${BASE}scheme> a skos:ConceptScheme ; dcterms:title "Keyword concept scheme" .\n\n`;
 top.forEach(e=>{const r=semRel(e.key),L=(a,p)=>a.slice(0,5).map(([k])=>` skos:${p} <${cid(k)}> ;`).join('');t+=`<${cid(e.key)}> a skos:Concept ; skos:inScheme <${BASE}scheme> ; skos:prefLabel ${lit(e.label)} ;`+[...e.alts.keys()].filter(a=>a!==e.label).slice(0,6).map(a=>` skos:altLabel ${lit(a)} ;`).join('')+L(r.broader,'broader')+L(r.narrower,'narrower')+L(r.related,'related')+` rdfs:comment ${lit(e.p.length+' papers')} .\n`});return t}
function semEx(el){el.innerHTML='<div class="note">Download the ontology or the SKOS concept scheme (top 150 concepts with synonyms and broader/narrower/related links) as Turtle. Load them into GraphDB, Protégé or any triple store.</div><div class="row"><button class="primary" id="x3o">⇩ Ontology (.ttl)</button><button class="primary" id="x3k">⇩ SKOS concepts (.ttl)</button></div>';Q('#x3o').onclick=()=>download('ontology.ttl',ontTtl(),'text/turtle');Q('#x3k').onclick=()=>{toast('Building concept scheme…');setTimeout(()=>download('skos-concepts.ttl',skosTtl(),'text/turtle'),30)}}
/* ---- Research Productivity, Research Impact, Performance Indicators (computed from every record) ---- */
const RPX={};
function rpxBase(){
  if(RPX.R===R&&RPX.d)return RPX.d;
  const years=new Map(),authors=new Map(),journals=new Map(),cites=[];
  let multi=0,auTot=0,doi=0,abs=0,kw=0,url=0,cty=0;
  for(let i=0;i<R.length;i++){
    const r=R[i],y=+r[3]||0,c=+r[0]||0,au=splitAuthors(r[1]),ks=splitKeywords(r[11]),j=S[r[4]]||'';
    cites.push(c);auTot+=au.length;if(au.length>=2)multi++;
    if(r[9])doi++;if(r[12])abs++;if(ks.length)kw++;if(r[8])url++;if(CO[r[7]])cty++;
    if(y){let e=years.get(y);if(!e)years.set(y,e={n:0,c:0,multi:0,au:0});e.n++;e.c+=c;e.au+=au.length;if(au.length>=2)e.multi++}
    const seen=new Set();
    au.forEach(a=>{const k=norm(a);if(!k||seen.has(k))return;seen.add(k);let e=authors.get(k);if(!e)authors.set(k,e={name:a,n:0,c:0});e.n++;e.c+=c});
    if(j){let e=journals.get(j);if(!e)journals.set(j,e={name:j,n:0,c:0});e.n++;e.c+=c}
  }
  cites.sort((a,b)=>b-a);
  RPX.R=R;RPX.d={years,authors,journals,cites,multi,auTot,doi,abs,kw,url,cty,N:R.length};
  return RPX.d;
}
const rpxN=n=>Number(n||0).toLocaleString();
const rpxP=(x,d=1)=>(x==null||!isFinite(x))?'n/a':(100*x).toFixed(d)+'%';
const rpxD=(x,d=2)=>(x==null||!isFinite(x))?'n/a':Number(x).toFixed(d);
function rpxH(c){let h=0;for(let k=0;k<c.length;k++){if(c[k]>=k+1)h=k+1;else break}return h}
function rpxG(c){let s=0,g=0;for(let k=0;k<c.length;k++){s+=c[k];if(s>=(k+1)*(k+1))g=k+1}return g}
function rpxCSS(){if(!document.getElementById('rpxCss')){const s=document.createElement('style');s.id='rpxCss';s.textContent='.rpx-kpi{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:8px;margin:10px 0}.rpx-kpi div{border:1px solid var(--line);border-radius:10px;padding:9px 11px;background:#fff}.rpx-kpi b{display:block;font-size:19px;color:var(--brand)}.rpx-kpi span{font-size:12px;color:var(--muted)}.rpx-row{display:grid;grid-template-columns:110px 1fr 150px;gap:8px;align-items:center;font-size:12.5px;margin:3px 0}.rpx-row i{display:block;height:10px;border-radius:5px;background:var(--brand2)}.rpx-row b{font-weight:600;white-space:nowrap}.x3 h4{margin:14px 0 6px}';document.head.appendChild(s)}return ''}
function rpxBars(rows){const mx=Math.max(1,...rows.map(r=>r.v));return `<div>${rows.map(r=>`<div class="rpx-row"><span>${esc(r.l)}</span><i style="width:${(100*r.v/mx).toFixed(1)}%"></i><b>${rpxN(r.v)}${r.p!=null?' · '+rpxP(r.p):''}</b></div>`).join('')}</div>`}
function rpProd(el){
  rpxCSS();const B=rpxBase(),N=B.N,ys=[...B.years.keys()].sort((a,b)=>a-b);
  const first=ys[0],last=ys[ys.length-1],span=last-first;
  const yr=ys.map((y,k)=>{const e=B.years.get(y),pv=k?B.years.get(ys[k-1]).n:null;return{y,n:e.n,share:e.n/N,cum:0,yoy:pv?(e.n-pv)/pv:null,multi:e.n?e.multi/e.n:null}});
  let cum=0;yr.forEach(r=>{cum+=r.n;r.cum=cum});
  const peak=yr.reduce((a,b)=>b.n>a.n?b:a,yr[0]||{n:0,y:'n/a'});
  const cagr=(span>0&&B.years.get(first).n>0)?Math.pow(B.years.get(last).n/B.years.get(first).n,1/span)-1:null;
  const nA=B.authors.size,perA=nA?[...B.authors.values()].reduce((s,e)=>s+e.n,0)/nA:null;
  const topA=[...B.authors.values()].sort((a,b)=>b.n-a.n||b.c-a.c||a.name.localeCompare(b.name)).slice(0,15);
  const topJ=[...B.journals.values()].sort((a,b)=>b.n-a.n||a.name.localeCompare(b.name)).slice(0,10);
  const kp=[[rpxN(N),'Papers'],[ys.length?first+'–'+last:'n/a','Publication years'],[rpxD(ys.length?N/ys.length:null,0),'Mean papers per year'],
    [peak.y+' ('+rpxN(peak.n)+')','Peak year'],[rpxP(yr.length>1?yr[yr.length-1].yoy:null),'Change, last year vs previous'],
    [rpxP(cagr),'Compound annual growth'],[rpxN(nA),'Distinct authors'],[rpxD(B.auTot/N,2),'Authors per paper'],
    [rpxP(B.multi/N),'Multi-authored papers'],[rpxD(perA,2),'Papers per author'],[rpxN(B.journals.size),'Distinct journals']];
  el.innerHTML=`<div class="note">Research output in this dataset: papers per year, who publishes, and where. Counts describe the records only; they do not measure funding, quality or effort.</div>
  <div class="rpx-kpi">${kp.map(([v,l])=>`<div><b>${v}</b><span>${l}</span></div>`).join('')}</div>
  <h4>Output by year</h4>${rpxBars(yr.map(r=>({l:String(r.y),v:r.n,p:r.share})))}
  <table><tr><th>Year</th><th>Papers</th><th>Share</th><th>Cumulative</th><th>Change vs previous year</th><th>Multi-authored</th></tr>
  ${yr.map(r=>`<tr><td>${r.y}</td><td>${rpxN(r.n)}</td><td>${rpxP(r.share)}</td><td>${rpxN(r.cum)}</td><td>${rpxP(r.yoy)}</td><td>${rpxP(r.multi)}</td></tr>`).join('')}</table>
  <h4>Most productive authors (top 15, by papers)</h4>
  <table><tr><th>Author</th><th>Papers</th><th>Citations</th></tr>${topA.map(a=>`<tr><td>${esc(a.name)}</td><td>${rpxN(a.n)}</td><td>${rpxN(a.c)}</td></tr>`).join('')}</table>
  <h4>Most productive journals (top 10)</h4>
  <table><tr><th>Journal</th><th>Papers</th><th>Share of papers</th></tr>${topJ.map(j=>`<tr><td>${esc(j.name)}</td><td>${rpxN(j.n)}</td><td>${rpxP(j.n/N)}</td></tr>`).join('')}</table>`;
  el.onclick=null;
}
function rpImpact(el){
  rpxCSS();const B=rpxBase(),N=B.N,c=B.cites,n=c.length;
  const total=c.reduce((s,x)=>s+x,0),mean=n?total/n:null,median=n?(n%2?c[(n-1)/2]:(c[n/2-1]+c[n/2])/2):null;
  const h=rpxH(c),g=rpxG(c),thr=n?c[Math.floor(n*.1)]:null,topN=c.filter(x=>x>=thr&&x>0).length,unc=c.filter(x=>x===0).length;
  const buckets=[['0',0,0],['1 to 4',1,4],['5 to 9',5,9],['10 to 24',10,24],['25 to 49',25,49],['50 to 99',50,99],['100 or more',100,Infinity]].map(([l,a,b])=>({l,v:c.filter(x=>x>=a&&x<=b).length,p:n?c.filter(x=>x>=a&&x<=b).length/n:null}));
  const ys=[...B.years.keys()].sort((a,b)=>a-b);
  const yrRows=ys.map(y=>{const e=B.years.get(y);return{y,n:e.n,mean:e.c/e.n}});
  const topIdx=[...Array(R.length).keys()].sort((a,b)=>R[b][0]-R[a][0]||a-b).slice(0,10);
  const jr=[...B.journals.values()].filter(j=>j.n>=10).map(j=>({name:j.name,n:j.n,mean:j.c/j.n,c:j.c})).sort((a,b)=>b.mean-a.mean||a.name.localeCompare(b.name)).slice(0,10);
  el.innerHTML=`<div class="note">Citation counts are a snapshot of the dataset. Older papers have had more time to accumulate citations, so compare years and journals with care.</div>
  <div class="rpx-kpi">${[[rpxN(total),'Total citations'],[rpxD(mean,1),'Mean citations per paper'],[rpxN(median),'Median citations'],[rpxN(R.reduce((m,r)=>Math.max(m,r[0]||0),0)),'Maximum citations'],
   [rpxN(h),'h-index (collection)'],[rpxN(g),'g-index (collection)'],[rpxP(unc/N),'Uncited papers'],[rpxN(topN),'Papers in top 10% (≥ '+rpxN(thr)+' citations)']]
   .map(([v,l])=>`<div><b>${v}</b><span>${l}</span></div>`).join('')}</div>
  <h4>Citation distribution</h4>${rpxBars(buckets)}
  <h4>Mean citations by publication year</h4>
  <table><tr><th>Year</th><th>Papers</th><th>Mean citations</th></tr>${yrRows.map(r=>`<tr><td>${r.y}</td><td>${rpxN(r.n)}</td><td>${rpxD(r.mean,1)}</td></tr>`).join('')}</table>
  <h4>Most cited papers (top 10)</h4>
  <table><tr><th>Title</th><th>Year</th><th>Journal</th><th>Citations</th></tr>${topIdx.map(i=>`<tr><td><button class="ghost" type="button" data-p="${i}">${esc(R[i][2]||'Untitled')}</button></td><td>${R[i][3]||'n/a'}</td><td>${esc(S[R[i][4]]||'')}</td><td>${rpxN(R[i][0])}</td></tr>`).join('')}</table>
  <h4>Journals by mean citations (at least 10 papers, top 10)</h4>
  <table><tr><th>Journal</th><th>Papers</th><th>Mean citations</th><th>Total citations</th></tr>${jr.map(j=>`<tr><td>${esc(j.name)}</td><td>${rpxN(j.n)}</td><td>${rpxD(j.mean,1)}</td><td>${rpxN(j.c)}</td></tr>`).join('')||'<tr><td colspan="4">No journal has 10 or more papers.</td></tr>'}</table>`;
  el.onclick=e=>{const p=e.target.closest('[data-p]');if(p){e.preventDefault();detail(+p.dataset.p)}};
}
function rpPerf(el){
  rpxCSS();const B=rpxBase(),N=B.N,ys=[...B.years.keys()].sort((a,b)=>a-b),first=ys[0],last=ys[ys.length-1],span=last-first;
  const c=B.cites,mean=N?c.reduce((s,x)=>s+x,0)/N:null,median=N?(N%2?c[(N-1)/2]:(c[N/2-1]+c[N/2])/2):null;
  const cagr=(span>0&&B.years.get(first).n>0)?Math.pow(B.years.get(last).n/B.years.get(first).n,1/span)-1:null;
  const hhi=[...B.journals.values()].reduce((s,j)=>s+Math.pow(j.n/N,2),0);
  const perA=B.authors.size?[...B.authors.values()].reduce((s,e)=>s+e.n,0)/B.authors.size:null;
  const rows=[
    ['Productivity','Papers',rpxN(N),'Records in the dataset'],
    ['Productivity','Mean papers per year',rpxD(N/ys.length,0),'Papers ÷ number of years'],
    ['Productivity','Compound annual growth',rpxP(cagr),'(last year ÷ first year)^(1 ÷ span) − 1'],
    ['Collaboration','Authors per paper',rpxD(B.auTot/N,2),'Author–paper links ÷ papers'],
    ['Collaboration','Multi-authored share',rpxP(B.multi/N),'Papers with at least 2 authors ÷ papers'],
    ['Collaboration','Papers per author',rpxD(perA,2),'Author–paper links ÷ distinct authors'],
    ['Impact','Mean citations',rpxD(mean,1),'Total citations ÷ papers'],
    ['Impact','Median citations',rpxN(median),'Middle citation count'],
    ['Impact','h-index',rpxN(rpxH(c)),'Largest h with h papers each cited ≥ h times'],
    ['Impact','g-index',rpxN(rpxG(c)),'Largest g with the top g papers totalling ≥ g² citations'],
    ['Diversity','Distinct journals',rpxN(B.journals.size),'Distinct non-blank journal names'],
    ['Diversity','Distinct countries',rpxN(new Set(R.map(r=>CO[r[7]]).filter(Boolean)).size),'Distinct non-blank countries'],
    ['Diversity','Journal concentration (HHI)',rpxD(hhi,3),'Σ (journal share)²; near 0 = spread out, 1 = one journal']];
  const comp=[['DOI',B.doi],['Abstract',B.abs],['Keywords',B.kw],['Article link',B.url],['Country',B.cty]];
  el.innerHTML=`<div class="note">Indicators computed from every record in the dataset. They describe this collection only. They are not normalised by field or age and are not benchmarks.</div>
  <table><tr><th>Area</th><th>Indicator</th><th>Value</th><th>How it is calculated</th></tr>${rows.map(r=>`<tr><td>${r[0]}</td><td>${r[1]}</td><td><b>${r[2]}</b></td><td>${esc(r[3])}</td></tr>`).join('')}</table>
  <h4>Data completeness</h4>${rpxBars(comp.map(([l,v])=>({l,v,p:v/N})))}
  <p class="tiny">Share shown after each count is the fraction of all ${rpxN(N)} records that have that field. Missing fields are not counted as zero in any other indicator.</p>`;
  el.onclick=null;
}

const semOpen=s=>tabbed('◈ Semantic Layer',[['ov','Ontology'],['cn','Concepts (SKOS)'],['ss','Semantic search'],['tg','Semantic tags'],['pr','Research Productivity'],['ri','Research Impact'],['pi','Performance Indicators'],['im','Import'],['bc','⛓ Blockchain'],['ex','Export'],...(window.X5?X5.tabs:[])],(k,el)=>k.startsWith('x5')?window.X5.render(k,el):({ov:semOv,cn:semCn,ss:semSs,tg:semTags,pr:rpProd,ri:rpImpact,pi:rpPerf,im:semIm,bc:semBc,ex:semEx})[k](el),s);

/* =====================  3. LINKED OPEN DATA  ===================== */
const lk=()=>lsGet('x3Links',{}),setLk=o=>{try{localStorage.setItem('x3Links',JSON.stringify(o))}catch{toast('Could not store links')}};
const J=u=>onlineFetchJson(u,{timeout:10000,headers:{Accept:'application/json'}}),strip=s=>String(s||'').replace(/<[^>]+>/g,'');
const oa=t=>async q=>((await J('https://api.openalex.org/'+t+'?per-page=5&search='+encodeURIComponent(q))).results||[]).map(x=>({src:'OpenAlex',uri:x.id,label:x.display_name,desc:strip(x.description||x.orcid||x.issn_l||x.host_organization_name||'')}));
const wdS=async q=>((await J('https://www.wikidata.org/w/api.php?action=wbsearchentities&format=json&language=en&origin=*&limit=5&search='+encodeURIComponent(q))).search||[]).map(x=>({src:'Wikidata',uri:x.concepturi||'http://www.wikidata.org/entity/'+x.id,label:x.label,desc:x.description||''}));
const dbS=async q=>((await J('https://lookup.dbpedia.org/api/search?format=json&maxResults=5&query='+encodeURIComponent(q))).docs||[]).map(x=>({src:'DBpedia',uri:[].concat(x.resource)[0],label:strip([].concat(x.label)[0]),desc:strip([].concat(x.comment||'')[0]).slice(0,160)}));
const SRC={keyword:[wdS,dbS,oa('topics')],author:[oa('authors'),wdS],journal:[oa('sources'),wdS],publisher:[oa('publishers'),wdS],country:[wdS,dbS]};
async function lodFind(type,q){const r=await Promise.allSettled(SRC[type].map(f=>f(q)));return{items:r.flatMap(x=>x.status==='fulfilled'?x.value:[]).filter(x=>x.uri),err:r.filter(x=>x.status==='rejected').length}}
const onl=()=>`<div class="note">${navigator.onLine?'🌐 Online: Wikidata, DBpedia and OpenAlex are used.':'⚠ Offline: linking and SPARQL need internet. Saved links and RDF export still work.'}</div>`;
const TYPES=['keyword','author','journal','publisher','country'];
function lodRec(el){el.innerHTML=onl()+`<div class="row"><label>Entity type <select id="x3t">${TYPES.map(t=>`<option>${t}</option>`).join('')}</select></label>${SC}<button class="primary" id="x3auto">Auto-link first 10</button></div><div id="x3rl"></div>`;
 const draw=()=>{const type=Q('#x3t').value,m=new Map(),L=lk();hits().forEach(i=>{const o=recObj(i);({keyword:splitKeywords(o.keywords),author:splitAuthors(o.authors),journal:[o.source],publisher:[o.publisher],country:[o.country]})[type].forEach(l=>{l=(l||'').trim();if(!l)return;const k=norm(l),e=m.get(k)||{l,n:0};e.n++;m.set(k,e)})});
  Q('#x3rl').innerHTML='<table><tr><th>Label</th><th>Papers</th><th>Linked open data URI</th><th></th></tr>'+[...m.values()].sort((a,b)=>b.n-a.n).slice(0,25).map(e=>{const k=type+'|'+norm(e.l),x=L[k];return `<tr data-k="${esc(k)}" data-l="${esc(e.l)}"><td>${esc(e.l)}</td><td>${e.n}</td><td>${x?`<a href="${esc(safeUrl(x.uri))}" target="_blank" rel="noopener">${esc(x.src)}: ${esc(x.label)}</a>`:'—'}</td><td><button class="ghost" data-f="1">${x?'Re-link':'Find'}</button></td></tr><tr><td colspan="4"></td></tr>`}).join('')+'</table>'};
 Q('#x3t').onchange=draw;Q('#x3n').onchange=draw;draw();
 Q('#x3rl').onclick=async e=>{if(e.target.dataset.f){const tr=e.target.closest('tr'),box=tr.nextElementSibling.firstChild;box.textContent='Searching…';const r=await lodFind(Q('#x3t').value,tr.dataset.l);tr.cand=r.items;box.innerHTML=r.items.map((c,j)=>`<div><button class="ghost" data-a="${j}">Accept</button> <b>${esc(c.src)}</b> ${esc(c.label)} <span class="tiny">${esc(c.desc)}</span></div>`).join('')||`<span class="bad">No candidates${r.err?' ('+r.err+' source(s) unreachable)':''}</span>`}
  else if(e.target.dataset.a!==undefined){const p=e.target.closest('tr').previousElementSibling,L=lk();L[p.dataset.k]=p.cand[+e.target.dataset.a];setLk(L);draw();toast('Link saved')}};
 Q('#x3auto').onclick=async()=>{let n=0;for(const tr of QA('#x3rl tr[data-k]').slice(0,10)){if(lk()[tr.dataset.k])continue;const r=await lodFind(Q('#x3t').value,tr.dataset.l),c=r.items.find(x=>norm(x.label)===norm(tr.dataset.l));if(c){const L=lk();L[tr.dataset.k]=c;setLk(L);n++}toast('Auto-linked '+n)}draw()}}
function lodLinked(el){const L=lk(),ks=Object.keys(L);el.innerHTML=`<div class="row"><b>${ks.length} saved link(s)</b><button class="ghost" id="x3lj">⇩ JSON</button><button class="ghost" id="x3lc">Clear all</button></div><table><tr><th>Type</th><th>Entity</th><th>Linked to</th><th></th></tr>${ks.map(k=>`<tr><td>${esc(k.split('|')[0])}</td><td>${esc(k.split('|').slice(1).join('|'))}</td><td><a href="${esc(safeUrl(L[k].uri))}" target="_blank" rel="noopener">${esc(L[k].src)}: ${esc(L[k].label)}</a></td><td><button class="ghost" data-d="${esc(k)}">✕</button></td></tr>`).join('')||'<tr><td colspan="4" class="tiny">No links yet. Use the Reconcile tab.</td></tr>'}</table>`;
 Q('#x3lj').onclick=()=>download('linked-entities.json',JSON.stringify(L,null,1),'application/json');Q('#x3lc').onclick=()=>{if(confirm('Remove all saved links?')){setLk({});lodLinked(el)}};
 el.onclick=e=>{const d=e.target.dataset.d;if(d){const M=lk();delete M[d];setLk(M);lodLinked(el)}}}
function lodSparql(el){const L=lk(),wd=Object.values(L).filter(x=>/wikidata\.org\/entity\/Q\d+$/.test(x.uri)).map(x=>'wd:'+x.uri.split('/').pop()),db=Object.values(L).filter(x=>/dbpedia\.org\/resource\//.test(x.uri)).map(x=>'<'+x.uri+'>');
 const gd=(typeof DB_DEFAULTS!=='undefined'&&DB_DEFAULTS.graphRepo)||'http://localhost:7200/repositories/library';
 const EP={wikidata:'https://query.wikidata.org/sparql',dbpedia:'https://dbpedia.org/sparql',graphdb:gd},
 PR={wd:`PREFIX wd: <http://www.wikidata.org/entity/>\nPREFIX schema: <http://schema.org/>\nSELECT ?item ?itemLabel ?itemDescription ?article WHERE {\n  VALUES ?item { ${wd.join(' ')||'wd:Q5'} }\n  OPTIONAL { ?article schema:about ?item ; schema:isPartOf <https://en.wikipedia.org/> }\n  SERVICE wikibase:label { bd:serviceParam wikibase:language "en". }\n}`,db:`PREFIX dbo: <http://dbpedia.org/ontology/>\nSELECT ?s ?abstract WHERE {\n  VALUES ?s { ${db.join(' ')||'<http://dbpedia.org/resource/Library>'} }\n  ?s dbo:abstract ?abstract . FILTER(lang(?abstract)='en')\n}`,gd:`SELECT ?type (COUNT(*) AS ?n) WHERE { ?s a ?type } GROUP BY ?type ORDER BY DESC(?n)`};
 el.innerHTML=onl()+`<div class="row"><label>Endpoint <select id="x3ep"><option value="wikidata">Wikidata</option><option value="dbpedia">DBpedia</option><option value="graphdb">My GraphDB (${esc(gd)})</option></select></label><button class="ghost" data-p="wd">Preset: describe linked Wikidata items</button><button class="ghost" data-p="db">Preset: DBpedia abstracts</button><button class="ghost" data-p="gd">Preset: GraphDB class counts</button></div><textarea id="x3sq" rows="8">${esc(PR.wd)}</textarea><div class="row"><button class="primary" id="x3run">▶ Run query</button><span class="tiny" id="x3st"></span></div><div id="x3res" style="overflow:auto"></div>`;
 el.querySelectorAll('[data-p]').forEach(b=>b.onclick=()=>{Q('#x3sq').value=PR[b.dataset.p];Q('#x3ep').value={wd:'wikidata',db:'dbpedia',gd:'graphdb'}[b.dataset.p]});
 Q('#x3run').onclick=async()=>{const ep=Q('#x3ep').value,u=EP[ep]+(EP[ep].includes('?')?'&':'?')+(ep==='wikidata'?'format=json&':'')+'query='+encodeURIComponent(Q('#x3sq').value);Q('#x3st').textContent='Running…';
  try{const r=await onlineFetchJson(u,{timeout:25000,headers:{Accept:'application/sparql-results+json'}}),v=r.head?.vars||[],b=r.results?.bindings||[];Q('#x3st').textContent=b.length+' row(s)';
   Q('#x3res').innerHTML=`<table><tr>${v.map(x=>`<th>${esc(x)}</th>`).join('')}</tr>${b.map(row=>`<tr>${v.map(x=>{const c=row[x];if(!c)return '<td></td>';const s=safeUrl(c.value);return `<td>${s?`<a href="${esc(s)}" target="_blank" rel="noopener">${esc(c.value.length>60?'…'+c.value.slice(-50):c.value)}</a>`:esc(c.value.slice(0,300))}</td>`}).join('')}</tr>`).join('')}</table>`}
  catch(e){Q('#x3st').innerHTML='<span class="bad">'+esc(e.message||e)+' — check internet/endpoint/CORS</span>'}}}
function triples(ix,abs){const T=[],L=lk(),seen=new Set(),t=(s,p,o,ty,dt)=>T.push([s,X(p),ty==='i'?X(o):o,ty,dt&&X(dt)]),once=(u,f)=>{if(!seen.has(u)){seen.add(u);f()}},link=(type,label,u)=>{const m=L[type+'|'+norm(label)];if(m)t(u,type==='keyword'?'skos:exactMatch':'owl:sameAs',m.uri,'i')};
 ix.forEach(i=>{const o=recObj(i),doi=(o.doi||'').replace(/^https?:\/\/(dx\.)?doi\.org\//i,'').trim(),pu=doi?'https://doi.org/'+doi:BASE+'paper/'+i;
  ['schema:ScholarlyArticle','bibo:AcademicArticle','ex:Paper'].forEach(c=>t(pu,'rdf:type',c,'i'));t(pu,'dcterms:title',o.title,'l');
  if(o.year)t(pu,'dcterms:issued',String(o.year),'l','xsd:gYear');if(doi)t(pu,'prism:doi',doi,'l');{const pl=L['paper|'+norm(o.title)];if(pl)t(pu,'owl:sameAs',pl.uri,'i')}if(safeUrl(o.url))t(pu,'schema:url',safeUrl(o.url),'i');t(pu,'ex:citedByCount',String(o.cites||0),'l','xsd:integer');if(abs&&o.abstract)t(pu,'dcterms:abstract',o.abstract,'l');
  splitAuthors(o.authors).forEach(a=>{const u=BASE+'author/'+slug(a);t(pu,'dcterms:creator',u,'i');once(u,()=>{t(u,'rdf:type','foaf:Person','i');t(u,'foaf:name',a,'l');link('author',a,u)})});
  let ju=null;if(o.source){ju=(o.issn&&/\d{4}-?\d{3}[\dXx]/.test(o.issn))?'urn:issn:'+o.issn.match(/\d{4}-?\d{3}[\dXx]/)[0].replace(/^(\d{4})(\d)/,'$1-$2'):BASE+'journal/'+slug(o.source);t(pu,'schema:isPartOf',ju,'i');once(ju,()=>{t(ju,'rdf:type','schema:Periodical','i');t(ju,'dcterms:title',o.source,'l');link('journal',o.source,ju)})}
  if(o.publisher){const u=BASE+'publisher/'+slug(o.publisher);t(pu,'dcterms:publisher',u,'i');once(u,()=>{t(u,'rdf:type','foaf:Organization','i');t(u,'foaf:name',o.publisher,'l');link('publisher',o.publisher,u);if(o.country){const cu=BASE+'country/'+slug(o.country);t(u,'schema:location',cu,'i');once(cu,()=>{t(cu,'rdf:type','schema:Country','i');t(cu,'schema:name',o.country,'l');link('country',o.country,cu)})}})}
  splitKeywords(o.keywords).forEach(k=>{k=k.trim();const key=stem(k);if(!key)return;const u=cid(key);t(pu,'dcterms:subject',u,'i');once(u,()=>{t(u,'rdf:type','skos:Concept','i');t(u,'skos:prefLabel',k,'l');link('keyword',k,u)})})});return T}
const oStr=(o,full)=>o[3]==='i'?(full?'<'+o[2]+'>':C(o[2])):lit(o[2])+(o[4]?'^^'+(full?'<'+o[4]+'>':C(o[4])):'');
function serialize(T,f){if(f==='nt')return T.map(x=>`<${x[0]}> <${x[1]}> ${oStr(x,1)} .`).join('\n');
 if(f==='jsonld'){const g=new Map();T.forEach(([s,p,o,ty,dt])=>{let n=g.get(s);if(!n)g.set(s,n={'@id':s});if(p===PFX.rdf+'type')(n['@type']=n['@type']||[]).push(o);else(n[p]=n[p]||[]).push(ty==='i'?{'@id':o}:dt?{'@value':o,'@type':dt}:o)});return JSON.stringify({'@context':pfx(),'@graph':[...g.values()]},null,1)}
 const g=new Map();T.forEach(x=>(g.get(x[0])||g.set(x[0],[]).get(x[0])).push(x));let s=PFXT();g.forEach((a,k)=>{s+=C(k)+'\n'+a.map(x=>'    '+(x[1]===PFX.rdf+'type'?'a':C(x[1]))+' '+oStr(x)).join(' ;\n')+' .\n\n'});return s}
function lodExp(el){el.innerHTML=`<div class="note">Exports the scoped records as Linked Data (Schema.org, Dublin Core, FOAF, BIBO, SKOS, PRISM). DOIs become real URIs, ISSNs become urn:issn: URIs, and entities you linked in the Reconcile tab are added as owl:sameAs / skos:exactMatch.</div>
 <div class="row">${SC}<label>Format <select id="x3f"><option value="ttl">Turtle</option><option value="jsonld">JSON-LD</option><option value="nt">N-Triples</option></select></label><label><input type="checkbox" id="x3ab"> include abstracts</label></div>
 <div class="row"><label>Base URI for new entities <input type="text" id="x3base" size="34" value="${esc(BASE)}"></label></div>
 <div class="row"><button class="ghost" id="x3pv">Preview</button><button class="primary" id="x3dl">⇩ Download</button><button class="ghost" id="x3cp">Copy</button><button class="ghost" id="x3gd">⬆ Push to GraphDB</button><span class="tiny" id="x3info"></span></div><textarea id="x3out" rows="14" readonly placeholder="Preview appears here"></textarea>`;
 const gen=()=>{BASE=Q('#x3base').value.trim().replace(/\/?$/,'/')||BASE;try{localStorage.setItem('x3Base',BASE)}catch{}const T=triples(hits(),Q('#x3ab').checked),f=Q('#x3f').value,s=serialize(T,f);Q('#x3info').textContent=T.length.toLocaleString()+' triples';return{s,f}};
 Q('#x3pv').onclick=()=>{const {s}=gen();Q('#x3out').value=s.length>20000?s.slice(0,20000)+'\n# … preview truncated; download for the full file':s};
 Q('#x3dl').onclick=()=>{const {s,f}=gen();download('research-linked-data.'+({ttl:'ttl',jsonld:'jsonld',nt:'nt'})[f],s,{ttl:'text/turtle',jsonld:'application/ld+json',nt:'application/n-triples'}[f])};
 Q('#x3cp').onclick=async()=>{try{await navigator.clipboard.writeText(gen().s);toast('Copied')}catch{toast('Copy failed — use Download')}};
 Q('#x3gd').onclick=async()=>{const gd=(typeof DB_DEFAULTS!=='undefined'&&DB_DEFAULTS.graphRepo)||'http://localhost:7200/repositories/library';BASE=Q('#x3base').value.trim().replace(/\/?$/,'/')||BASE;const body=serialize(triples(hits(),Q('#x3ab').checked),'ttl');try{const r=await fetch(gd.replace(/\/$/,'')+'/statements',{method:'POST',headers:{'Content-Type':'text/turtle'},body});if(!r.ok)throw new Error(r.status+' '+r.statusText);toast('Pushed to GraphDB')}catch(e){toast('GraphDB push failed: '+(e.message||e))}}}
const lodOpen=s=>tabbed('🔗 Linked Open Data',[['uri','Open Data URI'],['rec','Reconcile'],['lnk','Linked entities'],['sq','SPARQL'],['ex','Export RDF']],(k,el)=>({uri:lodUri,rec:lodRec,lnk:lodLinked,sq:lodSparql,ex:lodExp})[k](el),s);

/* ===== X4 additions: AI Search, extended Research Gap Finder (+), Semantic tags / Import / Blockchain, Open Data URI tab ===== */
const st4=document.createElement('style');st4.textContent=`
.x3 .badge4{margin-right:4px;display:inline-block;border-radius:999px;padding:2px 10px;font-size:11.5px;font-weight:700;background:#eaf0fb;color:#1f4e8c;margin-left:8px;vertical-align:middle}
.x3 .badge4.ok{background:#e6f6ee;color:#0f6b46}.x3 .badge4.warn{background:#fff4e0;color:#8a5a00}.x3 .badge4.bad{background:#fdeeee;color:#a12b2b}
.x3 .tag4{display:inline-block;border-radius:6px;padding:1px 7px;font-size:11.5px;margin:2px 3px 2px 0;border:1px solid var(--line);background:#f6f8fb;cursor:pointer}
.x3 .tag4 small{opacity:.65;margin-left:3px}
.x3 .tag4.f-Topic{background:#eaf0fb}.x3 .tag4.f-Method{background:#e6f6ee}.x3 .tag4.f-Design{background:#f1ecfa}.x3 .tag4.f-Context{background:#fff4e0}.x3 .tag4.f-Theory{background:#fdeeee}.x3 .tag4.f-Outcome{background:#e8f6f7}.x3 .tag4.f-Type{background:#eef2e2}.x3 .tag4.f-Impact{background:#fbe9f1}.x3 .tag4.f-Recency{background:#eceff3}.x3 .tag4.f-Region{background:#f3ede4}.x3 .tag4.f-MyTags{background:#fff7bf;border-color:#e6cf55}.x3 .tag4.f-Imported{background:#e4f5d9;border-color:#9ccc7a}
.x3 .mono{font-family:ui-monospace,Consolas,monospace;font-size:11.5px;word-break:break-all}
.x3 button.primary,.x3 button.ghost{cursor:pointer}
.x3 .aiwrap{display:flex;flex-direction:column;height:min(74vh,720px)}
.x3 .ailog{flex:1;overflow:auto;border:1px solid var(--line);border-radius:10px;padding:10px;background:#fbfcfe}
.x3 .aimsg{margin:0 0 12px;display:flex;gap:8px}.x3 .aimsg.u{justify-content:flex-end}
.x3 .aibub{max-width:94%;border-radius:12px;padding:9px 12px;border:1px solid var(--line);background:#fff}
.x3 .aimsg.u .aibub{background:var(--brand);color:#fff;border-color:var(--brand)}
.x3 .aires{border:1px solid var(--line);border-radius:9px;padding:8px 10px;margin:7px 0;background:#fff}
.x3 .aires mark{background:#fff2a8;padding:0 1px}
.x3 .aiin{display:flex;gap:8px;margin-top:8px;align-items:flex-end}.x3 .aiin textarea{flex:1;font-family:inherit;font-size:14px}
.x3 .aibar{display:inline-block;height:12px;background:var(--brand);border-radius:3px;vertical-align:middle}
.x3 .gapx{position:relative}
.gap-card{position:relative}
.gap-plus{position:absolute;right:10px;top:10px;width:28px;height:28px;border-radius:50%;border:1.5px solid #8a5a00;background:#fff;color:#8a5a00;font-weight:800;font-size:18px;line-height:1;cursor:pointer;padding:0}
.gap-plus:hover{background:#8a5a00;color:#fff}
.gap-more{margin-top:8px;padding:8px 10px;border-left:3px solid #c98a00;background:#fffaf0;border-radius:6px;font-size:13px}
.gap-more[hidden]{display:none}
.gap-more a,.gap-more button.lnk{margin-right:10px;font-size:12.5px}
.chain-ok{color:#0f6b46;font-weight:700}.chain-bad{color:#b42318;font-weight:700}
.sample-header .toolbar #aiBtn{background:#f1ecfa!important;color:#5b2a9a!important}
`;document.head.appendChild(st4);

/* ---------- storage + crypto helpers ---------- */
const lsPut=(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v));return true}catch{toast('Browser storage is full or blocked');return false}};
const K256=[],H256=[];(()=>{const pr=[];for(let n=2;pr.length<64;n++)if(pr.every(p=>n%p))pr.push(n);const fr=x=>Math.floor((x-Math.floor(x))*4294967296);pr.forEach((p,i)=>{K256[i]=fr(Math.cbrt(p));if(i<8)H256[i]=fr(Math.sqrt(p))})})();
function sha256(str){const b=new TextEncoder().encode(String(str)),l=b.length,nw=((l+9+63)>>6)<<4,w=new Uint32Array(nw);for(let i=0;i<l;i++)w[i>>2]|=b[i]<<(24-(i&3)*8);w[l>>2]|=0x80<<(24-(l&3)*8);w[nw-1]=(l*8)>>>0;w[nw-2]=Math.floor(l*8/4294967296);
 let h=H256.slice();const W=new Uint32Array(64);
 for(let o=0;o<nw;o+=16){for(let i=0;i<16;i++)W[i]=w[o+i];for(let i=16;i<64;i++){const a=W[i-15],c=W[i-2];W[i]=(W[i-16]+(((a>>>7)|(a<<25))^((a>>>18)|(a<<14))^(a>>>3))+W[i-7]+(((c>>>17)|(c<<15))^((c>>>19)|(c<<13))^(c>>>10)))>>>0}
  let [a,b2,c2,d,e,f,g,hh]=h;
  for(let i=0;i<64;i++){const S1=((e>>>6)|(e<<26))^((e>>>11)|(e<<21))^((e>>>25)|(e<<7)),ch=(e&f)^(~e&g),t1=(hh+S1+ch+K256[i]+W[i])>>>0,S0=((a>>>2)|(a<<30))^((a>>>13)|(a<<19))^((a>>>22)|(a<<10)),mj=(a&b2)^(a&c2)^(b2&c2),t2=(S0+mj)>>>0;hh=g;g=f;f=e;e=(d+t1)>>>0;d=c2;c2=b2;b2=a;a=(t1+t2)>>>0}
  h=[h[0]+a,h[1]+b2,h[2]+c2,h[3]+d,h[4]+e,h[5]+f,h[6]+g,h[7]+hh].map(x=>x>>>0)}
 return h.map(x=>('00000000'+x.toString(16)).slice(-8)).join('')}
function merkle(leaves){if(!leaves.length)return sha256('');let L=leaves.slice();while(L.length>1){if(L.length&1)L.push(L[L.length-1]);const N=[];for(let i=0;i<L.length;i+=2)N.push(sha256(L[i]+L[i+1]));L=N}return L[0]}
function merkleProof(leaves,idx){let L=leaves.slice(),path=[],i=idx;while(L.length>1){if(L.length&1)L.push(L[L.length-1]);path.push({h:L[i^1],left:!!(i&1)});const N=[];for(let k=0;k<L.length;k+=2)N.push(sha256(L[k]+L[k+1]));L=N;i>>=1}return path}
function verifyProof(leaf,path,root){let h=leaf;for(const s of path)h=s.left?sha256(s.h+h):sha256(h+s.h);return h===root}
const doiOf=d=>String(d||'').replace(/^https?:\/\/(dx\.)?doi\.org\//i,'').replace(/^doi:\s*/i,'').trim();
const tnorm=s=>norm(s).replace(/[^a-z0-9]+/g,' ').trim();
const recKey=i=>{const d=doiOf(R[i][9]).toLowerCase();return d||('t:'+sha256(tnorm(R[i][2])).slice(0,16))};
const copyText=async t=>{try{await navigator.clipboard.writeText(t);toast('Copied')}catch{const a=document.createElement('textarea');a.value=t;document.body.appendChild(a);a.select();try{document.execCommand('copy');toast('Copied')}catch{toast('Copy failed')}a.remove()}};
const CSVq=v=>'"'+String(v??'').replace(/"/g,'""')+'"';
const backBtn=(fn,label)=>`<button class="ghost" id="x4back" type="button">← ${label}</button>`;

/* ---------- shared facet dictionaries (also used by the gap finder) ---------- */
const CTX=[['students / learners',/\b(students?|learners?|undergraduates?|pupils?)\b/i],['university / higher education',/\b(universit(?:y|ies)|higher education|college)\b/i],['schools / teachers',/\b(schools?|k-12|teachers?|secondary education|primary education)\b/i],['children / adolescents',/\b(children|adolescents?|youth|teenagers?)\b/i],['older adults',/\b(older adults?|elderly|ageing|aging)\b/i],['healthcare settings',/\b(hospitals?|patients?|clinical|nurses?|healthcare|health care)\b/i],['libraries / librarians',/\b(librar(?:y|ies|ians?))\b/i],['firms / industry',/\b(smes?|small business|firms?|industry|enterprises?|companies)\b/i],['rural / developing regions',/\b(rural|developing countr(?:y|ies)|global south|low-income)\b/i],['public sector / policy',/\b(government|public sector|policy ?makers?)\b/i],['online / social platforms',/\b(online|social media|mooc|e-learning|digital platform)\b/i]];
const DESIGN=[['longitudinal / panel design',/\b(longitudinal|panel data|cohort|follow-up)\b/i],['randomised / experimental design',/\b(randomi[sz]ed|experiment(?:al)?|quasi-experiment\w*)\b/i],['mixed methods',/\bmixed[- ]methods?\b/i],['qualitative inquiry',/\b(qualitative|interviews?|focus groups?|ethnograph\w+)\b/i],['cross-sectional survey',/\b(survey|questionnaire|cross-sectional)\b/i],['systematic review / meta-analysis',/\b(systematic review|meta-analys\w+)\b/i],['case study',/\bcase stud(?:y|ies)\b/i],['computational / data-driven',/\b(machine learning|deep learning|text mining|big data|algorithm\w*)\b/i]];
const THEORY=[['technology acceptance (TAM/UTAUT)',/\b[Tt]echnology [Aa]cceptance|\bTAM\b|\bUTAUT\b/],['social cognitive / self-efficacy',/\b(self-efficacy|social cognitive)\b/i],['constructivist / learning theory',/\b(constructivis\w+|connectivis\w+|learning theory)\b/i],['diffusion of innovations',/\bdiffusion of innovations?\b/i],['information behaviour models',/\binformation (?:seeking|behaviou?r)\b/i],['sustainability frameworks (SDGs)',/\b(sustainab\w+|SDGs?)\b/],['knowledge management theory',/\bknowledge (?:management|sharing)\b/i]];
const OUTC=[['performance / achievement',/\b(performance|achievement|outcomes?)\b/i],['satisfaction / user experience',/\b(satisfaction|user experience|usability)\b/i],['wellbeing / mental health',/\b(well-?being|mental health|stress|anxiety)\b/i],['equity / inclusion / access',/\b(equity|inclusion|inclusive|accessib\w+|digital divide)\b/i],['ethics / privacy / trust',/\b(ethic\w*|privacy|trust|bias|responsible)\b/i],['cost / economic impact',/\b(cost|economic|productivity|return on investment)\b/i]];

/* ---------- semantic tags (auto facets + my tags + imported tags) ---------- */
const TG={cut:null};
function tgCuts(){if(TG.cut&&TG.R===R)return TG.cut;const a=Float64Array.from(R,r=>+r[0]||0).sort();const p=q=>a[Math.min(a.length-1,Math.floor(a.length*q))];TG.R=R;return TG.cut={p95:p(.95),p75:p(.75),p50:p(.5)}}
const tgStore=()=>lsGet('x4Tags',{});
function autoTags(i){const o=recObj(i),txt=(o.title||'')+' '+(o.keywords||'')+' '+(o.abstract||''),out=[],seen=new Set(),add=(f,t)=>{t=String(t||'').trim();if(!t)return;const k=f+'|'+t.toLowerCase();if(seen.has(k))return;seen.add(k);out.push([f,t])};
 splitKeywords(o.keywords).slice(0,6).forEach(k=>add('Topic',k));riMethodsFor(o).forEach(m=>add('Method',m));
 [[DESIGN,'Design'],[CTX,'Context'],[THEORY,'Theory'],[OUTC,'Outcome']].forEach(([L,f])=>L.forEach(([n,re])=>re.test(txt)&&add(f,n)));
 const t=o.title||'';add('Type',/review|meta-analys|bibliometric|scoping|state of the art|overview|mapping/i.test(t)?'Review / synthesis':/theor|conceptual|framework|perspective|viewpoint|editorial|commentary/i.test(t)?'Conceptual / commentary':'Empirical / applied study');
 const c=tgCuts(),n=+o.cites||0;add('Impact',n>=c.p95&&n>0?'Highly cited (top 5%)':n>=c.p75&&n>0?'Well cited (top 25%)':n===0?'Not yet cited':'Moderately cited');
 const my=(M&&M.maxYear)||2025;if(o.year>=my-1)add('Recency','Recent (last 2 years)');else if(o.year<=my-8)add('Recency','Established (8+ years)');else add('Recency','Mid-range');
 if(o.country)add('Region',o.country);return out}
function allTags(i){const s=tgStore()[recKey(i)]||{},a=autoTags(i);(s.user||[]).forEach(t=>a.push(['MyTags',t]));(s.imp||[]).forEach(t=>a.push(['Imported',t]));return a}
function addUserTag(i,tag,kind='user'){tag=String(tag||'').trim();if(!tag)return false;const S=tgStore(),k=recKey(i),e=S[k]||(S[k]={user:[],imp:[]});const arr=e[kind]||(e[kind]=[]);if(!arr.includes(tag))arr.push(tag);return lsPut('x4Tags',S)}
function rmUserTag(i,tag,kind='user'){const S=tgStore(),k=recKey(i);if(S[k]&&S[k][kind]){S[k][kind]=S[k][kind].filter(t=>t!==tag);lsPut('x4Tags',S)}}
const tagHtml=(f,t,n)=>`<span class="tag4 f-${f}" data-tf="${esc(f)}" data-tt="${esc(t)}" title="${esc(f)}">${esc(t)}${n!=null?`<small>${n}</small>`:''}</span>`;
function semTags(el){
 el.innerHTML=`<div class="note">Every record is tagged automatically along ten semantic facets (topic, method, design, context, theory, outcome, article type, citation impact, recency, region). You can add your own tags and import tags from files (Import tab). Tags feed the Blockchain ledger and AI Search.</div>
 <div class="row">${SC}<label>Facet <select id="x4tf"><option value="">All facets</option>${['Topic','Method','Design','Context','Theory','Outcome','Type','Impact','Recency','Region','MyTags','Imported'].map(f=>`<option>${f}</option>`).join('')}</select></label><input type="text" id="x4tq" placeholder="filter tags…" size="18"><button class="ghost" id="x4tj">⇩ Tags JSON</button><button class="ghost" id="x4tc">⇩ Tags CSV</button><button class="ghost" id="x4tt">⇩ Tags Turtle</button></div>
 <div class="row"><b>＋ Tag all listed papers:</b><input type="text" id="x4bulk" placeholder="my tag" size="20"><button class="primary" id="x4bulkb">＋ Add</button><span class="tiny" id="x4tinfo"></span></div><div id="x4tf-body"></div><div id="x4tf-list"></div>`;
 let sel=null;
 const build=()=>{const ix=hits(),fac=Q('#x4tf').value,q=norm(Q('#x4tq').value),M2=new Map();ix.forEach(i=>allTags(i).forEach(([f,t])=>{if(fac&&f!==fac)return;if(q&&!norm(t).includes(q))return;const k=f+'\u0001'+t;(M2.get(k)||M2.set(k,[]).get(k)).push(i)}));
  const byF=new Map();M2.forEach((v,k)=>{const [f,t]=k.split('\u0001');(byF.get(f)||byF.set(f,[]).get(f)).push([t,v])});
  Q('#x4tf-body').innerHTML=[...byF].map(([f,a])=>`<div class="card"><b>${esc(f)}</b> <span class="tiny">${a.length} tags</span><div>${a.sort((x,y)=>y[1].length-x[1].length).slice(0,40).map(([t,v])=>tagHtml(f,t,v.length)).join('')}</div></div>`).join('')||'<p class="tiny">No tags match.</p>';
  Q('#x4tinfo').textContent=ix.length+' papers in scope';TG.map=M2;TG.ix=ix;if(sel)list(sel[0],sel[1])};
 const list=(f,t)=>{sel=[f,t];const v=(TG.map.get(f+'\u0001'+t)||[]).slice().sort((a,b)=>R[b][0]-R[a][0]).slice(0,40);
  Q('#x4tf-list').innerHTML=`<h3>${tagHtml(f,t)} <span class="tiny">${(TG.map.get(f+'\u0001'+t)||[]).length} papers</span></h3>`+v.map(i=>`<div class="card"><a href="#" data-p="${i}"><b>${esc(R[i][2])}</b></a><div class="tiny">${esc(R[i][1])} · ${R[i][3]} · ${R[i][0]} cites</div><div>${allTags(i).map(([ff,tt])=>tagHtml(ff,tt)).join('')}</div><div class="row"><input type="text" data-addtag="${i}" placeholder="＋ add my tag, press Enter" size="26">${(tgStore()[recKey(i)]?.user||[]).map(tt=>`<button class="ghost" data-rm="${i}" data-t="${esc(tt)}">✕ ${esc(tt)}</button>`).join('')}</div></div>`).join('')};
 Q('#x4tf').onchange=build;Q('#x4tq').oninput=build;Q('#x3n').onchange=build;build();
 Q('#x4bulkb').onclick=()=>{const t=Q('#x4bulk').value.trim();if(!t)return toast('Type a tag first');TG.ix.forEach(i=>addUserTag(i,t));toast('Tag added to '+TG.ix.length+' papers');build()};
 el.onclick=e=>{const c=e.target.closest('[data-tt]'),p=e.target.closest('[data-p]'),rm=e.target.closest('[data-rm]');if(rm){rmUserTag(+rm.dataset.rm,rm.dataset.t);build();return}if(c){list(c.dataset.tf,c.dataset.tt);Q('#x4tf-list').scrollIntoView({block:'nearest'})}if(p){e.preventDefault();x4Detail(+p.dataset.p,()=>semOpen('tg'),'Semantic tags')}};
 el.onkeydown=e=>{const a=e.target.dataset?.addtag;if(a!==undefined&&e.key==='Enter'){addUserTag(+a,e.target.value);build()}};
 const rows=()=>TG.ix.map(i=>({id:recKey(i),doi:doiOf(R[i][9]),title:R[i][2],tags:allTags(i).map(([f,t])=>({facet:f,tag:t}))}));
 Q('#x4tj').onclick=()=>download('semantic-tags.json',JSON.stringify({format:'are-semantic-tags/1',records:rows()},null,1),'application/json');
 Q('#x4tc').onclick=()=>download('semantic-tags.csv','doi,title,tags\n'+rows().map(r=>[CSVq(r.doi),CSVq(r.title),CSVq(r.tags.map(t=>t.facet+':'+t.tag).join('; '))].join(',')).join('\n'),'text/csv');
 Q('#x4tt').onclick=()=>{let t=PFXT();rows().forEach(r=>{const pu=r.doi?'https://doi.org/'+r.doi:BASE+'paper/'+slug(r.title);t+=`<${pu}> dcterms:title ${lit(r.title)} ;`+r.tags.map(x=>` dcterms:subject <${BASE}tag/${slug(x.facet)}/${slug(x.tag)}> ;`).join('')+' a schema:ScholarlyArticle .\n';});const seen=new Set();rows().forEach(r=>r.tags.forEach(x=>{const u=BASE+'tag/'+slug(x.facet)+'/'+slug(x.tag);if(seen.has(u))return;seen.add(u);t+=`<${u}> a skos:Concept ; skos:prefLabel ${lit(x.tag)} ; skos:inScheme <${BASE}tag/${slug(x.facet)}> .\n`}));download('semantic-tags.ttl',t,'text/turtle')}}
function x4Detail(i,back,label){detail(i);const b=document.createElement('div');b.innerHTML=backBtn(back,label);Q('#modalBody').prepend(b.firstChild);Q('#x4back').onclick=back}

/* ---------- Import (JSON / CSV / Turtle / N-Triples / JSON-LD) ---------- */
function parseCSV(t){const rows=[];let r=[],f='',q=false;for(let i=0;i<t.length;i++){const c=t[i];if(q){if(c==='"'){if(t[i+1]==='"'){f+='"';i++}else q=false}else f+=c}else if(c==='"')q=true;else if(c===','){r.push(f);f=''}else if(c==='\n'||c==='\r'){if(c==='\r'&&t[i+1]==='\n')i++;r.push(f);f='';if(r.length>1||r[0]!=='')rows.push(r);r=[]}else f+=c}r.push(f);if(r.length>1||r[0]!=='')rows.push(r);return rows}
function parseTTL(src){const pre={},T=[];let i=0,n=src.length;const tok=[];
 const rd=()=>{while(i<n){const c=src[i];if(/\s/.test(c)){i++;continue}if(c==='#'){while(i<n&&src[i]!=='\n')i++;continue}break}};
 while(i<n){rd();if(i>=n)break;const c=src[i];
  if(c==='<'){const j=src.indexOf('>',i);tok.push({t:'i',v:src.slice(i+1,j)});i=j+1;continue}
  if(c==='"'||c==="'"){let q=c;if(src.startsWith(c.repeat(3),i))q=c.repeat(3);let j=i+q.length,s='';while(j<n&&!src.startsWith(q,j)){if(src[j]==='\\'){const e=src[j+1];s+=({n:'\n',t:'\t',r:'\r'})[e]??e;j+=2}else s+=src[j++]}j+=q.length;const L={t:'l',v:s};
   if(src.startsWith('^^',j)){j+=2;if(src[j]==='<'){const k=src.indexOf('>',j);L.dt=src.slice(j+1,k);j=k+1}else{const m=/^[^\s;,.()\[\]]+/.exec(src.slice(j));L.dtp=m?m[0]:'';j+=L.dtp.length}}else if(src[j]==='@'){const m=/^@[A-Za-z-]+/.exec(src.slice(j));if(m){L.lang=m[0];j+=m[0].length}}
   tok.push(L);i=j;continue}
  if(';,.[]()'.includes(c)){tok.push({t:'p',v:c});i++;continue}
  const m=/^[^\s;,()\[\]<>"']+/.exec(src.slice(i,i+300));let w=m?m[0]:src[i];i+=w.length;
  if(w.length>1&&w.endsWith('.')&&!/^\d+\.\d+$/.test(w)){w=w.slice(0,-1);tok.push({t:'w',v:w});tok.push({t:'p',v:'.'});continue}tok.push({t:'w',v:w})}
 const res=(x)=>{if(x.t==='i')return x.v;if(x.t==='w'){if(x.v==='a')return PFX.rdf+'type';const k=x.v.indexOf(':');if(k>=0&&pre[x.v.slice(0,k)]!==undefined)return pre[x.v.slice(0,k)]+x.v.slice(k+1);return x.v}if(x.t==='l')return x.v;return null};
 let p=0;while(p<tok.length){const x=tok[p];
  if(x.t==='w'&&/^@?prefix$/i.test(x.v)){const nm=tok[p+1].v.replace(/:$/,''),iri=tok[p+2].v;pre[nm]=iri;p+=3;if(tok[p]&&tok[p].v==='.')p++;continue}
  if(x.t==='w'&&/^@?base$/i.test(x.v)){p+=2;if(tok[p]&&tok[p].v==='.')p++;continue}
  const s=res(x);p++;let pred=null;
  while(p<tok.length){const y=tok[p];if(y.t==='p'&&y.v==='.'){p++;break}if(y.t==='p'&&y.v===';'){p++;pred=null;continue}if(y.t==='p'&&y.v===','){p++;continue}
   if(pred===null){pred=res(y);p++;continue}
   if(y.t==='p'){p++;continue}
   const o=res(y);T.push([s,pred,o,y.t==='l'?'l':'i']);p++}}
 return T}
function parseJSONLD(j){const T=[],g=Array.isArray(j)?j:(j['@graph']||[j]);g.forEach(n=>{const s=n['@id'];if(!s)return;Object.entries(n).forEach(([k,v])=>{if(k==='@id')return;[].concat(v).forEach(x=>{if(k==='@type')T.push([s,PFX.rdf+'type',x,'i']);else if(x&&typeof x==='object'){if(x['@id'])T.push([s,X(k),x['@id'],'i']);else if('@value'in x)T.push([s,X(k),String(x['@value']),'l'])}else if(x!=null)T.push([s,X(k),String(x),'l'])})})});return T}
function graphToImport(T,facet){const by=new Map();T.forEach(t=>(by.get(t[0])||by.set(t[0],[]).get(t[0])).push(t));const ty=PFX.rdf+'type',lab=new Map(),concepts=[],recs=[];
 const P=n=>X(n),pref=P('skos:prefLabel'),alt=P('skos:altLabel'),subj=[P('dcterms:subject'),'http://purl.org/dc/elements/1.1/subject',P('schema:keywords'),'https://schema.org/about','http://schema.org/keywords'],title=[P('dcterms:title'),'http://purl.org/dc/elements/1.1/title','https://schema.org/name','http://schema.org/name'];
 by.forEach((a,s)=>{const l=a.find(t=>t[1]===pref||t[1]===P('rdfs:label'));if(l)lab.set(s,l[2])});
 by.forEach((a,s)=>{const isC=a.some(t=>t[1]===ty&&/Concept$/.test(t[2]));if(isC){const L=a.find(t=>t[1]===pref);if(L){const g=p=>a.filter(t=>t[1]===P('skos:'+p)).map(t=>t[3]==='i'?(lab.get(t[2])||t[2]):t[2]);concepts.push({label:L[2],alts:a.filter(t=>t[1]===alt).map(t=>t[2]),broader:g('broader'),narrower:g('narrower'),related:g('related')})}return}
  const tt=a.find(t=>title.includes(t[1])),doiT=a.find(t=>t[1]===P('prism:doi')||/#doi$/.test(t[1])),doi=doiT?doiT[2]:(/^https?:\/\/(dx\.)?doi\.org\//i.test(s)?doiOf(s):''),tags=a.filter(t=>subj.includes(t[1])).map(t=>t[3]==='i'?(lab.get(t[2])||t[2].split('/').pop().replace(/[-_]+/g,' ')):t[2]);
  if((tt||doi)&&tags.length)recs.push({doi,title:tt?tt[2]:'',tags:tags.map(t=>({facet,tag:t}))})});return{records:recs,concepts}}
function parseImport(text,fmt,facet){text=text.replace(/^﻿/,'').trim();if(!text)throw new Error('Nothing to import');
 if(fmt==='auto'){if(/^[\[{]/.test(text))fmt=/"@(graph|id|context)"/.test(text)?'jsonld':'json';else if(/^(@prefix|@base|PREFIX|<)/im.test(text)||/\s\.\s*$/m.test(text)&&/<http/.test(text))fmt='ttl';else fmt='csv'}
 if(fmt==='ttl')return graphToImport(parseTTL(text),facet);
 if(fmt==='jsonld')return graphToImport(parseJSONLD(JSON.parse(text)),facet);
 if(fmt==='json'){const j=JSON.parse(text),arr=Array.isArray(j)?j:(j.records||j.data||null),norm1=t=>typeof t==='string'?{facet,tag:t}:{facet:t.facet||facet,tag:String(t.tag??t.label??t.name??'')};
  if(arr)return{records:arr.map(r=>({doi:doiOf(r.doi||r.DOI||''),title:r.title||r.Title||'',tags:[].concat(r.tags||r.keywords||r.subjects||[]).flatMap(t=>typeof t==='string'?t.split(/[;|]/):[t]).map(norm1).filter(t=>t.tag.trim())})).filter(r=>r.tags.length),concepts:(j.concepts||[]).map(c=>({label:c.label,alts:c.alts||c.altLabels||[],broader:c.broader||[],narrower:c.narrower||[],related:c.related||[]}))};
  return{records:Object.entries(j).filter(([k,v])=>Array.isArray(v)).map(([k,v])=>({doi:/^10\./.test(doiOf(k))?doiOf(k):'',title:/^10\./.test(doiOf(k))?'':k,tags:v.map(norm1).filter(t=>t.tag.trim())})),concepts:[]}}
 const rows=parseCSV(text),h=rows[0].map(x=>norm(x).trim()),ci=n=>h.findIndex(x=>n.includes(x)),di=ci(['doi']),ti=ci(['title']),gi=ci(['tags','tag','keywords','subjects','subject','concepts']);if(gi<0||(di<0&&ti<0))throw new Error('CSV needs a "doi" or "title" column and a "tags" column');
 return{records:rows.slice(1).map(r=>({doi:doiOf(di>=0?r[di]:''),title:ti>=0?(r[ti]||''):'',tags:String(r[gi]||'').split(/[;|]/).map(t=>t.trim()).filter(Boolean).map(t=>{const m=t.match(/^([A-Za-z]+):(.+)$/);return m&&/^(Topic|Method|Design|Context|Theory|Outcome|Type|Impact|Recency|Region|MyTags|Imported)$/.test(m[1])?{facet:m[1],tag:m[2].trim()}:{facet,tag:t}})})).filter(r=>r.tags.length),concepts:[]}}
const IMP={};
function impMaps(){if(IMP.R===R)return IMP;IMP.R=R;IMP.doi=new Map();IMP.tit=new Map();for(let i=0;i<R.length;i++){const d=doiOf(R[i][9]).toLowerCase();if(d)IMP.doi.set(d,i);const t=tnorm(R[i][2]);if(t&&!IMP.tit.has(t))IMP.tit.set(t,i)}return IMP}
function semIm(el){
 el.innerHTML=`<div class="note"><b>Import semantic tags &amp; concepts.</b> Supported: <b>CSV</b> (columns <code>doi</code>/<code>title</code> + <code>tags</code>), <b>JSON</b> (this app's tag export, <code>{"10.1234/x":["tag"]}</code>, or an array of records), <b>Turtle / N-Triples / JSON-LD</b> (<code>dcterms:subject</code> on papers, <code>skos:Concept</code> with prefLabel/altLabel/broader/narrower). Records are matched to your library by DOI, then by exact title.</div>
 <div class="row"><input type="file" id="x4if" accept=".csv,.json,.jsonld,.ttl,.nt,.txt"><label>Format <select id="x4ifmt"><option value="auto">Auto-detect</option><option value="csv">CSV</option><option value="json">JSON</option><option value="ttl">Turtle / N-Triples</option><option value="jsonld">JSON-LD</option></select></label><label>Facet for imported tags <input type="text" id="x4ifc" value="Imported" size="12"></label></div>
 <textarea id="x4itx" rows="7" placeholder="…or paste CSV / JSON / Turtle here"></textarea>
 <div class="row"><button class="ghost" id="x4ipv">Preview</button><button class="primary" id="x4iap" disabled>⇩ Apply import</button><button class="ghost" id="x4itpl">Download CSV template</button><button class="ghost" id="x4iclr">Remove all imported tags</button><span class="tiny" id="x4iinfo"></span></div><div id="x4ires"></div>`;
 Q('#x4if').onchange=async e=>{const f=e.target.files[0];if(!f)return;Q('#x4itx').value=await f.text();const n=f.name.toLowerCase();Q('#x4ifmt').value=/\.csv$/.test(n)?'csv':/\.jsonld$/.test(n)?'jsonld':/\.json$/.test(n)?'json':/\.(ttl|nt)$/.test(n)?'ttl':'auto';preview()};
 const preview=()=>{try{const facet=Q('#x4ifc').value.trim()||'Imported',P=parseImport(Q('#x4itx').value,Q('#x4ifmt').value,facet),mp=impMaps();let hit=0,miss=[];P.records.forEach(r=>{const i=(r.doi?mp.doi.get(r.doi.toLowerCase()):undefined)??mp.tit.get(tnorm(r.title));if(i===undefined||i===null)miss.push(r);else{r.i=i;hit++}});IMP.P=P;Q('#x4iap').disabled=!(hit||P.concepts.length);
  Q('#x4iinfo').textContent='';Q('#x4ires').innerHTML=`<div class="card"><span class="badge4 ok">${hit} matched</span><span class="badge4 ${miss.length?'warn':''}">${miss.length} not found in library</span><span class="badge4">${P.concepts.length} concepts</span></div>`+(hit?`<table><tr><th>Matched paper</th><th>Tags to add</th></tr>${P.records.filter(r=>r.i!==undefined).slice(0,15).map(r=>`<tr><td>${esc(R[r.i][2])}</td><td>${r.tags.map(t=>tagHtml(t.facet,t.tag)).join('')}</td></tr>`).join('')}</table>`:'')+(miss.length?`<p class="tiny">Unmatched (first 8): ${miss.slice(0,8).map(r=>esc(r.doi||r.title)).join(' · ')}</p>`:'')+(P.concepts.length?`<p><b>Concepts:</b> ${P.concepts.slice(0,25).map(c=>`<span class="chip">${esc(c.label)}${c.alts.length?` <small>+${c.alts.length} syn</small>`:''}</span>`).join('')}</p>`:'')}catch(e){IMP.P=null;Q('#x4iap').disabled=true;Q('#x4ires').innerHTML='<p class="bad">⚠ '+esc(e.message||e)+'</p>'}};
 Q('#x4ipv').onclick=preview;
 Q('#x4iap').onclick=()=>{const P=IMP.P;if(!P)return;let n=0;const S=tgStore();P.records.forEach(r=>{if(r.i===undefined)return;const k=recKey(r.i),e=S[k]||(S[k]={user:[],imp:[]});r.tags.forEach(t=>{const lbl=t.facet&&t.facet!=='Imported'?t.facet+': '+t.tag:t.tag;if(!(e.imp=e.imp||[]).includes(lbl)){e.imp.push(lbl);n++}})});
  const Y=lsGet('x4Syn',{});P.concepts.forEach(c=>{const k=stem(c.label);Y[k]={label:c.label,alts:[...new Set([...(Y[k]?.alts||[]),...c.alts])],rel:[...new Set([...(Y[k]?.rel||[]),...c.broader,...c.narrower,...c.related])]}});
  if(lsPut('x4Tags',S)&&lsPut('x4Syn',Y))toast(n+' tags and '+P.concepts.length+' concepts imported')};
 Q('#x4itpl').onclick=()=>download('semantic-tags-template.csv','doi,title,tags\n10.1000/example,"Example paper title","topic one; topic two; Method:survey"\n','text/csv');
 Q('#x4iclr').onclick=()=>{if(!confirm('Remove all imported tags and imported synonyms?'))return;const S=tgStore();Object.values(S).forEach(e=>e.imp=[]);lsPut('x4Tags',S);lsPut('x4Syn',{});toast('Imported tags removed')}}

/* ---------- Blockchain (local tamper-evident ledger of semantic annotations) ---------- */
const ZERO='0'.repeat(64);
const chainGet=()=>lsGet('x4Chain',[]);
const blockHash=b=>sha256([b.index,b.time,b.prev,b.merkle,b.nonce,b.label,b.n,JSON.stringify(b.meta||{})].join('|'));
function leafFor(i){const o=recObj(i),tags=allTags(i).map(x=>x[0]+':'+x[1]).sort();return sha256(JSON.stringify({id:recKey(i),title:o.title,year:o.year,tags}))}
function verifyChain(C){C=C||chainGet();let prev=ZERO;for(let k=0;k<C.length;k++){const b=C[k];if(b.index!==k)return{ok:false,at:k,why:'index out of sequence'};if(b.prev!==prev)return{ok:false,at:k,why:'previous-hash link broken'};if(blockHash(b)!==b.hash)return{ok:false,at:k,why:'block contents do not match its hash (edited)'};if(!b.hash.startsWith('0'.repeat((b.meta&&b.meta.diff)||0)))return{ok:false,at:k,why:'proof-of-work target not met'};if(merkle((b.items||[]).map(x=>x.leaf))!==b.merkle)return{ok:false,at:k,why:'Merkle root does not match sealed records'};prev=b.hash}return{ok:true,at:-1}}
async function mineBlock(b,diff){const pre='0'.repeat(diff);let n=0;for(;;){b.nonce=n;b.hash=blockHash(b);if(b.hash.startsWith(pre))return b;n++;if(n%2500===0)await new Promise(r=>setTimeout(r,0))}}
const sh=(h,n=10)=>h?h.slice(0,n)+'…'+h.slice(-6):'';
function semBc(el){
 const draw=()=>{const C=chainGet(),V=verifyChain(C);
  el.innerHTML=`<div class="note"><b>Semantic blockchain ledger.</b> Seal the semantic tags of your current result set into a block: each record's tags are hashed (SHA-256), combined in a <b>Merkle tree</b>, and chained to the previous block with optional proof-of-work. Any later change to a sealed block or to a record's tags is detected. <span class="tiny">This is a private, local, tamper-evident chain in your browser — not a public cryptocurrency network. To timestamp publicly, copy a block hash and anchor it with <a href="https://opentimestamps.org" target="_blank" rel="noopener">OpenTimestamps</a> or a DOI service such as Zenodo.</span></div>
  <div class="card"><b>Seal a new block</b><div class="row">${SC}<label>Label <input type="text" id="x4bl" size="24" value="${esc(state.query?'Tags: '+state.query:'Semantic tags snapshot')}"></label><label>Difficulty <select id="x4bd"><option>0</option><option>1</option><option>2</option><option selected>3</option><option>4</option></select></label><button class="primary" id="x4bs">⛓ Seal &amp; mine block</button><span class="tiny" id="x4bi"></span></div></div>
  <div class="row"><b>${C.length} block(s)</b> <span class="badge4 ${V.ok?'ok':'bad'}" id="x4vs">${V.ok?(C.length?'✓ chain valid':'empty'):'✗ invalid at block #'+V.at+': '+esc(V.why)}</span><button class="ghost" id="x4bv">Verify chain</button><button class="ghost" id="x4be">⇩ Export ledger</button><button class="ghost" id="x4bim">⬆ Import ledger</button><button class="ghost" id="x4br">Reset</button></div>
  <div style="overflow:auto"><table><tr><th>#</th><th>Sealed</th><th>Label</th><th>Records</th><th>Merkle root</th><th>Block hash</th><th>Nonce</th><th></th></tr>${C.slice().reverse().map(b=>`<tr><td>${b.index}</td><td class="tiny">${esc(b.time.replace('T',' ').slice(0,19))}</td><td>${esc(b.label)}</td><td>${b.n}</td><td class="mono" title="${b.merkle}">${sh(b.merkle)}</td><td class="mono" title="${b.hash}">${sh(b.hash)}</td><td>${b.nonce}</td><td>${V.ok||b.index<V.at?'<span class="chain-ok">✓</span>':b.index===V.at?'<span class="chain-bad">✗</span>':'<span class="chain-bad">?</span>'}</td></tr>`).join('')||'<tr><td colspan="8" class="tiny">No blocks yet. Seal your first block above — a genesis block is created automatically.</td></tr>'}</table></div>
  <div class="card"><b>Prove a record</b> <span class="tiny">— check that a record's tags were sealed and are unchanged</span><div class="row"><input type="text" id="x4pq" placeholder="DOI or part of the title" size="40"><button class="ghost" id="x4pg">Find &amp; verify</button></div><div id="x4pr"></div></div>
  <textarea id="x4bt" rows="3" style="display:none" placeholder="Paste exported ledger JSON here"></textarea><div class="row" id="x4bimrow" style="display:none"><input type="file" id="x4bf" accept=".json"><button class="primary" id="x4bimgo">Verify &amp; import</button></div>`;
  Q('#x4bs').onclick=async()=>{const btn=Q('#x4bs'),ix=hits();if(!ix.length)return toast('No records in scope');btn.disabled=true;Q('#x4bi').textContent='Hashing '+ix.length+' records…';await new Promise(r=>setTimeout(r,20));
   let C2=chainGet();if(!C2.length){const g={index:0,time:new Date().toISOString(),prev:ZERO,merkle:merkle([]),nonce:0,label:'Genesis block',n:0,meta:{diff:0,type:'genesis'},items:[]};g.hash=blockHash(g);C2=[g]}
   const items=ix.map(i=>({id:recKey(i),title:String(R[i][2]).slice(0,90),leaf:leafFor(i)})),diff=+Q('#x4bd').value,b={index:C2.length,time:new Date().toISOString(),prev:C2[C2.length-1].hash,merkle:merkle(items.map(x=>x.leaf)),nonce:0,label:Q('#x4bl').value.trim()||'Semantic snapshot',n:items.length,meta:{diff,type:'semantic-tags',query:state.query||'',scope:ix.length},items};
   Q('#x4bi').textContent='Mining (difficulty '+diff+')…';await mineBlock(b,diff);C2.push(b);if(lsPut('x4Chain',C2)){toast('Block #'+b.index+' sealed');draw()}else btn.disabled=false};
  Q('#x4bv').onclick=()=>{draw();toast(verifyChain().ok?'Chain verified ✓':'Chain is NOT valid')};
  Q('#x4be').onclick=()=>download('semantic-ledger.json',JSON.stringify({format:'are-semantic-ledger/1',chain:chainGet()},null,1),'application/json');
  Q('#x4br').onclick=()=>{if(confirm('Delete the entire local ledger? This cannot be undone.')){lsPut('x4Chain',[]);draw()}};
  Q('#x4bim').onclick=()=>{Q('#x4bt').style.display='block';Q('#x4bimrow').style.display='flex'};
  Q('#x4bf').onchange=async e=>{if(e.target.files[0])Q('#x4bt').value=await e.target.files[0].text()};
  Q('#x4bimgo').onclick=()=>{try{const j=JSON.parse(Q('#x4bt').value),C3=Array.isArray(j)?j:j.chain,v=verifyChain(C3);if(!Array.isArray(C3)||!C3.length)throw new Error('No chain found');if(!v.ok)throw new Error('Imported ledger is invalid at block #'+v.at+': '+v.why);if(chainGet().length&&!confirm('Replace the current ledger ('+chainGet().length+' blocks) with the imported valid ledger ('+C3.length+' blocks)?'))return;lsPut('x4Chain',C3);toast('Ledger imported and verified');draw()}catch(e){toast('Import failed: '+(e.message||e))}};
  Q('#x4pg').onclick=()=>{const q=Q('#x4pq').value.trim().toLowerCase(),box=Q('#x4pr');if(!q)return;const found=[];C.forEach(b=>(b.items||[]).forEach((it,ix)=>{if(it.id.toLowerCase().includes(q)||it.title.toLowerCase().includes(q))found.push({b,it,ix})}));
   if(!found.length){box.innerHTML='<p class="bad">No sealed record matches.</p>';return}
   const mp=new Map();for(let i=0;i<R.length;i++)mp.set(recKey(i),i);
   box.innerHTML=found.slice(-6).reverse().map(({b,it,ix})=>{const leaves=b.items.map(x=>x.leaf),path=merkleProof(leaves,ix),okP=verifyProof(it.leaf,path,b.merkle),ri=mp.get(it.id),cur=ri!==undefined?leafFor(ri):null,same=cur===it.leaf;
    return `<div class="card"><b>${esc(it.title)}</b><div class="tiny mono">${esc(it.id)}</div><div>${okP?'<span class="chain-ok">✓</span>':'<span class="chain-bad">✗</span>'} Included in block #${b.index} — Merkle proof of ${path.length} step(s) ${okP?'verifies':'FAILS'} against root <span class="mono">${sh(b.merkle)}</span></div><div>${cur===null?'<span class="badge4 warn">record not in current library</span>':same?'<span class="chain-ok">✓</span> Current semantic tags are identical to the sealed version':'<span class="badge4 warn">⚠ Tags changed since sealing</span> — re-seal to record the new state'}</div><div class="row"><button class="ghost" data-cert="${b.index}|${ix}">⇩ Proof certificate</button></div></div>`}).join('');
   box.onclick=e=>{const c=e.target.dataset.cert;if(!c)return;const [bi,ix]=c.split('|').map(Number),b=C[bi],it=b.items[ix];download('proof-'+it.id.replace(/[^a-z0-9]+/gi,'_').slice(0,40)+'.json',JSON.stringify({format:'are-merkle-proof/1',record:it,block:{index:b.index,time:b.time,prev:b.prev,merkle:b.merkle,nonce:b.nonce,label:b.label,n:b.n,meta:{...b.meta},hash:b.hash},proof:merkleProof(b.items.map(x=>x.leaf),ix)},null,1),'application/json')}}};
 draw()}

/* ---------- Research Gap Finder: more gap lenses + (+) detail toggles ---------- */
const gapLinks=(c)=>{const q=(c||[]).filter(Boolean).slice(0,3).map(x=>'"'+x+'"').join(' ');const e=encodeURIComponent(q+' systematic review');return `<a href="https://scholar.google.com/scholar?q=${e}" target="_blank" rel="noopener">Google Scholar ↗</a><a href="https://api.openalex.org/works?search=${encodeURIComponent(q)}" target="_blank" rel="noopener">OpenAlex ↗</a><a href="https://www.semanticscholar.org/search?q=${encodeURIComponent(q)}" target="_blank" rel="noopener">Semantic Scholar ↗</a><a href="https://search.crossref.org/?q=${encodeURIComponent(q)}" target="_blank" rel="noopener">Crossref ↗</a>`};
const GAP_DESIGN={'Explicit gap statement':'Replicate or extend the cited study addressing exactly the limitation the authors name; pre-register the design.','Underexplored concept intersection':'Cross-concept study (survey, experiment or text-mining) that measures both constructs in the same sample.','Methodological opportunity':'Triangulate with the under-used method and compare conclusions with the dominant method.','Geographic concentration signal':'Comparative multi-country replication with harmonised measures.'};
function gapRQ(g){if(g.rq)return g.rq;const [a,b]=g.concepts||[];switch(g.type){case 'Explicit gap statement':return `What evidence would resolve the limitation stated in the source abstract${a?` (topic: “${a}”)`:''}?`;case 'Underexplored concept intersection':return `How are “${a}” and “${b}” related, and under which conditions does one shape the other?`;case 'Methodological opportunity':return `Do the dominant findings on “${b}” still hold when studied with “${a}”?`;case 'Geographic concentration signal':return `Do findings on this topic generalise beyond ${a}?`;default:return `What does the literature still fail to explain about ${a||'this topic'}?`}}
function gapPlus(g){return `<div><b>Suggested research question:</b> ${esc(gapRQ(g))}</div><div style="margin-top:4px"><b>Suggested approach:</b> ${esc(g.design||GAP_DESIGN[g.type]||'Scope a focused literature check, then design an empirical or review study that targets this gap.')}</div><div style="margin-top:6px"><b>Validate in the wider literature:</b> ${gapLinks(g.concepts)}<button class="lnk ghost" data-gapq="${esc((g.concepts||[]).join(' '))}">Search in this explorer</button><button class="lnk ghost" data-gapcopy="${esc(gapRQ(g))}">Copy question</button></div>`}
function riMoreGaps(hits){const out=[],N=hits.length;if(!N)return out;const recs=hits.map(h=>({i:h.i,o:recObj(h.i)})),txt=o=>(o.title||'')+' '+(o.keywords||'')+' '+(o.abstract||'');
 const have=new Set(riGapAnalysis(hits).gaps.map(g=>norm(g.statement).slice(0,150))),push=g=>{const k=norm(g.statement).slice(0,150);if(have.has(k))return;have.add(k);out.push(g)};
 // 1. future-work directives (beyond the standard gap cues)
 const FW=/\b(?:should|could|must|needs? to) (?:be )?(?:further )?(?:explored|examined|investigated|addressed|tested|validated|replicated|extended)\b|\bfuture (?:studies|work|investigations?|directions?|scholars?)\b|\bremains? to be\b|\bopen questions?\b|\bunanswered\b|\bunresolved\b|\bwarrants?\b|\bcalls? for\b/i,seenFW=new Set(riExplicitGaps(hits).map(x=>norm(x.text).slice(0,130)));let nf=0;
 for(const r of recs){if(nf>=4)break;for(const s of riSentenceSplit(r.o.abstract)){const k=norm(s).slice(0,130);if(FW.test(s)&&!seenFW.has(k)){seenFW.add(k);nf++;push({type:'Future-work directive',statement:s,papers:[r.i],concepts:splitKeywords(r.o.keywords).slice(0,3),confidence:'high',basis:'Future-work wording found directly in the source abstract.',score:9});break}}}
 // 2-5. coverage lenses
 const cover=L=>L.map(([n,re])=>({n,p:recs.filter(r=>re.test(txt(r.o))).map(r=>r.i)}));
 const lens=(L,type,rq,dsg)=>{if(N<8)return;const c=cover(L),dom=c.slice().sort((a,b)=>b.p.length-a.p.length)[0];if(!dom||dom.p.length<2)return;c.filter(x=>x.n!==dom.n&&x.p.length<=Math.floor(N*.05)).sort((a,b)=>a.p.length-b.p.length).slice(0,2).forEach(x=>push({type,statement:(x.p.length?`Only ${x.p.length} of ${N} analysed records address ${x.n}`:`None of the ${N} analysed records mentions ${x.n}`)+`, whereas ${dom.n} appears in ${dom.p.length}. Closing this imbalance could broaden what the evidence base can support.`,papers:dom.p.slice(0,2).concat(x.p.slice(0,2)),concepts:[x.n,dom.n],confidence:'medium',basis:'Keyword/abstract pattern matching over the selected corpus; absence of a term is not proof the topic is unstudied.',rq:rq(x.n,dom.n),design:dsg,score:5}))};
 lens(CTX,'Context / population gap',(x,d)=>`Do findings from ${d} settings transfer to ${x}, and what moderates the difference?`,'Replicate a core study in the under-represented population or setting and test for measurement invariance.');
 lens(DESIGN,'Study-design gap',(x,d)=>`Would a ${x} approach confirm, refine or contradict conclusions drawn mainly from ${d} evidence?`,'Run a complementary study using the missing design and report convergence/divergence with existing evidence.');
 lens(THEORY,'Theoretical-framework gap',(x,d)=>`Can ${x} explain outcomes that ${d} leaves unexplained?`,'Test competing theoretical models on the same data, or build an integrated framework.');
 lens(OUTC,'Outcome-measure gap',(x,d)=>`What are the ${x} consequences of the phenomena currently assessed mostly through ${d}?`,'Add the missing outcome to an existing design (secondary analysis or follow-up wave).');
 // 6. temporal
 const ys=[...new Set(recs.map(r=>r.o.year).filter(Boolean))].sort((a,b)=>a-b);if(ys.length>=3){const mY=ys[ys.length-1],kws=riTopKeywords(hits,20);let nd=0,ne=0;kws.forEach(k=>{const ps=[...k.papers],rec=ps.filter(i=>recObj(i).year>=mY-1).length,old=ps.filter(i=>recObj(i).year<=mY-3).length;
   if(old>=3&&rec===0&&nd<2){nd++;push({type:'Temporal gap — fading topic',statement:`“${k.label}” appears in ${old} older record(s) but in none from the last two years (${mY-1}–${mY}) of this corpus. Re-examining it with current data or methods may be timely.`,papers:ps.slice(0,4),concepts:[k.label],confidence:'medium',basis:'Year distribution of keyword occurrences in the selected corpus.',rq:`Do earlier findings on “${k.label}” still hold under present-day conditions?`,design:'Update or replicate earlier studies with recent data; examine what changed.',score:4})}
   else if(rec>=1&&old===0&&ps.length<=3&&ne<2){ne++;push({type:'Temporal gap — emerging but thin',statement:`“${k.label}” appears only in recent records (${ps.length} record${ps.length===1?'':'s'}) and not before ${mY-2}. Evidence is still thin, so early systematic work could shape the field.`,papers:ps.slice(0,4),concepts:[k.label],confidence:'medium',basis:'Year distribution of keyword occurrences in the selected corpus.',rq:`What is the evidence base for “${k.label}”, and which questions are still open?`,design:'Scoping review followed by a first confirmatory study.',score:4})}})}
 // 7. visibility gap
 const cs=recs.map(r=>+r.o.cites||0).sort((a,b)=>a-b),med=cs[cs.length>>1]||0,low=recs.slice(0,10).filter(r=>(+r.o.cites||0)<=Math.max(1,Math.floor(med/4)));if(N>=10&&low.length>=2)push({type:'Visibility gap — relevant but under-cited',statement:`${low.length} of the 10 best-matching records have very few citations (≤${Math.max(1,Math.floor(med/4))} versus a median of ${med}). Their ideas may be under-recognised and ripe for replication or extension.`,papers:low.map(r=>r.i).slice(0,4),concepts:splitKeywords(low[0].o.keywords).slice(0,2),confidence:'medium',basis:'Citation counts in the dataset versus rank in this scope.',rq:'Do these under-cited studies replicate, and why did they receive little attention?',design:'Direct replication or citation-context analysis.',score:3});
 // 8. collaboration
 const single=recs.filter(r=>splitAuthors(r.o.authors).length===1);if(N>=10&&single.length/N>=.4)push({type:'Collaboration gap',statement:`${single.length} of ${N} analysed records (${Math.round(single.length/N*100)}%) are single-authored. Multi-team, multi-disciplinary or cross-institutional studies could strengthen reliability and breadth.`,papers:single.slice(0,4).map(r=>r.i),concepts:[],confidence:'medium',basis:'Author counts in the bibliographic metadata.',rq:'How would multi-site collaborative designs change the conclusions in this area?',design:'Consortium or multi-institution study with shared protocol.',score:3});
 // 9. venue concentration
 const vc=new Map();recs.forEach(r=>r.o.source&&vc.set(r.o.source,(vc.get(r.o.source)||0)+1));const vt=[...vc].sort((a,b)=>b[1]-a[1])[0];if(N>=10&&vt&&vt[1]/N>=.4)push({type:'Venue concentration gap',statement:`${vt[1]} of ${N} analysed records appear in a single source (“${vt[0]}”). Work published in other disciplines' venues may be missing from this picture.`,papers:recs.filter(r=>r.o.source===vt[0]).slice(0,3).map(r=>r.i),concepts:[vt[0]],confidence:'medium',basis:'Source/journal field of the selected records.',rq:'What do adjacent disciplines report on this topic that this venue does not cover?',design:'Cross-disciplinary systematic search across venues.',score:3});
 // 10. interdisciplinary pairs among a wider concept set
 const wp=riPairs(hits,20),co=new Set(wp.pairs.map(p=>[norm(p.a),norm(p.b)].sort().join('§'))),top10=new Set(wp.tops.slice(0,10).map(t=>norm(t.label)));let ni=0;
 for(let a=0;a<wp.tops.length&&ni<3;a++)for(let b=a+1;b<wp.tops.length&&ni<3;b++){const A=wp.tops[a],B=wp.tops[b];if(A.count<3||B.count<3)continue;if(top10.has(norm(A.label))&&top10.has(norm(B.label)))continue;if(co.has([norm(A.label),norm(B.label)].sort().join('§')))continue;ni++;push({type:'Interdisciplinary gap — never co-studied',statement:`“${A.label}” (${A.count} records) and “${B.label}” (${B.count} records) never occur together in this corpus.`,papers:[...A.papers].slice(0,2).concat([...B.papers].slice(0,2)),concepts:[A.label,B.label],confidence:'medium',basis:'Zero co-occurrence of two recurring keywords.',rq:`Is there a meaningful relationship between “${A.label}” and “${B.label}”?`,design:'Exploratory mapping study, then a targeted empirical test.',score:3})}
 // 11. thin geography
 const gc=new Map();recs.forEach(r=>r.o.country&&gc.set(r.o.country,(gc.get(r.o.country)||0)+1));const thin=[...gc].filter(x=>x[1]===1);if(N>=15&&gc.size>=3&&thin.length)push({type:'Geographic gap — single-record regions',statement:`Only one analysed record each comes from ${thin.slice(0,5).map(x=>x[0]).join(', ')}${thin.length>5?' and others':''}. Deeper regional evidence is missing for these contexts.`,papers:recs.filter(r=>thin.some(x=>x[0]===r.o.country)).slice(0,4).map(r=>r.i),concepts:thin.slice(0,3).map(x=>x[0]),confidence:'medium',basis:'Country metadata of selected records (publisher country; may differ from study location).',rq:'How do conditions in these under-represented regions change the findings?',design:'Regional case studies or comparative replication.',score:2});
 return out.sort((a,b)=>(b.confidence==='high')-(a.confidence==='high')||b.score-a.score)}
const gapCardHtml=(g,n,user)=>`<div class="gap-card x4gap"><button class="gap-plus" type="button" aria-expanded="false" title="Show research question, approach and validation links">+</button><div class="confidence ${g.confidence}">${esc(g.type)} · ${g.confidence} confidence</div><h3>Gap ${n}</h3><div>${esc(g.statement)}</div>${g.basis?`<div class="evidence-quote"><b>Basis:</b> ${esc(g.basis)}</div>`:''}<div class="ri-tagrow">${(g.concepts||[]).map(c=>`<span class="ri-tag">${esc(c)}</span>`).join('')}</div>${(g.papers||[]).length?`<div class="tiny" style="margin-top:6px">Evidence: ${g.papers.slice(0,3).map(pi=>esc(recObj(pi).title)).join(' • ')}</div>`:''}${user!==undefined?`<div class="row"><button class="ghost" data-gapdel="${user}">✕ Remove</button></div>`:''}<div class="gap-more" hidden>${gapPlus(g)}</div></div>`;
const origGapModal=window.riGapModal;
window.riGapModal=function(focusIndex=null,graphOnly=false){origGapModal(focusIndex,graphOnly);if(graphOnly)return;const body=Q('#modalBody');if(!body||!body.querySelector('.gap-card')&&!body.querySelector('.ri-actions'))return;
 const hs=riScopeHits(focusIndex),base=riGapAnalysis(hs).gaps;
 [...body.querySelectorAll('.gap-card')].forEach((c,k)=>{if(c.querySelector('.gap-plus'))return;const g=base[k];if(!g)return;c.insertAdjacentHTML('afterbegin','<button class="gap-plus" type="button" aria-expanded="false" title="Show research question, approach and validation links">+</button>');c.insertAdjacentHTML('beforeend',`<div class="gap-more" hidden>${gapPlus(g)}</div>`)});
 const more=riMoreGaps(hs);let shown=0,total=base.length;const UG=()=>lsGet('x4UserGaps',[]);
 const box=document.createElement('div');box.className='ri-section';box.id='gapMoreBox';box.innerHTML=`<h3>＋ More research gaps <span class="badge4">${more.length} additional</span></h3><p class="tiny">Extra lenses: future-work statements, context/population, study design, theory, outcomes, temporal trends, visibility, collaboration, venue, interdisciplinary and geographic gaps. Click <b>+</b> on any card for a research question, approach and validation links.</p><div id="gapMoreList"></div><div class="row"><button class="primary gap" id="gapMoreBtn" type="button">＋ Show more gaps</button><button class="ghost" id="gapAddBtn" type="button">＋ Add my own gap</button></div><div id="gapAddForm" style="display:none" class="card"><textarea id="gapAddTx" rows="3" placeholder="Describe the gap you see…"></textarea><div class="row"><input type="text" id="gapAddCo" placeholder="concepts, comma separated" size="30"><button class="primary" id="gapAddOk" type="button">Save gap</button></div></div><div id="gapUserList"></div>`;
 body.appendChild(box);
 const renderUser=()=>{Q('#gapUserList').innerHTML=UG().map((g,k)=>gapCardHtml({type:'My own gap',statement:g.text,concepts:g.concepts,confidence:'medium',basis:'Added by you.',papers:[]},'U'+(k+1),k)).join('')};renderUser();
 const step=()=>{const nxt=more.slice(shown,shown+4);Q('#gapMoreList').insertAdjacentHTML('beforeend',nxt.map((g,k)=>gapCardHtml(g,total+shown+k+1)).join(''));shown+=nxt.length;const b=Q('#gapMoreBtn');b.textContent=shown>=more.length?'No more gaps':`＋ Show more gaps (${more.length-shown} left)`;b.disabled=shown>=more.length;if(!more.length)Q('#gapMoreList').innerHTML='<div class="note">No additional gap signals in this scope. Increase the analysis scope (Top 40 / Top 100) to enable more lenses.</div>'};
 step();Q('#gapMoreBtn').onclick=step;Q('#gapAddBtn').onclick=()=>{const f=Q('#gapAddForm');f.style.display=f.style.display==='none'?'block':'none'};
 Q('#gapAddOk').onclick=()=>{const t=Q('#gapAddTx').value.trim();if(!t)return toast('Describe the gap first');const L=UG();L.push({text:t,concepts:Q('#gapAddCo').value.split(',').map(x=>x.trim()).filter(Boolean)});lsPut('x4UserGaps',L);Q('#gapAddTx').value='';Q('#gapAddForm').style.display='none';renderUser();toast('Gap added')};
 if(!body.dataset.gapBound){body.dataset.gapBound='1';body.addEventListener('click',e=>{const t=e.target;
  if(t.classList&&t.classList.contains('gap-plus')){const m=t.parentElement.querySelector('.gap-more');if(!m)return;const open=m.hidden;m.hidden=!open;t.textContent=open?'−':'+';t.setAttribute('aria-expanded',String(open));return}
  if(t.dataset&&t.dataset.gapq!==undefined){$('#q').value=t.dataset.gapq;closeModal();$('#searchForm').requestSubmit();return}
  if(t.dataset&&t.dataset.gapcopy!==undefined){copyText(t.dataset.gapcopy);return}
  if(t.dataset&&t.dataset.gapdel!==undefined){const L=lsGet('x4UserGaps',[]);L.splice(+t.dataset.gapdel,1);lsPut('x4UserGaps',L);const u=Q('#gapUserList');if(u)u.innerHTML=L.map((g,k)=>gapCardHtml({type:'My own gap',statement:g.text,concepts:g.concepts,confidence:'medium',basis:'Added by you.',papers:[]},'U'+(k+1),k)).join('')}})}};

/* ---------- AI Search ---------- */
const AI={msgs:[],ctx:null,cfg:lsGet('x4AI',{mode:'local',model:'claude-sonnet-5-5',endpoint:'https://api.openai.com/v1',key:''}),busy:false};
const STOP=new Set('a an the and or of in on for to with by from at as is are was were be been being what which who whom whose how why when where do does did can could should would will shall may might me my we our you your i it its this that these those about into over under between among across any some all most more less than then there here show find list give tell please papers paper articles article studies study research literature work works publications publication regarding related relating using use used based new latest recent top best main key major important highly cited most-cited much many few get want need looking look search explain describe summarise summarize overview summary compare comparison versus vs also not no only just exist exists existing leading lead known field area topic topics about'.split(' '));
const root1=t=>t.replace(/ies$/,'y').replace(/(?<=[a-z]{3})(?:ing|ed|es|s)$/,'');
function aiParse(q0){let s=' '+q0+' ',f={},m;const my=(M&&M.maxYear)||new Date().getFullYear(),cut=re=>{const mm=s.match(re);if(mm)s=s.replace(mm[0],' ');return mm};
 if(m=cut(/\b(?:between|from)\s+((?:19|20)\d\d)\s*(?:and|to|-|–)\s*((?:19|20)\d\d)\b/i)){f.from=+m[1];f.to=+m[2]}
 else{if(m=cut(/\b(?:since|after|from|post|starting)\s+((?:19|20)\d\d)\b/i))f.from=+m[1];if(m=cut(/\b(?:before|until|up to|prior to|through)\s+((?:19|20)\d\d)\b/i))f.to=+m[1];if(m=cut(/\b(?:in|during|of|year)\s+((?:19|20)\d\d)\b/i)){f.from=f.to=+m[1]}}
 if(m=cut(/\b(?:last|past|recent|previous)\s+(\d{1,2})\s+years?\b/i))f.from=my-(+m[1])+1;
 if(m=cut(/(?:more than|over|at least|minimum of|>=?|≥)\s*(\d+)\s*(?:citations?|cites)/i))f.minCites=+m[1];
 if(cut(/\b(highly cited|most cited|top cited|influential|landmark|seminal)\b/i))f.high=true;
 if(cut(/\b(newest|latest|most recent)\b/i))f.sort='newest';
 const ns=' '+norm(s)+' ';for(const c of (CO||[])){if(c&&ns.includes(' '+norm(c)+' ')){f.country=c;s=s.replace(new RegExp('\\b(?:from|in|by|publishers? (?:in|from))?\\s*'+c.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+'\\b','i'),' ');break}}
 const low=norm(q0);let intent='search';if(/\bhypothes/.test(low))intent='hyp';else if(/\b(gaps?|understudied|underexplored|unexplored|research opportunit|future research|what.s missing|missing)\b/.test(low))intent='gaps';else if(/\b(trends?|over time|evolution|growth|timeline|emerging|per year|history)\b/.test(low))intent='trends';else if(/\b(journals?|venues?|where (?:to|can|should) (?:i )?(?:publish|submit))\b/.test(low))intent='journals';else if(/\b(authors?|researchers?|experts?|scholars?|who (?:is|are|has|have|works?|publish))\b/.test(low))intent='authors';else if(/\b(vs\.?|versus|compare|comparison|compared (?:to|with)|difference between)\b/.test(low))intent='compare';
 let cmp=null;if(intent==='compare'){const mm=s.match(/(.+?)\s+(?:vs\.?|versus|compared (?:to|with)|and)\s+(.+)/i)||s.match(/(?:compare|comparison|difference between)\s+(.+?)\s+(?:and|with|to)\s+(.+)/i);if(mm)cmp=[mm[1],mm[2]]}
 const terms=t=>tokens(t).filter(w=>!STOP.has(w)&&!/^(?:19|20)\d\d$/.test(w)&&w.length>1&&!/^(trends?|gaps?|hypothes[ie]s|authors?|journals?|venues?|researchers?|experts?|scholars?|compare|emerging|underexplored|understudied|unexplored|opportunit\w*|growth|timeline|evolution|compar\w*)$/.test(w));
 return{f,intent,terms:terms(s),cmp:cmp&&cmp.map(x=>terms(x)),raw:q0}}
function aiRetrieve(terms,f,cap=60){const T=[...new Set(terms)],syn=lsGet('x4Syn',{});let X2=[];const phr=stem(T.join(' '));if(syn[phr]){X2=syn[phr].alts.concat(syn[phr].rel||[]).flatMap(a=>tokens(a)).filter(w=>!STOP.has(w)&&w.length>2)}
 const mk=t=>{const r=root1(t);return t.length<=3?(x=>new RegExp('\\b'+t+'\\b').test(x)):(x=>x.includes(r))},M1=T.map(t=>({t,f:mk(t)})),M2=[...new Set(X2)].filter(w=>!T.includes(w)).map(t=>({t,f:mk(t)})),phrase=T.length>1?T.map(root1).join(' '):'';
 const ok=i=>{const r=R[i];if(f.from&&r[3]<f.from)return false;if(f.to&&r[3]>f.to)return false;if(f.minCites&&r[0]<f.minCites)return false;if(f.country){const want=countryCanon(f.country)||f.country;const have=countryCanon(CO[r[7]]||'')||CO[r[7]]||'';if(norm(want)!==norm(have))return false}return true};
 let sem=new Map();if(T.length){try{semSearch(T.join(' ')).out.forEach(([i,s])=>sem.set(i,s))}catch{}}
 let emb=new Map();if(T.length&&typeof neuralScores==='function'&&EMB&&EMB.ready){try{emb=neuralScores(T.join(' '))}catch{}}
 const need=Math.max(1,Math.ceil(T.length*.6)),res=[];let cut=f.minCites||0;if(f.high&&!f.minCites){cut=tgCuts().p95;f=Object.assign({},f,{minCites:Math.max(1,cut)})}
 for(let i=0;i<R.length;i++){if(!ok(i)){continue}if(!T.length){res.push({i,score:Math.log1p(R[i][0]),why:[]});continue}
  const x=INDEX[i];let sc=0,hit=0;const why=[];for(const {t,f:fn} of M1){let w=0;if(fn(x.t))w+=6;if(fn(x.k))w+=5;if(fn(x.b))w+=1.5;if(fn(x.a))w+=3;if(fn(x.s))w+=1.5;if(w){hit++;sc+=w;why.push(t)}}
  for(const {t,f:fn} of M2){if(fn(x.t)||fn(x.k)){sc+=1.5;why.push(t+' (syn)')}}
  const sv=sem.get(i);if(sv){sc+=sv*1.6;if(!hit)hit=1}
  const ev=emb.get(i);if(ev){sc+=ev*12;why.push('embedding');if(!hit)hit=1}
  if(hit<need)continue;if(phrase){if(x.t.includes(phrase))sc+=8;if(x.k.includes(phrase))sc+=6;if(x.b.includes(phrase))sc+=3}
  if(hit===T.length)sc+=4;res.push({i,score:sc+.25*Math.log1p(R[i][0]),why})}
 if(f.sort==='newest')res.sort((a,b)=>R[b.i][3]-R[a.i][3]||b.score-a.score);else if(f.high)res.sort((a,b)=>R[b.i][0]-R[a.i][0]);else res.sort((a,b)=>b.score-a.score);
 return{total:res.length,top:res.slice(0,cap)}}
function aiStats(top){const c=(m,k)=>m.set(k,(m.get(k)||0)+1),kw=new Map(),au=new Map(),jo=new Map(),yr=new Map(),co=new Map();top.forEach(({i})=>{const r=R[i];splitKeywords(r[11]).forEach(k=>{const n=norm(k).trim();if(!n)return;const e=kw.get(n)||{n:0,l:k,v:new Map()};e.n++;e.v.set(k,(e.v.get(k)||0)+1);e.l=[...e.v].sort((a,b)=>b[1]-a[1])[0][0];kw.set(n,e)});splitAuthors(r[1]).forEach(a=>{const e=au.get(a)||{n:0,c:0};e.n++;e.c+=r[0];au.set(a,e)});const s=S[r[4]];if(s){const e=jo.get(s)||{n:0,c:0};e.n++;e.c+=r[0];jo.set(s,e)}c(yr,r[3]);const k=CO[r[7]];if(k)c(co,k)});
 const srt=m=>[...m].sort((a,b)=>(b[1].n||b[1])-(a[1].n||a[1]));return{kw:srt(kw).map(([k,e])=>[e.l,e.n]),au:srt(au),jo:srt(jo),yr:[...yr].sort((a,b)=>a[0]-b[0]),co:srt(co)}}
function aiSnippet(i,terms){const a=riSentenceSplit(R[i][12]);if(!a.length)return'';const rs=terms.map(root1);let best=a[0],bs=-1;for(const s of a){const l=norm(s);const n=rs.filter(r=>l.includes(r)).length;if(n>bs){bs=n;best=s}}let h=esc(best.length>300?best.slice(0,297)+'…':best);rs.filter(r=>r.length>2).forEach(r=>{h=h.replace(new RegExp('('+r.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+'[a-z]*)','gi'),'<mark>$1</mark>')});return h}
const aiResCard=(r,k,terms)=>{const i=r.i,o=recObj(i),d=doiOf(o.doi),u=safeUrl(o.url)||(d?'https://doi.org/'+d:'');return `<div class="aires"><div><span class="tiny">#${k+1}</span> <a href="#" data-aip="${i}"><b>${esc(o.title)}</b></a></div><div class="tiny">${esc(o.authors)} · ${o.year} · ${esc(o.source)} · ${o.cites} cites${u?` · <a href="${esc(u)}" target="_blank" rel="noopener">${d?'DOI':'link'} ↗</a>`:''}</div>${aiSnippet(i,terms)?`<div style="margin-top:3px;font-size:12.5px">${aiSnippet(i,terms)}</div>`:''}${r.why&&r.why.length?`<div>${[...new Set(r.why)].slice(0,6).map(w=>`<span class="chip">${esc(w)}</span>`).join('')}</div>`:''}</div>`};
function aiHist(yr){if(!yr.length)return'';const mx=Math.max(...yr.map(x=>x[1]));return `<table>${yr.map(([y,n])=>`<tr><td style="width:48px">${y}</td><td><span class="aibar" style="width:${Math.max(3,n/mx*70)}%"></span> ${n}</td></tr>`).join('')}</table>`}
function aiFilterChips(f){const a=[];if(f.from&&f.to&&f.from===f.to)a.push('year '+f.from);else{if(f.from)a.push('from '+f.from);if(f.to)a.push('until '+f.to)}if(f.minCites)a.push('≥ '+f.minCites+' citations');if(f.high)a.push('highly cited');if(f.country)a.push('publisher country: '+f.country);if(f.sort==='newest')a.push('newest first');return a.map(x=>`<span class="badge4">${esc(x)}</span>`).join('')}
function aiTrendHtml(top,st){const my=(M&&M.maxYear)||2025,rec=new Map(),old=new Map();top.forEach(({i})=>{const y=R[i][3];splitKeywords(R[i][11]).forEach(k=>{const mp=y>=my-2?rec:old;mp.set(k,(mp.get(k)||0)+1)})});const em=[...rec].filter(([k,n])=>n>=2).map(([k,n])=>[k,n,(old.get(k)||0)]).sort((a,b)=>(b[1]-b[2])-(a[1]-a[2])).slice(0,8);return `<b>Publications per year (matching records)</b>${aiHist(st.yr)}${em.length?`<p><b>Rising themes (last 3 years vs earlier):</b> ${em.map(([k,n,o])=>`<span class="chip" data-aiq="${esc(k)}">${esc(k)} <small>${n} vs ${o}</small></span>`).join('')}</p>`:''}`}
async function aiAnswer(q){q=xlPlain(q);const P=aiParse(q);let terms=P.terms,f=P.f;if(!terms.length&&AI.ctx&&!P.cmp){terms=AI.ctx.terms}else if(terms.length&&!P.cmp)AI.ctx={terms,f};if(AI.ctx&&!P.terms.length){f=Object.assign({},AI.ctx.f||{},P.f)}
 const phrase=terms.join(' ');let html='',cards=[],top=[],total=0,follow=[];
 if(P.cmp&&P.cmp[0].length&&P.cmp[1].length){const A=aiRetrieve(P.cmp[0],f,100),B=aiRetrieve(P.cmp[1],f,100),sa=aiStats(A.top),sb=aiStats(B.top),avg=t=>t.length?Math.round(t.reduce((s,x)=>s+R[x.i][0],0)/t.length*10)/10:0,la=P.cmp[0].join(' '),lb=P.cmp[1].join(' ');
  const ka=new Set(sa.kw.slice(0,15).map(x=>x[0])),shared=sb.kw.slice(0,15).map(x=>x[0]).filter(k=>ka.has(k));
  html=`<p><b>Comparison:</b> “${esc(la)}” vs “${esc(lb)}” ${aiFilterChips(f)}</p><table><tr><th></th><th>${esc(la)}</th><th>${esc(lb)}</th></tr><tr><td>Matching records</td><td>${A.total.toLocaleString()}</td><td>${B.total.toLocaleString()}</td></tr><tr><td>Avg. citations (top ${A.top.length}/${B.top.length})</td><td>${avg(A.top)}</td><td>${avg(B.top)}</td></tr><tr><td>Peak year</td><td>${[...sa.yr].sort((a,b)=>b[1]-a[1])[0]?.[0]||'—'}</td><td>${[...sb.yr].sort((a,b)=>b[1]-a[1])[0]?.[0]||'—'}</td></tr><tr><td>Top themes</td><td>${sa.kw.slice(0,5).map(x=>esc(x[0])).join('; ')}</td><td>${sb.kw.slice(0,5).map(x=>esc(x[0])).join('; ')}</td></tr><tr><td>Leading venue</td><td>${esc(sa.jo[0]?.[0]||'—')}</td><td>${esc(sb.jo[0]?.[0]||'—')}</td></tr></table>${shared.length?`<p><b>Shared themes:</b> ${shared.slice(0,8).map(k=>`<span class="chip" data-aiq="${esc(k)}">${esc(k)}</span>`).join('')}</p>`:''}<b>Top papers — ${esc(la)}</b>${A.top.slice(0,3).map((r,k)=>aiResCard(r,k,P.cmp[0])).join('')}<b>Top papers — ${esc(lb)}</b>${B.top.slice(0,3).map((r,k)=>aiResCard(r,k,P.cmp[1])).join('')}`;top=A.top.slice(0,5).concat(B.top.slice(0,5));total=A.total+B.total;follow=['Research gaps in '+la,'Trends in '+lb]}
 else{const rr=aiRetrieve(terms,f,80);top=rr.top;total=rr.total;terms=terms.length?terms:[];const st=aiStats(top);
  if(!total){html=`<p>No records matched${phrase?` “${esc(phrase)}”`:''} ${aiFilterChips(f)}. Try fewer or broader terms, or remove filters.</p>`;follow=['Show all highly cited papers','Trends in '+(AI.ctx?.terms||[]).join(' ')]}
  else{const head=`<p>Found <b>${total.toLocaleString()}</b> matching record${total===1?'':'s'}${phrase?` for “${esc(phrase)}”`:''} ${aiFilterChips(f)}</p>`;
   if(P.intent==='gaps'){const g=riGapAnalysis(top.slice(0,40)).gaps.concat(riMoreGaps(top.slice(0,40))).slice(0,6);html=head+`<b>Research gaps detected in the top ${Math.min(40,top.length)} records</b>`+(g.map((x,k)=>`<div class="aires"><span class="badge4 ${x.confidence==='high'?'warn':''}">${esc(x.type)}</span> ${esc(x.statement)}<div class="tiny"><b>Research question:</b> ${esc(gapRQ(x))}</div></div>`).join('')||'<p class="tiny">No defensible gap signals in this scope.</p>')+`<p><button class="ghost" data-aiact="gapfinder">Open full Research Gap Finder for this topic ⌁</button></p>`;follow=['Hypotheses for '+phrase,'Trends in '+phrase]}
   else if(P.intent==='hyp'){const h=riHypotheses(top.slice(0,40)).hyps;html=head+`<b>Alternative hypotheses</b>`+(h.map((x,k)=>`<div class="aires"><b>H${k+1}:</b> ${esc(x.statement)}<div class="tiny"><b>Null:</b> ${esc(x.null)} · ${x.support} supporting record(s)</div></div>`).join('')||'<p class="tiny">Not enough repeated keyword relationships.</p>')+`<p class="tiny">Hypotheses are generated from keyword co-occurrence; they are not findings.</p>`;follow=['Research gaps in '+phrase]}
   else if(P.intent==='trends'){html=head+aiTrendHtml(top,st);follow=['Research gaps in '+phrase,'Top authors in '+phrase]}
   else if(P.intent==='authors'){html=head+`<b>Leading authors in the top ${top.length} matches</b><table><tr><th>Author</th><th>Papers</th><th>Citations</th></tr>${st.au.slice(0,12).map(([a,e])=>`<tr><td>${esc(a)}</td><td>${e.n}</td><td>${e.c}</td></tr>`).join('')}</table>`;follow=['Top journals for '+phrase]}
   else if(P.intent==='journals'){html=head+`<b>Leading venues in the top ${top.length} matches</b><table><tr><th>Journal</th><th>Papers</th><th>Citations</th></tr>${st.jo.slice(0,12).map(([a,e])=>`<tr><td>${esc(a)}</td><td>${e.n}</td><td>${e.c}</td></tr>`).join('')}</table>`;follow=['Top authors in '+phrase]}
   else{const py=[...st.yr].sort((a,b)=>b[1]-a[1])[0];html=head+`<div class="aires" style="background:#f7faff"><b>Overview</b><br>Key themes: ${st.kw.slice(0,8).map(([k,n])=>`<span class="chip" data-aiq="${esc(k)}">${esc(k)} <small>${n}</small></span>`).join('')||'—'}<br>Most active year: <b>${py?py[0]:'—'}</b> · Leading venue: <b>${esc(st.jo[0]?.[0]||'—')}</b> · Leading author: <b>${esc(st.au[0]?.[0]||'—')}</b>${st.co[0]?` · Publisher country: <b>${esc(st.co[0][0])}</b>`:''}</div>`+top.slice(0,8).map((r,k)=>aiResCard(r,k,terms)).join('');follow=['Research gaps in '+phrase,'Trends in '+phrase,'Top authors in '+phrase,'Only since '+(((M&&M.maxYear)||2025)-4)]}}}
 let llm='';if(AI.cfg.mode!=='local'&&AI.cfg.key&&top.length){try{llm=await aiLLM(q,top.slice(0,12))}catch(e){llm=`<div class="note bad">LLM call failed (${esc(e.message||e)}). Showing local semantic answer instead.</div>`}}
 return{html:llm+html,top,follow,total,terms,f}}
async function aiLLM(q,top){const ctx=top.map((r,k)=>{const o=recObj(r.i);return `[${k+1}] ${o.title} — ${o.authors} (${o.year}), ${o.source}, ${o.cites} citations${o.doi?`, DOI ${doiOf(o.doi)}`:''}. Keywords: ${o.keywords||'n/a'}. Abstract: ${(o.abstract||'n/a').slice(0,700)}`}).join('\n\n'),sys='You are a research assistant inside a bibliographic explorer. Answer ONLY from the numbered records provided. Cite records inline as [n]. If the records do not support an answer, say so. Be concise and structured; do not invent references.',user=`Question: ${q}\n\nRecords:\n${ctx}`;let txt;
 if(AI.cfg.mode==='anthropic'){const r=await fetch('https://api.anthropic.com/v1/messages',{method:'POST',headers:{'content-type':'application/json','x-api-key':AI.cfg.key,'anthropic-version':'2023-06-01','anthropic-dangerous-direct-browser-access':'true'},body:JSON.stringify({model:AI.cfg.model||'claude-sonnet-5-5',max_tokens:1200,system:sys,messages:[{role:'user',content:user}]})});if(!r.ok)throw new Error(r.status+' '+(await r.text()).slice(0,120));const j=await r.json();txt=(j.content||[]).map(c=>c.text||'').join('')}
 else{const r=await fetch((AI.cfg.endpoint||'https://api.openai.com/v1').replace(/\/$/,'')+'/chat/completions',{method:'POST',headers:{'content-type':'application/json',Authorization:'Bearer '+AI.cfg.key},body:JSON.stringify({model:AI.cfg.model,messages:[{role:'system',content:sys},{role:'user',content:user}],max_tokens:1200})});if(!r.ok)throw new Error(r.status+' '+(await r.text()).slice(0,120));const j=await r.json();txt=j.choices?.[0]?.message?.content||''}
 let h=esc(txt).replace(/\*\*(.+?)\*\*/g,'<b>$1</b>').replace(/\n/g,'<br>').replace(/\[(\d{1,2})\]/g,(m,n)=>top[n-1]?`<a href="#" data-aip="${top[n-1].i}">[${n}]</a>`:m);return `<div class="aires" style="background:#f6f1fd;border-color:#c9b3ec"><span class="badge4">✦ ${AI.cfg.mode==='anthropic'?'Claude':'LLM'} answer · grounded in the top ${top.length} records</span><div style="margin-top:6px">${h}</div></div>`}
function aiOpen(prefill,autorun){
 const EX=['What research gaps exist in information literacy?','Highly cited papers on artificial intelligence since 2020','Trends in open access publishing','Who are the leading authors in digital libraries?','Compare bibliometrics vs altmetrics'];
 H('✦ AI Search <span class="badge4" id="aimode"></span>',`<div class="aiwrap"><div class="ailog" id="ailog"></div><div id="aiset" style="display:none" class="card"></div><div class="aiin"><textarea id="aiq" rows="2" placeholder="Ask in natural language — e.g. “highly cited papers on machine learning in libraries since 2019”"></textarea><div style="display:grid;gap:6px"><button class="primary" id="aigo">Ask ✦</button><button class="ghost" id="aicfg" title="AI provider settings">⚙ Settings</button></div></div><div class="tiny" style="margin-top:4px">Understands years, citation thresholds, countries, “gaps”, “trends”, “hypotheses”, “top authors / journals”, “compare X vs Y” and follow-ups.</div></div>`);
 const log=Q('#ailog'),paint=()=>{Q('#aimode').textContent=AI.cfg.mode==='local'||!AI.cfg.key?'local semantic engine · works offline':(AI.cfg.mode==='anthropic'?'Claude · grounded answers':'LLM · grounded answers');Q('#aimode').className='badge4 '+(AI.cfg.mode==='local'||!AI.cfg.key?'ok':'');
  log.innerHTML=(AI.msgs.length?AI.msgs.map(m=>m.u?`<div class="aimsg u"><div class="aibub">${esc(m.u)}</div></div>`:`<div class="aimsg"><div class="aibub">${m.html}${m.top&&m.top.length?`<div class="row"><button class="ghost" data-aiact="apply" data-phrase="${esc((m.terms||[]).join(' '))}">Apply to main search</button><button class="ghost" data-aiact="csv" data-i="${AI.msgs.indexOf(m)}">⇩ CSV</button></div>`:''}${(m.follow||[]).length?`<div>${m.follow.map(x=>`<span class="chip" data-aiq="${esc(x)}">${esc(x)}</span>`).join('')}</div>`:''}</div></div>`).join(''):`<div class="aimsg"><div class="aibub"><b>Ask anything about the ${R.length.toLocaleString()} records in this library.</b><div>${EX.map(x=>`<span class="chip" data-aiq="${esc(x)}">${esc(x)}</span>`).join('')}</div></div></div>`);log.scrollTop=log.scrollHeight};
 const ask=async q=>{q=(q||'').trim();if(!q||AI.busy)return;AI.busy=true;AI.msgs.push({u:q});Q('#aiq').value='';paint();log.insertAdjacentHTML('beforeend','<div class="aimsg"><div class="aibub tiny" id="aithink">Searching and reasoning over the library…</div></div>');log.scrollTop=log.scrollHeight;await new Promise(r=>setTimeout(r,15));
  try{const a=await aiAnswer(q);AI.msgs.push({html:a.html,top:a.top,follow:a.follow,terms:a.terms,f:a.f})}catch(e){AI.msgs.push({html:`<span class="bad">Something went wrong: ${esc(e.message||e)}</span>`})}AI.busy=false;paint()};
 Q('#aigo').onclick=()=>ask(Q('#aiq').value);Q('#aiq').onkeydown=e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();ask(e.target.value)}};
 Q('#aicfg').onclick=()=>{const p=Q('#aiset');if(p.style.display==='block'){p.style.display='none';return}p.style.display='block';const c=AI.cfg;p.innerHTML=`<b>AI provider</b> <span class="tiny">— optional. Local mode needs no key and works offline. With a key, the top matching records are sent to the provider so the model can write a grounded answer. The key is stored only in this browser.</span><div class="row"><label>Mode <select id="aim"><option value="local">Local semantic engine (offline)</option><option value="anthropic">Anthropic (Claude)</option><option value="openai">OpenAI-compatible</option></select></label><label>Model <input type="text" id="aimod" size="22" value="${esc(c.model||'')}"></label></div><div class="row"><label>Endpoint <input type="text" id="aiep" size="36" value="${esc(c.endpoint||'')}"></label><label>API key <input type="password" id="aik" size="30" value="${esc(c.key||'')}" autocomplete="off"></label><button class="primary" id="aisave">Save</button></div>`;Q('#aim').value=c.mode;Q('#aisave').onclick=()=>{AI.cfg={mode:Q('#aim').value,model:Q('#aimod').value.trim(),endpoint:Q('#aiep').value.trim(),key:Q('#aik').value.trim()};lsPut('x4AI',AI.cfg);p.style.display='none';paint();toast('AI settings saved')}};
 log.onclick=e=>{const t=e.target,c=t.closest('[data-aiq]'),pp=t.closest('[data-aip]'),a=t.closest('[data-aiact]');if(c)ask(c.dataset.aiq);if(pp){e.preventDefault();x4Detail(+pp.dataset.aip,()=>aiOpen(),'Back to AI Search')}
  if(a){const act=a.dataset.aiact;if(act==='apply'){const ph=a.dataset.phrase;if(ph){$('#q').value=ph;closeModal();$('#searchForm').requestSubmit()}}
   else if(act==='gapfinder'){const last=[...AI.msgs].reverse().find(m=>m.terms);if(last&&last.terms.length){$('#q').value=last.terms.join(' ');closeModal();$('#searchForm').requestSubmit();setTimeout(()=>riGapModal(),250)}}
   else if(act==='csv'){const m=AI.msgs[+a.dataset.i];download('ai-search-results.csv','title,authors,year,source,cites,doi\n'+m.top.map(r=>{const o=recObj(r.i);return [o.title,o.authors,o.year,o.source,o.cites,doiOf(o.doi)].map(CSVq).join(',')}).join('\n'),'text/csv')}}};
 paint();setTimeout(()=>Q('#aiq')&&Q('#aiq').focus(),50);if(prefill){Q('#aiq').value=prefill;if(autorun)ask(prefill)}}

/* ---------- Open Data URI tab (works offline: resolvable URIs; online: live resolve + save) ---------- */
const E=encodeURIComponent,dpath=d=>d.split('/').map(E).join('/'),under=s=>String(s).trim().replace(/\s+/g,'_'),tcase=s=>String(s).trim().split(/\s+/).map(w=>w.charAt(0).toUpperCase()+w.slice(1)).join('_');
function uriSet(type,label,o){const L=[],add=(n,u,k)=>L.push({n,u,k:k||'page'}),q=E(label);
 if(type==='paper'){const d=doiOf(o.doi);if(d){add('DOI',`https://doi.org/${dpath(d)}`);add('OpenAlex',`https://api.openalex.org/works/doi:${dpath(d)}`,'data');add('Crossref',`https://api.crossref.org/works/${dpath(d)}`,'data');add('OpenCitations',`https://opencitations.net/index/coci/api/v1/metadata/${dpath(d)}`,'data');add('Semantic Scholar',`https://api.semanticscholar.org/graph/v1/paper/DOI:${dpath(d)}?fields=title,year,citationCount,openAccessPdf,externalIds`,'data');add('DataCite',`https://api.datacite.org/dois/${dpath(d)}`,'data');add('Altmetric',`https://api.altmetric.com/v1/doi/${dpath(d)}`,'data');add('Europe PMC',`https://europepmc.org/search?query=DOI:%22${E(d)}%22`)}
  else{add('OpenAlex search',`https://api.openalex.org/works?search=${q}`,'data');add('Crossref search',`https://search.crossref.org/?q=${q}`);add('Semantic Scholar',`https://www.semanticscholar.org/search?q=${q}`);add('Google Scholar',`https://scholar.google.com/scholar?q=${q}`)}
  const u=safeUrl(o.url);if(u)add('Article page',u)}
 else if(type==='author'){add('ORCID search',`https://orcid.org/orcid-search/search?searchQuery=${q}`);add('OpenAlex',`https://api.openalex.org/authors?search=${q}`,'data');add('Wikidata',`https://www.wikidata.org/w/index.php?search=${q}`);add('DBLP',`https://dblp.org/search?q=${q}`);add('VIAF',`https://viaf.org/viaf/search?query=local.names%20all%20%22${q}%22`);add('Google Scholar',`https://scholar.google.com/scholar?q=author%3A%22${q}%22`)}
 else if(type==='journal'){const is=o&&o.issn&&(String(o.issn).match(/\d{4}-?\d{3}[\dXx]/)||[])[0];if(is){const i2=is.replace(/^(\d{4})-?(\d)/,'$1-$2').toUpperCase();add('ISSN Portal',`https://portal.issn.org/resource/ISSN/${i2}`);add('Crossref journal',`https://api.crossref.org/journals/${i2}`,'data');add('OpenAlex source',`https://api.openalex.org/sources/issn:${i2}`,'data');add('DOAJ',`https://doaj.org/toc/${i2}`)}add('OpenAlex search',`https://api.openalex.org/sources?search=${q}`,'data');add('Wikidata',`https://www.wikidata.org/w/index.php?search=${q}`);add('Scimago',`https://www.scimagojr.com/journalsearch.php?q=${q}`)}
 else if(type==='publisher'){add('ROR',`https://ror.org/search?query=${q}`);add('OpenAlex',`https://api.openalex.org/publishers?search=${q}`,'data');add('Crossref members',`https://api.crossref.org/members?query=${q}`,'data');add('Wikidata',`https://www.wikidata.org/w/index.php?search=${q}`)}
 else if(type==='country'){add('Wikidata',`https://www.wikidata.org/w/index.php?search=${q}`);add('DBpedia',`http://dbpedia.org/resource/${E(under(label))}`,'data');add('Wikipedia',`https://en.wikipedia.org/wiki/${E(under(label))}`);add('REST Countries',`https://restcountries.com/v3.1/name/${q}`,'data');add('GeoNames',`https://www.geonames.org/search.html?q=${q}`)}
 else{add('Wikidata',`https://www.wikidata.org/w/index.php?search=${q}`);add('DBpedia',`http://dbpedia.org/resource/${E(tcase(label))}`,'data');add('Wikipedia',`https://en.wikipedia.org/w/index.php?search=${q}`);add('LC Subjects',`https://id.loc.gov/search/?q=${q}`);add('OpenAlex topics',`https://api.openalex.org/topics?search=${q}`,'data')}
 return L}
function mintUri(type,label,o){if(type==='paper'){const d=doiOf(o.doi);return d?'https://doi.org/'+dpath(d):BASE+'paper/'+o.index}return type==='keyword'?cid(label):BASE+type+'/'+slug(label)}
function uriLookup(raw){raw=String(raw||'').trim();if(!raw)return null;const r=[];let m;
 if(m=raw.match(/10\.\d{4,9}\/[^\s"<>]+/)){const d=m[0].replace(/[.,;)]+$/,'');return{kind:'DOI',id:d,uri:'https://doi.org/'+dpath(d),links:uriSet('paper','',{doi:d}),curl:`curl -sLH "Accept: application/vnd.citationstyles.csl+json" https://doi.org/${dpath(d)}`}}
 if(m=raw.match(/\b\d{4}-\d{4}-\d{4}-\d{3}[\dXx]\b/)){const o=m[0].toUpperCase();return{kind:'ORCID iD',id:o,uri:'https://orcid.org/'+o,links:[{n:'ORCID record',u:'https://orcid.org/'+o,k:'page'},{n:'ORCID public API',u:'https://pub.orcid.org/v3.0/'+o+'/record',k:'data'},{n:'OpenAlex',u:'https://api.openalex.org/authors/orcid:'+o,k:'data'}],curl:`curl -sH "Accept: application/json" https://pub.orcid.org/v3.0/${o}/record`}}
 if(m=raw.match(/\b\d{4}-\d{3}[\dXx]\b/)){const o=m[0].toUpperCase();return{kind:'ISSN',id:o,uri:'https://portal.issn.org/resource/ISSN/'+o,links:uriSet('journal','',{issn:o}),curl:`curl -s https://api.crossref.org/journals/${o}`}}
 if(m=raw.match(/\bQ\d+\b/)){const o=m[0];return{kind:'Wikidata item',id:o,uri:'http://www.wikidata.org/entity/'+o,links:[{n:'Wikidata page',u:'https://www.wikidata.org/wiki/'+o,k:'page'},{n:'JSON',u:'https://www.wikidata.org/wiki/Special:EntityData/'+o+'.json',k:'data'},{n:'Turtle (RDF)',u:'https://www.wikidata.org/wiki/Special:EntityData/'+o+'.ttl',k:'data'}],curl:`curl -sLH "Accept: text/turtle" http://www.wikidata.org/entity/${o}`}}
 if(m=raw.match(/\b(?:https?:\/\/openalex\.org\/)?([WAISCPF]\d{5,})\b/)){const o=m[1],k={W:'works',A:'authors',I:'institutions',S:'sources',C:'concepts',P:'publishers',F:'funders'}[o[0]];return{kind:'OpenAlex ID ('+k+')',id:o,uri:'https://openalex.org/'+o,links:[{n:'OpenAlex page',u:'https://openalex.org/'+o,k:'page'},{n:'JSON',u:`https://api.openalex.org/${k}/${o}`,k:'data'}],curl:`curl -s https://api.openalex.org/${k}/${o}`}}
 if(m=raw.match(/\b0[a-hj-km-np-tv-z0-9]{6}[0-9]{2}\b/)){const o=m[0];return{kind:'ROR ID',id:o,uri:'https://ror.org/'+o,links:[{n:'ROR page',u:'https://ror.org/'+o,k:'page'},{n:'ROR API',u:'https://api.ror.org/v2/organizations/'+o,k:'data'}],curl:`curl -s https://api.ror.org/v2/organizations/${o}`}}
 const u=safeUrl(raw);if(u)return{kind:'URI',id:u,uri:u,links:[{n:'Open URI',u,k:'page'}],curl:`curl -sIL "${u}"`};return{kind:'Unrecognised',id:raw,uri:'',links:[{n:'Wikidata search',u:'https://www.wikidata.org/w/index.php?search='+E(raw),k:'page'},{n:'OpenAlex search',u:'https://api.openalex.org/works?search='+E(raw),k:'data'}],curl:''}}
const linkChips=L=>L.map(x=>`<a class="chip" style="text-decoration:none" href="${esc(x.u)}" target="_blank" rel="noopener noreferrer" title="${esc(x.u)}">${esc(x.n)}${x.k==='data'?' <small>data</small>':''} ↗</a>`).join('');
const URIT=['paper','author','journal','publisher','country','keyword'],URIL={paper:'Papers',author:'Authors',journal:'Journals',publisher:'Publishers',country:'Countries',keyword:'Keywords'};
async function pingSvc(name,url){const c=new AbortController(),t=setTimeout(()=>c.abort(),9000);try{const r=await fetch(url,{signal:c.signal});clearTimeout(t);return r.ok?`<span class="chain-ok">✓</span> ${name}`:`<span class="chain-bad">✗</span> ${name} (HTTP ${r.status})`}catch(e){clearTimeout(t);return `<span class="chain-bad">✗</span> ${name} (${e.name==='AbortError'?'timeout':'blocked / offline / CORS'})`}}
let LODR=[];
function lodResolve(k){
  const row=LODR[k];if(!row)return;
  const key=norm(row.label);
  const ids=[];
  for(let i=0;i<R.length;i++){const r=R[i];let ok=false;
    if(row.type==='paper')ok=norm(r[2])===key;
    else if(row.type==='author')ok=splitAuthors(r[1]).some(a=>norm(a)===key);
    else if(row.type==='journal')ok=norm(S[r[4]]||'')===key;
    else if(row.type==='publisher')ok=norm(PUB[r[5]]||'')===key;
    else if(row.type==='country')ok=norm(CO[r[7]]||'')===key;
    else if(row.type==='keyword')ok=splitKeywords(r[11]).some(x=>norm(x)===key);
    if(ok)ids.push(i)}
  const cls={paper:'schema:ScholarlyArticle',author:'foaf:Person',journal:'schema:Periodical',publisher:'foaf:Organization',country:'schema:Country',keyword:'skos:Concept'}[row.type]||'owl:Thing';
  const turtle='<'+row.mint+'> a '+cls+' ;\n    rdfs:label '+lit(row.label)+' .';
  showModal(`<h2>Open Data URI: ${esc(row.label)}</h2>
    <p class="tiny">Type: <b>${esc(URIL[row.type]||row.type)}</b> · records in this library: <b>${ids.length.toLocaleString()}</b></p>
    <div class="card"><b>Minted URI</b><div class="mono">${esc(row.mint)}</div>
      <div class="row"><button class="ghost" id="lodResCopy" type="button">Copy URI</button></div>
      <p class="tiny">This URI is minted under your base URI (${esc(BASE)}). It identifies the entity inside this library. It resolves on the web only after you publish that base URI on a server.</p></div>
    <div class="card"><b>Description (Turtle)</b><textarea readonly rows="4" class="mono" style="width:100%">${esc(turtle)}</textarea></div>
    <div class="card"><b>Records</b>${ids.slice(0,10).map(i=>`<div><button class="ghost" type="button" data-lodp="${i}">${esc(R[i][2]||'Untitled')} (${esc(R[i][3]||'n/a')})</button></div>`).join('')||'<p class="tiny">No records.</p>'}${ids.length>10?`<p class="tiny">First 10 of ${ids.length.toLocaleString()} shown.</p>`:''}</div>
    <div class="card"><b>Open data links</b><div>${linkChips(row.links)}</div></div>`);
  $('#lodResCopy').onclick=()=>copyText(row.mint);
  $$('[data-lodp]').forEach(b=>b.onclick=()=>detail(Number(b.dataset.lodp)));
}
function lodUri(el){
 el.innerHTML=`<div class="note"><b>Open Data URIs.</b> Every paper, author, journal, publisher, country and keyword gets <b>working, clickable open-data URIs</b> (DOI, ORCID, ISSN, OpenAlex, Crossref, Wikidata, DBpedia, ROR, GeoNames, LC Subjects …) generated from the data in your library — no internet call is needed to build them. Click a link to open it in a new tab, or use <b>Copy</b>. <b>Resolve online</b> confirms an entity against live services and lets you save the matched URI as an <code>owl:sameAs</code> link used by Export RDF.</div>
 <div class="card"><b>Resolve any identifier</b> <span class="tiny">— paste a DOI, ORCID, ISSN, Wikidata Q-id, OpenAlex ID, ROR ID or URL</span><div class="row"><input type="text" id="x4ul" size="48" placeholder="e.g. 10.1000/182 · 0000-0002-1825-0097 · 1932-6203 · Q42"><button class="primary" id="x4ulg">Get URIs</button></div><div id="x4ulr"></div></div>
 <div class="row"><label>Entity type <select id="x4ut">${URIT.map(t=>`<option value="${t}">${URIL[t]}</option>`).join('')}</select></label>${SC}<input type="text" id="x4uf" placeholder="filter…" size="16"><button class="ghost" id="x4ucopy">Copy all minted URIs</button><button class="ghost" id="x4ujson">⇩ URI table (CSV)</button><button class="ghost" id="x4utest">Test connection</button></div>
 <div class="row"><label>Base URI for minted identifiers <input type="text" id="x4ubase" size="38" value="${esc(BASE)}"></label><span class="tiny">Persistent URIs for your own entities are minted under this base (publish it on a web server for them to resolve).</span></div><div id="x4utr" class="tiny"></div><div id="x4ub" style="overflow:auto"></div>`;
 let rowsCache=[];
 const build=()=>{const type=Q('#x4ut').value,flt=norm(Q('#x4uf').value),m=new Map();
  hits().forEach(i=>{const o=recObj(i);if(type==='paper'){m.set('p'+i,{l:o.title,n:o.cites,o});return}({keyword:splitKeywords(o.keywords),author:splitAuthors(o.authors),journal:[o.source],publisher:[o.publisher],country:[o.country]})[type].forEach(l=>{l=(l||'').trim();if(!l)return;const k=norm(l),e=m.get(k)||{l,n:0,o:type==='journal'?{issn:o.issn}:{}};e.n++;if(type==='journal'&&!e.o.issn&&o.issn)e.o.issn=o.issn;m.set(k,e)})});
  let a=[...m.values()].filter(e=>!flt||norm(e.l).includes(flt));a.sort((x,y)=>y.n-x.n);a=a.slice(0,type==='paper'?40:30);const L=lk();
  rowsCache=a.map(e=>({type,label:e.l,mint:mintUri(type,e.l,e.o),links:uriSet(type,e.l,e.o)}));LODR=rowsCache;
  Q('#x4ub').innerHTML=`<table><tr><th>${URIL[type].replace(/s$/,'')}</th><th>${type==='paper'?'Cites':'Papers'}</th><th>Persistent URI (minted)</th><th>Open data links</th><th></th></tr>${a.map((e,k)=>{const sv=L[(type==='paper'?'paper|'+norm(e.l):type+'|'+norm(e.l))];return `<tr data-k="${k}"><td style="max-width:240px">${esc(e.l)}</td><td>${e.n}</td><td class="mono" style="max-width:230px">${type==="paper"?`<a href="${esc(rowsCache[k].mint)}" target="_blank" rel="noopener">${esc(rowsCache[k].mint)}</a>`:`<button class="ghost" type="button" data-res="${k}" title="Describe this URI inside the app">${esc(rowsCache[k].mint)}</button>`} <button class="ghost" data-cp="${k}">Copy</button>${sv?`<div class="tiny chain-ok">sameAs → <a href="${esc(safeUrl(sv.uri))}" target="_blank" rel="noopener">${esc(sv.src)}: ${esc(sv.label)}</a></div>`:''}</td><td>${linkChips(rowsCache[k].links)}</td><td><button class="ghost" data-rs="${k}">Resolve online</button></td></tr><tr><td colspan="5" id="x4rr${k}" class="tiny"></td></tr>`}).join('')}</table>`};
 Q('#x4ut').onchange=build;Q('#x3n').onchange=build;Q('#x4uf').oninput=build;build();
 Q('#x4ubase').onchange=e=>{BASE=e.target.value.trim().replace(/\/?$/,'/')||BASE;try{localStorage.setItem('x3Base',BASE)}catch{}build()};
 Q('#x4ulg').onclick=()=>{const r=uriLookup(Q('#x4ul').value);Q('#x4ulr').innerHTML=r?`<div class="row"><span class="badge4">${esc(r.kind)}</span>${r.uri?`<span class="mono">${esc(r.uri)}</span><button class="ghost" id="x4ulc">Copy</button>`:''}</div><div>${linkChips(r.links)}</div>${r.curl?`<div class="tiny" style="margin-top:4px">Content negotiation: <span class="mono">${esc(r.curl)}</span></div>`:''}`:''};
 Q('#x4ul').onkeydown=e=>{if(e.key==='Enter')Q('#x4ulg').click()};
 Q('#x4ulr').onclick=e=>{if(e.target.id==='x4ulc')copyText(uriLookup(Q('#x4ul').value).uri)};
 Q('#x4ucopy').onclick=()=>copyText(rowsCache.map(r=>r.mint).join('\n'));
 Q('#x4ujson').onclick=()=>download('open-data-uris.csv','type,label,minted_uri,link_name,link_uri\n'+rowsCache.flatMap(r=>r.links.map(l=>[r.type,r.label,r.mint,l.n,l.u].map(CSVq).join(','))).join('\n'),'text/csv');
 Q('#x4utest').onclick=async()=>{Q('#x4utr').innerHTML='Testing connections…';const r=await Promise.all([pingSvc('OpenAlex','https://api.openalex.org/works?per-page=1'),pingSvc('Crossref','https://api.crossref.org/works?rows=0'),pingSvc('Wikidata','https://www.wikidata.org/w/api.php?action=wbsearchentities&search=test&language=en&format=json&origin=*&limit=1'),pingSvc('DBpedia Lookup','https://lookup.dbpedia.org/api/search?query=test&maxResults=1&format=json'),pingSvc('doi.org','https://doi.org/api/handles/10.1000/182')]);Q('#x4utr').innerHTML=r.join(' &nbsp; ')+'<br>'+(r.every(x=>x.includes('chain-ok'))?'All services reachable — Resolve online will work.':'Unreachable services only affect “Resolve online”; the direct links above still open normally (use Copy if your browser blocks pop-ups).')};
 el.onclick=async e=>{const t=e.target,cp=t.dataset.cp,rs=t.dataset.rs,sv=t.dataset.sv,rz=t.dataset.res;if(rz!==undefined){lodResolve(Number(rz));return}
  if(cp!==undefined){copyText(rowsCache[+cp].mint);return}
  if(rs!==undefined){const k=+rs,row=rowsCache[k],box=Q('#x4rr'+k);box.innerHTML='Resolving…';const tp=row.type;
   try{if(tp==='paper'){const rec=hits().map(i=>recObj(i)).find(o=>o.title===row.label),d=doiOf(rec&&rec.doi);if(!d)throw new Error('This record has no DOI — use the search links above');const w=await J(`https://api.openalex.org/works/doi:${dpath(d)}`);box.dataset.cand=JSON.stringify([{src:'OpenAlex',uri:w.id,label:w.display_name||row.label}]);
     box.innerHTML=`<div><b>Resolved:</b> <a href="${esc(safeUrl(w.id))}" target="_blank" rel="noopener">${esc(w.id)}</a> · ${w.cited_by_count??'?'} citations (OpenAlex) · ${w.open_access?.is_oa?'open access':'closed/unknown access'}${w.open_access?.oa_url?` · <a href="${esc(safeUrl(w.open_access.oa_url))}" target="_blank" rel="noopener">OA copy ↗</a>`:''}<br>${(w.authorships||[]).slice(0,6).map(a=>`${esc(a.author?.display_name||'')}${a.author?.orcid?` <a href="${esc(safeUrl(a.author.orcid))}" target="_blank" rel="noopener">ORCID ↗</a>`:''}`).join(' · ')}<br><button class="ghost" data-sv="${k}|0">Save as owl:sameAs</button></div>`}
    else{const r=await lodFind(tp,row.label);box.dataset.cand=JSON.stringify(r.items);box.innerHTML=r.items.map((c,j)=>`<div><button class="ghost" data-sv="${k}|${j}">Accept</button> <b>${esc(c.src)}</b> <a href="${esc(safeUrl(c.uri))}" target="_blank" rel="noopener">${esc(c.label)} ↗</a> <span class="tiny">${esc(c.desc)}</span></div>`).join('')||`<span class="bad">No candidates${r.err?' ('+r.err+' source(s) unreachable — click “Test connection”)':''}. Use the links in the row.</span>`}}
   catch(err){box.innerHTML=`<span class="bad">${esc(err.message||err)} — live lookup needs internet access and CORS-enabled services. The links in the row still work; click “Test connection” to diagnose.</span>`}return}
  if(sv!==undefined){const [k,j]=sv.split('|').map(Number),box=Q('#x4rr'+k),c=JSON.parse(box.dataset.cand||'[]')[j],row=rowsCache[k];if(!c)return;const L=lk();L[(row.type==='paper'?'paper|':row.type+'|')+norm(row.label)]=c;setLk(L);toast('Link saved');build()}};
}

/* ---------- navigation buttons ---------- */
const sp=Q('.toolbar .nav-spacer');
[['aiBtn','✦','AI Search',()=>aiOpen()],['mmBtn','✺','Mind Map',mmOpen],['semBtn','◈','Semantic Layer',()=>semOpen()]].forEach(([id,ic,lb,fn])=>{const el=Q('#'+id);if(el){el.onclick=fn;return;}const b=document.createElement('button');b.className='ghost';b.id=id;b.type='button';b.innerHTML=ic+' <span>'+lb+'</span>';b.onclick=fn;sp?sp.parentNode.insertBefore(b,sp):Q('.toolbar').appendChild(b);});
/* Linked Open Data: #onlineSearchBtn is already present and wired to onlineSearchModal; do not create a duplicate lodBtn. */
window.openAISearch=aiOpen;{const hb=document.getElementById('heroAiBtn');if(hb)hb.onclick=()=>{const v=($('#q').value||'').trim();aiOpen(v||undefined,!!v)}}window.openOpenDataURI=()=>lodOpen('uri');window.openSemanticBlockchain=()=>semOpen('bc');window.openMindMap=mmOpen;window.openSemanticLayer=semOpen;window.openLinkedOpenData=lodOpen;
})();
;
/* ---- enhance-v5-js ---- */
/* Knowledge graph results open on the whole page; every existing graph control is unchanged. */
(()=>{
  const modal=()=>document.getElementById('modal'),card=()=>document.getElementById('modalCard');
  const sync=()=>{const m=modal(),c=card();if(m&&c)m.classList.toggle('kg-full',c.classList.contains('graph-modal-card'))};
  const _show=window.showModal;
  window.showModal=function(){const r=_show.apply(this,arguments);sync();return r};
  const _close=window.closeModal;
  window.closeModal=function(){const m=modal();if(m)m.classList.remove('kg-full');return _close.apply(this,arguments)};
  let t=null;
  window.addEventListener('resize',()=>{clearTimeout(t);t=setTimeout(()=>{const m=modal();if(m&&m.classList.contains('kg-full')&&window.KG&&KG.canvas&&typeof kgResize==='function'){try{kgResize();if(typeof kgFit==='function')kgFit()}catch(e){}}},150)});
})();
;
/* ---- layout-v6-js ---- */
/* ===== Layout v6: sector placement, settled synchronously, collision-free, fitted with labels ===== */
const LAY6={rep:6000,soft:90,k:.012,damp:.86,grav:.01,spring:.006,collide:10,settle:400};
function kgTarget(e){return e.relation==='matched search'?145:(e.relation==='related paper'?115:88)}
function kgPhysicsStep(){
  const ns=KG.nodes,es=KG.edges,N=ns.length,P=LAY6;
  for(let i=0;i<N;i++){const a=ns[i];if(a.fixed)continue;let fx=0,fy=0;for(let j=0;j<N;j++){if(i===j)continue;const b=ns[j],dx=a.x-b.x,dy=a.y-b.y,d2=dx*dx+dy*dy+P.soft;const f=P.rep/d2;fx+=dx*f;fy+=dy*f}a.vx=(a.vx+fx*P.k)*P.damp;a.vy=(a.vy+fy*P.k)*P.damp}
  es.forEach(e=>{const a=e.a,b=e.b,dx=b.x-a.x,dy=b.y-a.y,d=Math.sqrt(dx*dx+dy*dy)||1;const f=(d-kgTarget(e))*P.spring,fx=dx/d*f,fy=dy/d*f;if(!a.fixed){a.vx+=fx;a.vy+=fy}if(!b.fixed){b.vx-=fx;b.vy-=fy}});
  for(let i=0;i<N;i++)for(let j=i+1;j<N;j++){const a=ns[i],b=ns[j],dx=b.x-a.x,dy=b.y-a.y,d=Math.hypot(dx,dy)||1,m=kgRadius(a)+kgRadius(b)+P.collide;if(d<m){const push=(m-d)/2*.5,ux=dx/d,uy=dy/d;if(!a.fixed){a.x-=ux*push;a.y-=uy*push}if(!b.fixed){b.x+=ux*push;b.y+=uy*push}}}
  ns.forEach(n=>{if(n.fixed)return;n.vx+=(0-n.x)*P.grav;n.vy+=(0-n.y)*P.grav;n.x+=n.vx;n.y+=n.vy});
  KG.steps=(KG.steps||0)+1;
}
function kgInitPositions(){
  const nodes=KG.nodes;if(!nodes.length)return;
  const idx=new Map();nodes.forEach((n,i)=>idx.set(n,i));
  const adj=nodes.map(()=>[]);
  KG.edges.forEach(e=>{const a=idx.get(e.a),b=idx.get(e.b);if(a!=null&&b!=null&&a!==b){adj[a].push(b);adj[b].push(a)}});
  const root=nodes.find(n=>n.type==='query'||n.root)||null;
  const papers=nodes.filter(n=>n.type==='paper');
  const ents=nodes.filter(n=>n.type!=='paper'&&n!==root);
  nodes.forEach(n=>{n.vx=0;n.vy=0});
  if(root){root.x=0;root.y=0;root.fixed=true}
  const P=Math.max(1,papers.length),r1=Math.max(120,P*17/(2*Math.PI)),R0=r1+110,gap=60;
  const byType=new Map();ents.forEach(n=>{if(!byType.has(n.type))byType.set(n.type,[]);byType.get(n.type).push(n)});
  const types=[...byType.keys()].sort(),total=Math.max(1,ents.length),rings=ents.length>90?3:ents.length>30?2:1;
  const placePapers=order=>order.forEach((n,k)=>{const a=-Math.PI/2+2*Math.PI*k/P;n.x=r1*Math.cos(a);n.y=r1*Math.sin(a);n.ang=a});
  const bary=n=>{const ps=adj[idx.get(n)].map(j=>nodes[j]).filter(m=>m.ang!==undefined);if(!ps.length)return 0;return Math.atan2(ps.reduce((s,m)=>s+Math.sin(m.ang),0),ps.reduce((s,m)=>s+Math.cos(m.ang),0))};
  const placeEnts=()=>{let start=-Math.PI/2;types.forEach(t=>{const list=byType.get(t),span=2*Math.PI*list.length/total;list.sort((a,b)=>bary(a)-bary(b));
    list.forEach((n,k)=>{const a=start+span*(k+.5)/list.length,ring=R0+gap*(k%rings);n.x=ring*Math.cos(a);n.y=ring*Math.sin(a);n.ang=a});start+=span})};
  placePapers(papers);placeEnts();
  const key=new Map(papers.map(p=>[p,bary(p)]));
  placePapers([...papers].sort((a,b)=>key.get(a)-key.get(b)));placeEnts();
  // settle synchronously so the result does not depend on frame rate
  for(let s=0;s<LAY6.settle;s++)kgPhysicsStep();
  nodes.forEach(n=>{n.vx=0;n.vy=0});
  KG.steps=LAY6.settle;KG.alpha=0;
}
function kgStep(){kgPhysicsStep()}
function kgAnimate(){
  if(KG.settledFor!==KG.nodes&&!KG.drag){kgInitPositions();KG.settledFor=KG.nodes}
  if(KG.drag){kgPhysicsStep();kgDraw();KG.anim=requestAnimationFrame(kgAnimate);return}
  KG.anim=0;kgDraw();kgFit();
}
/* Labels are drawn in screen space at a fixed pixel size; crowded labels are skipped so the rest stay readable */
function kgDrawLabels(){
  const L=KG.__lbl||[];if(!L.length||!KG.ctx||!KG.canvas)return;
  const ctx=KG.ctx,dpr=Math.min(2,window.devicePixelRatio||1);
  ctx.save();ctx.setTransform(dpr,0,0,dpr,0,0);ctx.textAlign='center';ctx.textBaseline='alphabetic';
  const boxes=[];
  L.slice().sort((a,b)=>a.pri-b.pri).forEach(o=>{
    const sx=o.x*KG.scale+KG.tx,sy=o.y*KG.scale+KG.ty+o.r*KG.scale+15;
    ctx.font=(o.pri===0?'600 12px':'11px')+' system-ui, sans-serif';
    const w=ctx.measureText(o.l).width+8,x0=sx-w/2,y0=sy-11,h=15;
    if(boxes.some(b=>x0<b.x1&&x0+w>b.x0&&y0<b.y1&&y0+h>b.y0))return;
    boxes.push({x0,x1:x0+w,y0,y1:y0+h});
    ctx.fillStyle='rgba(255,255,255,.92)';ctx.fillRect(x0,y0,w,h);
    ctx.fillStyle=o.col;ctx.fillText(o.l,sx,sy);
  });
  ctx.restore();
}
function kgFit(){
  if(!KG.nodes.length||!KG.canvas)return;const rect=KG.canvas.getBoundingClientRect();if(rect.width<10||rect.height<10)return;
  let x0=1e9,x1=-1e9,y0=1e9,y1=-1e9;
  KG.nodes.forEach(n=>{const r=kgRadius(n)+3,lw=Math.min(34,String(n.label||'').length)*3;x0=Math.min(x0,n.x-Math.max(r,lw));x1=Math.max(x1,n.x+Math.max(r,lw));y0=Math.min(y0,n.y-r);y1=Math.max(y1,n.y+r+16)});
  const pad=36,s=Math.min((rect.width-2*pad)/Math.max(1,x1-x0),(rect.height-2*pad)/Math.max(1,y1-y0));
  KG.scale=Math.max(.08,Math.min(s,1.6));
  KG.tx=rect.width/2-((x0+x1)/2)*KG.scale;KG.ty=rect.height/2-((y0+y1)/2)*KG.scale;
  kgDraw();
}
;
/* ---- hyp-v7-js ---- */
/* ===== Hypotheses v7: alternative hypotheses (H1 variants) and (+) detail toggles ===== */
(()=>{const st=document.createElement('style');st.id='hyp-v7-css';st.textContent='.hyp-card{position:relative;padding-right:46px}.hyp-plus{position:absolute;right:12px;top:12px}.hyp-alt{margin:6px 0 0;padding-left:18px}.hyp-alt li{margin:5px 0;font-size:13px;line-height:1.45}.hyp-more{margin-top:10px;padding:10px 12px;border-left:3px solid #7c3aed;background:#f7f3ff;border-radius:6px;font-size:13px;line-height:1.5}.hyp-more[hidden]{display:none}.hyp-more button.ghost{margin:3px 6px 3px 0;font-size:12px}';if(!document.getElementById('hyp-v7-css'))document.head.appendChild(st)})();
function hypAlts(h){
  const out=[],ps=(h.papers||[]).map(i=>recObj(i)),n=ps.length,A=h.concepts[0]||'the focal concept',B=h.concepts[1]||'the second concept';
  const top=arr=>{const m=new Map();arr.forEach(v=>{if(v!==''&&v!=null)m.set(v,(m.get(v)||0)+1)});return [...m].sort((a,b)=>b[1]-a[1])[0]||null};
  const j=top(ps.map(o=>o.source)),y=top(ps.map(o=>o.year));
  if(n>=2&&j&&j[1]>=Math.ceil(n/2))out.push({label:'H1a',text:`The link between “${A}” and “${B}” reflects publication venue rather than the topics: ${j[1]} of ${n} supporting records appear in “${j[0]}”.`,basis:'Venue concentration among supporting records'});
  if(n>=2&&y&&y[1]>=Math.ceil(n/2))out.push({label:'H1b',text:`The link reflects publication timing rather than a stable association: ${y[1]} of ${n} supporting records were published in ${y[0]}.`,basis:'Year concentration among supporting records'});
  if(h.support<=2)out.push({label:'H1c',text:`The pattern rests on ${h.support} record${h.support===1?'':'s'}, so it may not generalise beyond these papers.`,basis:'Small support count'});
  out.push({label:'H1d',text:`The relationship between “${A}” and “${B}” depends on context (population, setting or method) and is not a general association.`,basis:'Context dependence; test by stratifying the sample'});
  return out;
}
function hypCardHtml(h,i){
  const alts=hypAlts(h),ps=(h.papers||[]).slice(0,3);
  const vars=h.concepts.length>1?`predictor / concept A = “${esc(h.concepts[0])}”; concept B = “${esc(h.concepts[1])}”`:`focal concept = “${esc(h.concepts[0])}”`;
  return `<div class="hyp-card"><button class="gap-plus hyp-plus" type="button" aria-expanded="false" title="Show alternative hypotheses, variables and falsification criteria" onclick="hypToggle(this)">+</button>
    <div class="confidence ${h.confidence}">${esc(h.type)} · ${h.confidence} corpus signal</div>
    <h3>H${i+1}: ${esc(h.statement)}</h3>
    <div class="tiny"><b>Null hypothesis (H0):</b> ${esc(h.null)}</div>
    <div class="ri-tagrow">${h.concepts.map(c=>`<span class="ri-tag">${esc(c)}</span>`).join('')}<span class="ri-tag">${h.support} supporting record${h.support===1?'':'s'}</span></div>
    <div class="hyp-more" hidden>
      <div><b>Alternative hypotheses (H1 variants):</b><ul class="hyp-alt">${alts.map(a=>`<li><b>${a.label}:</b> ${esc(a.text)} <span class="tiny">(${esc(a.basis)})</span></li>`).join('')}</ul></div>
      <div><b>Variables:</b> ${vars}</div>
      <div><b>Falsification:</b> Reject H1 if the association is not detectable in the target sample at the chosen significance level, or if it disappears once the alternatives above are controlled for.</div>
      <div><b>Supporting records:</b> ${ps.map(p=>`<button class="ghost" type="button" onclick="detail(${Number(p)})">${esc(recObj(p).title||'Untitled')}</button>`).join(' ')||'none'}</div>
    </div></div>`;
}
function hypToggle(btn){const m=btn.parentElement.querySelector('.hyp-more');if(!m)return;const open=m.hidden;m.hidden=!open;btn.textContent=open?'−':'+';btn.setAttribute('aria-expanded',String(open));btn.title=open?'Hide details':'Show alternative hypotheses, variables and falsification criteria'}
;
/* ---- kg-v9-js ---- */
/* ===== Knowledge graph v9: full-page toggle, double-click expansion, on-canvas hint ===== */
(()=>{const st=document.createElement('style');st.id='kg-v9-css';st.textContent='.kg-hint{position:absolute;left:12px;bottom:10px;z-index:4;background:rgba(255,255,255,.94);border:1px solid #cbd5e1;border-radius:8px;padding:6px 10px;font-size:12px;color:#334155;pointer-events:none;box-shadow:0 2px 8px rgba(15,23,42,.08)}.kg-stage{position:relative}#kgFull{font-weight:700}';if(!document.getElementById('kg-v9-css'))document.head.appendChild(st)})();
const KG_EXPAND_REL={author:['writes',true],journal:['published_in',false],keyword:['described_by',false],publisher:['published_by',false],place:['published_at',false],year:['appears_in',false],country:['associated country',false]};
function kgRecordsWith(type,label,limit=8){
  const key=norm(label),out=[];
  for(let i=0;i<R.length;i++){const r=R[i];let ok=false;
    if(type==='author')ok=splitAuthors(r[1]).some(a=>norm(a)===key);
    else if(type==='keyword')ok=splitKeywords(r[11]).some(x=>norm(x)===key);
    else if(type==='journal')ok=norm(S[r[4]]||'')===key;
    else if(type==='publisher')ok=norm(PUB[r[5]]||'')===key;
    else if(type==='place')ok=norm(PLC[r[6]]||'')===key;
    else if(type==='country')ok=norm(CO[r[7]]||'')===key;
    else if(type==='year')ok=String(r[3])===label;
    if(ok)out.push(i)}
  return out.sort((a,b)=>R[b][0]-R[a][0]||a-b).slice(0,limit);
}
function kgExpand(n){
  if(!n||!KG.nodeMap)return;
  if(n.expanded){toast('Already expanded. Double-click another node.');return}
  n.expanded=true;
  const map=KG.nodeMap,before=new Set(KG.nodes),added=[];
  const add=spec=>{const key=spec.type==='paper'?('paper|'+spec.paperIndex):(spec.type+'|'+norm(spec.label));const had=map.has(key);const node=kgAddNode(map,spec);if(!had)added.push(node);return node};
  const link=(a,b,rel,detail)=>{if(!a||!b||a===b)return;const k=[a.id,b.id,rel].sort().join('§');if(KG.edges.some(e=>[e.a.id,e.b.id,e.relation].sort().join('§')===k))return;KG.edges.push({a,b,relation:rel,detail:detail||'',rev:'',hit:false})};
  const paperSpec=i=>{const o=recObj(i);return{type:'paper',label:o.title||'Untitled',paperIndex:i,cites:o.cites||0,year:o.year,source:o.source,url:safeUrl(o.url)||(doiOf(o.doi)?'https://doi.org/'+doiOf(o.doi):'')}};
  if(n.type==='paper'){
    const ps=relatedPapers(n.paperIndex,6);
    ps.forEach(x=>{const p=add(paperSpec(x.i));link(n,p,'related paper',x.reasons.join(', '))});
    if(!ps.length)toast('No related papers found for this record');
  }else if(KG_EXPAND_REL[n.type]){
    const recs=kgRecordsWith(n.type,n.label,8);
    const [rel,entityFirst]=KG_EXPAND_REL[n.type];
    recs.forEach(i=>{const p=add(paperSpec(i));if(entityFirst)link(n,p,rel,'Author → Title');else link(p,n,rel,'Title → '+n.type)});
    if(!recs.length)toast('No other records share this '+n.type);
  }else{toast('This node type cannot be expanded');n.expanded=false;return}
  // place new nodes on a ring around the node that was expanded
  const fresh=added.filter(x=>!before.has(x));
  fresh.forEach((x,k)=>{const a=-Math.PI/2+2*Math.PI*k/Math.max(1,fresh.length)+.2,r=kgRadius(n)+70+ (k%2)*22;x.x=n.x+r*Math.cos(a);x.y=n.y+r*Math.sin(a);x.vx=0;x.vy=0});
  KG.nodes=[...map.values()];
  // existing layout stays put; only new nodes settle
  const prev=new Map(KG.nodes.map(x=>[x,!!x.fixed]));
  KG.nodes.forEach(x=>{if(before.has(x))x.fixed=true});
  for(let s=0;s<220;s++)kgPhysicsStep();
  KG.nodes.forEach(x=>{x.fixed=prev.get(x)||false});
  kgSelect(n);
  if($('#kgStats'))$('#kgStats').innerHTML=kgStats();
  kgFit();
  toast(fresh.length?`Expanded: +${fresh.length} new node${fresh.length===1?'':'s'}`:'No new records are linked to this node');
}
function kgDblHandler(e){const c=KG.canvas,r=c.getBoundingClientRect(),n=kgHit(e.clientX-r.left,e.clientY-r.top);if(n)kgExpand(n)}
function kgToggleFull(){
  const m=document.getElementById('modal'),b=document.getElementById('kgFull');if(!m)return;
  const on=!m.classList.contains('kg-full');m.classList.toggle('kg-full',on);
  if(b)b.textContent=on?'⤢ Window view':'⛶ Full page';
  try{if(on&&document.documentElement.requestFullscreen&&!document.fullscreenElement)document.documentElement.requestFullscreen().catch(()=>{});
      if(!on&&document.fullscreenElement&&document.exitFullscreen)document.exitFullscreen().catch(()=>{})}catch(err){}
  setTimeout(()=>{if(KG.canvas){kgResize();kgFit()}},120);
}
function kgEnhance(){
  const bar=document.querySelector('#modalBody .kg-toolbar');
  if(bar&&!document.getElementById('kgFull')){const b=document.createElement('button');b.className='ghost';b.id='kgFull';b.type='button';
    b.textContent=document.getElementById('modal').classList.contains('kg-full')?'⤢ Window view':'⛶ Full page';b.onclick=kgToggleFull;
    bar.insertBefore(b,document.getElementById('kgFit')||null)}
  const stage=document.querySelector('#modalBody .kg-stage');
  if(stage&&!stage.querySelector('.kg-hint')){const h=document.createElement('div');h.className='kg-hint';h.textContent='Double-click a node to expand it · drag to move · scroll to zoom';stage.appendChild(h)}
  if(KG.canvas)KG.canvas.ondblclick=kgDblHandler;
}
(()=>{const _open=window.kgOpen;window.kgOpen=function(){const r=_open.apply(this,arguments);try{kgEnhance()}catch(err){console.warn(err)}return r}})();
;
/* ---- view-modes-js ---- */
/* ===== View modes: Window View · Desktop View · Full Screen View (additive; no existing feature is changed) ===== */
(()=>{
'use strict';
const D=document,H=D.documentElement,Q=s=>D.querySelector(s),KEY='areView',WK='areWinW';
let base='desktop',cur='desktop',realFS=false;
try{const v=localStorage.getItem(KEY);if(v==='window'||v==='desktop')base=v}catch(e){}
const fsEl=()=>D.fullscreenElement||D.webkitFullscreenElement||null;
const reqFS=()=>{const f=H.requestFullscreen||H.webkitRequestFullscreen;if(!f)return Promise.reject(new Error('unsupported'));try{const r=f.call(H,{navigationUI:'hide'});return r&&r.then?r:Promise.resolve()}catch(e){return Promise.reject(e)}};
const exitFS=()=>{const f=D.exitFullscreen||D.webkitExitFullscreen;if(f&&fsEl()){try{const r=f.call(D);if(r&&r.catch)r.catch(()=>{})}catch(e){}}};
const note=m=>{try{if(typeof toast==='function')toast(m)}catch(e){}};
const ICON={
 window:'<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="4.5" width="18" height="15" rx="2.5"/><path d="M3 9h18"/><circle cx="6.2" cy="6.8" r=".6"/><circle cx="8.6" cy="6.8" r=".6"/></svg>',
 desktop:'<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="2.5" y="4" width="19" height="12.5" rx="2"/><path d="M8.5 20h7M12 16.5V20"/></svg>',
 full:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/></svg>'};
const LABEL={window:['Window','Window View — the app in a framed, centred window'],desktop:['Desktop','Desktop View — the standard wide layout'],full:['Full screen','Full Screen View — fill the whole screen (Esc to exit)']};

/* controls */
const sw=D.createElement('span');sw.className='view-switch';sw.setAttribute('role','group');sw.setAttribute('aria-label','Display view');
sw.innerHTML='<em>View</em>'+['window','desktop','full'].map(k=>`<button type="button" data-view="${k}" title="${LABEL[k][1]}" aria-label="${LABEL[k][1]}" aria-pressed="false">${ICON[k]}<span>${LABEL[k][0]}</span></button>`).join('');
const tool=Q('.sample-header .toolbar')||Q('.toolbar'),sp=tool&&tool.querySelector('.nav-spacer');
if(tool){if(sp)sp.after(sw);else{sw.style.marginLeft='auto';tool.appendChild(sw)}}
const tb=D.createElement('div');tb.id='viewTitlebar';
tb.innerHTML=`<span class="vt-dots" aria-hidden="false"><i class="r" aria-hidden="true"></i><i class="y" aria-hidden="true"></i><button type="button" data-view="desktop" title="Maximise to Desktop View" aria-label="Maximise to Desktop View"></button></span><span class="vt-title">Academic Research Explorer — Window View</span><span class="vt-sp"></span><label>Window width <span class="vt-w" role="group" aria-label="Window width"><button type="button" data-w="compact" title="Compact window">S</button><button type="button" data-w="standard" title="Standard window">M</button><button type="button" data-w="wide" title="Wide window">L</button></span></label><button type="button" class="vt-fs" data-view="full" title="${LABEL.full[1]}">⛶ Full screen</button>`;
const hd=Q('header.sample-header')||Q('header');if(hd)hd.parentNode.insertBefore(tb,hd);else D.body.insertBefore(tb,D.body.firstChild);
const ex=D.createElement('button');ex.id='viewExit';ex.type='button';ex.innerHTML='✕ Exit full screen <kbd>Esc</kbd>';ex.setAttribute('aria-label','Exit Full Screen View');D.body.appendChild(ex);

const refit=()=>{window.dispatchEvent(new Event('resize'));try{if(window.KG&&KG.canvas&&Q('#modal.open')&&typeof kgResize==='function'){kgResize();if(typeof kgFit==='function')kgFit()}}catch(e){}};
function paint(){H.setAttribute('data-view',cur);sw.querySelectorAll('[data-view]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.view===cur)));
  const fb=sw.querySelector('[data-view=full]');if(fb){const t=cur==='full'?'Exit Full Screen View (Esc)':LABEL.full[1];fb.title=t;fb.setAttribute('aria-label',t)}setTimeout(refit,80)}
function apply(v){cur=v;paint()}
function setView(v){
  if(v==='window'||v==='desktop'){base=v;try{localStorage.setItem(KEY,v)}catch(e){}if(fsEl()){realFS=false;exitFS()}apply(v);return}
  if(v==='full'){
    if(cur==='full'){realFS=false;exitFS();apply(base);return}
    apply('full');
    reqFS().then(()=>{realFS=!!fsEl()}).catch(()=>{realFS=false;note('Browser full screen was blocked here — showing the full-screen layout instead (press F11 for the browser’s own full screen).')})}}
D.addEventListener('click',e=>{
  const b=e.target.closest&&e.target.closest('button[data-view]');if(b&&b.dataset.view){setView(b.dataset.view);return}
  const w=e.target.closest&&e.target.closest('button[data-w]');if(w){H.setAttribute('data-win',w.dataset.w);try{localStorage.setItem(WK,w.dataset.w)}catch(er){}setTimeout(refit,80)}
  if(e.target.closest&&e.target.closest('#viewExit'))setView('full')});
const onFs=()=>{if(fsEl()){if(cur==='full')realFS=true;return}if(cur==='full'&&realFS){realFS=false;apply(base)}};
D.addEventListener('fullscreenchange',onFs);D.addEventListener('webkitfullscreenchange',onFs);
D.addEventListener('keydown',e=>{if(e.key==='Escape'&&cur==='full'&&!realFS&&!fsEl()&&!Q('#modal.open'))setView('full')});
window.setAppView=setView;window.getAppView=()=>cur;
apply(base);
})();
;
/* ---- gx-engine-js ---- */
/* ===== GX: optimized, responsive graph engine (auto fit/center, zoom, overlap removal, crossing reduction, readable labels) ===== */
(()=>{
'use strict';
const FONT='Inter,system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif';
const CSS=`
.gx{display:flex;flex-direction:column;width:100%;height:100%;min-height:320px;background:#fff;border:1px solid var(--line,#dfe4ec);border-radius:12px;overflow:hidden;position:relative}
.gx.gx-full{position:fixed;inset:0;z-index:3000;border-radius:0;height:100vh;width:100vw;min-height:0}
.gx-bar{display:flex;gap:6px;flex-wrap:wrap;align-items:center;padding:6px 8px;background:#f7f9fc;border-bottom:1px solid var(--line,#dfe4ec);font-size:12px}
.gx-bar select,.gx-bar input{border:1px solid var(--line,#dfe4ec);border-radius:7px;padding:4px 6px;background:#fff;font:inherit;font-size:12px;max-width:120px}
.gx-bar button{border:1px solid var(--line,#dfe4ec);background:#fff;border-radius:7px;padding:4px 9px;font-size:12px;cursor:pointer;color:var(--brand,#184e77);font-weight:600}
.gx-bar button:hover,.gx-bar button.on{background:#eaf0fb}
.gx-bar .gx-sp{flex:1}.gx-bar .gx-stat{color:#687386;font-size:11.5px}
.gx-st{position:relative;flex:1 1 auto;min-height:200px;background:linear-gradient(#fcfdff,#f5f8fc)}
.gx-st canvas{position:absolute;left:0;top:0;width:100%;height:100%;display:block;touch-action:none;cursor:grab}
.gx-st canvas.drag{cursor:grabbing}
.gx-leg{position:absolute;left:8px;top:8px;background:rgba(255,255,255,.92);border:1px solid var(--line,#dfe4ec);border-radius:8px;padding:5px 8px;font-size:11.5px;max-width:230px;pointer-events:none;line-height:1.7}
.gx-leg i{display:inline-block;width:10px;height:10px;border-radius:50%;margin-right:5px;vertical-align:-1px}
.gx-tip{position:absolute;pointer-events:none;background:#152033;color:#fff;border-radius:7px;padding:5px 8px;font-size:12px;max-width:300px;display:none;z-index:5;line-height:1.35}
.gx-msg{position:absolute;inset:0;display:none;align-items:center;justify-content:center;color:#687386;font-size:13px;text-align:center;padding:20px}
`;
let cssDone=false;
const rng=seed=>()=>{seed|=0;seed=seed+0x6D2B79F5|0;let t=Math.imul(seed^seed>>>15,1|seed);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296};
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

/* ---------- geometry ---------- */
function segCross(a,b,c,d){
  const o=(p,q,r)=>(q.x-p.x)*(r.y-p.y)-(q.y-p.y)*(r.x-p.x);
  const d1=o(a,b,c),d2=o(a,b,d),d3=o(c,d,a),d4=o(c,d,b);
  return d1*d2<0&&d3*d4<0;
}
function countCross(N,UE){
  let c=0;
  for(let i=0;i<UE.length;i++){const a=UE[i];
    for(let j=i+1;j<UE.length;j++){const b=UE[j];
      if(a[0]===b[0]||a[0]===b[1]||a[1]===b[0]||a[1]===b[1])continue;
      if(segCross(N[a[0]],N[a[1]],N[b[0]],N[b[1]]))c++}}
  return c;
}
function overlapCount(N,idx){
  let c=0;
  for(let a=0;a<idx.length;a++)for(let b=a+1;b<idx.length;b++){
    const p=N[idx[a]],q=N[idx[b]];
    if((p.fw+q.fw)/2-Math.abs(q.x-p.x)>0.5&&(p.fh+q.fh)/2-Math.abs(q.y-p.y)>0.5)c++}
  return c;
}

/* ---------- layout stages ---------- */
function components(N){
  const seen=new Uint8Array(N.length),out=[];
  for(let s=0;s<N.length;s++){if(seen[s])continue;const comp=[s];seen[s]=1;
    for(let h=0;h<comp.length;h++)for(const u of N[comp[h]].nb)if(!seen[u]){seen[u]=1;comp.push(u)}
    out.push(comp)}
  return out;
}
function radialInit(comp,N,gap){
  if(comp.length===1){N[comp[0]].x=0;N[comp[0]].y=0;return}
  const root=comp.reduce((a,b)=>N[b].wdeg>N[a].wdeg?b:a,comp[0]);
  const lvl=new Map([[root,0]]),kids=new Map(),q=[root];
  for(let h=0;h<q.length;h++){const v=q[h];
    for(const u of N[v].nb)if(!lvl.has(u)){lvl.set(u,lvl.get(v)+1);(kids.get(v)||kids.set(v,[]).get(v)).push(u);q.push(u)}}
  const leaves=new Map();
  for(let h=q.length-1;h>=0;h--){const v=q[h],ks=kids.get(v)||[];leaves.set(v,ks.length?ks.reduce((s,k)=>s+leaves.get(k),0):1)}
  const ang=new Map([[root,[0,2*Math.PI]]]);
  q.forEach(v=>{const [a0,a1]=ang.get(v),ks=kids.get(v)||[];let a=a0;const tot=leaves.get(v);
    ks.forEach(k=>{const span=(a1-a0)*leaves.get(k)/tot;ang.set(k,[a,a+span]);a+=span})});
  const byL=new Map();q.forEach(v=>{const L=lvl.get(v);(byL.get(L)||byL.set(L,[]).get(L)).push(v)});
  const R=[0];const maxL=Math.max(...byL.keys());
  for(let L=1;L<=maxL;L++){const arr=byL.get(L)||[],circ=arr.reduce((s,v)=>s+Math.max(N[v].fw,N[v].fh)*1.05,0);R[L]=Math.max(R[L-1]+gap,circ/(2*Math.PI))}
  q.forEach(v=>{const [a0,a1]=ang.get(v),L=lvl.get(v),m=(a0+a1)/2;N[v].x=Math.cos(m)*R[L];N[v].y=Math.sin(m)*R[L]});
}
function forceStage(comp,N,UE,L,iters,rand){
  const n=comp.length;if(n<2)return;
  const pos=new Map(comp.map((v,i)=>[v,i])),X=new Float64Array(n),Y=new Float64Array(n),DX=new Float64Array(n),DY=new Float64Array(n);
  comp.forEach((v,i)=>{X[i]=N[v].x+(rand()-.5)*2;Y[i]=N[v].y+(rand()-.5)*2});
  const es=UE.filter(e=>pos.has(e[0])).map(e=>[pos.get(e[0]),pos.get(e[1]),e[2]]);
  const wmax=Math.max(1,...es.map(e=>e[2])),R=comp.map(v=>N[v].r);
  for(let it=0;it<iters;it++){
    const temp=L*1.2*(1-it/iters)+L*.05;
    DX.fill(0);DY.fill(0);
    for(let i=0;i<n;i++)for(let j=i+1;j<n;j++){
      let dx=X[i]-X[j],dy=Y[i]-Y[j],d2=dx*dx+dy*dy;if(d2<1e-4){dx=rand()-.5;dy=rand()-.5;d2=dx*dx+dy*dy+1e-4}
      const d=Math.sqrt(d2),f=(L*L*(1+(R[i]+R[j])/L))/d2;DX[i]+=dx*f;DY[i]+=dy*f;DX[j]-=dx*f;DY[j]-=dy*f}
    for(const [a,b,w] of es){const dx=X[a]-X[b],dy=Y[a]-Y[b],d=Math.sqrt(dx*dx+dy*dy)||1e-3,f=d/L*(.4+.6*Math.min(1,w/wmax));
      DX[a]-=dx*f;DY[a]-=dy*f;DX[b]+=dx*f;DY[b]+=dy*f}
    for(let i=0;i<n;i++){DX[i]-=X[i]*.012;DY[i]-=Y[i]*.012;
      const d=Math.sqrt(DX[i]*DX[i]+DY[i]*DY[i])||1e-6,m=Math.min(d,temp);X[i]+=DX[i]/d*m;Y[i]+=DY[i]/d*m}
  }
  comp.forEach((v,i)=>{N[v].x=X[i];N[v].y=Y[i]});
}
function removeOverlap(comp,N,rand,maxIt=250){
  for(let it=0;it<maxIt;it++){let moved=false;
    for(let a=0;a<comp.length;a++)for(let b=a+1;b<comp.length;b++){
      const p=N[comp[a]],q=N[comp[b]];let dx=q.x-p.x,dy=q.y-p.y;
      const ox=(p.fw+q.fw)/2-Math.abs(dx),oy=(p.fh+q.fh)/2-Math.abs(dy);
      if(ox>0&&oy>0){moved=true;
        if(dx===0&&dy===0){dx=rand()-.5;dy=rand()-.5}
        if(ox<oy){const s=(ox/2+.6)*(dx>=0?1:-1);p.x-=s;q.x+=s}else{const s=(oy/2+.6)*(dy>=0?1:-1);p.y-=s;q.y+=s}}}
    if(!moved)break}
}
function crossInc(N,UE,inc,vs){
  const A=new Set();vs.forEach(v=>(inc.get(v)||[]).forEach(e=>A.add(e)));let c=0;
  for(const ei of A){const a=UE[ei];
    for(let ej=0;ej<UE.length;ej++){if(ej===ei||(A.has(ej)&&ej<ei))continue;const b=UE[ej];
      if(a[0]===b[0]||a[0]===b[1]||a[1]===b[0]||a[1]===b[1])continue;
      if(segCross(N[a[0]],N[a[1]],N[b[0]],N[b[1]]))c++}}
  return c;
}
function reduceCrossings(comp,N,UEall,rand,ms){
  const set=new Set(comp),UE=UEall.filter(e=>set.has(e[0]));
  if(UE.length<3||comp.length<4)return;
  const inc=new Map();UE.forEach((e,i)=>{(inc.get(e[0])||inc.set(e[0],[]).get(e[0])).push(i);(inc.get(e[1])||inc.set(e[1],[]).get(e[1])).push(i)});
  let total=countCross(N,UE);if(!total)return;
  const t0=performance.now();let stale=0;
  while(performance.now()-t0<ms&&total>0&&stale<4000){
    const v=comp[Math.floor(rand()*comp.length)];
    const near=comp.filter(u=>u!==v).sort((a,b)=>((N[a].x-N[v].x)**2+(N[a].y-N[v].y)**2)-((N[b].x-N[v].x)**2+(N[b].y-N[v].y)**2)).slice(0,8);
    near.push(comp[Math.floor(rand()*comp.length)]);
    const u=near[Math.floor(rand()*near.length)];if(u===v){stale++;continue}
    const ra=N[v].fw*N[v].fh,rb=N[u].fw*N[u].fh;if(Math.max(ra,rb)/Math.min(ra,rb)>2.6){stale++;continue}
    const before=crossInc(N,UE,inc,[v,u]);
    let t=N[v].x;N[v].x=N[u].x;N[u].x=t;t=N[v].y;N[v].y=N[u].y;N[u].y=t;
    const after=crossInc(N,UE,inc,[v,u]);
    if(after<before){total-=before-after;stale=0}else{t=N[v].x;N[v].x=N[u].x;N[u].x=t;t=N[v].y;N[v].y=N[u].y;N[u].y=t;stale++}
  }
}
function circleStage(comp,N,UE,rand){
  const n=comp.length;if(n<3){comp.forEach((v,i)=>{N[v].x=i*N[v].fw*1.5;N[v].y=0});return}
  const set=new Set(comp);let order=[];const seen=new Set();
  const root=comp.reduce((a,b)=>N[b].wdeg>N[a].wdeg?b:a,comp[0]);
  const dfs=v=>{seen.add(v);order.push(v);N[v].nb.slice().sort((a,b)=>N[b].wdeg-N[a].wdeg).forEach(u=>{if(!seen.has(u)&&set.has(u))dfs(u)})};dfs(root);
  const es=UE.filter(e=>set.has(e[0]));
  const crossings=ord=>{const p=new Map(ord.map((v,i)=>[v,i]));let c=0;
    for(let i=0;i<es.length;i++){let [a,b]=[p.get(es[i][0]),p.get(es[i][1])];if(a>b)[a,b]=[b,a];
      for(let j=i+1;j<es.length;j++){let [x,y]=[p.get(es[j][0]),p.get(es[j][1])];if(x>y)[x,y]=[y,x];
        if(a===x||a===y||b===x||b===y)continue;if((a<x&&x<b&&b<y)||(x<a&&a<y&&y<b))c++}}return c};
  let best=order.slice(),bc=crossings(best);
  for(let k=0;k<24;k++){const p=new Map(best.map((v,i)=>[v,i])),bar=new Map();
    best.forEach(v=>{const nb=N[v].nb.filter(u=>set.has(u));if(!nb.length){bar.set(v,p.get(v));return}
      let sx=0,sy=0;nb.forEach(u=>{const a=p.get(u)/n*2*Math.PI;sx+=Math.cos(a);sy+=Math.sin(a)});
      let a=Math.atan2(sy,sx);if(a<0)a+=2*Math.PI;bar.set(v,a/(2*Math.PI)*n+(rand()-.5)*.01)});
    const cand=best.slice().sort((a,b)=>bar.get(a)-bar.get(b)),cc=crossings(cand);if(cc<=bc){best=cand;bc=cc}}
  const circ=best.reduce((s,v)=>s+N[v].fw*1.15,0),Rr=Math.max(120,circ/(2*Math.PI));
  best.forEach((v,i)=>{const a=i/n*2*Math.PI;N[v].x=Math.cos(a)*Rr;N[v].y=Math.sin(a)*Rr});
}
function layerStage(comp,N,UE){
  const set=new Set(comp),root=comp.reduce((a,b)=>N[b].wdeg>N[a].wdeg?b:a,comp[0]);
  const lvl=new Map([[root,0]]),q=[root];for(let h=0;h<q.length;h++)for(const u of N[q[h]].nb)if(!lvl.has(u)&&set.has(u)){lvl.set(u,lvl.get(q[h])+1);q.push(u)}
  const layers=[];q.forEach(v=>(layers[lvl.get(v)]||(layers[lvl.get(v)]=[])).push(v));
  const idx=new Map();layers.forEach(L=>L.forEach((v,i)=>idx.set(v,i)));
  const bary=(v,adj)=>{const nb=N[v].nb.filter(u=>set.has(u)&&adj(u));return nb.length?nb.reduce((s,u)=>s+idx.get(u),0)/nb.length:idx.get(v)};
  for(let s=0;s<8;s++){
    for(let l=1;l<layers.length;l++){layers[l].sort((a,b)=>bary(a,u=>lvl.get(u)===l-1)-bary(b,u=>lvl.get(u)===l-1));layers[l].forEach((v,i)=>idx.set(v,i))}
    for(let l=layers.length-2;l>=0;l--){layers[l].sort((a,b)=>bary(a,u=>lvl.get(u)===l+1)-bary(b,u=>lvl.get(u)===l+1));layers[l].forEach((v,i)=>idx.set(v,i))}}
  let x=0;layers.forEach(L=>{const w=Math.max(...L.map(v=>N[v].fw));const h=L.reduce((s,v)=>s+N[v].fh*1.1,0);let y=-h/2;
    L.forEach(v=>{N[v].x=x+w/2;N[v].y=y+N[v].fh*.55;y+=N[v].fh*1.1});x+=w*1.25+60});
}
function packComponents(comps,N,aspect){
  if(comps.length<=1){const c=comps[0]||[];if(!c.length)return;
    let x0=1e9,x1=-1e9,y0=1e9,y1=-1e9;c.forEach(v=>{const n=N[v];x0=Math.min(x0,n.x-n.fw/2);x1=Math.max(x1,n.x+n.fw/2);y0=Math.min(y0,n.y-n.fh/2);y1=Math.max(y1,n.y+n.fh/2)});
    const cx=(x0+x1)/2,cy=(y0+y1)/2;c.forEach(v=>{N[v].x-=cx;N[v].y-=cy});return}
  const boxes=comps.map(c=>{let x0=1e9,x1=-1e9,y0=1e9,y1=-1e9;c.forEach(v=>{const n=N[v];x0=Math.min(x0,n.x-n.fw/2);x1=Math.max(x1,n.x+n.fw/2);y0=Math.min(y0,n.y-n.fh/2);y1=Math.max(y1,n.y+n.fh/2)});
    return{c,x0,y0,w:x1-x0,h:y1-y0}}).sort((a,b)=>b.w*b.h-a.w*a.h);
  const m=36,area=boxes.reduce((s,b)=>s+(b.w+m)*(b.h+m),0),W0=Math.max(boxes[0].w+m,Math.sqrt(area*aspect)*1.08);
  let x=0,y=0,rowH=0,maxX=0;
  boxes.forEach(b=>{if(x>0&&x+b.w>W0){x=0;y+=rowH+m;rowH=0}
    const dx=x-b.x0,dy=y-b.y0;b.c.forEach(v=>{N[v].x+=dx;N[v].y+=dy});x+=b.w+m;rowH=Math.max(rowH,b.h);maxX=Math.max(maxX,x)});
  const tot=y+rowH,cx=(maxX-m)/2,cy=tot/2;comps.forEach(c=>c.forEach(v=>{N[v].x-=cx;N[v].y-=cy}));
}

/* ---------- mount ---------- */
function mount(host,opt){
  opt=opt||{};
  if(!cssDone){const s=document.createElement('style');s.textContent=CSS;document.head.appendChild(s);cssDone=true}
  host.innerHTML='';
  const root=document.createElement('div');root.className='gx';
  root.innerHTML=`<div class="gx-bar">
    <select data-r="layout" title="Layout algorithm"><option value="auto">Layout: Optimized</option><option value="radial">Radial tree</option><option value="force">Force-directed</option><option value="circle">Circular</option><option value="layers">Layered</option></select>
    <select data-r="labels" title="Label display"><option value="smart">Labels: smart</option><option value="all">Labels: all</option><option value="none">Labels: off</option></select>
    <button data-r="in" title="Zoom in">＋</button><button data-r="out" title="Zoom out">－</button><button data-r="fit" title="Fit and centre the whole graph">⤢ Fit</button><button data-r="re" title="Recompute the layout">↻ Re-layout</button><button data-r="full" title="Fill the whole screen">⛶ Full screen</button>
    <input data-r="find" type="text" placeholder="Find node…" size="10"><span class="gx-sp"></span><span class="gx-stat" data-r="stat"></span>
    <button data-r="png" title="Download PNG">PNG</button><button data-r="svg" title="Download SVG">SVG</button></div>
    <div class="gx-st"><canvas></canvas><div class="gx-leg" style="display:none"></div><div class="gx-tip"></div><div class="gx-msg"></div></div>`;
  host.appendChild(root);
  const $=s=>root.querySelector(s),st=$('.gx-st'),cv=$('canvas'),ctx=cv.getContext('2d'),tip=$('.gx-tip'),msg=$('.gx-msg'),leg=$('.gx-leg');
  const S={nodes:[],E:[],UE:[],k:1,tx:0,ty:0,W:600,H:400,dpr:1,sel:-1,hov:-1,auto:true,labels:'smart',layout:opt.layout||'auto',fontPx:opt.fontPx||12,rMin:opt.rMin||6,rMax:opt.rMax||22,pad:opt.pad||10,seed:7,stats:{},lbl:[],dirty:true,opt};
  $('[data-r=layout]').value=S.layout;
  const set=(sel,txt)=>{const e=$(sel);if(e)e.textContent=txt};

  function prep(){
    ctx.font=S.fontPx+'px '+FONT;
    const N=S.nodes,idx=new Map();N.forEach((n,i)=>{n.i=i;idx.set(n.id,i);n.nb=[];n.deg=0;n.wdeg=0});
    const seen=new Map(),UE=[],E=[];
    (S.rawE||[]).forEach(e=>{const s=idx.get(e.s),t=idx.get(e.t);if(s==null||t==null||s===t)return;
      E.push({s,t,w:e.w||1,color:e.color,dash:e.dash,label:e.label,dir:e.dir});
      const k=s<t?s+'|'+t:t+'|'+s,u=seen.get(k);
      if(u)u[2]+=e.w||1;else{const r=[Math.min(s,t),Math.max(s,t),e.w||1];seen.set(k,r);UE.push(r);N[s].nb.push(t);N[t].nb.push(s)}
      N[s].deg++;N[t].deg++;N[s].wdeg+=e.w||1;N[t].wdeg+=e.w||1});
    S.E=E;S.UE=UE;
    const mx=Math.max(1e-9,...N.map(n=>+n.size||1)),md=Math.max(1,...N.map(n=>n.deg));
    N.forEach(n=>{n.text=String(n.label??n.id);if(n.text.length>(opt.maxChars||30))n.text=n.text.slice(0,(opt.maxChars||30)-1)+'…';
      n.r=S.rMin+(S.rMax-S.rMin)*Math.sqrt(Math.max(0,(+n.size||1))/mx);n.lw=ctx.measureText(n.text).width;
      n.fw=Math.max(2*n.r,Math.min(n.lw,130)*.78)+S.pad;n.fh=2*n.r+S.fontPx+S.pad;
      n.imp=(+n.size||1)/mx+.35*n.deg/md+(n.pri||0)});
  }
  function layout(){
    const t0=performance.now(),N=S.nodes,rand=rng(S.seed);if(!N.length)return;
    if(S.layout==='fixed'){S.stats={nodes:N.length,edges:S.E.length,crossings:0,overlaps:overlapCount(N,N.map((n,i)=>i)),ms:0,comps:1};return}
    const comps=components(N),gap=Math.max(70,...N.map(n=>n.fw*.9)),L=Math.max(60,gap*.9);
    const iters=Math.max(60,Math.min(320,Math.round(90000/Math.max(8,N.length))));
    comps.forEach(c=>{
      if(S.layout==='circle'){circleStage(c,N,S.UE,rand);return}
      if(S.layout==='layers'){layerStage(c,N,S.UE);removeOverlap(c,N,rand);return}
      if(S.layout==='force'){c.forEach((v,i)=>{const a=i/c.length*2*Math.PI,r=L*Math.sqrt(c.length);N[v].x=Math.cos(a)*r;N[v].y=Math.sin(a)*r});forceStage(c,N,S.UE,L,iters,rand)}
      else{radialInit(c,N,gap);if(S.layout==='auto')forceStage(c,N,S.UE,L,Math.round(iters*.6),rand)}
      removeOverlap(c,N,rand);
      if(S.layout!=='radial'||true)reduceCrossings(c,N,S.UE,rand,Math.min(450,120+c.length*4));
      removeOverlap(c,N,rand,120)});
    const singles=comps.filter(c=>c.length===1),multi=comps.filter(c=>c.length>1);
    if(singles.length>1){const cols=Math.max(2,Math.ceil(Math.sqrt(singles.length*1.8))),cw=Math.max(...singles.map(c=>N[c[0]].fw))*1.04,ch=Math.max(...singles.map(c=>N[c[0]].fh))*1.04;
      singles.forEach((c,i)=>{N[c[0]].x=(i%cols)*cw;N[c[0]].y=Math.floor(i/cols)*ch});multi.push(singles.flat());packComponents(multi,N,S.W/Math.max(1,S.H))}
    else packComponents(comps,N,S.W/Math.max(1,S.H));
    for(let p=0;p<3;p++)removeOverlap(N.map((n,i)=>i),N,rand,60);
    N.forEach(n=>{n.bx=n.x;n.by=n.y});S.sx=1;S.sy=1;stretch();
    S.lastAspect=S.W/Math.max(1,S.H);
    S.stats={nodes:N.length,edges:S.E.length,crossings:countCross(N,S.UE),overlaps:overlapCount(N,N.map((n,i)=>i)),ms:Math.round(performance.now()-t0),comps:comps.length};
  }
  /* affine stretch so the layout fills the available aspect ratio; crossings are invariant, overlaps can only shrink */
  function stretch(){
    const N=S.nodes;if(S.layout==='fixed'||N.length<3||!S.W||!S.H)return;
    let x0=1e9,x1=-1e9,y0=1e9,y1=-1e9;N.forEach(n=>{x0=Math.min(x0,n.bx-n.fw/2);x1=Math.max(x1,n.bx+n.fw/2);y0=Math.min(y0,n.by-n.fh/2);y1=Math.max(y1,n.by+n.fh/2)});
    const w=Math.max(1,x1-x0),h=Math.max(1,y1-y0),target=Math.max(.3,(S.W-60)/Math.max(100,S.H-60)),cur=w/h;
    let sx=1,sy=1;if(cur<target*.92)sx=Math.min(target/cur,2.6);else if(cur>target/.92)sy=Math.min(cur/target,2.6);
    S.sx=sx;S.sy=sy;N.forEach(n=>{n.x=n.bx*sx;n.y=n.by*sy});
  }
  function bbox(){
    const N=S.nodes;if(!N.length)return null;let x0=1e9,x1=-1e9,y0=1e9,y1=-1e9;
    N.forEach(n=>{const hw=Math.max(n.r,Math.min(n.lw,130)/2/Math.max(.35,S.k)*.0+n.r),hh=n.r;x0=Math.min(x0,n.x-n.r);x1=Math.max(x1,n.x+n.r);y0=Math.min(y0,n.y-n.r);y1=Math.max(y1,n.y+n.r)});
    return{x0,x1,y0,y1};
  }
  function fit(anim){
    const b=bbox();if(!b)return;const padPx=Math.max(26,Math.min(60,Math.min(S.W,S.H)*.07)),lblPx=S.labels==='none'?0:Math.min(70,S.fontPx*5);
    const bw=Math.max(1,b.x1-b.x0),bh=Math.max(1,b.y1-b.y0);
    const k=Math.max(.01,Math.min((S.W-2*padPx-lblPx)/bw,(S.H-2*padPx-S.fontPx*2)/bh,opt.maxFit||2.2));
    const cx=(b.x0+b.x1)/2,cy=(b.y0+b.y1)/2,tx=S.W/2-cx*k,ty=S.H/2-cy*k;
    S.auto=true;
    if(anim&&!opt.noAnim){const a={k:S.k,tx:S.tx,ty:S.ty},t0=performance.now();const step=t=>{const p=Math.min(1,(t-t0)/260),e=p*(2-p);S.k=a.k+(k-a.k)*e;S.tx=a.tx+(tx-a.tx)*e;S.ty=a.ty+(ty-a.ty)*e;S.dirty=true;draw();if(p<1)requestAnimationFrame(step)};requestAnimationFrame(step)}
    else{S.k=k;S.tx=tx;S.ty=ty;S.dirty=true;draw()}
  }
  function resize(){
    const r=st.getBoundingClientRect();if(r.width<10||r.height<10)return;
    S.dpr=window.devicePixelRatio||1;S.W=Math.round(r.width);S.H=Math.round(r.height);
    cv.width=Math.round(S.W*S.dpr);cv.height=Math.round(S.H*S.dpr);
    if(S.auto){const a=S.W/S.H;if(S.nodes.length>2&&S.lastAspect&&Math.abs(a/S.lastAspect-1)>.1)stretch();S.lastAspect=a;fit(false)}else{S.dirty=true;draw()}
  }
  function placeLabels(){
    const N=S.nodes,k=S.k,tx=S.tx,ty=S.ty,W=S.W,H=S.H;
    ctx.font=S.fontPx+'px '+FONT;
    const out=new Array(N.length).fill(null);if(S.labels==='none')return out;
    const sc=N.map(n=>({x:n.x*k+tx,y:n.y*k+ty,r:Math.max(3.5,n.r*k)}));
    const boxes=[],h=S.fontPx+4;
    const order=N.map((n,i)=>i).sort((a,b)=>(N[b].imp+(b===S.sel||b===S.hov?9:0))-(N[a].imp+(a===S.sel||a===S.hov?9:0)));
    const hit=b=>{for(const o of boxes)if(b.x<o.x+o.w&&b.x+b.w>o.x&&b.y<o.y+o.h&&b.y+b.h>o.y)return true;return false};
    const hitN=(b,skip)=>{for(let j=0;j<sc.length;j++){if(j===skip)continue;const c=sc[j];if(c.x+c.r>b.x&&c.x-c.r<b.x+b.w&&c.y+c.r>b.y&&c.y-c.r<b.y+b.h)return true}return false};
    for(const i of order){const c=sc[i],n=N[i];if(c.x<-40||c.x>W+40||c.y<-20||c.y>H+20)continue;
      const w=n.lw+6,force=i===S.sel||i===S.hov||S.labels==='all';
      const cands=[[c.x-w/2,c.y+c.r+2],[c.x+c.r+3,c.y-h/2],[c.x-c.r-3-w,c.y-h/2],[c.x-w/2,c.y-c.r-2-h],[c.x+c.r*.7,c.y+c.r*.7],[c.x-c.r*.7-w,c.y+c.r*.7],[c.x+c.r*.7,c.y-c.r*.7-h],[c.x-c.r*.7-w,c.y-c.r*.7-h]];
      for(const [x,y] of cands){const b={x,y,w,h};if(x<2||y<2||x+w>W-2||y+h>H-2)continue;if(force||(!hit(b)&&!hitN(b,i))){out[i]=b;boxes.push(b);break}}
      if(!out[i]&&force){const b={x:Math.max(2,Math.min(W-w-2,c.x-w/2)),y:Math.max(2,Math.min(H-h-2,c.y+c.r+2)),w,h};out[i]=b;boxes.push(b)}}
    return out;
  }
  function draw(){
    if(!S.W)return;
    const N=S.nodes,k=S.k,tx=S.tx,ty=S.ty;
    ctx.setTransform(S.dpr,0,0,S.dpr,0,0);ctx.clearRect(0,0,S.W,S.H);
    if(opt.underlay){ctx.save();try{opt.underlay(ctx,S)}catch(e){}ctx.restore()}
    msg.style.display=N.length?'none':'flex';if(!N.length)return;
    const hov=S.hov>=0?S.hov:S.sel,nbs=hov>=0?new Set([hov,...N[hov].nb]):null;
    const dim=i=>nbs&&!nbs.has(i);
    const dense=S.E.length>350;
    S.E.forEach(e=>{const a=N[e.s],b=N[e.t],hl=nbs&&(e.s===hov||e.t===hov),dm=nbs&&!hl;
      ctx.globalAlpha=dm?.06:hl?.95:Math.min(.85,(dense?.18:(S.E.length<60?.62:.32))+Math.min(.4,e.w*.05));
      ctx.strokeStyle=hl?'#184e77':(e.color||'#8a9bb0');ctx.lineWidth=(hl?2:Math.min(3.2,.8+Math.log1p(e.w)*.45));
      ctx.setLineDash(e.dash?[5,4]:[]);
      const x1=a.x*k+tx,y1=a.y*k+ty,x2=b.x*k+tx,y2=b.y*k+ty;ctx.beginPath();ctx.moveTo(x1,y1);ctx.lineTo(x2,y2);ctx.stroke();
      if(e.dir){const dx=x2-x1,dy=y2-y1,d=Math.hypot(dx,dy)||1,r=Math.max(3.5,b.r*k)+2,px=x2-dx/d*r,py=y2-dy/d*r,ux=dx/d,uy=dy/d;ctx.setLineDash([]);ctx.fillStyle=ctx.strokeStyle;ctx.beginPath();ctx.moveTo(px,py);ctx.lineTo(px-ux*9+uy*4,py-uy*9-ux*4);ctx.lineTo(px-ux*9-uy*4,py-uy*9+ux*4);ctx.closePath();ctx.fill()}});
    ctx.setLineDash([]);
    N.forEach((n,i)=>{const x=n.x*k+tx,y=n.y*k+ty,r=Math.max(3.5,n.r*k);if(x<-r||x>S.W+r||y<-r||y>S.H+r)return;
      ctx.globalAlpha=dim(i)?.18:1;ctx.beginPath();ctx.arc(x,y,r,0,7);ctx.fillStyle=n.color||'#184e77';ctx.fill();
      ctx.lineWidth=i===S.sel?3:1.2;ctx.strokeStyle=i===S.sel?'#f59e0b':'#fff';ctx.stroke();
      if(n.cen){ctx.beginPath();ctx.arc(x,y,r+4,0,7);ctx.lineWidth=2.5;ctx.strokeStyle='#f59e0b';ctx.stroke()}
      if(n.fx){ctx.fillStyle='#fff';ctx.beginPath();ctx.arc(x,y,2,0,7);ctx.fill()}});
    if(S.dirty||!S.lbl.length||S.lbl.length!==N.length){S.lbl=placeLabels();S.dirty=false}
    ctx.font=S.fontPx+'px '+FONT;ctx.textBaseline='middle';
    N.forEach((n,i)=>{const b=S.lbl[i];if(!b)return;ctx.globalAlpha=dim(i)?.25:1;
      ctx.lineWidth=3.4;ctx.strokeStyle='rgba(255,255,255,.94)';ctx.lineJoin='round';ctx.strokeText(n.text,b.x+3,b.y+b.h/2);
      ctx.fillStyle=i===S.sel?'#92400e':'#162033';ctx.fillText(n.text,b.x+3,b.y+b.h/2)});
    if(S.rawE&&S.E.some(e=>e.label)&&(opt.edgeLabels==='always'||(S.E.length<=40&&k>.5))){
      ctx.font=(S.fontPx-1)+'px '+FONT;ctx.textAlign='center';ctx.textBaseline='middle';
      const taken=[];S.lbl.forEach(bx=>{if(bx)taken.push(bx)});N.forEach(n=>{const r=Math.max(3.5,n.r*k);taken.push({x:n.x*k+tx-r,y:n.y*k+ty-r,w:2*r,h:2*r})});
      const area=b=>{let s=0;for(const o of taken){const w=Math.min(b.x+b.w,o.x+o.w)-Math.max(b.x,o.x),h=Math.min(b.y+b.h,o.y+o.h)-Math.max(b.y,o.y);if(w>0&&h>0)s+=w*h}return s},few=S.E.length<=14;
      S.E.forEach(e=>{if(!e.label)return;const a=N[e.s],c=N[e.t],w=ctx.measureText(e.label).width+6,h=S.fontPx+3;let best=null;
        for(const f of [.5,.4,.6,.32,.68,.24,.76,.16,.84]){const x=(a.x+(c.x-a.x)*f)*k+tx,y=(a.y+(c.y-a.y)*f)*k+ty,b={x:x-w/2,y:y-h/2,w,h},ar=area(b);if(!best||ar<best.ar){best={x,y,b,ar}}if(ar===0)break}
        if(!best||(best.ar>0&&!few))return;taken.push(best.b);ctx.globalAlpha=nbs&&!(e.s===hov||e.t===hov)?.2:1;
        ctx.lineWidth=3.4;ctx.strokeStyle='rgba(255,255,255,.95)';ctx.strokeText(e.label,best.x,best.y);ctx.fillStyle='#1f4e8c';ctx.fillText(e.label,best.x,best.y)});
      ctx.textAlign='start'}
    ctx.globalAlpha=1;
    set('[data-r=stat]',`${S.stats.nodes||0} nodes · ${S.stats.edges||0} edges · crossings ${S.stats.crossings??'–'} · overlaps ${S.stats.overlaps??'–'} · ${Math.round(S.k*100)}%`);
  }
  function hit(px,py){const N=S.nodes;let best=-1,bd=1e9;N.forEach((n,i)=>{const x=n.x*S.k+S.tx,y=n.y*S.k+S.ty,r=Math.max(3.5,n.r*S.k)+4,d=Math.hypot(px-x,py-y);if(d<r&&d<bd){bd=d;best=i}});return best}
  /* interaction */
  const ptrs=new Map();let drag=null,pinch=null,moved=false;
  const pos=e=>{const r=cv.getBoundingClientRect();return[e.clientX-r.left,e.clientY-r.top]};
  const zoomAt=(px,py,f)=>{const nk=Math.max(.02,Math.min(8,S.k*f)),r=nk/S.k;S.tx=px-(px-S.tx)*r;S.ty=py-(py-S.ty)*r;S.k=nk;S.auto=false;S.dirty=true;draw()};
  cv.addEventListener('wheel',e=>{e.preventDefault();const [px,py]=pos(e);zoomAt(px,py,e.deltaY<0?1.14:.877)},{passive:false});
  cv.addEventListener('pointerdown',e=>{cv.setPointerCapture(e.pointerId);const [px,py]=pos(e);ptrs.set(e.pointerId,[px,py]);moved=false;
    if(ptrs.size===2){const [a,b]=[...ptrs.values()];pinch={d:Math.hypot(a[0]-b[0],a[1]-b[1])};drag=null;return}
    const i=hit(px,py);drag=i>=0?{node:i,ox:px,oy:py}:{pan:true,x:px-S.tx,y:py-S.ty};cv.classList.add('drag')});
  cv.addEventListener('pointermove',e=>{const [px,py]=pos(e);
    if(ptrs.has(e.pointerId))ptrs.set(e.pointerId,[px,py]);
    if(pinch&&ptrs.size===2){const [a,b]=[...ptrs.values()],d=Math.hypot(a[0]-b[0],a[1]-b[1]);if(pinch.d>0)zoomAt((a[0]+b[0])/2,(a[1]+b[1])/2,d/pinch.d);pinch.d=d;moved=true;return}
    if(drag){moved=true;
      if(drag.node!=null){const n=S.nodes[drag.node];n.x=(px-S.tx)/S.k;n.y=(py-S.ty)/S.k;n.bx=n.x/(S.sx||1);n.by=n.y/(S.sy||1);n.fx=true;S.auto=false}
      else{S.tx=px-drag.x;S.ty=py-drag.y;S.auto=false}
      S.dirty=true;draw();return}
    const i=hit(px,py);
    if(i!==S.hov){S.hov=i;S.dirty=true;draw()}
    if(i>=0){const n=S.nodes[i];tip.innerHTML=opt.tip?opt.tip(n):`<b>${esc(n.label)}</b>`;tip.style.display='block';tip.style.left=Math.min(S.W-200,px+14)+'px';tip.style.top=Math.min(S.H-40,py+12)+'px'}else tip.style.display='none'});
  const up=e=>{const [px,py]=pos(e);ptrs.delete(e.pointerId);if(ptrs.size<2)pinch=null;cv.classList.remove('drag');
    if(drag&&!moved){const i=hit(px,py);S.sel=i;S.dirty=true;draw();if(i>=0&&opt.onSelect)opt.onSelect(S.nodes[i]);else if(i<0&&opt.onSelect)opt.onSelect(null)}
    if(drag&&moved&&drag.node!=null){S.stats.crossings=countCross(S.nodes,S.UE);draw()}
    drag=null};
  cv.addEventListener('pointerup',up);cv.addEventListener('pointercancel',up);
  cv.addEventListener('pointerleave',()=>{tip.style.display='none';if(S.hov>=0){S.hov=-1;S.dirty=true;draw()}});
  cv.addEventListener('dblclick',e=>{const [px,py]=pos(e),i=hit(px,py);if(i>=0&&opt.onOpen)opt.onOpen(S.nodes[i]);else fit(true)});
  /* toolbar */
  root.addEventListener('click',e=>{const b=e.target.closest('button[data-r]');if(!b)return;const a=b.dataset.r;
    if(a==='in')zoomAt(S.W/2,S.H/2,1.3);if(a==='out')zoomAt(S.W/2,S.H/2,1/1.3);if(a==='fit')fit(true);
    if(a==='re'){S.seed=(S.seed*31+11)%100000;relayout()}
    if(a==='full'){root.classList.toggle('gx-full');b.classList.toggle('on',root.classList.contains('gx-full'));b.textContent=root.classList.contains('gx-full')?'✕ Exit full screen':'⛶ Full screen';setTimeout(()=>{resize();fit(false)},60)}
    if(a==='png')cv.toBlob(bl=>{const u=URL.createObjectURL(bl),l=document.createElement('a');l.href=u;l.download=(opt.name||'graph')+'.png';l.click();setTimeout(()=>URL.revokeObjectURL(u),2000)});
    if(a==='svg')dl(toSVG(),(opt.name||'graph')+'.svg','image/svg+xml')});
  root.querySelector('[data-r=layout]').onchange=e=>{S.layout=e.target.value;relayout()};
  root.querySelector('[data-r=labels]').onchange=e=>{S.labels=e.target.value;S.dirty=true;draw()};
  root.querySelector('[data-r=find]').oninput=e=>{const q=e.target.value.trim().toLowerCase();if(!q){S.sel=-1;S.dirty=true;draw();return}const i=S.nodes.findIndex(n=>String(n.label).toLowerCase().includes(q));if(i<0)return;S.sel=i;const n=S.nodes[i];S.k=Math.max(S.k,Math.min(1.6,.9));S.tx=S.W/2-n.x*S.k;S.ty=S.H/2-n.y*S.k;S.auto=false;S.dirty=true;draw()};
  const dl=(t,name,type)=>{const bl=new Blob([t],{type}),u=URL.createObjectURL(bl),l=document.createElement('a');l.href=u;l.download=name;l.click();setTimeout(()=>URL.revokeObjectURL(u),2000)};
  function toSVG(){
    const N=S.nodes,b=bbox()||{x0:0,x1:10,y0:0,y1:10},m=60,w=b.x1-b.x0+2*m,h=b.y1-b.y0+2*m;
    const sv=[`<svg xmlns="http://www.w3.org/2000/svg" viewBox="${b.x0-m} ${b.y0-m} ${w} ${h}" width="${Math.round(w)}" height="${Math.round(h)}" font-family="${FONT}"><rect x="${b.x0-m}" y="${b.y0-m}" width="${w}" height="${h}" fill="#fff"/>`];
    S.E.forEach(e=>{const a=N[e.s],c=N[e.t];sv.push(`<line x1="${a.x.toFixed(1)}" y1="${a.y.toFixed(1)}" x2="${c.x.toFixed(1)}" y2="${c.y.toFixed(1)}" stroke="${e.color||'#8a9bb0'}" stroke-opacity=".6" stroke-width="${Math.min(3,.8+Math.log1p(e.w)*.45).toFixed(2)}"/>`)});
    N.forEach(n=>sv.push(`<circle cx="${n.x.toFixed(1)}" cy="${n.y.toFixed(1)}" r="${n.r.toFixed(1)}" fill="${n.color||'#184e77'}" stroke="#fff"/>`+(S.labels==='none'?'':`<text x="${n.x.toFixed(1)}" y="${(n.y+n.r+13).toFixed(1)}" font-size="12" text-anchor="middle" fill="#162033" stroke="#fff" stroke-width="3" paint-order="stroke">${esc(n.text)}</text>`)));
    return sv.join('')+'</svg>';
  }
  function relayout(){layout();fit(false);S.dirty=true;draw()}
  const ro=typeof ResizeObserver!=='undefined'?new ResizeObserver(()=>{clearTimeout(S.rt);S.rt=setTimeout(resize,40)}):null;if(ro)ro.observe(st);else addEventListener('resize',resize);
  const api={
    setData(nodes,edges,o){S.nodes=(nodes||[]).map(n=>Object.assign({},n));S.rawE=edges||[];S.sel=-1;S.hov=-1;S.lbl=[];if(o&&o.layout){S.layout=o.layout;if(o.layout!=='fixed')root.querySelector('[data-r=layout]').value=o.layout}
      const fx=S.layout==='fixed';['[data-r=layout]','[data-r=re]'].forEach(q=>{const e=root.querySelector(q);if(e)e.style.display=fx?'none':''});
      msg.textContent=opt.empty||'Nothing to display for this selection.';
      const lg=(o&&o.legend)||opt.legend;if(lg&&lg.length){leg.style.display='block';leg.innerHTML=lg.map(x=>`<div><i style="background:${x.color}"></i>${esc(x.label)}</div>`).join('')}else leg.style.display='none';
      resize();prep();layout();S.auto=true;fit(false);S.dirty=true;draw();return api},
    fit,relayout,resize,select(id){const i=S.nodes.findIndex(n=>n.id===id);S.sel=i;S.dirty=true;draw()},
    stats:()=>Object.assign({k:S.k,tx:S.tx,ty:S.ty,W:S.W,H:S.H},S.stats),nodes:()=>S.nodes,state:S,toSVG,
    destroy(){if(ro)ro.disconnect();root.remove()}};
  return api;
}
window.GX={mount,_t:{countCross,overlapCount,segCross}};
})();
;
/* ---- semantic-links-js ---- */
/* ===== Semantic Layer — linked browser (add-on): every class, entity and value is a link; entity knowledge graphs ===== */
(()=>{
'use strict';
const D=document,Q=s=>D.querySelector(s),QA=s=>[...D.querySelectorAll(s)];
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fm=n=>Number(n).toLocaleString(),enc=encodeURIComponent,dec=decodeURIComponent;
const short=(s,n=38)=>{s=String(s||'');return s.length>n?s.slice(0,n-1)+'…':s};
const okUrl=u=>/^https?:\/\//i.test(String(u||''))?u:'';
const TY={
 paper:{l:'Papers',s:'Paper',c:'#184e77'},
 author:{l:'Authors',s:'Author',c:'#7c3aed',rel:'dcterms:creator'},
 journal:{l:'Journals',s:'Journal',c:'#047857',rel:'schema:isPartOf'},
 concept:{l:'Concepts (keywords)',s:'Concept',c:'#c2410c',rel:'dcterms:subject'},
 year:{l:'Years',s:'Year',c:'#475569',rel:'dcterms:issued'},
 publisher:{l:'Publishers',s:'Publisher',c:'#b45309',rel:'dcterms:publisher'},
 country:{l:'Countries',s:'Country',c:'#be123c',rel:'schema:location'}};
const BYNAME=Object.fromEntries(Object.entries(TY).map(([k,v])=>[v.s.toLowerCase(),k]));
const ONT=[['paper','author','dcterms:creator'],['paper','journal','schema:isPartOf'],['paper','concept','dcterms:subject'],['paper','publisher','dcterms:publisher'],['paper','year','dcterms:issued'],['journal','publisher','schema:publisher'],['publisher','country','schema:location']];
const css=D.createElement('style');css.textContent=`
#slx{margin:6px 0 12px}
#slx .slx-bar{display:flex;gap:6px;align-items:center;flex-wrap:wrap;margin:0 0 8px}
#slx .slx-bar button,#slx .slx-act button,#slx .slx-pg button{border:1px solid var(--line,#dfe4ec);background:#fff;border-radius:8px;padding:5px 10px;font-weight:600;color:var(--brand,#184e77);cursor:pointer;font-size:12.5px}
#slx .slx-bar button:disabled,#slx .slx-pg button:disabled{opacity:.4;cursor:default}
#slx .slx-bar button:hover:not(:disabled),#slx .slx-act button:hover,#slx .slx-pg button:hover:not(:disabled){background:#eaf0fb}
#slx .slx-crumb{font-size:13px;color:#51607a;display:flex;flex-wrap:wrap;gap:4px;align-items:center}
#slx a[data-go]{cursor:pointer;color:var(--brand,#184e77);text-decoration:none;border-bottom:1px dotted currentColor}#slx a[data-go]:hover{background:#eaf0fb}
.slx-link{cursor:pointer;color:var(--brand,#184e77)!important;text-decoration:none!important;border-bottom:1px dotted currentColor;font-weight:inherit}.slx-link:hover{background:#eaf0fb}
#slx .slx-chip{display:inline-flex;align-items:center;gap:5px;margin:2px 4px 2px 0;padding:3px 9px;border:1px solid var(--line,#dfe4ec);border-left:4px solid var(--c,#184e77);border-radius:999px;background:#fff;font-size:12.5px;border-bottom-width:1px;border-bottom-style:solid}
#slx .slx-chip small{color:#687386;font-size:11px}
#slx .slx-cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(138px,1fr));gap:7px;margin:8px 0}
#slx .slx-cards a{display:block;padding:7px 10px;border:1px solid var(--line,#dfe4ec);border-left:5px solid var(--c);border-radius:10px;background:#fff;border-bottom:1px solid var(--line,#dfe4ec)}
#slx .slx-cards b{display:block;font-size:14px;color:#152033}#slx .slx-cards span{font-size:12px;color:#687386}#slx .slx-cards em{font-style:normal;color:var(--brand,#184e77);font-weight:700;font-size:12px}
#slx h3{margin:14px 0 4px;font-size:15px;color:var(--brand,#184e77);border-bottom:1px solid var(--line,#dfe4ec);padding-bottom:3px}
#slx .slx-k{display:grid;grid-template-columns:repeat(auto-fill,minmax(120px,1fr));gap:8px;margin:8px 0}
#slx .slx-k div{border:1px solid var(--line,#dfe4ec);border-radius:10px;padding:7px 10px;background:#fff}#slx .slx-k b{display:block;font-size:19px}#slx .slx-k span{font-size:11.5px;color:#687386}
#slx table{width:100%;border-collapse:collapse;font-size:13px}#slx th,#slx td{padding:5px 7px;border-bottom:1px solid #e8edf4;text-align:left;vertical-align:top}#slx th{background:#f3f7fb;font-size:12px}#slx .n{text-align:right;white-space:nowrap}
#slx .slx-sub{font-size:11.5px;color:#687386}
#slx .slx-ctl{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin:8px 0}#slx .slx-ctl input,#slx .slx-ctl select{border:1px solid var(--line,#dfe4ec);border-radius:8px;padding:6px 8px;font:inherit;font-size:13px}
#slx .slx-az{display:flex;flex-wrap:wrap;gap:2px;margin:4px 0}#slx .slx-az button{min-width:26px;padding:3px 4px;border:1px solid var(--line,#dfe4ec);background:#fff;border-radius:6px;font-size:12px;cursor:pointer;color:var(--brand,#184e77)}#slx .slx-az button.on{background:var(--brand,#184e77);color:#fff}
#slx .slx-pg{display:flex;gap:6px;align-items:center;margin:8px 0;flex-wrap:wrap;font-size:12.5px}
#slx .slx-act{display:flex;gap:6px;flex-wrap:wrap;margin:8px 0}
#slx .slx-badge{display:inline-block;padding:2px 9px;border-radius:999px;color:#fff;font-size:12px;font-weight:700}
#slx .slx-tl{display:flex;gap:6px;align-items:flex-end;height:80px;margin:6px 0}#slx .slx-tl a{flex:1;max-width:70px;background:var(--c,#184e77);color:#fff;border-radius:5px 5px 0 0;text-align:center;font-size:11px;display:flex;align-items:flex-end;justify-content:center;border-bottom:0!important;min-height:18px}
#slx .slx-abs{background:#f8fafc;border:1px solid var(--line,#dfe4ec);border-radius:10px;padding:9px 11px;line-height:1.55;font-size:13px}
#slx .slx-gh{width:100%;margin:6px 0}
@media(max-width:700px){#slx .slx-cards{grid-template-columns:1fr 1fr}}`;
D.head.appendChild(css);

/* ---------- data index (built once, on demand) ---------- */
let IXc=null;
function IX(){
  if(IXc&&IXc.R===R)return IXc;
  const Mp={author:new Map(),journal:new Map(),concept:new Map(),year:new Map(),publisher:new Map(),country:new Map()},n=R.length;
  const PA=new Array(n),PC=new Array(n),PJ=new Array(n),PP=new Array(n),PO=new Array(n);
  const add=(t,k,l,i)=>{if(!k)return;const m=Mp[t];let e=m.get(k);if(!e){e={k,l,p:[],t};m.set(k,e)}if(e.p[e.p.length-1]!==i)e.p.push(i)};
  for(let i=0;i<n;i++){const r=R[i],ak=[],ck=[];
    splitAuthors(r[1]).forEach(a=>{a=String(a).trim();const k=norm(a);if(k&&!ak.includes(k)){ak.push(k);add('author',k,a,i)}});
    splitKeywords(r[11]).forEach(w=>{w=String(w).trim();const k=norm(w);if(k&&!ck.includes(k)){ck.push(k);add('concept',k,w,i)}});
    PA[i]=ak;PC[i]=ck;
    const js=source(r),ps=publisher(r),cs=country(r),y=r[3];PJ[i]=js?norm(js):'';PP[i]=ps?norm(ps):'';PO[i]=cs?String(cs).trim():'';
    if(js)add('journal',PJ[i],js,i);if(ps)add('publisher',PP[i],ps,i);if(cs)add('country',PO[i],cs,i);if(y)add('year',String(y),String(y),i)}
  return IXc={R,M:Mp,PA,PC,PJ,PP,PO}}
const cites=i=>+R[i][0]||0;
function stat(e){if(e.c!=null)return e;const c=e.p.map(cites).sort((a,b)=>b-a);let h=0;while(h<c.length&&c[h]>=h+1)h++;let s=0;c.forEach(v=>s+=v);
  const ys=e.p.map(i=>+R[i][3]||0).filter(Boolean);e.c=s;e.h=h;e.y0=ys.length?Math.min(...ys):0;e.y1=ys.length?Math.max(...ys):0;return e}
const keysOf=(i,t)=>{const X=IX();return t==='author'?X.PA[i]:t==='concept'?X.PC[i]:t==='journal'?(X.PJ[i]?[X.PJ[i]]:[]):t==='publisher'?(X.PP[i]?[X.PP[i]]:[]):t==='country'?(X.PO[i]?[X.PO[i]]:[]):(R[i][3]?[String(R[i][3])]:[])};
function related(papers,t,N,skip){const X=IX(),cnt=new Map();papers.forEach(i=>keysOf(i,t).forEach(k=>{if(k!==skip)cnt.set(k,(cnt.get(k)||0)+1)}));
  return [...cnt].sort((a,b)=>b[1]-a[1]).slice(0,N).map(([k,n])=>({e:X.M[t].get(k),n})).filter(x=>x.e)}
const go_=(t,k)=>`data-go="ent|${t}|${enc(k)}"`;
const chip=(t,e,n)=>`<a href="#" class="slx-chip" style="--c:${TY[t].c}" ${go_(t,e.k)}>${esc(e.l)}${n!=null?`<small>${n}</small>`:''}</a>`;
const chips=(arr,t)=>arr.length?arr.map(x=>chip(t,x.e,x.n)).join(''):'<span class="slx-sub">—</span>';
const lnk=(t,e,txt)=>e?`<a href="#" ${go_(t,e.k)}>${esc(txt||e.l)}</a>`:esc(txt||'');
function paperLink(i){return `<a href="#" ${go_('paper',i)}>${esc(R[i][2]||'(untitled)')}</a>`}
function copyText(t){try{if(navigator.clipboard&&navigator.clipboard.writeText)return navigator.clipboard.writeText(t)}catch(e){}const a=D.createElement('textarea');a.value=t;a.style.position='fixed';a.style.opacity='0';D.body.appendChild(a);a.select();try{D.execCommand('copy')}catch(e){}a.remove()}
const note=m=>{try{toast(m)}catch(e){}};
const csv=(name,head,rows)=>{const q=v=>'"'+String(v??'').replace(/"/g,'""')+'"',t=[head.map(q).join(',')].concat(rows.map(r=>r.map(q).join(','))).join('\n');try{download(name,t,'text/csv')}catch(e){const b=new Blob([t],{type:'text/csv'}),u=URL.createObjectURL(b),a=D.createElement('a');a.href=u;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(u),2000)}};

/* ---------- navigation ---------- */
let root=null,G=null,NAV={h:[{t:'home'}],i:0},pending=null,COUNTS={};
function go(v,push=true){if(push){const cur=NAV.h[NAV.i];if(JSON.stringify(cur)===JSON.stringify(v))return;NAV.h=NAV.h.slice(0,NAV.i+1);NAV.h.push(v);NAV.i++}render()}
function hashOf(v){return v.t==='dir'?'#sl/dir/'+v.type:v.t==='ent'?'#sl/ent/'+v.type+'/'+enc(v.key):''}
function setHash(v){try{const h=hashOf(v);if(h)history.replaceState(null,'',h);else if(location.hash.startsWith('#sl/'))history.replaceState(null,'',location.pathname+location.search)}catch(e){}}
function parseHash(h){const m=String(h||'').match(/^#sl\/(dir|ent)\/([a-z]+)(?:\/(.+))?$/);if(!m||!TY[m[2]])return null;return m[1]==='dir'?{t:'dir',type:m[2]}:{t:'ent',type:m[2],key:dec(m[3]||'')}}
function crumbs(v){const a=[`<a href="#" data-go="home">Ontology</a>`];
  if(v.t==='dir')a.push(`<b>${TY[v.type].l}</b>`);
  if(v.t==='ent'){a.push(`<a href="#" data-go="dir|${v.type}">${TY[v.type].l}</a>`);a.push(`<b>${esc(short(entLabel(v.type,v.key),60))}</b>`)}
  return a.join(' <span>›</span> ')}
function entLabel(t,k){if(t==='paper')return R[+k]?R[+k][2]:'Paper';const e=IX().M[t].get(k);return e?e.l:k}

/* ---------- views ---------- */
function render(){
  if(!root||!root.isConnected)return;
  if(G){try{G.destroy()}catch(e){}G=null}
  const v=NAV.h[NAV.i];
  root.innerHTML=`<div class="slx-bar"><button data-nav="-1" ${NAV.i<1?'disabled':''}>‹ Back</button><button data-nav="1" ${NAV.i>=NAV.h.length-1?'disabled':''}>Forward ›</button><div class="slx-crumb">${crumbs(v)}</div></div><div id="slxb"></div>`;
  const b=root.querySelector('#slxb');
  ({home:viewHome,dir:viewDir,ent:viewEnt})[v.t](b,v);setHash(v);
  const top=root.getBoundingClientRect().top;if(v.t!=='home'&&top<0){const sc=root.closest('#modalCard')||D.scrollingElement;try{root.scrollIntoView({block:'start'})}catch(e){}}}

function graphHost(el,h){const d=D.createElement('div');d.className='slx-gh';d.style.height=h+'px';el.appendChild(d);return d}
const gh=host=>{const card=Q('#modalCard');if(!card||!host)return 460;const off=host.getBoundingClientRect().top-card.getBoundingClientRect().top+card.scrollTop;return Math.max(400,Math.min(720,card.clientHeight-off-28))};

function viewHome(b){
  const cl=Object.keys(TY);
  b.innerHTML=`<div class="slx-sub" style="margin-bottom:4px"><b>Every class is a link.</b> Click a node (or a card below) to browse <b>all</b> its records — each author, journal, publisher, country, year, concept and paper opens its own page with a knowledge graph, and everything on those pages links onward.</div>
  <div class="slx-cards">${cl.map(t=>`<a href="#" style="--c:${TY[t].c}" data-go="dir|${t}"><b>${TY[t].l}</b><span>${COUNTS[t]!=null?fm(COUNTS[t])+' records':'browse all'}</span><em style="display:block">Open all →</em></a>`).join('')}</div>
  <div class="slx-ctl"><label><input type="checkbox" id="slxti"> Show top entities in the graph</label><label>per class <select id="slxtn"><option>3</option><option selected>5</option><option>8</option></select></label></div>
  <div id="slxg"></div>`;
  const draw=()=>{if(G){G.destroy();G=null}const host=Q('#slxg');host.innerHTML='';
    const inst=Q('#slxti').checked,per=+Q('#slxtn').value,build=()=>{
      const nodes=cl.map(t=>({id:t,label:TY[t].s+' · '+(COUNTS[t]!=null?fm(COUNTS[t]):'…'),size:t==='paper'?800:Math.max(60,Math.sqrt(COUNTS[t]||50)*5),color:TY[t].c,cls:t,pri:2})),edges=ONT.map(([a,c,l])=>({s:a,t:c,label:l,dir:true,w:3,color:'#64748b'}));
      if(inst){const X=IX();['author','journal','concept','publisher','country','year'].forEach(t=>{[...X.M[t].values()].sort((a,c)=>c.p.length-a.p.length).slice(0,per).forEach(e=>{const id=t+':'+e.k;nodes.push({id,label:e.l,size:Math.max(4,Math.sqrt(e.p.length)*2),color:TY[t].c+'bb',t,k:e.k,n:e.p.length});edges.push({s:id,t,dash:true,w:1,color:TY[t].c})})})}
      const d=graphHost(host,gh(host));
      G=GX.mount(d,{name:'ontology',edgeLabels:'always',rMin:inst?5:20,rMax:inst?20:44,maxChars:32,fontPx:12,
        tip:n=>n.cls?`<b>${esc(TY[n.cls].l)}</b><br>Click to browse all`:`<b>${esc(n.label)}</b><br>${fm(n.n)} paper(s) · click to open`,
        onSelect:n=>{if(!n)return;if(n.cls)go({t:'dir',type:n.cls});else go({t:'ent',type:n.t,key:n.k})}});
      G.setData(nodes,edges,{legend:cl.map(t=>({color:TY[t].c,label:TY[t].s}))})};
    if(inst){host.innerHTML='<div class="slx-sub">Indexing records…</div>';setTimeout(build,30)}else build()};
  draw();Q('#slxti').onchange=draw;Q('#slxtn').onchange=draw}

/* directory of all records of a class */
const DIR={};
function dirRows(t){
  if(DIR[t]&&DIR[t].R===R)return DIR[t].rows;const X=IX();let rows;
  if(t==='paper'){rows=R.map((r,i)=>({k:String(i),l:String(r[2]||'(untitled)'),n:1,c:+r[0]||0,y0:+r[3]||0,y1:+r[3]||0,x1:source(r)||'',x2:String(r[1]||''),h:(String(r[2]||'')+' '+String(r[1]||'')).toLowerCase()}))}
  else{rows=[...X.M[t].values()].map(e=>{stat(e);const o={k:e.k,l:e.l,n:e.p.length,c:e.c,y0:e.y0,y1:e.y1,h:e.l.toLowerCase()};
    if(t==='journal'){const f=e.p[0];o.x1=publisher(R[f])||'';o.x1k=X.PP[f];o.x2=(R[f][10]||'')}
    if(t==='publisher'||t==='country'){const s=new Set();e.p.forEach(i=>X.PJ[i]&&s.add(X.PJ[i]));o.x1=s.size}
    return o})}
  DIR[t]={R,rows};return rows}
function viewDir(b,v){
  const t=v.type;b.innerHTML=`<h3 style="margin-top:4px"><span class="slx-badge" style="background:${TY[t].c}">${TY[t].s}</span> All ${TY[t].l.toLowerCase()}</h3><p class="slx-sub">Preparing the list…</p>`;
  setTimeout(()=>{const rows=dirRows(t);COUNTS[t]=rows.length;let miss=0,flt='',sort=t==='paper'?'c':'n',letter='',page=0;const PS=100,hasAZ=t!=='year';
    const sortOpts=t==='paper'?[['c','Citations (high → low)'],['y','Year (newest)'],['l','Title A–Z']]:[['n','Papers (most → fewest)'],['c','Citations (high → low)'],['l','Name A–Z'],['y','Latest year']];
    const cols=t==='paper'?['Title','Year','Journal','Cites']:t==='journal'?['Journal','Publisher','Papers','Citations','Active']:t==='publisher'||t==='country'?[TY[t].s,'Journals','Papers','Citations','Active']:t==='year'?['Year','Papers','Citations']:[TY[t].s,'Papers','Citations','Active'];
    b.innerHTML=`<h3 style="margin-top:4px"><span class="slx-badge" style="background:${TY[t].c}">${TY[t].s}</span> All ${TY[t].l.toLowerCase()} <span class="slx-sub" id="slxc"></span></h3>
    ${(t==='country'||t==='publisher'||t==='journal')&&(miss=R.reduce((n,r)=>n+((t==='country'?country(r):t==='publisher'?publisher(r):source(r))?0:1),0))>0?`<div class="slx-sub">${fm(miss)} record(s) have no ${TY[t].s.toLowerCase()} value and are not listed here.</div>`:''}
    ${t==='concept'?`<div class="slx-sub">Keyword strings normalised for case and punctuation. The <b>Concepts (SKOS)</b> tab merges synonyms further${COUNTS.skos?` (${fm(COUNTS.skos)} concepts)`:''}.</div>`:''}
    <div class="slx-ctl"><input type="search" id="slxf" placeholder="Filter ${TY[t].l.toLowerCase()}…" size="30"><label>Sort <select id="slxs">${sortOpts.map(([k,l])=>`<option value="${k}">${l}</option>`).join('')}</select></label><button class="ghost" id="slxe" style="border:1px solid var(--line,#dfe4ec);background:#fff;border-radius:8px;padding:5px 10px;font-weight:600;color:var(--brand,#184e77);cursor:pointer">⬇ CSV (filtered)</button></div>
    ${hasAZ?`<div class="slx-az" id="slxa"></div>`:''}<div id="slxt"></div>`;
    let view=rows;const letterOf=l=>{const c=(l||'').trim().charAt(0).toUpperCase();return /[A-Z]/.test(c)?c:'#'};
    const draw=()=>{const f=flt.toLowerCase();view=rows.filter(r=>(!f||r.h.includes(f))&&(!letter||letterOf(r.l)===letter));
      view.sort((a,c)=>sort==='l'?a.l.localeCompare(c.l):sort==='y'?(c.y1-a.y1)||(c.c-a.c):sort==='c'?(c.c-a.c)||(c.n-a.n):(c.n-a.n)||(c.c-a.c));
      const pages=Math.max(1,Math.ceil(view.length/PS));page=Math.min(page,pages-1);const sl=view.slice(page*PS,page*PS+PS);
      Q('#slxc').textContent='· '+fm(view.length)+(view.length!==rows.length?' of '+fm(rows.length):'')+' shown';
      const row=r=>t==='paper'?`<tr><td><a href="#" ${go_('paper',r.k)}>${esc(r.l)}</a><div class="slx-sub">${esc(short(r.x2,90))}</div></td><td>${r.y0?`<a href="#" ${go_('year',String(r.y0))}>${r.y0}</a>`:''}</td><td>${esc(short(r.x1,40))}</td><td class="n">${fm(r.c)}</td></tr>`
        :t==='journal'?`<tr><td><a href="#" ${go_(t,r.k)}>${esc(r.l)}</a><div class="slx-sub">${esc(r.x2?'ISSN '+r.x2:'')}</div></td><td>${r.x1k&&IX().M.publisher.get(r.x1k)?`<a href="#" ${go_('publisher',r.x1k)}>${esc(r.x1)}</a>`:esc(r.x1)}</td><td class="n">${fm(r.n)}</td><td class="n">${fm(r.c)}</td><td>${r.y0?r.y0+'–'+r.y1:''}</td></tr>`
        :t==='publisher'||t==='country'?`<tr><td><a href="#" ${go_(t,r.k)}>${esc(r.l)}</a></td><td class="n">${fm(r.x1)}</td><td class="n">${fm(r.n)}</td><td class="n">${fm(r.c)}</td><td>${r.y0?r.y0+'–'+r.y1:''}</td></tr>`
        :t==='year'?`<tr><td><a href="#" ${go_(t,r.k)}>${esc(r.l)}</a></td><td class="n">${fm(r.n)}</td><td class="n">${fm(r.c)}</td></tr>`
        :`<tr><td><a href="#" ${go_(t,r.k)}>${esc(r.l)}</a></td><td class="n">${fm(r.n)}</td><td class="n">${fm(r.c)}</td><td>${r.y0?r.y0+(r.y1!==r.y0?'–'+r.y1:''):''}</td></tr>`;
      Q('#slxt').innerHTML=`<table><tr>${cols.map((c,i)=>`<th class="${i>0&&/Papers|Cites|Citations|Journals/.test(c)?'n':''}">${c}</th>`).join('')}</tr>${sl.map(row).join('')||`<tr><td colspan="${cols.length}" class="slx-sub">No matches.</td></tr>`}</table>
      <div class="slx-pg"><button data-p="0" ${page<1?'disabled':''}>« First</button><button data-p="${page-1}" ${page<1?'disabled':''}>‹ Prev</button><span>Page ${page+1} of ${fm(pages)}</span><button data-p="${page+1}" ${page>=pages-1?'disabled':''}>Next ›</button><button data-p="${pages-1}" ${page>=pages-1?'disabled':''}>Last »</button></div>`;
      if(hasAZ)Q('#slxa').innerHTML=['All',...'ABCDEFGHIJKLMNOPQRSTUVWXYZ#'].map(c=>`<button data-l="${c==='All'?'':c}" class="${(letter||'')===(c==='All'?'':c)?'on':''}">${c}</button>`).join('')};
    let tm;Q('#slxf').oninput=e=>{clearTimeout(tm);tm=setTimeout(()=>{flt=e.target.value.trim();page=0;draw()},160)};Q('#slxs').value=sort;Q('#slxs').onchange=e=>{sort=e.target.value;page=0;draw()};
    b.onclick=e=>{const p=e.target.closest('[data-p]'),l=e.target.closest('[data-l]');if(p&&!p.disabled){page=+p.dataset.p;draw()}if(l){letter=l.dataset.l;page=0;draw()}};
    Q('#slxe').onclick=()=>csv(t+'-directory.csv',t==='paper'?['title','authors','year','journal','citations']:['name','papers','citations','first_year','last_year'],view.map(r=>t==='paper'?[r.l,r.x2,r.y0,r.x1,r.c]:[r.l,r.n,r.c,r.y0,r.y1]));
    draw()},20)}

/* entity page (author, journal, publisher, country, year, concept, paper) */
function kgFor(t,key){
  const X=IX(),nodes=new Map(),edges=[],seenE=new Set();
  const addN=(ty,k,label,size,ex)=>{const id=ty+':'+k;if(!nodes.has(id))nodes.set(id,Object.assign({id,label,size,color:TY[ty].c,t:ty,k:String(k)},ex||{}));return id};
  const addE=(s,c,label,dash)=>{const id=s+'>'+c;if(seenE.has(id))return;seenE.add(id);edges.push({s,t:c,label,dir:true,w:2,dash,color:'#7b8aa0'})};
  const lab=(ty,k)=>{const e=X.M[ty].get(k);return e?e.l:k};
  let papers;
  if(t==='paper'){const i=+key;papers=[i];const pid=addN('paper',i,short(R[i][2],42),90,{pri:9,n:cites(i)});
    // related papers sharing keywords/authors
    const sc=new Map();[...X.PC[i]].forEach(k=>{const e=X.M.concept.get(k);if(e&&e.p.length<400)e.p.forEach(j=>{if(j!==i)sc.set(j,(sc.get(j)||0)+1)})});X.PA[i].forEach(k=>{const e=X.M.author.get(k);if(e&&e.p.length<200)e.p.forEach(j=>{if(j!==i)sc.set(j,(sc.get(j)||0)+2)})});
    [...sc].sort((a,b)=>b[1]-a[1]||cites(b[0])-cites(a[0])).slice(0,4).forEach(([j])=>{const q=addN('paper',j,short(R[j][2],36)+' ('+R[j][3]+')',25,{n:cites(j)});addE(pid,q,'related',true)})}
  else{const e=X.M[t].get(key);if(!e)return{nodes:[],edges:[],legend:[]};stat(e);papers=e.p.slice().sort((a,b)=>cites(b)-cites(a)).slice(0,8);addN(t,key,e.l,140,{pri:9,n:e.p.length,cen:1})}
  papers.forEach(i=>{const pid=addN('paper',i,short(R[i][2],34)+' ('+R[i][3]+')',22+Math.sqrt(cites(i))*2,{n:cites(i)});
    const want={author:t==='paper'?8:3,journal:1,concept:t==='paper'?6:2,publisher:(t==='paper'||t==='publisher'||t==='country')?1:0,year:(t==='paper'||t==='year')?1:0,country:0};
    ['author','journal','concept','publisher','year'].forEach(ty=>{let ks=keysOf(i,ty);if(ty===t&&t!=='paper')ks=[key];else ks=ks.slice(0,want[ty]);if(ty===t&&t==='paper')return;
      ks.forEach(k=>{const id=addN(ty,k,lab(ty,k),14,{n:(X.M[ty].get(k)||{p:[]}).p.length});addE(pid,id,TY[ty].rel)})});
    if(t==='country'||t==='paper'){const k=X.PP[i],c=X.PO[i];if(k&&c&&(t==='country'?c===key:true)){const pidn='publisher:'+k;if(nodes.has(pidn)&&c){const cid=addN('country',c,lab('country',c),16,{n:(X.M.country.get(c)||{p:[]}).p.length});addE(pidn,cid,'schema:location')}}}
    if(t==='journal'||t==='paper'){const jk=X.PJ[i],pk=X.PP[i];if(jk&&pk&&nodes.has('journal:'+jk)&&nodes.has('publisher:'+pk))addE('journal:'+jk,'publisher:'+pk,'schema:publisher')}});
  const deg=new Map();edges.forEach(e=>{deg.set(e.s,(deg.get(e.s)||0)+1);deg.set(e.t,(deg.get(e.t)||0)+1)});
  nodes.forEach(n=>{if(!n.cen&&n.t!=='paper'&&n.pri!==9)n.size=10+(deg.get(n.id)||1)*14});
  const present=[...new Set([...nodes.values()].map(n=>n.t))];
  return{nodes:[...nodes.values()],edges,legend:present.map(ty=>({color:TY[ty].c,label:TY[ty].s}))}}

function entityGraph(el,t,key){
  const d=kgFor(t,key);if(d.nodes.length<2){el.innerHTML='<div class="slx-sub">Not enough linked data to draw a graph.</div>';return}
  const host=graphHost(el,Math.max(420,Math.min(620,innerHeight-260)));
  G=GX.mount(host,{name:'knowledge-graph-'+t,edgeLabels:d.nodes.length<=34?'always':'auto',rMin:7,rMax:30,maxChars:30,fontPx:12,
    tip:n=>`<b>${esc(n.label)}</b><br>${TY[n.t].s}${n.t==='paper'?' · '+fm(n.n)+' citations':' · '+fm(n.n)+' paper(s)'}<br><i>click to open</i>`,
    onSelect:n=>{if(n&&n.t&&!n.cen&&!(n.t===t&&n.k===String(key)))go({t:'ent',type:n.t,key:n.k})}});
  G.setData(d.nodes,d.edges,{legend:d.legend})}

function paperTable(papers,id,lim){
  const X=IX(),sorted=papers.slice().sort((a,b)=>cites(b)-cites(a));let n=lim||15;
  const html=()=>`<table><tr><th>Paper</th><th>Year</th><th>Journal</th><th class="n">Cites</th></tr>${sorted.slice(0,n).map(i=>{const r=R[i],au=X.PA[i].slice(0,3).map(k=>{const e=X.M.author.get(k);return e?lnk('author',e):''}).join('; ');
    return `<tr><td>${paperLink(i)}<div class="slx-sub">${au}${X.PA[i].length>3?' et al.':''}</div></td><td>${r[3]?lnk('year',X.M.year.get(String(r[3])),String(r[3])):''}</td><td>${X.PJ[i]?lnk('journal',X.M.journal.get(X.PJ[i])):''}</td><td class="n">${fm(cites(i))}</td></tr>`}).join('')}</table>${sorted.length>n?`<div class="slx-pg"><button data-more="${id}">Show ${Math.min(25,sorted.length-n)} more (${fm(sorted.length-n)} left)</button></div>`:''}`;
  return{html,more(){n+=25}}}

function viewEnt(b,v){
  const t=v.type,key=v.key,X=IX();let e=null,papers,title,sub='';
  if(t==='paper'){const i=+key;if(!R[i]){b.innerHTML='<div class="note">Record not found.</div>';return}papers=[i];title=R[i][2]||'(untitled)'}
  else{e=X.M[t].get(key);if(!e){b.innerHTML=`<div class="note">“${esc(key)}” was not found in the current dataset.</div>`;return}stat(e);papers=e.p;title=e.l}
  const act=`<div class="slx-act"><button data-a="search">⌕ Search library for this</button><button data-a="kg">⌘ Open in app Knowledge Graph</button><button data-a="csv">⬇ Papers (CSV)</button><button data-a="copy">🔗 Copy link</button></div>`;
  let body='';
  if(t==='paper'){const o=recObj(+key),i=+key,doi=o.doi?'https://doi.org/'+o.doi:okUrl(o.url);
    const au=X.PA[i].map(k=>X.M.author.get(k)).filter(Boolean),ky=X.PC[i].map(k=>X.M.concept.get(k)).filter(Boolean);
    body=`<div class="slx-k"><div><b>${fm(cites(i))}</b><span>Citations</span></div><div><b>${r4(R[i][3])}</b><span>Year</span></div><div><b>${au.length}</b><span>Authors</span></div></div>
    <h3>Authors</h3>${au.map(a=>chip('author',a,a.p.length)).join('')||'—'}
    <h3>Published in</h3>${X.PJ[i]?chip('journal',X.M.journal.get(X.PJ[i]),X.M.journal.get(X.PJ[i]).p.length):''}${X.PP[i]?chip('publisher',X.M.publisher.get(X.PP[i])):''}${X.PO[i]?chip('country',X.M.country.get(X.PO[i])):''}${R[i][3]?chip('year',X.M.year.get(String(R[i][3]))):''}${o.issn?`<span class="slx-sub"> ISSN ${esc(o.issn)}</span>`:''}
    <h3>Concepts / keywords</h3>${ky.map(k=>chip('concept',k,k.p.length)).join('')||'—'}
    ${doi?`<h3>Identifiers</h3><div><a href="${esc(doi)}" target="_blank" rel="noopener noreferrer">${esc(doi)} ↗</a></div>`:''}
    ${o.abstract?`<h3>Abstract</h3><div class="slx-abs">${esc(o.abstract)}</div>`:''}`;
    sub=`${au.slice(0,3).map(a=>esc(a.l)).join('; ')}${au.length>3?' et al.':''} · ${R[i][3]||''}`}
  else{
    const k5=[['Papers',fm(e.p.length)],['Citations',fm(e.c)],['h-index',e.h],['Mean cites',(e.c/e.p.length).toFixed(1)],['Active',e.y0?e.y0+(e.y1!==e.y0?'–'+e.y1:''):'–']];
    const sec=(h,html)=>`<h3>${h}</h3>${html}`,yrs=(()=>{const c=new Map();e.p.forEach(i=>{const y=R[i][3];if(y)c.set(y,(c.get(y)||0)+1)});const a=[...c].sort((x,y)=>x[0]-y[0]),mx=Math.max(1,...a.map(x=>x[1]));return a.length>1&&t!=='year'?`<div class="slx-tl" style="--c:${TY[t].c}">${a.map(([y,n])=>`<a href="#" ${go_('year',String(y))} title="${y}: ${n} paper(s)" style="height:${Math.max(18,n/mx*76)}px">${y}</a>`).join('')}</div>`:''})();
    const R_=(ty,n)=>chips(related(e.p,ty,n,ty===t?key:null),ty);let rel='';
    if(t==='author')rel=sec('Co-authors',R_('author',30))+sec('Journals',R_('journal',14))+sec('Publishers',R_('publisher',8))+sec('Countries',R_('country',8))+sec('Concepts / keywords',R_('concept',30));
    if(t==='journal')rel=sec('Publisher &amp; country',R_('publisher',3)+R_('country',3))+sec('Authors',R_('author',30))+sec('Concepts / keywords',R_('concept',30));
    if(t==='publisher')rel=sec('Journals',R_('journal',60))+sec('Countries',R_('country',5))+sec('Authors',R_('author',30))+sec('Concepts / keywords',R_('concept',30));
    if(t==='country')rel=sec('Publishers',R_('publisher',20))+sec('Journals',R_('journal',30))+sec('Authors',R_('author',30))+sec('Concepts / keywords',R_('concept',30));
    if(t==='year')rel=sec('Journals',R_('journal',30))+sec('Authors',R_('author',30))+sec('Concepts / keywords',R_('concept',40))+sec('Countries',R_('country',10));
    if(t==='concept')rel=sec('Related concepts',R_('concept',36))+sec('Authors',R_('author',30))+sec('Journals',R_('journal',16))+sec('Countries',R_('country',8));
    body=`<div class="slx-k">${k5.map(([l,v])=>`<div><b>${v}</b><span>${l}</span></div>`).join('')}</div>${yrs}${rel}`;
    sub=`${fm(e.p.length)} papers · ${fm(e.c)} citations`}
  b.innerHTML=`<h3 style="margin-top:4px"><span class="slx-badge" style="background:${TY[t].c}">${TY[t].s}</span> ${esc(title)}</h3><div class="slx-sub">${esc(sub)}</div>${act}
  <h3>Knowledge graph</h3><div class="slx-sub">The centre is this ${TY[t].s.toLowerCase()}; papers connect it to related authors, journals, publishers and concepts. Click any node to open it. Edge labels are the ontology properties.</div><div id="slxeg"></div>
  <div id="slxbody">${body}</div>${t==='paper'?'':`<h3>Papers (${fm(papers.length)})</h3><div id="slxpt"></div>`}`;
  entityGraph(Q('#slxeg'),t,key);
  let PT=null;if(t!=='paper'){PT=paperTable(papers,'pt',15);const draw=()=>{Q('#slxpt').innerHTML=PT.html()};draw();Q('#slxpt').onclick=ev=>{if(ev.target.dataset.more){PT.more();draw()}}}
  else{const o=recObj(+key);Q('#slxbody').insertAdjacentHTML('beforeend',`<div class="slx-act"><button data-a="detail">Open full record</button></div>`)}
  b.querySelector('.slx-act').onclick=ev=>{const a=ev.target.dataset.a;if(!a)return;
    if(a==='search'){const q=t==='paper'?title:t==='year'?String(title):title;Q('#q').value=q;closeModal();Q('#searchForm').requestSubmit()}
    if(a==='kg'){try{const hits=papers.slice().sort((x,y)=>cites(y)-cites(x)).slice(0,80).map(i=>({i,score:1,why:[]}));closeModal();kgOpen(hits,'results')}catch(er){note('Knowledge graph is unavailable for this selection')}}
    if(a==='csv')csv(t+'-papers.csv',['title','authors','year','journal','citations','doi'],papers.map(i=>[R[i][2],R[i][1],R[i][3],source(R[i]),cites(i),R[i][9]||'']));
    if(a==='copy'){copyText(location.href.split('#')[0]+hashOf(v));note('Link copied')}};
  const dtl=b.querySelector('[data-a=detail]');if(dtl)dtl.onclick=()=>detail(+key)}
const r4=y=>y||'–';

function viewHomeCounts(){const X=IX();for(const t of Object.keys(X.M))COUNTS[t]=X.M[t].size;COUNTS.paper=R.length}

/* ---------- mount into the Ontology tab ---------- */
function parseCounts(svg){const txt=svg.textContent;[['paper','Paper'],['author','Author'],['journal','Journal'],['concept','Concept'],['year','Year'],['publisher','Publisher'],['country','Country']].forEach(([t,l])=>{const m=txt.match(new RegExp(l+'\\s*([\\d,]+)\\s*instances'));if(m)COUNTS[t]=+m[1].replace(/,/g,'')});COUNTS.skos=COUNTS.concept}
function mount(host,svg){
  if(svg.dataset.sl)return;parseCounts(svg);
  const r=D.createElement('div');r.id='slx';svg.dataset.sl='1';svg.replaceWith(r);root=r;
  r.addEventListener('click',ev=>{const nav=ev.target.closest('[data-nav]');if(nav&&!nav.disabled){NAV.i=Math.max(0,Math.min(NAV.h.length-1,NAV.i+ +nav.dataset.nav));render();return}
    const a=ev.target.closest('a[data-go]');if(!a)return;ev.preventDefault();const p=a.dataset.go.split('|');
    if(p[0]==='home')go({t:'home'});else if(p[0]==='dir')go({t:'dir',type:p[1]});else if(p[0]==='ent')go({t:'ent',type:p[1],key:dec(p[2])})});
  // class names in the existing tables become links
  host.querySelectorAll('table td').forEach(td=>{if(td.dataset.sl)return;const tx=td.textContent.trim().toLowerCase(),t=BYNAME[tx];if(t&&td.children.length<=1&&!td.querySelector('a')){td.dataset.sl='1';const lab=td.textContent.trim();td.innerHTML=`<a href="#" class="slx-link" data-slc="${t}">${esc(lab)}</a>`}});
  NAV={h:[{t:'home'}],i:0};
  if(pending){NAV.h.push(pending);NAV.i=1;pending=null}
  render();
  setTimeout(()=>{try{const X=IX();Object.keys(X.M).forEach(t=>COUNTS[t]=X.M[t].size);COUNTS.paper=R.length;if(root&&root.isConnected&&NAV.h[NAV.i].t==='home')render()}catch(e){}},80)}
D.addEventListener('click',ev=>{const a=ev.target.closest&&ev.target.closest('a.slx-link');if(!a)return;ev.preventDefault();ev.stopPropagation();
  const c=a.dataset.slc;if(c){if(root&&root.isConnected)go({t:'dir',type:c});else{pending={t:'dir',type:c};toOntology()}return}
  const v={t:'ent',type:a.dataset.slt,key:a.dataset.slk};if(root&&root.isConnected){go(v);try{root.scrollIntoView({block:'start'})}catch(e){}}else{pending=v;toOntology()}},true);
function toOntology(){const b=QA('#modalCard .tabs button').find(x=>/^\s*Ontology\s*$/.test(x.textContent));if(b)b.click()}

/* ---------- link values in the other Semantic Layer tabs (authors, journals, publishers, countries, keywords) ---------- */
function linkify(scope){
  if(!scope||!D.querySelector('#modal.open'))return;
  const X=IX(),order=['journal','publisher','country','author'];let nTouched=0;
  scope.querySelectorAll('td,li').forEach(el=>{if(nTouched>900||el.dataset.sl||el.closest('#slx'))return;if(el.querySelector('a,button,input,select,svg,table'))return;
    const tx=(el.textContent||'').trim();if(tx.length<2||tx.length>150||/^[\d\s.,%–\-+/:()]+$/.test(tx))return;const k=norm(tx);let hit=null;
    for(const ty of order){const e=X.M[ty].get(k);if(e){hit=[ty,e];break}}
    if(!hit){const col=colHeader(el);if(/keyword|concept|topic|term|subject/i.test(col)){const e=X.M.concept.get(k);if(e)hit=['concept',e]}}
    if(!hit)return;el.dataset.sl='1';nTouched++;const a=D.createElement('a');a.href='#';a.className='slx-link';a.dataset.slt=hit[0];a.dataset.slk=hit[1].k;a.title='Open '+TY[hit[0]].s+' page';a.textContent=el.textContent;el.textContent='';el.appendChild(a)})}
function colHeader(td){if(td.tagName!=='TD')return'';const tr=td.parentElement,tb=tr&&tr.closest('table');if(!tb)return'';const i=[...tr.children].indexOf(td),h=tb.querySelector('tr');return h&&h.children[i]?h.children[i].textContent:''}

/* ---------- observer ---------- */
let t0=0,busy=false;
function scan(){
  if(busy)return;const host=D.getElementById('x3b');if(!host||!D.querySelector('#modal.open'))return;
  const svg=host.querySelector(':scope > svg');
  busy=true;try{
    if(svg&&/dcterms:creator/.test(svg.textContent)&&!svg.dataset.sl){mount(host,svg)}
    else if(!host.querySelector('#slx')){const tab=(QA('#modalCard .tabs button.on')[0]||{}).textContent||'';if(/Productivity|Impact|Performance|Semantic search/i.test(tab))linkify(host)}
    else if(root&&root.isConnected){host.querySelectorAll('table td:not([data-sl])').forEach(td=>{const t=BYNAME[td.textContent.trim().toLowerCase()];if(t&&!td.closest('#slx')){td.dataset.sl='1';td.innerHTML=`<a href="#" class="slx-link" data-slc="${t}">${esc(td.textContent.trim())}</a>`}})}
  }catch(e){console.warn('semantic-links',e)}finally{busy=false;if(mo)mo.takeRecords()}}
let mo=null;
function start(){const tgt=D.getElementById('modalBody')||D.body;mo=new MutationObserver(()=>{clearTimeout(t0);t0=setTimeout(scan,120)});mo.observe(tgt,{childList:true,subtree:true})}
const _cm=window.closeModal;if(typeof _cm==='function')window.closeModal=function(){try{if(G){G.destroy();G=null}if(location.hash.startsWith('#sl/'))history.replaceState(null,'',location.pathname+location.search)}catch(e){}root=null;return _cm.apply(this,arguments)};
start();
/* deep links: …#sl/ent/author/<key> opens the Semantic Layer on that page */
function openFromHash(){const v=parseHash(location.hash);if(!v)return;const tryOpen=()=>{if(typeof R==='undefined'||!R||!R.length||typeof openSemanticLayer!=='function'){setTimeout(tryOpen,300);return}pending=v;openSemanticLayer()};tryOpen()}
addEventListener('hashchange',()=>{if(location.hash.startsWith('#sl/')&&!(root&&root.isConnected))openFromHash()});
if(location.hash.startsWith('#sl/'))openFromHash();
window.SemanticLinks={open:(t,k)=>{pending=k==null?{t:'dir',type:t}:{t:'ent',type:t,key:String(k)};if(root&&root.isConnected){go(pending);pending=null}else{if(!D.querySelector('#modal.open'))openSemanticLayer();else toOntology()}}};
})();
;
/* ---- kg-clarity-js ---- */
/* ===== KG clarity layer: numbered papers, readable halo labels, focus highlighting, clickable type legend, results + key-findings panel ===== */
(()=>{
'use strict';
if(typeof KG==='undefined'||typeof kgDraw!=='function')return;
const Q=s=>document.querySelector(s),QA=s=>[...document.querySelectorAll(s)];
const E=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const TC=t=>KG_COLORS[t]||'#64748b',cut=(s,n)=>{s=String(s||'');return s.length>n?s.slice(0,n-1)+'…':s};
const st=document.createElement('style');st.textContent=`
.kgx-leg{position:absolute;left:10px;top:10px;right:10px;display:flex;flex-wrap:wrap;gap:5px;z-index:2;pointer-events:none}
.kgx-chip{pointer-events:auto;display:inline-flex;align-items:center;gap:6px;border:1px solid #cbd5e1;background:rgba(255,255,255,.95);border-radius:999px;padding:3px 10px 3px 8px;font:600 12px system-ui,sans-serif;color:#1e293b;cursor:default}
button.kgx-chip{cursor:pointer}button.kgx-chip:hover{background:#eef5fb;border-color:#93b4d3}.kgx-chip.off{opacity:.45;text-decoration:line-through}
.kgx-chip i{width:11px;height:11px;border-radius:50%;display:inline-block}.kgx-chip b{color:#475569;font-weight:700}
.kgx-selbox{position:sticky;top:-12px;z-index:3;background:#fff;border-bottom:2px solid #dbe5f0;margin:-4px -4px 10px;padding:4px 4px 8px;max-height:44%;overflow:auto}
.kgx-sec{border-top:1px solid var(--line);margin-top:10px;padding-top:6px}.kgx-sec>summary{cursor:pointer;font-weight:700;font-size:13px;padding:3px 0}
.kgx-it{display:flex;gap:8px;align-items:flex-start;width:100%;text-align:left;border:1px solid transparent;background:#fff;border-radius:8px;padding:5px 6px;margin:2px 0;font:inherit;font-size:12px;cursor:pointer;color:#1e293b}
.kgx-it:hover,.kgx-it:focus{background:#eef5fb;border-color:#b6cde3}.kgx-it.on{background:#fff4e0;border-color:#f59e0b}
.kgx-rk{flex:none;min-width:22px;height:22px;border-radius:50%;color:#fff;font-weight:700;font-size:11px;display:inline-flex;align-items:center;justify-content:center}
.kgx-tx{flex:1;min-width:0;line-height:1.3}.kgx-tx small{display:block;color:#64748b;font-size:11px}.kgx-ct{flex:none;font-weight:700;color:#475569}
.kgx-sub{font-size:11px;font-weight:700;color:#64748b;margin:8px 0 2px}
`;document.head.appendChild(st);

function label(n){return n.type==='paper'?((n.rank?n.rank+'. ':'')+n.label):n.label}
window.kgDraw=function(){
 if(!KG.ctx||!KG.canvas)return;
 const ctx=KG.ctx,rect=KG.canvas.getBoundingClientRect(),dpr=Math.min(2,window.devicePixelRatio||1);
 ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,rect.width,rect.height);ctx.fillStyle='#fbfcfe';ctx.fillRect(0,0,rect.width,rect.height);
 const foc=KG.selected||KG.hover,off=KG.hiddenRel||new Set(),nb=new Set(),sc=KG.scale,L=[];
 if(foc){nb.add(foc);KG.edges.forEach(e=>{if(e.a===foc||e.b===foc){nb.add(e.a);nb.add(e.b)}})}
 ctx.save();ctx.translate(KG.tx,KG.ty);ctx.scale(sc,sc);ctx.lineCap='round';
 KG.edges.forEach(e=>{if(off.has(e.relation))return;
  const act=foc&&(e.a===foc||e.b===foc),dim=foc&&!act,col=e.relation==='related paper'?'109,40,217':e.hit?'217,119,6':'71,85,105';
  ctx.strokeStyle=`rgba(${col},${dim?.07:act?.95:e.hit?.8:.4})`;ctx.lineWidth=(act?2.8:e.hit?2.1:1.3)/Math.sqrt(sc);
  ctx.beginPath();ctx.moveTo(e.a.x,e.a.y);ctx.lineTo(e.b.x,e.b.y);ctx.stroke();
  const dx=e.b.x-e.a.x,dy=e.b.y-e.a.y,d=Math.hypot(dx,dy)||1,r=kgRadius(e.b)+4,ux=dx/d,uy=dy/d;
  if(!dim&&d>r*3){const tx=e.b.x-ux*r,ty=e.b.y-uy*r;ctx.fillStyle=ctx.strokeStyle;ctx.beginPath();ctx.moveTo(tx,ty);ctx.lineTo(tx-ux*8-uy*4,ty-uy*8+ux*4);ctx.lineTo(tx-ux*8+uy*4,ty-uy*8-ux*4);ctx.fill()}
  if((KG.showEdgeLabels||act)&&sc>.5&&!dim){let ang=Math.atan2(dy,dx);if(ang>Math.PI/2||ang<-Math.PI/2)ang+=Math.PI;ctx.save();ctx.translate((e.a.x+e.b.x)/2,(e.a.y+e.b.y)/2);ctx.rotate(ang);ctx.font='600 10px system-ui';const w=ctx.measureText(e.relation).width;ctx.fillStyle='rgba(255,255,255,.95)';ctx.fillRect(-w/2-3,-8,w+6,13);ctx.fillStyle=e.hit?'#b45309':'#334155';ctx.textAlign='center';ctx.fillText(e.relation,0,2);ctx.restore()}
 });
 KG.nodes.forEach(n=>{
  const kz=Math.min(1.9,1/Math.sqrt(Math.max(.3,sc))),r=Math.max(9,kgRadius(n)+2)*kz,isSel=KG.selected===n,faded=foc&&!nb.has(n);ctx.globalAlpha=faded?.22:1;
  if(isSel){ctx.beginPath();ctx.arc(n.x,n.y,r+7,0,Math.PI*2);ctx.fillStyle='rgba(245,158,11,.28)';ctx.fill()}
  ctx.beginPath();ctx.arc(n.x,n.y,r,0,Math.PI*2);ctx.fillStyle=TC(n.type);ctx.fill();
  ctx.lineWidth=2.5/Math.max(.6,sc);ctx.strokeStyle=isSel?'#111827':n.hit?'#f59e0b':'#ffffff';ctx.stroke();
  if(n.type==='paper'&&n.rank&&r*sc>=7){ctx.fillStyle='#fff';ctx.font='700 '+Math.min(r*1.15,13/sc)+'px system-ui';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(String(n.rank),n.x,n.y+.5)}
  const root=n.type==='query'||n.root,show=foc?nb.has(n)||root:(root||n.hit||n.type==='paper'||(n.weight||1)>1||KG.nodes.length<=40);
  if(show)L.push({x:n.x,y:n.y,r,l:cut(root?n.label:n.type==='paper'?n.label:n.label,n.type==='paper'?40:30),pre:n.type==='paper'&&n.rank?'':'',col:n.type==='paper'?'#17314f':TC(n.type),pri:isSel?0:(foc&&nb.has(n))?1:(root||n.hit)?2:n.type==='paper'?3:4,must:foc&&nb.has(n),bold:root||n.hit||isSel,faded});
 });
 ctx.globalAlpha=1;ctx.restore();
 ctx.save();ctx.setTransform(dpr,0,0,dpr,0,0);ctx.textAlign='center';ctx.textBaseline='alphabetic';ctx.lineJoin='round';
 const boxes=[];
 L.sort((a,b)=>a.pri-b.pri).forEach(o=>{
  const sx=o.x*sc+KG.tx,sy=o.y*sc+KG.ty+o.r*sc+15;if(sx<-80||sx>rect.width+80||sy<-20||sy>rect.height+20)return;
  ctx.font=(o.bold?'700 13px':'600 12px')+' system-ui, sans-serif';
  const w=ctx.measureText(o.l).width+6,x0=sx-w/2,y0=sy-12,h=17;
  if(!o.must&&boxes.some(b=>x0<b.x1&&x0+w>b.x0&&y0<b.y1&&y0+h>b.y0))return;
  boxes.push({x0,x1:x0+w,y0,y1:y0+h});
  ctx.globalAlpha=o.faded?.35:1;ctx.strokeStyle='rgba(255,255,255,.96)';ctx.lineWidth=4;ctx.strokeText(o.l,sx,sy);ctx.fillStyle=o.col;ctx.fillText(o.l,sx,sy);
 });
 ctx.restore();
};
window.kgDrawLabels=function(){};

function legend(){
 const stg=Q('.kg-stage');if(!stg)return;let el=stg.querySelector('.kgx-leg');
 if(!el){el=document.createElement('div');el.className='kgx-leg';stg.appendChild(el);
  el.addEventListener('click',e=>{const b=e.target.closest('[data-kgt]');if(!b)return;const cb=QA('.kgType').find(x=>x.value===b.dataset.kgt);if(cb){cb.checked=!cb.checked;if(cb.onchange)cb.onchange()}})}
 const c={};KG.nodes.forEach(n=>{if(n.type!=='query'&&!n.root)c[n.type]=(c[n.type]||0)+1});
 const cbs=QA('.kgType'),types=[...new Set(['paper',...Object.keys(c),...cbs.map(x=>x.value)])];
 el.innerHTML=types.map(t=>{const cb=cbs.find(x=>x.value===t),n=c[t]||0;if(!cb&&!n)return '';const tag=cb?'button type="button"':'span';
  return `<${tag} class="kgx-chip${cb&&!cb.checked?' off':''}" ${cb?`data-kgt="${t}" title="${cb.checked?'Click to hide':'Click to show'} ${E(KG_NAMES[t]||t)}"`:''}><i style="background:${TC(t)}"></i>${E(KG_NAMES[t]||t)} <b>${n}</b></${cb?'button':'span'}>`}).join('')}

function panel(){
 const dg=new Map();KG.edges.forEach(e=>{dg.set(e.a,(dg.get(e.a)||0)+1);dg.set(e.b,(dg.get(e.b)||0)+1)});
 const ix=n=>KG.nodes.indexOf(n),papers=KG.nodes.filter(n=>n.type==='paper').sort((a,b)=>(a.rank||999)-(b.rank||999)||(b.cites||0)-(a.cites||0));
 let h='';
 if(papers.length)h+=`<details class="kgx-sec" open><summary>Papers in this graph (${papers.length})</summary>${papers.slice(0,60).map(n=>`<button type="button" class="kgx-it" data-kgi="${ix(n)}"><span class="kgx-rk" style="background:${TC('paper')}">${n.rank||'•'}</span><span class="kgx-tx">${E(cut(n.label,90))}<small>${n.year||''}${n.cites!=null?' · cited '+Number(n.cites).toLocaleString()+'×':''}</small></span></button>`).join('')}</details>`;
 const groups=[['author','Authors'],['journal','Journals'],['keyword','Keywords'],['concept','Concepts'],['publisher','Publishers'],['place','Places'],['year','Years']].map(([t,T])=>{const l=KG.nodes.filter(n=>n.type===t).sort((a,b)=>(dg.get(b)||0)-(dg.get(a)||0)).slice(0,5);return l.length?`<div class="kgx-sub">${T}, most connected</div>`+l.map(n=>`<button type="button" class="kgx-it" data-kgi="${ix(n)}"><span class="kgx-tx">${E(cut(n.label,60))}</span><span class="kgx-ct">${dg.get(n)||0}</span></button>`).join(''):''}).join('');
 if(groups)h+=`<details class="kgx-sec" open><summary>Key findings</summary>${groups}</details>`;
 return h}
const _s=window.kgStats;
window.kgStats=function(){const base=_s.apply(this,arguments);try{legend()}catch(e){}let p='';try{p=panel()}catch(e){}return base+p};
const _o=window.kgOpen;
window.kgOpen=function(){
 const r=_o.apply(this,arguments),side=Q('.kg-side'),stats=Q('#kgStats');
 if(side&&!side.dataset.kgx){side.dataset.kgx='1';const h4=QA('.kg-side h4').find(x=>/Selected node/i.test(x.textContent)),sel=Q('#kgSelection');
  if(h4&&sel){const w=document.createElement('div');w.className='kgx-selbox';side.insertBefore(w,side.firstChild);w.appendChild(h4);w.appendChild(sel)}}
 if(stats&&!stats.dataset.kgx){stats.dataset.kgx='1';stats.addEventListener('click',e=>{const b=e.target.closest('[data-kgi]');if(!b)return;const n=KG.nodes[+b.dataset.kgi];if(!n)return;kgSelect(n);
  const rc=KG.canvas.getBoundingClientRect();KG.tx=rc.width/2-n.x*KG.scale;KG.ty=rc.height/2-n.y*KG.scale;kgDraw();
  QA('.kgx-it.on').forEach(x=>x.classList.remove('on'));b.classList.add('on');const sb=Q('.kgx-selbox');if(sb)sb.scrollTop=0})}
 try{legend();kgDraw()}catch(e){}
 return r};
})();
;
/* ---- diamond-oa-js ---- */
/* ===== Diamond OA tab: existing dataset or online (OpenAlex), grouped by discipline and national/international publisher, with knowledge graphs ===== */
(()=>{'use strict';
const Q=s=>document.querySelector(s),X=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])),N=x=>Number(x).toLocaleString();
const NAT=[['IN','India',['India']],['GB','United Kingdom',['United Kingdom','England']],['US','United States',['United States of America','United State of America','United State of america','USA','America']],['NL','Netherlands',['Netherlands']],['DE','Germany',['Germany']],['SE','Sweden',['Sweden']],['CA','Canada',['Canada']],['IR','Iran',['Iran']],['SG','Singapore',['Singapore']],['AU','Australia',['Australia']],['KR','South Korea',['South Korea']],['BR','Brazil',['Brazil']],['ID','Indonesia',['Indonesia']],['MX','Mexico',['Mexico']],['ES','Spain',['Spain']],['FR','France',['France']],['CN','China',['China']],['JP','Japan',['Japan']],['ZA','South Africa',['South Africa']],['NG','Nigeria',['Nigeria']]];
const TH=[['AI, data and technology',/artificial intelligence|machine learning|deep learning|chatgpt|generative|big data|data science|blockchain|natural language/],['Bibliometrics and scientometrics',/bibliometr|scientometr|altmetr|citation|h-index|impact factor|research evaluation|research performance/],['Knowledge organisation and semantic web',/ontolog|semantic|linked data|metadata|knowledge graph|taxonom|catalogu|classification|thesaur/],['Scholarly communication and open access',/open access|scholarly|publishing|peer review|repositor|open science|preprint|predatory|open data/],['Digital libraries and preservation',/digital librar|digiti[sz]|archiv|preservation|digital collection/],['Information literacy and education',/literacy|education|teaching|student|curricul|training|e-learning/],['Information behaviour and users',/information seeking|behaviou?r|reading|satisfaction|awareness|attitude|perception/],['Library services and management',/librar|service|management|space|covid/]];
const theme=t=>{t=(t||'').toLowerCase();for(const[n,rx]of TH)if(rx.test(t))return n;return 'Other topics'};
const S={mode:'data',q:'',nat:'IN',pages:1,items:[],vis:[],sel:{},shown:100,busy:false,msg:''};
const nat=()=>NAT.find(n=>n[0]===S.nat)||NAT[0];
const scopeOf=(code,name)=>{const n=nat();if(S.mode==='data'){if(!name)return 'Unspecified';return n[2].includes(name)?'National':'International'}return code?(code===n[0]?'National':'International'):'Unspecified'};
function dataSearch(q){const o=[];for(let i=0;i<R.length;i++){const r=relevance(i,q),s=typeof r==='number'?r:r.score;if(s>0||!q.trim()){const c=country(R[i]);o.push({i,s})}}
 o.sort((a,b)=>b.s-a.s||R[b.i][0]-R[a.i][0]);
 return o.slice(0,3000).map(({i,s})=>{const r=recObj(i);return {idx:i,score:s,title:r.title,authors:r.authors,year:r.year,source:r.source,publisher:r.publisher,country:r.country,place:r.place,url:r.url,doi:r.doi,keywords:r.keywords,abstract:r.abstract,cites:r.cites,scope:scopeOf('',r.country),disc:theme(r.title+' '+r.keywords)}})}
async function onlineSearch(q,pages){let res=[];const mail='&mailto=research-explorer@example.com';
 for(let p=1;p<=pages;p++){S.msg=`Searching OpenAlex for diamond open access articles… page ${p} of ${pages}`;out();
  const r=await fetch(`https://api.openalex.org/works?search=${encodeURIComponent(q)}&filter=open_access.oa_status:diamond,type:article&per_page=100&page=${p}&select=id,doi,title,publication_year,cited_by_count,authorships,primary_location,primary_topic,keywords${mail}`);
  if(!r.ok)throw new Error('OpenAlex answered '+r.status);const j=await r.json();res=res.concat(j.results||[]);if((j.results||[]).length<100)break}
 const ids=[...new Set(res.map(w=>w.primary_location&&w.primary_location.source&&w.primary_location.source.id).filter(Boolean))].map(u=>u.split('/').pop()),src={};
 S.msg='Looking up publisher countries…';out();
 await Promise.all(Array.from({length:Math.ceil(ids.length/50)},async(_,k)=>{try{const r=await fetch(`https://api.openalex.org/sources?filter=openalex:${ids.slice(k*50,k*50+50).join('|')}&per_page=50&select=id,country_code,host_organization,host_organization_name,display_name,homepage_url${mail}`);if(r.ok)(await r.json()).results.forEach(s=>src[s.id.split('/').pop()]=s)}catch(e){}}));
 const pb={};const hosts=[...new Set(Object.values(src).map(s=>(s.host_organization||'').split('/').pop()).filter(Boolean))];S.msg='Looking up publisher websites…';out();
await Promise.all(Array.from({length:Math.ceil(hosts.length/50)},async(_,k)=>{try{const r=await fetch(`https://api.openalex.org/publishers?filter=openalex:${hosts.slice(k*50,k*50+50).join('|')}&per_page=50&select=id,display_name,homepage_url${mail}`);if(r.ok)(await r.json()).results.forEach(p=>pb[p.id.split('/').pop()]=p)}catch(e){}}));
const safeU=u=>/^https?:\/\//.test(u||'')?u:'';
return res.filter(w=>w.title).map((w,k)=>{const ps=w.primary_location&&w.primary_location.source||{},sid=(ps.id||'').split('/').pop(),s=src[sid]||{},pt=w.primary_topic||{},cc=(s.country_code||'').toUpperCase();
  const kw=[...(w.keywords||[]).map(x=>x.display_name||x.keyword),pt.subfield&&pt.subfield.display_name,pt.display_name].filter(Boolean).join('; ');
  return {idx:null,score:0,title:w.title,authors:(w.authorships||[]).slice(0,10).map(a=>a.author&&a.author.display_name).filter(Boolean).join('; '),year:w.publication_year||'',source:ps.display_name||'',publisher:s.host_organization_name||ps.host_organization_name||ps.display_name||'',country:cc,place:'',url:w.doi||w.id,pu:safeU((pb[(s.host_organization||'').split('/').pop()]||{}).homepage_url||s.homepage_url),ju:safeU(s.homepage_url),doi:(w.doi||'').replace(/^https?:\/\/(dx\.)?doi\.org\//,''),keywords:kw,abstract:'',cites:w.cited_by_count||0,scope:scopeOf(cc),disc:pt.field&&pt.field.display_name||'Unclassified'}})}
const grp=(a,f)=>{const m=new Map();a.forEach(x=>{const k=f(x),e=m.get(k)||{k,n:0,National:0,International:0,Unspecified:0,c:x.country,u:x.pu||''};e.n++;e[x.scope]++;m.set(k,e)});return[...m.values()].sort((a,b)=>b.n-a.n)};
const chip=(t,k)=>`<span class="dx-chip">${X(t)} <button type="button" data-clear="${k}" aria-label="Remove filter">×</button></span>`;
function out(){const el=Q('#dxOut');if(!el)return;if(S.busy||!S.items.length){el.innerHTML=`<p class="tiny">${X(S.busy?S.msg:S.msg||'Enter a topic and press Search.')}</p>`;return}
 const it=S.items,f=S.sel,vis=S.vis=it.filter(x=>(!f.d||x.disc===f.d)&&(!f.p||x.publisher===f.p)&&(!f.s||x.scope===f.s)&&(!f.j||x.source===f.j)),c=s=>it.filter(x=>x.scope===s).length;
 const pubs=s=>grp(it.filter(x=>x.scope===s),x=>x.publisher||'(not stated)').slice(0,12),pt=(s,t)=>`<div><h4>${t}</h4>${pubs(s).map(e=>`<div class="dx-row"><span>${e.u?`<a class="dx-name" href="${X(e.u)}" target="_blank" rel="noopener">${X(e.k)}</a>`:`<button type="button" class="dx-name" data-p="${X(e.k)}" data-s="${s}">${X(e.k)}</button>`}${e.c?` <small>${X(e.c)}</small>`:''}</span><button type="button" class="dx-cnt" data-p="${X(e.k)}" data-s="${s}"><b>${N(e.n)}</b></button></div>`).join('')||'<p class="tiny">None</p>'}</div>`;
 const jn=f.d?(()=>{const m=new Map();it.filter(x=>x.disc===f.d).forEach(x=>{const k=x.source||'(not stated)';const e=m.get(k)||{k,n:0,u:'',p:x.publisher||''};e.n++;if(!e.u&&x.ju)e.u=x.ju;m.set(k,e)});return[...m.values()].sort((a,b)=>b.n-a.n)})():null;
 const jl=jn?`<h3>Journals in ${X(f.d)}</h3><div class="dx-jl">${jn.map(e=>`<div class="dx-row"><span>${e.u?`<a class="dx-name" href="${X(e.u)}" target="_blank" rel="noopener">${X(e.k)}</a>`:`<button type="button" class="dx-name" data-j="${X(e.k)}">${X(e.k)}</button>`}${e.p?` <small>${X(e.p)}</small>`:''}</span><button type="button" class="dx-cnt" data-j="${X(e.k)}"><b>${N(e.n)}</b></button></div>`).join('')}</div>`:'';
el.innerHTML=`<div class="dx-kpis"><div><b>${N(it.length)}</b>results</div><div><b>${N(c('National'))}</b>national (${X(nat()[1])})</div><div><b>${N(c('International'))}</b>international</div><div><b>${N(c('Unspecified'))}</b>country not stated</div></div>
 <h3>By discipline</h3><table class="dx-t"><tr><th>${S.mode==='data'?'Theme (keyword rules)':'Discipline (OpenAlex field)'}</th><th>National</th><th>International</th><th>Total</th></tr>${grp(it,x=>x.disc).map(e=>`<tr><td><button type="button" class="dx-link" data-d="${X(e.k)}">${X(e.k)}</button></td><td><button type="button" class="dx-link" data-d="${X(e.k)}" data-s="National">${N(e.National)}</button></td><td><button type="button" class="dx-link" data-d="${X(e.k)}" data-s="International">${N(e.International)}</button></td><td><b>${N(e.n)}</b></td></tr>`).join('')}</table>
 ${jl}<h3>By publisher source</h3><div class="dx-two">${pt('National','National publishers')}${pt('International','International publishers')}</div>
 <div class="dx-bar"><b>Results${f.d||f.p||f.s||f.j?' (filtered)':''}: ${N(vis.length)}</b>${f.d?chip(f.d,'d'):''}${f.p?chip(f.p,'p'):''}${f.s?chip(f.s,'s'):''}${f.j?chip(f.j,'j'):''}<span class="sp"></span><button class="ghost" data-act="kgall">Knowledge Graph: all results</button>${f.d||f.p||f.s||f.j?'<button class="ghost" data-act="kgvis">Knowledge Graph: filtered view</button>':''}<button class="ghost" data-act="csv">Export CSV</button></div>
 <ol class="dx-list">${vis.slice(0,S.shown).map((x,k)=>`<li><a href="${S.mode==='data'?'#':X(x.url||'#')}" ${S.mode==='data'?'':'target="_blank" rel="noopener"'} data-i="${k}">${X(x.title)}</a><div class="tiny">${X((x.authors||'').slice(0,110))} · ${X(x.year)} · ${x.ju?`<a href="${X(x.ju)}" target="_blank" rel="noopener">${X(x.source)}</a>`:X(x.source)} · ${X(x.publisher)}${x.country?' ('+X(x.country)+')':''} · <b class="dx-${x.scope}">${x.scope}</b> · ${X(x.disc)}${x.cites?' · cited '+N(x.cites)+'×':''}</div></li>`).join('')}</ol>${vis.length>S.shown?'<button class="ghost" data-act="more">Show more</button>':''}`}
async function run(){S.q=Q('#dxQ').value.trim();S.nat=Q('#dxNat').value;S.pages=+Q('#dxPg').value;S.sel={};S.shown=100;
 if(S.mode==='online'&&!S.q){S.msg='Type a topic for the online search.';out();return}
 S.busy=true;S.msg='Searching…';out();
 try{S.items=S.mode==='data'?dataSearch(S.q):await onlineSearch(S.q,S.pages);S.msg=S.items.length?'':'No records found. Try broader words.'}
 catch(e){S.items=[];S.msg='The online search failed ('+(e.message||e)+'). Check the internet connection and try again.'}
 S.busy=false;out()}
function graph(list){if(!list.length){toast('No results to graph');return}
 if(S.mode==='data'){kgOpen(list.map(x=>({i:x.idx,score:x.score||1})),'results');return}
 window.__lastOnlineResults=list;kgOpenOnline(list,S.q)}
function csv(list){const q=v=>'"'+String(v==null?'':v).replace(/"/g,'""')+'"';download('diamond-oa-results.csv','title,authors,year,journal,publisher,publisher_country,scope,discipline,citations,doi\n'+list.map(x=>[x.title,x.authors,x.year,x.source,x.publisher,x.country,x.scope,x.disc,x.cites,x.doi].map(q).join(',')).join('\n'),'text/csv')}
function open(){S.items=[];S.msg='';$('#modalCard').classList.add('x2-wide');
 showModal(`<div class="x3 dx"><h2>💎 Diamond Open Access Explorer</h2>
 <p class="tiny">Diamond open access means articles are free to read and free to publish in: the journal charges neither readers nor authors. Choose a source, search, then browse the results by discipline and by country or international publisher.</p>
 <div class="dx-modes" role="radiogroup" aria-label="Search source"><label><input type="radio" name="dxm" value="data" checked> Existing dataset <small>(${N(R.length)} records, works offline)</small></label><label><input type="radio" name="dxm" value="online"> Online search <small>(OpenAlex, diamond OA articles)</small></label></div>
 <div class="dx-form"><input id="dxQ" type="search" placeholder="Topic, e.g. information literacy" aria-label="Search topic"><label>Country =<select id="dxNat">${NAT.map(n=>`<option value="${n[0]}"${n[0]===S.nat?' selected':''}>${n[1]}</option>`).join('')}</select></label><label id="dxPgL" hidden>Results<select id="dxPg"><option value="1">100</option><option value="2">200</option><option value="3">300</option></select></label><button id="dxGo" class="primary">Search</button></div>
 <p class="tiny" id="dxNote">Existing dataset: the records are not tagged by fee model, so this option searches all ${N(R.length)} records. Themes come from keyword rules; national means the record's country matches your choice.</p>
 <div id="dxOut"></div></div>`);
 const root=Q('.dx');root.onchange=e=>{if(e.target.name==='dxm'){S.mode=e.target.value;S.items=[];S.msg='';Q('#dxPgL').hidden=S.mode==='data';Q('#dxNote').textContent=S.mode==='data'?`Existing dataset: the records are not tagged by fee model, so this option searches all ${N(R.length)} records. Themes come from keyword rules; national means the record's country matches your choice.`:'Online: articles in diamond open access journals from OpenAlex (a live service; needs internet). Discipline is the OpenAlex field; publisher country comes from the journal record. Click a publisher or journal name to open its website; click a number to filter the results.';out()}if(e.target.id==='dxNat'&&S.items.length)run()};
 Q('#dxPg').onchange=null;Q('#dxGo').onclick=run;Q('#dxQ').onkeydown=e=>{if(e.key==='Enter')run()};
 root.onclick=e=>{const t=e.target.closest('button,a');if(!t)return;const d=t.dataset;
  if(d.clear){delete S.sel[d.clear];S.shown=100;out()}
  else if(d.act==='more'){S.shown+=200;out()}else if(d.act==='csv')csv(S.vis)
  else if(d.act==='kgall')graph(S.items.slice(0,60));else if(d.act==='kgvis')graph(S.vis.slice(0,60))
  else if(d.i!==undefined&&t.tagName==='A'){const x=S.vis[+d.i];if(S.mode==='data'){e.preventDefault();x4Detail?x4Detail(x.idx,()=>open(),'Back'):detail(x.idx)}}
  else if(d.j){S.sel.j=d.j;S.shown=100;out()}
  else if(d.d||d.p){if(d.d)S.sel.d=d.d;if(d.p)S.sel.p=d.p;if(d.s)S.sel.s=d.s;S.shown=100;out()}}}
const st=document.createElement('style');st.textContent=`.dx-modes{display:flex;gap:18px;flex-wrap:wrap;margin:8px 0}.dx-modes label{border:1px solid #cbd5e1;border-radius:10px;padding:8px 12px;background:#fff;font-weight:600}.dx-modes small{font-weight:400;color:#64748b}
.dx-form{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin:6px 0}.dx-form input[type=search]{flex:1;min-width:220px;padding:8px 10px;border:1px solid #cbd5e1;border-radius:8px}.dx-form label{font-size:12px;display:flex;gap:6px;align-items:center}.dx-form select{padding:6px;border-radius:8px;border:1px solid #cbd5e1}
.dx-kpis{display:flex;gap:10px;flex-wrap:wrap;margin:10px 0}.dx-kpis div{flex:1;min-width:130px;border:1px solid #dbe5f0;background:#f8fafc;border-radius:10px;padding:8px 12px;font-size:12px;color:#475569}.dx-kpis b{display:block;font-size:22px;color:#0f3b57}
table.dx-t{width:100%;border-collapse:collapse;font-size:13px}.dx-t th,.dx-t td{border-bottom:1px solid #e2e8f0;padding:6px 8px;text-align:left}.dx-t th:not(:first-child),.dx-t td:not(:first-child){text-align:right}
.dx-link{background:none;border:0;color:#0b5cad;cursor:pointer;font:inherit;padding:0;text-align:left}.dx-link:hover{text-decoration:underline}
.dx-two{display:grid;grid-template-columns:1fr 1fr;gap:14px}.dx-two h4{margin:4px 0}.dx-row{display:flex;justify-content:space-between;gap:8px;width:100%;text-align:left;border:1px solid transparent;background:#fff;padding:5px 8px;border-radius:7px;cursor:pointer;font:inherit;font-size:12.5px}.dx-row:hover{background:#eef5fb;border-color:#b6cde3}.dx-row small{color:#64748b}.dx-row>span{flex:1;min-width:0}.dx-name{background:none;border:0;padding:0;font:inherit;font-weight:600;color:#0b5cad;text-align:left;cursor:pointer;text-decoration:none}a.dx-name:hover,.dx-name:hover{text-decoration:underline}.dx-cnt{border:0;background:none;cursor:pointer;font:inherit;padding:0 2px}.dx-cnt b{color:#0f3b57}.dx-cnt:hover b{text-decoration:underline}
.dx-bar{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin:14px 0 6px;padding-top:10px;border-top:2px solid #dbe5f0}.dx-bar .sp{flex:1}.dx-chip{background:#e8f1fb;border-radius:999px;padding:2px 4px 2px 10px;font-size:12px}.dx-chip button{border:0;background:none;cursor:pointer;font-size:14px}
.dx-list li{margin:7px 0}.dx-list a{font-weight:600}.dx-National{color:#0f7a4d}.dx-International{color:#8a4b00}.dx-Unspecified{color:#64748b}
@media(max-width:760px){.dx-two{grid-template-columns:1fr}}`;document.head.appendChild(st);
const btn=document.createElement('button');btn.id='dxBtn';btn.type='button';btn.textContent='💎 Diamond OA';btn.title='Diamond open access: existing dataset or online search';
const anchor=Q('#semBtn');if(anchor){btn.className=anchor.className;anchor.insertAdjacentElement('afterend',btn)}else document.body.appendChild(btn);
btn.onclick=open;window.openDiamondOA=open;
})();
;
/* ---- litreview-js ---- */
/* ===== Literature Review generator: recent references + in-text citations from search results (additive; existing features untouched) ===== */
(()=>{
'use strict';
const Q=s=>document.querySelector(s),QA=s=>[...document.querySelectorAll(s)];
const ls=(k,d)=>{try{return JSON.parse(localStorage.getItem(k))||d}catch(e){return d}};
const cfg=Object.assign({style:'apa',n:40,yf:'',yt:'',minc:0,org:'themes',len:'standard',rec:3,topic:'',src:'results',sf:false,s:{intro:1,method:1,trends:1,themes:1,methods:1,venues:1,gaps:1,future:1,recent:1,concl:1}},ls('lrCfg',{}));
const NUM={ieee:1,vancouver:1};
const REC=new Map();let SEQ=0,LAST=null,UNDO='';
const ST={num:new Map(),suf:new Map()};
const dec=s=>{const t=document.createElement('textarea');t.innerHTML=s||'';return t.value};
const plain=h=>{const d=document.createElement('div');d.innerHTML=h;return d.textContent};
const ttl=s=>s.replace(/\b[a-z]/g,c=>c.toUpperCase());
const med=a=>{a=[...a].sort((x,y)=>x-y);return a.length?a[a.length>>1]:0};

/* ---------- records ---------- */
const PART=/^(van|von|de|del|da|di|bin|al|el|le|la|der|den|dos|du)$/i;
function pname(s){s=s.trim().replace(/\s+/g,' ');if(!s)return null;let f,g='';
 if(s.includes(',')){const i=s.indexOf(',');f=s.slice(0,i).trim();g=s.slice(i+1).trim()}
 else{const p=s.split(' ');if(p.length<2)f=s;else if(cfg.sf){f=p[0];g=p.slice(1).join(' ')}else{let k=p.length-1;while(k>1&&PART.test(p[k-1]))k--;f=p.slice(k).join(' ');g=p.slice(0,k).join(' ')}}
 return{f,g,ini:g.split(/[\s.\-]+/).filter(Boolean).map(x=>x[0].toUpperCase())}}
function rec(id){const k=String(id);if(REC.has(k))return REC.get(k);let o;try{o=recObj(/^\d+$/.test(k)?+k:k)}catch(e){return null}
 if(!o||!o.title)return null;
 const r={k,n:++SEQ,au:(o.authors||'').split(';').map(pname).filter(Boolean),yr:parseInt(o.year)||0,ti:dec(o.title).replace(/\s+/g,' ').trim(),so:dec(o.source),doi:(o.doi||'').replace(/^https?:\/\/(dx\.)?doi\.org\//i,''),url:o.url||'',kw:(o.keywords||'').split(/[;|]/).map(x=>dec(x).trim().toLowerCase()).filter(x=>x.length>2&&x.length<60),ab:dec(o.abstract),c:+o.cites||0};
 REC.set(k,r);return r}
function pool(){const sv=()=>[...savedSet()];let ids;
 if(cfg.src==='saved')ids=sv();else if(cfg.src==='both')ids=[...new Set([...(currentResults||[]).map(h=>h.i),...sv()])];else ids=(currentResults||[]).map(h=>h.i);
 return ids.map(rec).filter(Boolean).filter(r=>(!cfg.yf||r.yr>=+cfg.yf)&&(!cfg.yt||r.yr<=+cfg.yt)&&r.c>=(+cfg.minc||0)).slice(0,+cfg.n||40)}

/* ---------- citation styles ---------- */
function inText(r,m,st){const a=r.au;const au=!a.length?r.ti.split(' ').slice(0,3).join(' ')+'…':a.length===1?a[0].f:a.length===2?a[0].f+(m==='p'&&st==='apa'?' & ':' and ')+a[1].f:a[0].f+' et al.';
 const y=(r.yr||'n.d.')+(ST.suf.get(r.k)||'');
 if(st==='mla')return au;if(m==='n')return au+' ('+y+')';return st==='apa'||st==='harvard'?au+', '+y:au+' '+y}
function citeStr(keys,m,st){const rs=keys.map(rec).filter(Boolean);if(!rs.length)return '(?)';
 if(NUM[st]){const ns=keys.map(k=>ST.num.get(k)||'?'),b=st==='ieee'?'['+ns.join(', ')+']':'('+ns.join(', ')+')';
  return m==='n'?rs.map(r=>r.au[0]?r.au[0].f+(r.au.length>1?' et al.':''):'Ref.').join(', ')+' '+b:b}
 if(m==='n'){const t=rs.map(r=>inText(r,'n',st));return t.length===2?t.join(' and '):t.join(', ')}
 rs.sort((a,b)=>(a.au[0]?a.au[0].f:a.ti).localeCompare(b.au[0]?b.au[0].f:b.ti)||a.yr-b.yr);
 return '('+rs.map(r=>inText(r,'p',st)).join('; ')+')'}
function authList(r,st){const a=r.au;if(!a.length)return '';const ini=(x,sp,dot)=>x.ini.map(i=>i+(dot?'.':'')).join(sp?' ':'');
 const nm={apa:x=>x.f+', '+ini(x,1,1),harvard:x=>x.f+', '+ini(x,0,1),vancouver:x=>x.f+' '+ini(x,0,0),ieee:x=>ini(x,1,1)+' '+x.f,
  mla:(x,i)=>i?(x.g+' '+x.f).trim():x.f+(x.g?', '+x.g:''),chicago:(x,i)=>i?(x.g+' '+x.f).trim():x.f+(x.g?', '+x.g:'')}[st];
 let L=a.slice(),et=false;const lim={apa:20,harvard:6,mla:2,chicago:10,ieee:6,vancouver:6}[st];
 if(L.length>lim){L=L.slice(0,{mla:1,chicago:7,ieee:1,harvard:3,vancouver:6,apa:19}[st]);et=true}
 const s=L.map((x,i)=>nm(x,i));
 if(st==='vancouver')return s.join(', ')+(et?', et al':'');
 if(et)return s.join(', ')+(st==='apa'?', . . . '+nm(a[a.length-1],0):', et al.');
 if(s.length===1)return s[0];
 const sep={apa:', & ',mla:', and ',chicago:', and ',ieee:s.length>2?', and ':' and ',harvard:' and '}[st];
 return s.slice(0,-1).join(', ')+sep+s[s.length-1]}
function refHTML(r,st){const au=esc(authList(r,st)),ti=esc(r.ti),so=r.so?'<i>'+esc(r.so)+'</i>':'',y=(r.yr||'n.d.')+(ST.suf.get(r.k)||'');
 const lk=r.doi?'https://doi.org/'+r.doi:safeUrl(r.url),L=lk?`<a href="${esc(lk)}" target="_blank" rel="noopener">${esc(lk)}</a>`:'';
 const dot=s=>!s||/[.?!]$/.test(s)?s:s+'.';
 switch(st){
  case 'harvard':return `${au} (${y}) ‘${ti}’, ${so}${so?'.':''}${L?' Available at: '+L+'.':''}`;
  case 'mla':return `${dot(au)} “${dot(ti)}” ${so}${so?', ':''}${y}${L?', '+L:''}.`;
  case 'chicago':return `${dot(au)} ${y}. “${dot(ti)}” ${so}${so?'. ':''}${L}`;
  case 'ieee':return `${au?au+', ':''}“${ti},” ${so}${so?', ':''}${y}${r.doi?', doi: '+esc(r.doi):''}.`;
  case 'vancouver':return `${au?dot(au)+' ':''}${dot(ti)} ${esc(r.so)}${r.so?'. ':''}${y}.${r.doi?' doi:'+esc(r.doi):''}`;
  default:return `${dot(au)} (${y}). ${dot(ti)} ${so}${so?'. ':''}${L}`}}
const cs=(keys,m)=>`<span class="lr-cite" contenteditable="false" data-ids="${keys.join(',')}" data-m="${m}">${esc(citeStr(keys,m,cfg.style))}</span>`;

/* ---------- text analysis ---------- */
const STOP=new Set('a an and are as at be been by for from has have in into is it its of on or that the their this to was were which with within using use used based study studies paper research analysis review article approach results new role among between during through toward via than also can may such these those our we more most other some many one two three how what why when who not but if only both each about'.split(' '));
const tk=s=>(norm(s).match(/[a-z][a-z0-9+#-]{2,}/g)||[]).filter(w=>!STOP.has(w));
const stm=w=>w.replace(/ies$/,'y').replace(/([^s])s$/,'$1');
function themes(P,k){const df=new Map(),add=(t,i)=>{if(!df.has(t))df.set(t,new Set());df.get(t).add(i)};
 P.forEach((r,i)=>{r.kw.forEach(x=>{const t=tk(x).map(stm).join(' ');if(t)add(t,i)});const w=tk(r.ti).map(stm);w.forEach(x=>x.length>3&&add(x,i));for(let j=0;j<w.length-1;j++)add(w[j]+' '+w[j+1],i)});
 const min=Math.max(2,Math.ceil(P.length*.04)),max=P.length*.6,cand=[...df].filter(([t,s])=>s.size>=min&&s.size<=max),out=[],cov=new Set();
 while(out.length<k){let best=null,bs=0;cand.forEach(([t,s])=>{const tw=t.split(' ');if(out.some(o=>o.t.split(' ').some(w=>tw.includes(w))))return;const nw=[...s].filter(i=>!cov.has(i)).length,sc=nw*(tw.length>1?1.3:1);if(nw>=2&&sc>bs){bs=sc;best=[t,s]}});
  if(!best)break;out.push({t:best[0],set:best[1],ids:[]});best[1].forEach(i=>cov.add(i))}
 P.forEach((r,i)=>{const o=out.find(o=>o.set.has(i));if(o)o.ids.push(i)});
 const g=out.map(o=>({label:o.t,recs:o.ids.map(i=>P[i])})),rest=P.filter((r,i)=>!out.some(o=>o.set.has(i)));
 if(rest.length)g.push({label:'other perspectives',recs:rest});return g}
const sents=a=>(a||'').replace(/\s+/g,' ').replace(/\b(e\.g|i\.e|et al|vs|etc|Fig|Dr|No)\./g,'$1\u2024').replace(/([.!?])\s+(?=[A-Z("“])/g,'$1\u0001').split('\u0001').map(s=>s.replace(/\u2024/g,'.').trim()).filter(s=>s.length>35);
const CUE=/\b(aim|purpose|objective|examin|investigat|explor|analy[sz]|found|finding|result|reveal|show|conclu|propos|develop|identif|assess|evaluat|demonstrat|highlight|suggest|indicat)/i,BAD=/(copyright|©|keywords?:|http|published by|all rights|received:|doi:)/i;
const cut=s=>{s=s.replace(/[.]+$/,'');return s.length>260?s.slice(0,s.lastIndexOf(' ',250))+'…':s};
function pick(r,terms,n){const S=sents(r.ab);if(!S.length)return[];
 return S.map((s,i)=>[(CUE.test(s)?2:0)+(i<2?1:0)+tk(s).filter(w=>terms.has(stm(w))).length*.5-(s.length>300?3:0)-(s.length<60?1:0)-(BAD.test(s)?6:0),i,s]).sort((a,b)=>b[0]-a[0]).slice(0,n).filter(x=>x[0]>-1).sort((a,b)=>a[1]-b[1]).map(x=>cut(x[2]))}
const VERB=/^(?:in\s+(?:this|the present|the current)\s+\w+,?\s+)?(?:this|the present|the current|the)\s+(?:study|paper|article|research|work|chapter|review|investigation|report|survey|analysis|case study)\s+(?:also\s+|further\s+)?([a-z]+)\s+(.*)$/i;
const SKIP=new Set('is was has are were have had will can may would could'.split(' ')),COM=new Set('the a an in on at as with for from by it its this these those there their they many most some several such despite although while when because since using through during given however due recent recently'.split(' '));
const conj=(v,pl)=>{v=v.toLowerCase();if(!pl||!/s$/.test(v)||/ss$/.test(v)||v.length<4)return v;if(/ies$/.test(v))return v.slice(0,-3)+'y';if(/(sses|shes|ches|xes|zzes)$/.test(v))return v.slice(0,-2);return v.slice(0,-1)};
const third=x=>/([sxz]|ch|sh)$/.test(x)?x+'es':/[^aeiou]y$/.test(x)?x.slice(0,-1)+'ies':x+'s';
const lc=s=>COM.has(s.split(/\s/)[0].toLowerCase())?s[0].toLowerCase()+s.slice(1):s;
let ALT=0;
function say(r,s){const pl=r.au.length>1,nar=cs([r.k],'n'),t=s.replace(/[.]+$/,''),v=t.match(VERB);
 if(v&&!SKIP.has(v[1].toLowerCase())&&/(s|ed)$/.test(v[1]))return `${nar} ${conj(v[1],pl)} ${esc(v[2])}.`;
 const w=t.match(/^we\s+(?:also\s+)?([a-z]+)\s+(.*)$/i);if(w&&!SKIP.has(w[1].toLowerCase())&&!/(s|ed)$/.test(w[1]))return `${nar} ${pl?w[1]:third(w[1])} ${esc(w[2])}.`;
 return ALT++%2?`${nar} ${pl?'note':'notes'} that ${esc(lc(t))}.`:`According to ${nar}, ${esc(lc(t))}.`}
const METH=[['bibliometric or scientometric analysis',/bibliometric|scientometric|citation analysis|vosviewer|biblioshiny/i],['systematic, scoping or literature reviews',/systematic (literature )?review|literature review|scoping review|meta-analysis|prisma/i],['surveys and questionnaires',/survey|questionnaire/i],['interviews and focus groups',/interview|focus group/i],['case studies',/case stud/i],['content or thematic analysis',/content analysis|thematic analysis|text analysis/i],['machine learning and AI techniques',/machine learning|deep learning|neural|natural language|\bnlp\b|large language|chatgpt|generative/i],['experimental designs',/experiment|quasi-experiment|randomi[sz]ed/i],['mixed-methods designs',/mixed[- ]method/i],['conceptual or framework-building work',/conceptual|framework/i]];
const GAPRE=/\b(limited|lack(?:s|ing)?|scarce|understudied|under-?explored|gap|little (?:is known|attention)|remains? (?:unclear|unexplored|limited)|not (?:yet )?(?:fully|well|adequately))\b/i,FUTRE=/\b(further (?:research|studies|investigation)|future (?:research|studies|work|directions)|should (?:be|focus)|needs? to be|recommend)/i;
const join=a=>a.length<2?a.join(''):a.slice(0,-1).join(', ')+' and '+a[a.length-1];
const top=(a,n)=>{const m=new Map();a.forEach(x=>m.set(x,(m.get(x)||0)+1));return[...m].sort((x,y)=>y[1]-x[1]).slice(0,n)};

/* ---------- generator ---------- */
function generate(){const P=pool();if(!P.length)return null;
 const per={concise:2,standard:4,detailed:7}[cfg.len]||4,spn=cfg.len==='detailed'?2:1,S=cfg.s,T=cfg.topic||(state&&state.query)||'the selected research area';
 const ys=P.map(r=>r.yr).filter(Boolean),y1=Math.min(...ys),y2=Math.max(...ys),byc=[...P].sort((a,b)=>b.c-a.c);
 const terms=new Set(tk(T).map(stm));let h=`<h1>Literature Review: ${esc(ttl(T))}</h1><p class="lr-meta">Compiled ${new Date().toLocaleDateString()} from ${P.length} records (${y1}–${y2}) · citation style: ${esc(cfg.style.toUpperCase())}</p>`;
 const kws=top(P.flatMap(r=>r.kw),8),srcs=top(P.map(r=>r.so).filter(Boolean),5),aus=top(P.flatMap(r=>r.au.map(a=>a.f+', '+a.ini.join(''))),6).filter(x=>x[1]>1);
 if(S.intro)h+=`<h2>1. Introduction</h2><p>This review synthesises ${P.length} publications on <b>${esc(T)}</b> published between ${y1} and ${y2} in ${new Set(P.map(r=>r.so)).size} journals or sources. Together they have been cited ${P.reduce((a,r)=>a+r.c,0).toLocaleString()} times in the dataset (median ${med(P.map(r=>r.c))} per paper).</p>`+
  (byc[0].c?`<p>The most cited contribution is ${cs([byc[0].k],'n')} (${byc[0].c} citations)${byc[1]&&byc[1].c?`, followed by ${cs([byc[1].k],'n')} (${byc[1].c} citations)`:''}. `:'<p>')+(kws.length?`The most frequent author keywords are ${esc(join(kws.map(k=>`${k[0]} (${k[1]})`)))}.`:'')+'</p>';
 if(S.method)h+=`<h2>2. Review method</h2><ul><li>Source: the bibliographic collection loaded in this application; query: ${state&&state.query?'“'+esc(state.query)+'”':'none (records chosen from '+(cfg.src==='saved'?'saved items':'the collection')+')'}.</li><li>Sample: top ${P.length} records${cfg.yf||cfg.yt?` published ${cfg.yf||'…'}–${cfg.yt||'…'}`:''}${+cfg.minc?` with at least ${cfg.minc} citations`:''}.</li><li>Synthesis: keyword-based thematic grouping and attributed abstract sentences. Statements are taken from titles, keywords and abstracts only, not full texts, and should be verified against the sources before submission.</li></ul>`;
 if(S.trends){const yc=top(P.map(r=>r.yr).filter(Boolean),99).sort((a,b)=>a[0]-b[0]),pk=[...yc].sort((a,b)=>b[1]-a[1])[0],old=[...P].filter(r=>r.yr).sort((a,b)=>a.yr-b.yr||b.c-a.c)[0],nw=[...P].filter(r=>r.yr).sort((a,b)=>b.yr-a.yr||b.c-a.c)[0];
  h+=`<h2>3. Publication trends</h2><p>Output peaks in ${pk[0]} with ${pk[1]} records. The earliest paper in the sample is ${cs([old.k],'n')} and the most recent is ${cs([nw.k],'n')}.</p><table><tr><th>Year</th><th>Records</th><th>Mean citations</th></tr>${yc.map(([y,c])=>`<tr><td>${y}</td><td>${c}</td><td>${(P.filter(r=>r.yr===y).reduce((a,r)=>a+r.c,0)/c).toFixed(1)}</td></tr>`).join('')}</table>`}
 if(S.themes){const chrono=cfg.org==='chrono';let G;
  if(chrono)G=[...new Set(P.map(r=>r.yr))].sort((a,b)=>a-b).map(y=>({label:String(y||'n.d.'),recs:P.filter(r=>r.yr===y)}));else G=themes(P,5);
  h+=`<h2>4. ${chrono?'Chronological':'Thematic'} synthesis</h2>`;
  G.forEach(g=>{const rs=[...g.recs].sort((a,b)=>b.c-a.c||b.yr-a.yr),main=rs.slice(0,per),rest=rs.slice(per),pc=Math.round(g.recs.length/P.length*100);
   h+=`<h3>${esc(ttl(g.label))}</h3><p>${chrono?`In ${esc(g.label)}, ${g.recs.length} of the ${P.length} studies (${pc}%) were published.`:`${g.recs.length} of the ${P.length} studies (${pc}%) ${g.label==='other perspectives'?'address other perspectives':'concern <b>'+esc(g.label)+'</b>'}.`}`;
   const gt=new Set([...terms,...g.label.split(' ')]);
   main.forEach(r=>{const p=pick(r,gt,spn);h+=' '+(p.length?p.map(s=>say(r,s)).join(' '):`${cs([r.k],'n')} address “${esc(r.ti)}”.`)});
   const co=top(g.recs.flatMap(r=>r.kw).filter(k=>!g.label.split(' ').some(w=>k.includes(w))),4);
   h+=(co.length&&!chrono?` Frequently co-occurring terms are ${esc(join(co.map(c=>c[0])))}.`:'')+'</p>';
   if(rest.length)h+=`<p>Further work in this group includes ${cs(rest.slice(0,6).map(r=>r.k),'p')}.</p>`})}
 if(S.methods){const mm=METH.map(([l,re])=>[l,P.filter(r=>re.test(r.ti+' '+r.ab))]).filter(x=>x[1].length).sort((a,b)=>b[1].length-a[1].length).slice(0,6);
  if(mm.length)h+=`<h2>5. Research methods and approaches</h2><ul>${mm.map(([l,a])=>`<li><b>${esc(ttl(l))}</b>: ${a.length} studies (e.g. ${cs(a.sort((x,y)=>y.c-x.c).slice(0,3).map(r=>r.k),'p')}).</li>`).join('')}</ul>`}
 if(S.venues)h+=`<h2>6. Key venues and contributors</h2><p>${srcs.length?`The sources contributing most records are ${esc(join(srcs.map(s=>`${s[0]} (${s[1]})`)))}. `:''}${aus.length?`The most frequently appearing authors are ${esc(join(aus.map(a=>`${a[0]} (${a[1]} papers)`)))}.`:'No author appears more than once in this sample.'}</p>`;
 if(S.gaps||S.future){const gp=[],fu=[];[...P].sort((a,b)=>b.yr-a.yr).forEach(r=>{const ss=sents(r.ab).filter(s=>!BAD.test(s));const g=ss.find(s=>GAPRE.test(s)),f=ss.find(s=>FUTRE.test(s));if(g&&gp.length<4)gp.push([r,cut(g)]);if(f&&fu.length<4)fu.push([r,cut(f)])});
  if(S.gaps){const T5=themes(P,5).filter(g=>g.label!=='other perspectives').map(g=>g.label),has=(r,l)=>{r._t=r._t||new Set(tk(r.ti+' '+r.kw.join(' ')+' '+r.ab).map(stm));return l.split(' ').every(w=>r._t.has(w))},pairs=[];
   for(let i=0;i<T5.length;i++)for(let j=i+1;j<T5.length;j++){const m=P.filter(r=>has(r,T5[i])&&has(r,T5[j]));if(m.length<2)pairs.push([T5[i],T5[j],m])}
   h+=`<h2>7. Critical discussion and research gaps</h2>`+(gp.length?`<p>Several authors state limitations or gaps explicitly. ${gp.map(([r,s])=>`${cs([r.k],'n')} ${r.au.length>1?'observe':'observes'} that ${esc(lc(s))}.`).join(' ')}</p>`:'')+
    (pairs.length?`<p>Conceptually, the sample shows thin coverage of combinations of themes: ${pairs.slice(0,3).map(([a,b,m])=>m.length?`only one study (${cs([m[0].k],'n')}) jointly addresses ${esc(a)} and ${esc(b)}`:`no study in this sample jointly addresses ${esc(a)} and ${esc(b)}`).join('; ')}.</p>`:'')+(gp.length||pairs.length?'':'<p>No explicit gap statements were detected in the abstracts of this sample.</p>')}
  if(S.future){const rc=P.filter(r=>r.yr>=y2-1),em=top(rc.flatMap(r=>r.kw),30).filter(([k,c])=>c>=2&&P.filter(r=>r.kw.includes(k)).every(r=>r.yr>=y2-1)).slice(0,4);
   h+=`<h2>8. Future research directions</h2>`+(fu.length?`<p>${fu.map(([r,s])=>`${cs([r.k],'n')} ${r.au.length>1?'suggest':'suggests'} that ${esc(lc(s))}.`).join(' ')}</p>`:'')+(em.length?`<p>Terms appearing only in the most recent two years, and therefore emerging, include ${esc(join(em.map(e=>e[0])))}.</p>`:'')+(fu.length||em.length?'':'<p>No explicit future-research statements were detected in this sample.</p>')}}
 if(S.recent){const from=y2-(+cfg.rec||3)+1,rc=P.filter(r=>r.yr>=from).sort((a,b)=>b.yr-a.yr||b.c-a.c).slice(0,{concise:5,standard:8,detailed:12}[cfg.len]||8);
  if(rc.length)h+=`<h2>9. Recent developments (${from}–${y2})</h2><p>${P.filter(r=>r.yr>=from).length} of the ${P.length} studies (${Math.round(P.filter(r=>r.yr>=from).length/P.length*100)}%) appeared in the last ${cfg.rec} years of the sample.</p><ul>${rc.map(r=>{const p=pick(r,terms,1);return `<li>${p.length?say(r,p[0]):`${cs([r.k],'n')} address “${esc(r.ti)}”.`}</li>`}).join('')}</ul>`}
 if(S.concl){const g=themes(P,3).filter(x=>x.label!=='other perspectives');h+=`<h2>10. Conclusion</h2><p>The ${P.length} reviewed studies show ${g.length?`concentration around ${esc(join(g.map(x=>x.label)))}`:'a diverse set of concerns'}, with ${y2-y1+1>1?`output spread across ${y1}–${y2}`:'all output in '+y1}. This draft is assembled from metadata and abstracts; check each claim against the full text, refine the synthesis in your own words and confirm the reference list before submission.</p>`}
 return h+`<h2>References</h2><div id="lr-refs" contenteditable="false"></div>`}

/* ---------- document, refresh, persistence ---------- */
const D=()=>Q('#lrDoc');
const skel='<h1>Literature review</h1><p><br></p><h2>References</h2><div id="lr-refs" contenteditable="false"></div>';
function refresh(){const d=D();if(!d)return;const sp=[...d.querySelectorAll('.lr-cite')],keys=[];
 sp.forEach(s=>s.dataset.ids.split(',').forEach(k=>{if(!keys.includes(k))keys.push(k)}));
 ST.num=new Map(keys.map((k,i)=>[k,i+1]));ST.suf=new Map();const g={};
 keys.forEach(k=>{const r=rec(k);if(r)(g[(r.au[0]?r.au[0].f:r.ti)+'|'+r.au.length+'|'+r.yr]=g[(r.au[0]?r.au[0].f:r.ti)+'|'+r.au.length+'|'+r.yr]||[]).push(r)});
 Object.values(g).forEach(a=>{if(a.length>1)a.sort((x,y)=>x.ti.localeCompare(y.ti)).forEach((r,i)=>ST.suf.set(r.k,String.fromCharCode(97+i)))});
 sp.forEach(s=>{const t=citeStr(s.dataset.ids.split(','),s.dataset.m,cfg.style);if(s.textContent!==t)s.textContent=t});
 const rs=keys.map(rec).filter(Boolean);if(!NUM[cfg.style])rs.sort((a,b)=>(a.au[0]?a.au[0].f:a.ti).localeCompare(b.au[0]?b.au[0].f:b.ti)||a.yr-b.yr||a.ti.localeCompare(b.ti));
 const RF=d.querySelector('#lr-refs');
 if(RF)RF.innerHTML=rs.map(r=>`<div class="lr-ref${NUM[cfg.style]?' num':''}" id="lr-ref-${r.n}">${NUM[cfg.style]?`<span class="lr-n">${cfg.style==='ieee'?'['+ST.num.get(r.k)+']':ST.num.get(r.k)+'.'}</span> `:''}${refHTML(r,cfg.style)}</div>`).join('')||'<p class="tiny">No citations yet. Use “Cite from results”.</p>';
 stats(keys,sp);save(keys)}
function stats(keys,sp){const e=Q('#lrStats');if(!e)return;const d=D(),c=d.cloneNode(true);c.querySelector('#lr-refs')?.remove();const w=(c.textContent.match(/\S+/g)||[]).length,P=pool();
 e.innerHTML=`<b>${w}</b> words · <b>${sp.length}</b> in-text citations · <b>${keys.length}</b> references · <b>${P.filter(r=>!keys.includes(r.k)).length}</b> of ${P.length} source records not yet cited`}
function save(keys){const d=D();if(!d)return;const recs={};keys.forEach(k=>{const r=REC.get(k);if(r)recs[k]={...r,ab:''}});try{localStorage.setItem('lrAuto',JSON.stringify({html:d.innerHTML,recs}));localStorage.setItem('lrCfg',JSON.stringify(cfg))}catch(e){}}
function load(){const a=ls('lrAuto',null);if(!a||!a.html)return skel;Object.entries(a.recs||{}).forEach(([k,r])=>{if(!REC.has(k))REC.set(k,{...r,n:++SEQ,ab:r.ab||''})});return a.html}
function ins(keys,m){const d=D();if(!d)return;const t=document.createElement('span');t.className='lr-cite';t.contentEditable='false';t.dataset.ids=keys.join(',');t.dataset.m=m;t.textContent='…';
 if(LAST&&d.contains(LAST.commonAncestorContainer)&&!LAST.commonAncestorContainer.parentElement?.closest('#lr-refs')){const r=LAST.cloneRange();r.collapse(false);r.insertNode(t);t.after(document.createTextNode(' '));LAST=null}
 else{const p=[...d.querySelectorAll('p')].filter(p=>!p.closest('#lr-refs')).pop();if(p){p.append(document.createTextNode(' '),t)}else d.insertBefore(t,d.querySelector('#lr-refs'))}
 refresh();toast('Citation inserted in the review')}
const copyRich=(html,text)=>{try{navigator.clipboard.write([new ClipboardItem({'text/html':new Blob([html],{type:'text/html'}),'text/plain':new Blob([text],{type:'text/plain'})})]).then(()=>toast('Copied'),()=>navigator.clipboard.writeText(text).then(()=>toast('Copied text')))}catch(e){navigator.clipboard&&navigator.clipboard.writeText(text).then(()=>toast('Copied text'))}};
const outHTML=()=>{refresh();const c=D().cloneNode(true);c.querySelectorAll('[contenteditable]').forEach(e=>e.removeAttribute('contenteditable'));return c.innerHTML};
const wrap=b=>`<!doctype html><html><head><meta charset="utf-8"><title>Literature review</title><style>body{font:12pt/1.55 "Times New Roman",serif;max-width:780px;margin:2em auto;color:#111}h1{font-size:20pt}h2{font-size:15pt;margin-top:1.2em}h3{font-size:12.5pt}.lr-ref{margin:0 0 6pt 24pt;text-indent:-24pt}.lr-meta{color:#555;font-style:italic}table{border-collapse:collapse}td,th{border:1px solid #999;padding:3px 8px}</style></head><body>${b}


</body></html>`;
function printDoc(){const f=document.createElement('iframe');f.style.cssText='position:fixed;width:0;height:0;border:0';document.body.appendChild(f);f.srcdoc=wrap(outHTML());f.onload=()=>{f.contentWindow.focus();f.contentWindow.print();setTimeout(()=>f.remove(),2000)}}

/* ---------- citation matching (tf-idf cosine) ---------- */
function index(P){const N=P.length,df=new Map(),V=P.map(r=>{const tf=new Map(),add=(s,w)=>tk(s).map(stm).forEach(t=>tf.set(t,(tf.get(t)||0)+w));add(r.ti,3);add(r.kw.join(' '),2);add(r.ab,1);tf.forEach((v,t)=>df.set(t,(df.get(t)||0)+1));return tf});
 const idf=t=>Math.log(1+N/(df.get(t)||N)),vec=tf=>{const v=new Map();let n=0;tf.forEach((c,t)=>{const w=(1+Math.log(c))*idf(t);v.set(t,w);n+=w*w});return{v,n:Math.sqrt(n)||1}},DV=V.map(vec);
 return{match(text,k){const q=new Map();tk(text).map(stm).forEach(t=>q.set(t,(q.get(t)||0)+1));const qv=vec(q);return DV.map((d,i)=>{let s=0;qv.v.forEach((w,t)=>{if(d.v.has(t))s+=w*d.v.get(t)});return[s/(qv.n*d.n),P[i]]}).sort((a,b)=>b[0]-a[0]).slice(0,k)}}}
const THR=()=>+(Q('#lrThr')?.value||.1);
function suggest(text){const P=pool(),ix=index(P);return sents(text.replace(/\n+/g,' ')).map(s=>({s,m:ix.match(s,3)}))}
function autoCite(){const d=D(),P=pool();if(!P.length)return toast('No source records in scope');UNDO=d.innerHTML;const ix=index(P);let n=0;
 d.querySelectorAll('p,li').forEach(p=>{if(p.closest('#lr-refs')||p.querySelector('.lr-cite')||p.classList.contains('lr-meta'))return;const t=p.textContent.trim();if(t.split(/\s+/).length<8)return;
  const m=ix.match(t,1)[0];if(m&&m[0]>=THR()){const sp=document.createElement('span');sp.className='lr-cite';sp.contentEditable='false';sp.dataset.ids=m[1].k;sp.dataset.m='p';sp.textContent='…';
   const last=[...p.childNodes].reverse().find(x=>x.nodeType===3&&x.textContent.trim());if(last&&/[.!?]\s*$/.test(last.textContent)){const i=last.textContent.search(/[.!?]\s*$/);last.splitText(i);last.after(document.createTextNode(' '),sp)}else p.append(' ',sp);n++}});
 refresh();toast(n?`Added ${n} citations (use Undo to revert)`:'No uncited paragraph reached the match threshold')}

/* ---------- UI ---------- */
const row=(r,extra)=>`<div class="lr-item"><input type="checkbox" data-k="${esc(r.k)}"><div><b>${esc(r.ti)}</b><div class="tiny">${esc(r.au.map(a=>a.f).slice(0,4).join(', '))}${r.au.length>4?' et al.':''} · ${r.yr||'n.d.'} · ${esc(r.so)} · ${r.c} citations</div>${extra||''}</div><div class="lr-acts"><button class="ghost" data-act="cp" data-k="${esc(r.k)}">( ) cite</button><button class="ghost" data-act="cn" data-k="${esc(r.k)}">Narrative</button></div></div>`;
const sel=()=>QA('#lrRoot [data-k]:checked').map(c=>c.dataset.k);
function recentList(){const P=pool(),y2=Math.max(0,...P.map(r=>r.yr)),w=+(Q('#lrRecW')?.value||cfg.rec),sort=Q('#lrRecS')?.value||'year',f=norm(Q('#lrRecQ')?.value||'');
 let a=P.filter(r=>!w||r.yr>y2-w).filter(r=>!f||norm(r.ti+' '+r.au.map(x=>x.f).join(' ')+' '+r.kw.join(' ')).includes(f));
 a.sort((x,y)=>sort==='cites'?y.c-x.c:sort==='title'?x.ti.localeCompare(y.ti):y.yr-x.yr||y.c-x.c);return a}
function drawRecent(){const a=recentList(),e=Q('#lrRecL');if(e)e.innerHTML=a.length?a.map(r=>row(r,`<div class="lr-ref-p">${refHTML(r,cfg.style)}</div>`)).join(''):'<p class="tiny">No records in this window. Run a search or widen the source filters.</p>';Q('#lrRecN').textContent=a.length+' recent records'}
function drawCite(){const f=norm(Q('#lrCQ')?.value||''),a=pool().filter(r=>!f||norm(r.ti+' '+r.au.map(x=>x.f).join(' ')+' '+r.kw.join(' ')).includes(f)).slice(0,60);Q('#lrCL').innerHTML=a.map(r=>row(r,`<div class="tiny">(${esc(inText(r,'p',cfg.style==='ieee'||cfg.style==='vancouver'?'apa':cfg.style))}) · ${esc(inText(r,'n',cfg.style==='ieee'||cfg.style==='vancouver'?'apa':cfg.style))}</div>`)).join('')||'<p class="tiny">No matching records in scope.</p>'}
function drawBib(){const m=Q('#lrBibM').value,P=pool(),y2=Math.max(0,...P.map(r=>r.yr));let a;
 if(m==='cited'){refresh();a=[...new Set(QA('#lrDoc .lr-cite').flatMap(s=>s.dataset.ids.split(',')))].map(rec).filter(Boolean)}else if(m==='recent')a=P.filter(r=>r.yr>y2-cfg.rec);else a=P;
 a=[...a].sort((x,y)=>(x.au[0]?x.au[0].f:x.ti).localeCompare(y.au[0]?y.au[0].f:y.ti)||x.yr-y.yr);Q('#lrBibL').innerHTML=a.map(r=>`<div class="lr-ref">${refHTML(r,cfg.style)}</div>`).join('')||'<p class="tiny">Nothing to list.</p>';Q('#lrBibL').dataset.k=a.map(r=>r.k).join('|~|')}
const bibRecs=()=>(Q('#lrBibL').dataset.k||'').split('|~|').filter(Boolean).map(k=>/^\d+$/.test(k)?+k:k);
function poolInfo(){const P=pool(),e=Q('#lrPool');if(!e)return;const ys=P.map(r=>r.yr).filter(Boolean);e.innerHTML=P.length?`<b>${P.length}</b> records in scope (${Math.min(...ys)}–${Math.max(...ys)})`:'<span class="bad">No records in scope — run a search (or type a topic and press “Search topic”).</span>'}

function open(){Q('#modalCard').classList.add('x2-wide');
 const o=(v,l,c)=>`<option value="${v}"${c==v?' selected':''}>${l}</option>`,S=cfg.s;
 showModal(`<div class="x3 lr" id="lrRoot"><h2>📚 Literature Review Generator</h2>
 <div class="row"><label>Topic <input type="text" id="lrTopic" size="30" placeholder="${esc((state&&state.query)||'research topic')}" value="${esc(cfg.topic)}"></label><button class="ghost" id="lrSearch">⌕ Search topic</button>
 <label>Source <select id="lrSrc">${o('results','Current search results',cfg.src)}${o('saved','Saved records',cfg.src)}${o('both','Results + saved',cfg.src)}</select></label>
 <label>Top <input type="number" id="lrN" min="5" max="300" value="${cfg.n}" style="width:70px"></label><label>Years <input type="number" id="lrYF" placeholder="from" value="${cfg.yf}" style="width:70px">–<input type="number" id="lrYT" placeholder="to" value="${cfg.yt}" style="width:70px"></label><label>Min citations <input type="number" id="lrMC" min="0" value="${cfg.minc}" style="width:60px"></label>
 <label>Style <select id="lrStyle">${[['apa','APA 7'],['harvard','Harvard'],['mla','MLA'],['chicago','Chicago (author-date)'],['ieee','IEEE (numeric)'],['vancouver','Vancouver (numeric)']].map(([v,l])=>o(v,l,cfg.style)).join('')}</select></label></div>
 <div class="tiny" id="lrPool"></div>
 <div class="tabs"><button data-p="gen">Generate &amp; edit</button><button data-p="rec">Recent references</button><button data-p="cite">In-text citations</button><button data-p="bib">Bibliography &amp; export</button></div>
 <section data-pane="gen"><div class="row"><label>Organise by <select id="lrOrg">${o('themes','Themes',cfg.org)}${o('chrono','Chronology',cfg.org)}</select></label><label>Length <select id="lrLen">${o('concise','Concise',cfg.len)}${o('standard','Standard',cfg.len)}${o('detailed','Detailed',cfg.len)}</select></label><label>Recent window <select id="lrRec">${[1,2,3,5].map(v=>o(v,'last '+v+' yr',cfg.rec)).join('')}</select></label>
 <details><summary>Sections</summary>${[['intro','Introduction'],['method','Review method'],['trends','Trends'],['themes','Synthesis'],['methods','Methods'],['venues','Venues &amp; authors'],['gaps','Gaps'],['future','Future work'],['recent','Recent developments'],['concl','Conclusion']].map(([k,l])=>`<label class="lr-chk"><input type="checkbox" data-sec="${k}"${S[k]?' checked':''}> ${l}</label>`).join('')}</details>
 <button class="primary" id="lrGen">✦ Generate review</button></div>
 <div class="row lr-tools"><button class="ghost" data-cmd="bold"><b>B</b></button><button class="ghost" data-cmd="italic"><i>I</i></button><button class="ghost" data-cmd="formatBlock" data-v="h2">H2</button><button class="ghost" data-cmd="formatBlock" data-v="p">¶</button><button class="ghost" data-cmd="undo">↶</button><button class="ghost" data-cmd="redo">↷</button><button class="ghost" id="lrRef">↻ Refresh citations</button><span class="lr-sp"></span>
 <button class="ghost" id="lrCopy">Copy</button><button class="ghost" id="lrDoc2">Word (.doc)</button><button class="ghost" id="lrHtml">HTML</button><button class="ghost" id="lrTxt">Text</button><button class="ghost" id="lrPrint">Print / PDF</button></div>
 <div id="lrStats" class="tiny"></div><div id="lrDoc" class="lr-doc" contenteditable="true" spellcheck="true"></div></section>
 <section data-pane="rec" hidden><div class="row"><label>Window <select id="lrRecW">${[[1,'last year'],[2,'last 2 years'],[3,'last 3 years'],[5,'last 5 years'],[0,'all years']].map(([v,l])=>o(v,l,cfg.rec)).join('')}</select></label><label>Sort <select id="lrRecS">${o('year','Newest first','year')}${o('cites','Most cited','')}${o('title','Title','')}</select></label><input type="text" id="lrRecQ" placeholder="filter by title, author, keyword" size="28"><span class="tiny" id="lrRecN"></span></div>
 <div class="row"><button class="ghost" id="lrRecAll">Select all</button><button class="primary" id="lrRecIns">Insert selected citation(s) in review</button><button class="ghost" id="lrRecPara">Add “Recent literature” paragraph</button><button class="ghost" id="lrRecCopy">Copy selected references</button></div><div id="lrRecL"></div></section>
 <section data-pane="cite" hidden><div class="row"><input type="text" id="lrCQ" placeholder="find a record to cite (title, author, keyword)" size="40"><button class="primary" id="lrCIns">Insert selected as one citation</button></div><div id="lrCL" class="lr-scroll"></div>
 <div class="card"><b>Suggest citations for text</b><div class="tiny">Paste a claim or paragraph; the best-matching records from the source scope are proposed for each sentence (tf-idf similarity on title, keywords and abstract).</div><textarea id="lrSugIn" rows="4" placeholder="Paste text here…"></textarea>
 <div class="row"><label>Match strictness <select id="lrThr"><option value=".06">Low</option><option value=".1" selected>Medium</option><option value=".18">High</option></select></label><button class="primary" id="lrSug">Suggest</button><button class="ghost" id="lrSugEd">Use review text</button><button class="primary" id="lrAuto">Auto-cite uncited paragraphs in review</button><button class="ghost" id="lrUndo">Undo auto-cite</button></div><div id="lrSugOut"></div></div></section>
 <section data-pane="bib" hidden><div class="row"><label>List <select id="lrBibM">${o('cited','Cited in review','cited')}${o('recent','Recent references (window above)','')}${o('all','All records in scope','')}</select></label><button class="ghost" id="lrBibCopy">Copy</button><button class="ghost" id="lrBibBib">BibTeX</button><button class="ghost" id="lrBibRis">RIS</button><button class="ghost" id="lrBibCsv">CSV</button></div><div id="lrBibL" class="lr-scroll"></div></section></div>`);
 const R=Q('#lrRoot'),d=D();d.innerHTML=load();
 const tab=p=>{QA('#lrRoot .tabs button').forEach(b=>b.classList.toggle('on',b.dataset.p===p));QA('#lrRoot [data-pane]').forEach(s=>s.hidden=s.dataset.pane!==p);if(p==='rec')drawRecent();if(p==='cite')drawCite();if(p==='bib')drawBib()};
 tab('gen');poolInfo();refresh();
 const gen=()=>{if(!pool().length)return toast('No records in scope — run a search first');if(d.textContent.length>400&&!/^Literature review\s*References/.test(d.textContent.replace(/\n/g,''))&&!confirm('Replace the current draft with a newly generated review?'))return;UNDO=d.innerHTML;d.innerHTML=generate();refresh();toast('Review generated — edit freely, then export')};
 const read=()=>{cfg.topic=Q('#lrTopic').value.trim();cfg.src=Q('#lrSrc').value;cfg.n=+Q('#lrN').value||40;cfg.yf=Q('#lrYF').value;cfg.yt=Q('#lrYT').value;cfg.minc=+Q('#lrMC').value||0;cfg.org=Q('#lrOrg').value;cfg.len=Q('#lrLen').value;cfg.rec=+Q('#lrRec').value;QA('[data-sec]').forEach(c=>cfg.s[c.dataset.sec]=c.checked?1:0);poolInfo()};
 R.onchange=e=>{const t=e.target;if(t.id==='lrStyle'){cfg.style=t.value;refresh();const p=QA('#lrRoot .tabs .on')[0]?.dataset.p;tab(p)}else if(t.id==='lrRec'||t.id==='lrRecW'){cfg.rec=+t.value||cfg.rec;if(t.id==='lrRecW')drawRecent()}else if(t.id==='lrRecS')drawRecent();else if(t.id==='lrBibM')drawBib();else if(t.closest('.row,details')){read();const p=QA('#lrRoot .tabs .on')[0]?.dataset.p;if(p==='rec')drawRecent();if(p==='cite')drawCite()}};
 R.oninput=e=>{if(e.target.id==='lrRecQ')drawRecent();else if(e.target.id==='lrCQ')drawCite();else if(e.target.id==='lrDoc'){clearTimeout(R._t);R._t=setTimeout(()=>{const k=[...new Set(QA('#lrDoc .lr-cite').flatMap(s=>s.dataset.ids.split(',')))];save(k)},600)}};
 d.addEventListener('focusout',()=>refresh());
 d.onclick=e=>{const c=e.target.closest('.lr-cite');if(!c)return;c.dataset.ids.split(',').forEach((k,i)=>{const r=REC.get(k),el=r&&d.querySelector('#lr-ref-'+r.n);if(el&&!i){el.scrollIntoView({behavior:'smooth',block:'center'})}if(el){el.classList.add('flash');setTimeout(()=>el.classList.remove('flash'),1800)}})};
 R.onclick=e=>{const b=e.target.closest('button');if(!b)return;const k=b.dataset.k,id=b.id;
  if(b.dataset.p)return tab(b.dataset.p);
  if(b.dataset.cmd){d.focus();document.execCommand(b.dataset.cmd,false,b.dataset.v||null);return}
  if(b.dataset.act==='cp'||b.dataset.act==='cn'){ins([k],b.dataset.act==='cp'?'p':'n');return}
  if(b.dataset.ins!==undefined){const x=JSON.parse(b.dataset.ins);ins(x,'p');return}
  switch(id){
   case'lrSearch':{read();const t=cfg.topic||Q('#lrTopic').value.trim();if(!t)return toast('Type a topic first');Q('#q').value=t;Q('#searchForm').requestSubmit();setTimeout(()=>{cfg.src='results';Q('#lrSrc').value='results';poolInfo();toast('Search done — '+(currentResults||[]).length+' matches')},350);break}
   case'lrGen':read();gen();break;
   case'lrRef':refresh();break;
   case'lrCopy':{const h=outHTML();copyRich(h,plain(h));break}
   case'lrDoc2':download('literature_review.doc',wrap(outHTML()),'application/msword');break;
   case'lrHtml':download('literature_review.html',wrap(outHTML()),'text/html');break;
   case'lrTxt':{const h=outHTML().replace(/<\/(p|h\d|div|li|tr)>/g,'$&\n');download('literature_review.txt',plain(h),'text/plain');break}
   case'lrPrint':printDoc();break;
   case'lrRecAll':QA('#lrRecL [data-k]').forEach(c=>c.checked=true);break;
   case'lrRecIns':{const s=sel();if(!s.length)return toast('Tick one or more records');ins(s,'p');break}
   case'lrRecPara':{const s=sel().map(rec).filter(Boolean);if(!s.length)return toast('Tick one or more records');const T=new Set(tk(cfg.topic||state.query||'').map(stm)),p=document.createElement('p');p.innerHTML='Recent literature includes: '+s.map(r=>{const t=pick(r,T,1);return t.length?say(r,t[0]):`${cs([r.k],'n')} address “${esc(r.ti)}”.`}).join(' ');const rf=d.querySelector('#lr-refs'),h2=[...d.querySelectorAll('h2')].find(x=>/^References/.test(x.textContent));d.insertBefore(p,h2||rf);refresh();toast('Paragraph added before the references');break}
   case'lrRecCopy':{const s=sel().map(rec).filter(Boolean),h=s.map(r=>`<p>${refHTML(r,cfg.style)}</p>`).join('');if(!s.length)return toast('Tick one or more records');copyRich(h,plain(h.replace(/<\/p>/g,'\n')));break}
   case'lrCIns':{const s=sel();if(!s.length)return toast('Tick one or more records');ins(s,'p');break}
   case'lrSug':case'lrSugEd':{if(id==='lrSugEd'){const c=d.cloneNode(true);c.querySelector('#lr-refs')?.remove();c.querySelectorAll('.lr-cite').forEach(x=>x.remove());Q('#lrSugIn').value=c.textContent.replace(/\s+/g,' ').trim().slice(0,2500)}
    const out=suggest(Q('#lrSugIn').value),t=THR();Q('#lrSugOut').innerHTML=out.length?out.map((o,i)=>`<div class="card"><div>${esc(o.s)}</div>${o.m.filter(m=>m[0]>=t*.6).map(m=>`<div class="lr-item"><div><b>${esc(m[1].ti)}</b><div class="tiny">${esc(inText(m[1],'p',cfg.style==='ieee'||cfg.style==='vancouver'?'apa':cfg.style))} · match ${(m[0]*100).toFixed(0)}%</div></div><div class="lr-acts"><button class="ghost" data-ins='${JSON.stringify([m[1].k])}'>Insert at cursor</button></div></div>`).join('')||'<div class="tiny">No record passes the match threshold.</div>'}</div>`).join(''):'<p class="tiny">Enter at least one full sentence.</p>';break}
   case'lrAuto':autoCite();break;
   case'lrUndo':if(UNDO){d.innerHTML=UNDO;refresh();toast('Reverted')}break;
   case'lrBibCopy':{const h=Q('#lrBibL').innerHTML;copyRich(h,plain(h.replace(/<\/div>/g,'\n')));break}
   case'lrBibBib':download('review_references.bib',bibRecs().map(i=>bib(recObj(i))).join('\n\n'),'application/x-bibtex');break;
   case'lrBibRis':download('review_references.ris',bibRecs().map(i=>ris(recObj(i))).join('\n\n'),'application/x-research-info-systems');break;
   case'lrBibCsv':download('review_references.csv',['Authors,Year,Title,Source,DOI'].concat(bibRecs().map(rec).filter(Boolean).map(r=>[r.au.map(a=>a.f+(a.ini.length?', '+a.ini.join(''):'')).join('; '),r.yr,r.ti,r.so,r.doi].map(csvCell).join(','))).join('\n'),'text/csv');break}};
 document.addEventListener('selectionchange',()=>{const s=getSelection(),dd=D();if(dd&&s.rangeCount&&dd.contains(s.anchorNode))LAST=s.getRangeAt(0).cloneRange()});
}

/* ---------- styles + entry points ---------- */
const st=document.createElement('style');st.textContent=`.lr .lr-doc{border:1px solid var(--line);border-radius:10px;background:#fff;padding:18px 26px;min-height:380px;max-height:62vh;overflow:auto;font:14.5px/1.65 Georgia,"Times New Roman",serif}
.lr .lr-doc h1{font-size:23px;margin:.2em 0}.lr .lr-doc h2{font-size:17px;margin:1.1em 0 .3em;color:var(--brand)}.lr .lr-doc h3{font-size:14.5px;margin:.9em 0 .2em}.lr .lr-meta{color:#64748b;font-style:italic}
.lr .lr-cite{color:#0b5cad;cursor:pointer;border-radius:4px;padding:0 1px}.lr .lr-cite:hover{background:#e8f1fb}
.lr .lr-ref{margin:0 0 7px 24px;text-indent:-24px;font-size:13.5px}.lr .lr-ref.num{margin-left:34px;text-indent:-34px}.lr .lr-n{display:inline-block;min-width:30px;font-weight:700}.lr .lr-ref.flash{background:#fff3bf}
.lr .lr-tools{border-top:1px solid var(--line);padding-top:8px}.lr .lr-sp{flex:1}.lr-item{display:grid;grid-template-columns:22px 1fr auto;gap:8px;padding:7px 4px;border-bottom:1px solid var(--line);align-items:start}.lr-acts{display:flex;gap:4px;flex-wrap:wrap}
.lr .lr-scroll{max-height:52vh;overflow:auto}.lr .lr-ref-p{font-size:12px;color:#475569;margin-top:3px}.lr .lr-chk{margin-right:12px;font-size:12.5px}.lr .lr-doc table{width:auto;margin:6px 0}
.sample-header .toolbar #lrBtn{background:#fff4e0!important;color:#8a4b00!important}`;document.head.appendChild(st);
window.openLiteratureReview=open;
let btn=Q('#lrBtn');
if(!btn){btn=document.createElement('button');btn.id='lrBtn';btn.type='button';btn.innerHTML='📚 <span>Literature Review</span>';btn.title='Generate a literature review with recent references and in-text citations from the search results';const anc=Q('#dxBtn')||Q('#semBtn');if(anc){btn.className=anc.className;anc.insertAdjacentElement('afterend',btn)}else Q('.toolbar')?.appendChild(btn);}
btn.onclick=open;
const fg=Q('.feature-grid');if(fg){const c=document.createElement('button');c.className='feature-card';c.type='button';c.innerHTML='<span class="feature-icon gold">📚</span><div><b>Literature Review</b><small>Generate a cited review from your results</small></div>';c.onclick=open;fg.appendChild(c)}
const rb=Q('#resultRelated');if(rb){const b=document.createElement('button');b.className='ghost';b.type='button';b.id='resultLitReview';b.textContent='📚 Literature review';b.onclick=open;rb.insertAdjacentElement('afterend',b)}
})();
;
/* ---- x5-scholar-intelligence ---- */
/* ===== Semantic Layer additions: coverage, global rankings, unique IDs, scholar-controlled profiles, mentorship trees, integrated analytics, natural-language queries (existing features untouched) ===== */
(()=>{
'use strict';
const Q=s=>document.querySelector(s),QA=s=>[...document.querySelectorAll(s)];
const ls=(k,d)=>{try{return JSON.parse(localStorage.getItem(k))||d}catch{return d}},lp=(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v))}catch{toast('Browser storage blocked')}};
const F=n=>Math.round(+n||0).toLocaleString(),D=(n,k=2)=>(+n||0).toFixed(k),trim=s=>String(s||'').replace(/\u00a0/g,' ').trim();
const st=document.createElement('style');st.textContent=`.x5 .grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(125px,1fr));gap:8px;margin:8px 0}.x5 .kpi{border:1px solid var(--line);border-radius:10px;padding:8px;background:#f6fafc}.x5 .kpi b{display:block;font-size:19px;color:var(--brand)}.x5 .kpi span{font-size:11.5px;color:var(--muted)}.x5 a.ent{color:var(--brand);font-weight:600;cursor:pointer;text-decoration:underline dotted}.x5 .tier{display:inline-block;padding:1px 8px;border-radius:999px;font-size:11px;font-weight:700;background:#fff4d6;color:#8a5a00}.x5 .mono{font-family:ui-monospace,Consolas,monospace;font-size:11.5px}.x5 ul.tree{list-style:none;margin:2px 0 2px 10px;padding-left:12px;border-left:2px solid #c8dceb}.x5 .tree summary{cursor:pointer;padding:2px 0}.x5 .inf{color:#9a6700}.x5 .dec{color:#157347}.x5 label.f{display:block;font-size:12.5px;margin:5px 0}.x5 label.f input[type=text],.x5 label.f textarea{width:100%}.x5 .tiny{font-size:11.5px;color:var(--muted)}.x5 .bar{display:inline-block;height:9px;background:var(--brand2);border-radius:3px;vertical-align:middle}`;document.head.appendChild(st);

/* ---------- taxonomy & lookups ---------- */
const PROG=[['Scholarly communication & bibliometrics',/bibliometr|scientometr|citation|altmetric|h-index|research impact|scholarly communication|peer review|research evaluation|co-?authorship|journal impact|research productivity/],['Open access, repositories & research data',/open access|repositor|research data|data management|open science|open data|preprint|\bfair\b|data sharing/],['Digital libraries & preservation',/digital librar|digitali[sz]ation|digital preservation|digital archive|digital collection|e-resource|electronic resource|e-book/],['Knowledge organization & metadata',/ontolog|taxonom|classification|catalog|metadata|linked data|semantic web|knowledge graph|thesaur|indexing|knowledge organi/],['AI, data science & text mining',/artificial intelligence|machine learning|deep learning|chatgpt|large language|generative|natural language|text mining|\bnlp\b|data mining|big data|neural|\bai\b/],['Information literacy & LIS education',/information literacy|digital literacy|media literacy|curricul|lis education|library school|teaching|pedagog|training|competenc|instruction/],['Library services & management',/academic librar|public librar|school librar|special librar|library service|reference service|library management|library space|makerspace|outreach|library automation|user satisfaction|service quality|librarian/],['Information behaviour & users',/information seeking|information behavio|user behavio|information need|user experience|usability|information use|reading habit/],['Information retrieval & search',/information retrieval|search engine|query|recommender|relevance|discovery|search behavio/],['Social media, society & ethics',/social media|misinformation|fake news|covid|pandemic|digital divide|privacy|ethic|social network|twitter|facebook|whatsapp|inclusion|community/],['Archives, records & heritage',/archiv|records management|cultural heritage|museum|manuscript|heritage|special collection/],['Information systems & knowledge management',/knowledge management|information system|information management|enterprise|decision|cloud|blockchain|\biot\b|rfid|software|mobile app/],['Health & biomedical information',/health|medical|clinical|patient|biomedical|nursing|pubmed|medicine/],['General LIS & other',/$^/]];
const CNM={usa:'United States','united states of america':'United States','united state of america':'United States',america:'United States',england:'United Kingdom'};
const ISO={'India':'IN','United States':'US','United Kingdom':'GB','Canada':'CA','Sweden':'SE','Germany':'DE','South Korea':'KR','Netherlands':'NL','Iran':'IR','Singapore':'SG','Australia':'AU'};
const LAY=[['scholar','Scholars'],['inst','Institutions (publishing organisations)'],['venue','Journals / venues'],['country','Countries'],['program','Academic programs / disciplines'],['spec','Specialties (concepts)'],['aff','Declared affiliations (from scholar profiles)']];
const LN=Object.fromEntries(LAY);
const W0={n:.15,c:.25,h:.20,fw:.20,t10:.10,rec:.10},WL={n:'Output',c:'Citations',h:'h-index',fw:'Field-weighted impact',t10:'Top-10% papers',rec:'Recent output (2023–25)'};
const fnv=s=>{let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619)}return (h>>>0).toString(36).toUpperCase().padStart(7,'0')};
const stem=s=>norm(s).replace(/\([^)]*\)/g,' ').replace(/[-_\/]/g,' ').replace(/[^a-z0-9 ]/g,'').split(/\s+/).filter(Boolean).map(w=>w.length>3?w.replace(/ies$/,'y').replace(/([^s])s$/,'$1'):w).join(' ');
const parts=n=>{let t=norm(n).replace(/\./g,' ').replace(/[^a-z ,'-]/g,' ');if(t.includes(',')){const[a,b]=t.split(',');t=b+' '+a}const w=t.split(/\s+/).filter(Boolean);while(w.length>1&&/^(jr|sr|ii|iii)$/.test(w[w.length-1]))w.pop();return{s:w[w.length-1]||'',g:w.slice(0,-1)}};
const compat=(a,b)=>{const n=Math.min(a.length,b.length);for(let i=0;i<n;i++){const x=a[i],y=b[i];if(x!==y&&!((x.length===1&&y[0]===x)||(y.length===1&&x[0]===y)))return false}return true};
const orcidOk=o=>{o=String(o||'').replace(/^https?:\/\/orcid\.org\//,'').toUpperCase();if(!/^\d{4}-\d{4}-\d{4}-\d{3}[\dX]$/.test(o))return false;const d=o.replace(/-/g,'');let t=0;for(let i=0;i<15;i++)t=(t+ +d[i])*2;const r=(12-t%11)%11;return d[15]===(r===10?'X':String(r))};
const doiN=d=>String(d||'').toLowerCase().replace(/^https?:\/\/(dx\.)?doi\.org\//,'').trim();
const cn=i=>{const c=trim(CO[R[i][7]]);return c?(CNM[norm(c)]||c):''};
const profs=()=>ls('x5Profiles',{}),X={W:ls('x5W',{...W0}),lim:50};

/* ---------- engine ---------- */
function metrics(e){const ps=e.papers,cs=ps.map(i=>R[i][0]).sort((a,b)=>b-a);let h=0,g=0,run=0;while(h<cs.length&&cs[h]>=h+1)h++;cs.forEach((c,k)=>{run+=c;if(run>=(k+1)*(k+1))g=k+1});
 e.n=ps.length;e.c=run;e.h=h;e.g=g;e.i10=cs.filter(c=>c>=10).length;e.mc=e.n?run/e.n:0;e.fw=e.n?ps.reduce((a,i)=>a+X.fw[i],0)/e.n:0;e.t10=ps.filter(i=>X.top[i]).length;e.rec=ps.filter(i=>R[i][3]>=2023).length;
 const ys=ps.map(i=>R[i][3]);e.fy=ys.length?Math.min(...ys):0;e.ly=ys.length?Math.max(...ys):0;return e}
const lb=(a,v)=>{let l=0,h=a.length;while(l<h){const m=(l+h)>>1;a[m]<v?l=m+1:h=m}return l},ub=(a,v)=>{let l=0,h=a.length;while(l<h){const m=(l+h)>>1;a[m]<=v?l=m+1:h=m}return l};
function rankLayer(arr,W=X.W){const N=arr.length,tw=Object.values(W).reduce((a,b)=>a+b,0)||1,P={};Object.keys(W).forEach(k=>{const s=arr.map(e=>e[k]).sort((a,b)=>a-b);P[k]=e=>(lb(s,e[k])+ub(s,e[k]))/2/N});
 arr.forEach(e=>{e.sii=e.n?100*Object.keys(W).reduce((a,k)=>a+W[k]*P[k](e),0)/tw:0});const o=arr.slice().sort((a,b)=>b.sii-a.sii||b.c-a.c||b.n-a.n);o.forEach((e,i)=>{e.rank=i+1;e.pct=100*(i+1)/N;e.tier=N<20?('Rank '+(i+1)+' of '+N):e.pct<=1?'Elite · top 1%':e.pct<=5?'Distinguished · top 5%':e.pct<=10?'Notable · top 10%':e.pct<=25?'Established · top 25%':'Emerging'});return o}
function build(){
 if(X.ok===R)return;const N=R.length,P=PROG.length;X.pl=new Array(N);X.pr=new Array(N);
 for(let i=0;i<N;i++){const r=R[i],t=norm(r[2]),k=norm(r[11]),a=norm((r[12]||'').slice(0,600));let best=-1,bs=0;const lab=[];for(let p=0;p<P-1;p++){const re=PROG[p][1],s=re.test(t)*3+re.test(k)*2+re.test(a);if(s>=3)lab.push(p);if(s>bs){bs=s;best=p}}
  if(!lab.length)lab.push(bs>0?best:P-1);X.pl[i]=lab;X.pr[i]=bs>0?best:P-1}
 /* scholar identity resolution */
 const vid=new Map(),V=[],pa=new Array(N);
 for(let i=0;i<N;i++){const ids=[];for(const a of splitAuthors(R[i][1])){const key=norm(a).replace(/[^a-z ]/g,' ').replace(/\s+/g,' ').trim();if(!key)continue;let v=vid.get(key);if(v===undefined){v=V.length;vid.set(key,v);V.push({name:a,key,p:parts(a),papers:[],cl:v})}V[v].papers.push(i);if(!ids.includes(v))ids.push(v)}pa[i]=ids}
 const B=new Map();V.forEach((v,k)=>{if(v.p.g.length){const b=v.p.s+'|'+v.p.g[0][0];(B.get(b)||B.set(b,[]).get(b)).push(k)}});
 const co=k=>V[k].co||(V[k].co=new Set(V[k].papers.flatMap(i=>pa[i].filter(x=>x!==k).map(x=>V[x].p.s+'|'+(V[x].p.g[0]||'?')[0]))));
 const ov=(a,b)=>{const A=co(a),Bs=co(b);let n=0;A.forEach(x=>{if(Bs.has(x))n++});return n};
 X.log=[];X.amb=0;
 B.forEach(ks=>{if(ks.length<2)return;ks.sort((a,b)=>V[b].p.g.length-V[a].p.g.length||V[b].papers.length-V[a].papers.length);const cl=[];
  for(const k of ks){const g=V[k].p.g,full=g[0].length>1;let c=cl.filter(r=>compat(V[r].p.g,g));
   if(c.length>1){const e=c.map(r=>[r,ov(k,r)]).sort((a,b)=>b[1]-a[1]);c=e[0][1]>e[1][1]&&e[0][1]>0?[e[0][0]]:[];if(!c.length)X.amb++}
   if(c.length===1){const r=c[0],ev=ov(k,r),same=full&&V[r].p.g[0]===g[0];if(same||ev>0){V[k].cl=r;X.log.push([V[k].name,V[r].name,same?'same given name, compatible initials':'shared co-author evidence ('+ev+')'])}else{cl.push(k);X.amb++}}else cl.push(k)}});
 const SC=new Map();V.forEach(v=>{let s=SC.get(v.cl);if(!s)SC.set(v.cl,s={ix:0,names:new Map(),papers:new Set()});s.names.set(v.name,v.papers.length);v.papers.forEach(i=>s.papers.add(i))});
 const seen=new Map(),roots=new Map();X.nm=new Map();
 const sch=[...SC].map(([rk,s],ix)=>{const nm=[...s.names].sort((a,b)=>b[0].length-a[0].length||b[1]-a[1])[0][0];let id='ARE-S-'+fnv(parts(nm).s+'|'+norm(nm)),c=seen.get(id)||0;seen.set(id,c+1);if(c)id+='-'+(c+1);roots.set(rk,ix);[...s.names.keys()].forEach(a=>X.nm.set(norm(a),ix));return{ix,name:nm,id,aliases:[...s.names.keys()].filter(x=>x!==nm),all:[...s.papers],k:ix}});
 X.ps=pa.map(ids=>[...new Set(ids.map(v=>roots.get(V[v].cl)))]);X.rawAuthors=V.length;X.coll=[...seen.values()].filter(c=>c>1).length;
 /* year x program field normalisation */
 const ye=new Map(),yc={};X.fw=new Float64Array(N);X.top=new Uint8Array(N);
 for(let i=0;i<N;i++){const k=R[i][3]+'|'+X.pr[i],e=ye.get(k)||ye.set(k,[0,0]).get(k);e[0]+=R[i][0];e[1]++;(yc[R[i][3]]=yc[R[i][3]]||[]).push(R[i][0])}
 const thr={};Object.keys(yc).forEach(y=>{const s=yc[y].sort((a,b)=>a-b);thr[y]=s[Math.floor(.9*(s.length-1))]});
 for(let i=0;i<N;i++){const e=ye.get(R[i][3]+'|'+X.pr[i]),m=e[0]/e[1];X.fw[i]=m>0?R[i][0]/m:0;X.top[i]=R[i][0]>0&&R[i][0]>=thr[R[i][3]]?1:0}
 /* other layers */
 const grp=f=>{const m=new Map();for(let i=0;i<N;i++)[].concat(f(i)).forEach(k=>{if(k===''||k==null)return;(m.get(k)||m.set(k,[]).get(k)).push(i)});return m};
 const mk=(m,lab,pre,idf)=>[...m].map(([k,ps],ix)=>({ix,k,name:lab(k),papers:ps,id:'ARE-'+pre+'-'+idf(k)}));
 const lab=new Map(),spk=i=>{const o=[];splitKeywords(R[i][11]).forEach(x=>{const s=stem(x);if(s.length>2&&!o.includes(s)){o.push(s);if(!lab.has(s))lab.set(s,x.trim())}});return o};
 const sm=grp(spk);[...sm].forEach(([k,v])=>{if(v.length<8)sm.delete(k)});
 X.kf={scholar:i=>X.ps[i],inst:i=>R[i][5],venue:i=>R[i][4],country:cn,program:i=>X.pl[i],spec:spk};
 X.L={scholar:sch,inst:mk(grp(i=>R[i][5]),k=>trim(PUB[k]),'I',k=>fnv(trim(PUB[k]))),venue:mk(grp(i=>R[i][4]),k=>S[k],'V',k=>fnv(S[k])),country:mk(grp(cn),k=>k,'C',k=>ISO[k]||fnv(k).slice(0,3)),program:mk(grp(i=>X.pl[i]),k=>PROG[k][0],'P',k=>fnv(PROG[k][0])),spec:mk(sm,k=>lab.get(k)||k,'T',k=>fnv(k))};
 X.ent={};Object.keys(X.L).forEach(l=>{X.ent[l]=new Map(X.L[l].map(e=>[e.k,e]))});
 X.ok=R;recalc(true)}
function recalc(all){const pf=profs(),sc=X.L.scholar;sc.forEach(e=>{const p=pf[e.id],ex=p&&p.ex?new Set(p.ex):null;e.papers=ex?e.all.filter(i=>!ex.has(i)):e.all;e.prof=p||null});
 const ls_=all?Object.keys(X.L):['scholar'];ls_.forEach(l=>{X.L[l].forEach(metrics)});
 const aff=new Map();sc.forEach(e=>{const a=e.prof&&e.prof.aff&&e.prof.aff.trim();if(a)(aff.get(a)||aff.set(a,new Set()).get(a)).add(e)});
 X.L.aff=[...aff].map(([a,ss],ix)=>({ix,k:a,name:a,id:'ARE-A-'+fnv(norm(a)),papers:[...new Set([...ss].flatMap(e=>e.papers))],members:[...ss]}));X.L.aff.forEach(metrics);
 X.rk={};Object.keys(X.L).forEach(l=>{X.rk[l]=rankLayer(X.L[l])});
 X.dec=new Map();sc.forEach(e=>{const p=e.prof;if(!p)return;(p.mentors||[]).forEach(n=>{const m=X.nm.get(norm(n));if(m!==undefined&&m!==e.ix)(X.dec.get(m)||X.dec.set(m,[]).get(m)).push(e)});(p.mentees||[]).forEach(n=>{const m=X.nm.get(norm(n));if(m!==undefined&&m!==e.ix)(X.dec.get(e.ix)||X.dec.set(e.ix,[]).get(e.ix)).push(sc[m])})})}
const lnk=(l,e)=>`<a class="ent" data-pf="${l}:${e.ix}">${esc(e.name)}</a>`,badge=e=>`<span class="tier">${esc(e.tier)}</span>`;
const csvq=s=>'"'+String(s??'').replace(/"/g,'""')+'"';
const sortTop=(a,k,n)=>a.slice().sort((x,y)=>y[k]-x[k]).slice(0,n);

/* ---------- tab: coverage ---------- */
function cov(el){const N=R.length,pc=f=>D(100*R.filter(f).length/N,1)+'%',yrs=M.yearCounts.slice().sort((a,b)=>a[0]-b[0]),mx=Math.max(...yrs.map(y=>y[1]));
 const cites=y=>R.reduce((a,r)=>a+(r[3]===y?r[0]:0),0);
 el.innerHTML=`<div class="x5"><div class="note"><b>Scholarly coverage.</b> Everything below is computed live from the ${F(N)} records loaded in this portal. Author names are resolved into unique scholar identities (variants such as “D. K. W. Chiu” and “Dickson K.W. Chiu” are merged only with evidence); countries are normalised (USA / United States of America → United States).</div>
 <div class="grid">${[[N,'records'],[X.rawAuthors,'raw author strings'],[X.L.scholar.length,'unique scholars'],[X.L.inst.length,'institutions (publishers)'],[X.L.venue.length,'journals'],[X.L.country.length,'countries'],[X.L.program.length,'program areas'],[X.L.spec.length,'specialties (≥8 papers)'],[M.minYear+'–'+M.maxYear,'years']].map(([a,b])=>`<div class="kpi"><b>${typeof a==='number'?F(a):a}</b><span>${b}</span></div>`).join('')}</div>
 <div class="grid">${[['DOI',r=>r[9]],['Abstract',r=>r[12]],['Keywords',r=>r[11]],['Citation data',r=>r[0]>0]].map(([l,f])=>`<div class="kpi"><b>${pc(f)}</b><span>${l} present</span></div>`).join('')}</div>
 <table><tr><th>Year</th><th>Papers</th><th></th><th>Citations</th></tr>${yrs.map(([y,c])=>`<tr><td>${y}</td><td>${F(c)}</td><td><span class="bar" style="width:${Math.round(240*c/mx)}px"></span></td><td>${F(cites(y))}</td></tr>`).join('')}</table>
 <h3>Coverage by program area</h3><table><tr><th>Program / discipline</th><th>Papers</th><th>Scholars</th><th>Citations</th></tr>${X.rk.program.map(e=>`<tr><td>${lnk('program',e)}</td><td>${F(e.n)}</td><td>${F(new Set(e.papers.flatMap(i=>X.ps[i])).size)}</td><td>${F(e.c)}</td></tr>`).join('')}</table>
 <h3>Coverage by country (publisher location)</h3><table><tr><th>Country</th><th>ID</th><th>Papers</th><th>Journals</th></tr>${X.rk.country.map(e=>`<tr><td>${lnk('country',e)}</td><td class="mono">${e.id}</td><td>${F(e.n)}</td><td>${new Set(e.papers.map(i=>R[i][4])).size}</td></tr>`).join('')}</table>
 <p class="tiny">Scope note: the corpus is library &amp; information science literature, ${M.minYear}–${M.maxYear}. Records carry no author affiliations, so “institutions” are the publishing organisations and “countries” are publisher locations; scholars can declare their own affiliation in the Profiles tab, which then feeds the “Declared affiliations” ranking.</p></div>`}

/* ---------- tab: rankings ---------- */
function rk(el){const lay=X.rl||'scholar';el.innerHTML=`<div class="x5"><div class="note"><b>Quantitative global rankings.</b> Each entity gets an <b>Impact Index (0–100)</b>: the weighted mid-rank percentile across output, citations, h-index, field-weighted impact (citations ÷ mean citations of papers from the same year and program area), top-10% papers per year, and recent output. Rankings are computed for every layer of the corpus; weights are adjustable.</div>
 <div class="row"><label>Layer <select id="x5l">${LAY.map(([k,l])=>`<option value="${k}" ${k===lay?'selected':''}>${l}</option>`).join('')}</select></label><label>Min papers <input type="number" id="x5m" min="1" value="${X.rm||1}" style="width:60px"></label><input type="text" id="x5s" placeholder="Filter by name…" size="22"><button class="ghost" id="x5w">⚖ Index weights</button><button class="ghost" id="x5c">⇩ CSV</button></div><div id="x5wp" style="display:none" class="card"></div><div id="x5t"></div></div>`;
 const draw=()=>{const l=Q('#x5l').value,m=+Q('#x5m').value||1,f=norm(Q('#x5s').value),a=(X.rk[l]||[]).filter(e=>e.n>=m&&(!f||norm(e.name).includes(f)));X.rl=l;X.rm=m;
  Q('#x5t').innerHTML=`<p class="tiny">${F(a.length)} ${LN[l].toLowerCase()} ranked${l==='aff'&&!a.length?' — no scholar has declared an affiliation yet (Profiles tab)':''}</p><table><tr><th>#</th><th>Name</th><th>Unique ID</th><th>Tier</th><th>Index</th><th>Papers</th><th>Cites</th><th>h</th><th>FWCI</th><th>Top10%</th></tr>${a.slice(0,X.lim).map(e=>`<tr><td>${e.rank}</td><td>${lnk(l,e)}</td><td class="mono">${e.id}</td><td>${badge(e)}</td><td><b>${D(e.sii,1)}</b></td><td>${F(e.n)}</td><td>${F(e.c)}</td><td>${e.h}</td><td>${D(e.fw)}</td><td>${e.t10}</td></tr>`).join('')}</table>${a.length>X.lim?`<button class="ghost" id="x5mr">Show 50 more</button>`:''}`;
  const b=Q('#x5mr');if(b)b.onclick=()=>{X.lim+=50;draw()}};
 Q('#x5l').onchange=()=>{X.lim=50;draw()};Q('#x5m').onchange=Q('#x5s').oninput=()=>{X.lim=50;draw()};draw();
 Q('#x5w').onclick=()=>{const p=Q('#x5wp');p.style.display=p.style.display==='none'?'block':'none';p.innerHTML=Object.keys(W0).map(k=>`<label class="f" style="display:inline-block;margin-right:12px">${WL[k]} <input type="number" step="0.05" min="0" max="1" data-w="${k}" value="${X.W[k]}" style="width:62px"></label>`).join('')+'<button class="primary" id="x5wa">Apply</button> <button class="ghost" id="x5wr">Reset</button>';
  Q('#x5wa').onclick=()=>{QA('[data-w]').forEach(i=>X.W[i.dataset.w]=Math.max(0,+i.value||0));lp('x5W',X.W);Object.keys(X.L).forEach(l=>X.rk[l]=rankLayer(X.L[l]));draw();toast('Rankings recomputed')};Q('#x5wr').onclick=()=>{X.W={...W0};lp('x5W',X.W);Object.keys(X.L).forEach(l=>X.rk[l]=rankLayer(X.L[l]));Q('#x5w').click();Q('#x5w').click();draw()}};
 Q('#x5c').onclick=()=>{const l=Q('#x5l').value;download('ranking-'+l+'.csv','rank,id,name,tier,index,papers,citations,h_index,g_index,fwci,top10_papers,first_year,last_year\n'+X.rk[l].map(e=>[e.rank,e.id,csvq(e.name),csvq(e.tier),D(e.sii,2),e.n,e.c,e.h,e.g,D(e.fw,3),e.t10,e.fy,e.ly].join(',')).join('\n'),'text/csv')}}

/* ---------- tab: top & identity ---------- */
function idt(el){const top=(l,n)=>X.rk[l].slice(0,n),tb=(l,n)=>`<table><tr><th>#</th><th>Name</th><th>Unique ID</th><th>Tier</th><th>Index</th></tr>${top(l,n).map(e=>`<tr><td>${e.rank}</td><td>${lnk(l,e)}</td><td class="mono">${e.id}</td><td>${badge(e)}</td><td>${D(e.sii,1)}</td></tr>`).join('')}</table>`;
 el.innerHTML=`<div class="x5"><div class="note"><b>Unique identification.</b> Every scholar, institution, journal, country, program and specialty receives a deterministic ID (ARE-S / I / V / C / P / T + hash or ISO code) that stays the same across sessions. Scholar IDs are built after name-variant resolution; merges require a shared given name or shared co-author evidence, and uncertain cases are left separate.</div>
 <div class="grid">${[[X.rawAuthors,'raw author strings'],[X.L.scholar.length,'unique scholar IDs'],[X.log.length,'name variants merged'],[X.amb,'ambiguous cases kept apart'],[X.coll,'hash collisions (resolved)']].map(([a,b])=>`<div class="kpi"><b>${F(a)}</b><span>${b}</span></div>`).join('')}</div>
 <div class="row"><input type="text" id="x5q" size="34" placeholder="Resolve a name or ID (e.g. ARE-C-IN)"><button class="primary" id="x5g">Resolve</button><button class="ghost" id="x5ej">⇩ Registry JSON</button><button class="ghost" id="x5ec">⇩ Registry CSV</button></div><div id="x5r"></div>
 <h3>Top scholars worldwide</h3>${tb('scholar',15)}<h3>Top institutions</h3>${tb('inst',10)}<h3>Top countries</h3>${tb('country',10)}
 <details><summary><b>Name-merge log</b> (first 60 of ${F(X.log.length)})</summary><table><tr><th>Variant</th><th>Merged into</th><th>Evidence</th></tr>${X.log.slice(0,60).map(r=>`<tr><td>${esc(r[0])}</td><td>${esc(r[1])}</td><td>${esc(r[2])}</td></tr>`).join('')}</table></details></div>`;
 const res=()=>{const q=Q('#x5q').value.trim(),n=norm(q);if(!q)return;let h=[];Object.keys(X.L).forEach(l=>X.L[l].forEach(e=>{if(e.id.toLowerCase()===q.toLowerCase()||(l!=='spec'&&norm(e.name).includes(n))||(e.aliases||[]).some(a=>norm(a)===n))h.push([l,e])}));h.sort((a,b)=>(a[1].rank||1e9)-(b[1].rank||1e9));
  Q('#x5r').innerHTML=h.length?`<table><tr><th>Layer</th><th>Name</th><th>ID</th><th>Rank</th></tr>${h.slice(0,12).map(([l,e])=>`<tr><td>${LN[l]}</td><td>${lnk(l,e)}${(e.aliases||[]).length?` <span class="tiny">aka ${esc(e.aliases.slice(0,3).join('; '))}</span>`:''}</td><td class="mono">${e.id}</td><td>${e.rank}</td></tr>`).join('')}</table>`:'<p class="tiny">No match.</p>'};
 Q('#x5g').onclick=res;Q('#x5q').onkeydown=e=>{if(e.key==='Enter')res()};
 const reg=()=>['scholar','inst','venue','country','program'].flatMap(l=>X.L[l].map(e=>({layer:l,id:e.id,name:e.name,aliases:e.aliases||[],rank:e.rank,index:+D(e.sii,2),papers:e.n,citations:e.c})));
 Q('#x5ej').onclick=()=>download('identity-registry.json',JSON.stringify({format:'are-identity-registry/1',entities:reg()},null,1),'application/json');
 Q('#x5ec').onclick=()=>download('identity-registry.csv','layer,id,name,aliases,rank,index,papers,citations\n'+reg().map(r=>[r.layer,r.id,csvq(r.name),csvq(r.aliases.join('; ')),r.rank,r.index,r.papers,r.citations].join(',')).join('\n'),'text/csv')}

/* ---------- tab: profiles ---------- */
const pk=(l,e)=>X.kf[l]?null:null;
function topSchol(e,n=8){const m=new Map();e.papers.forEach(i=>X.ps[i].forEach(s=>{const o=m.get(s)||m.set(s,{n:0,c:0}).get(s);o.n++;o.c+=R[i][0]}));return [...m].sort((a,b)=>b[1].c-a[1].c||b[1].n-a[1].n).slice(0,n).map(([s,o])=>[X.L.scholar[s],o])}
function topKeys(e,l,n=6){const m=new Map();e.papers.forEach(i=>[].concat(X.kf[l](i)).forEach(k=>{if(k!==''&&k!=null)m.set(k,(m.get(k)||0)+1)}));return [...m].sort((a,b)=>b[1]-a[1]).slice(0,n).map(([k,v])=>[X.ent[l].get(k),v]).filter(x=>x[0])}
function profile(l,ix){const e=X.L[l][ix];if(!e)return '<p class="tiny">Not found.</p>';const ys=[2020,2021,2022,2023,2024,2025].map(y=>[y,e.papers.filter(i=>R[i][3]===y)]);const mx=Math.max(1,...ys.map(y=>y[1].length));
 const chips=(a,lay)=>a.map(([x,v])=>`<span class="chip" data-pf="${lay}:${x.ix}">${esc(x.name)} <b>${v}</b></span>`).join('')||'—';
 let h=`<div class="card"><h3 style="margin:0">${esc(e.name)}</h3><div class="tiny">${LN[l]} · <span class="mono">${e.id}</span> · global rank <b>${e.rank}</b> of ${F(X.L[l].length)} · ${badge(e)}${e.prof&&e.prof.v?' · <span class="dec">✓ verified by DOI evidence</span>':e.prof?' · <span class="inf">claimed, unverified</span>':''}</div>${(e.aliases||[]).length?`<div class="tiny">Also appears as: ${esc(e.aliases.join('; '))}</div>`:''}
 <div class="grid">${[[D(e.sii,1),'Impact Index'],[F(e.n),'papers'],[F(e.c),'citations'],[e.h,'h-index'],[e.g,'g-index'],[e.i10,'i10-index'],[D(e.fw),'FWCI'],[e.t10,'top-10% papers'],[e.fy?e.fy+'–'+e.ly:'—','active']].map(([a,b])=>`<div class="kpi"><b>${a}</b><span>${b}</span></div>`).join('')}</div>
 <table><tr><th>Year</th><th>Papers</th><th></th><th>Citations</th></tr>${ys.map(([y,p])=>`<tr><td>${y}</td><td>${p.length}</td><td><span class="bar" style="width:${Math.round(200*p.length/mx)}px"></span></td><td>${F(p.reduce((a,i)=>a+R[i][0],0))}</td></tr>`).join('')}</table>
 <p><b>Program areas</b> ${chips(topKeys(e,'program',4),'program')}</p><p><b>Specialties</b> ${chips(topKeys(e,'spec',8),'spec')}</p>`;
 if(l==='scholar'){const m=new Map();e.papers.forEach(i=>X.ps[i].forEach(s=>{if(s!==ix)m.set(s,(m.get(s)||0)+1)}));h+=`<p><b>Frequent co-authors</b> ${chips([...m].sort((a,b)=>b[1]-a[1]).slice(0,8).map(([s,v])=>[X.L.scholar[s],v]),'scholar')}</p><p><b>Venues</b> ${chips(topKeys(e,'venue',4),'venue')} <b>Publisher countries</b> ${chips(topKeys(e,'country',3),'country')}</p>`}
 else if(l==='aff')h+=`<p><b>Members</b> ${chips(e.members.map(s=>[s,s.n]),'scholar')}</p>`;else h+=`<p><b>Leading scholars</b> ${chips(topSchol(e).map(([s,o])=>[s,o.c]),'scholar')} <span class="tiny">(cites)</span></p><p><b>Main countries</b> ${chips(topKeys(e,'country',4),'country')}</p>`;
 h+=`<b>Most cited papers</b><ol>${e.papers.slice().sort((a,b)=>R[b][0]-R[a][0]).slice(0,8).map(i=>`<li><a href="#" data-p="${i}">${esc(R[i][2])}</a> <span class="tiny">(${R[i][3]}, ${R[i][0]} cites)</span></li>`).join('')}</ol>`;
 if(l==='scholar')h+=`<button class="ghost" data-mt="${ix}">🌳 Mentorship tree</button> `;return h+`<button class="ghost" data-json="${l}:${ix}">⇩ Profile JSON-LD</button></div>`+(l==='scholar'?claimForm(e):'')}
function claimForm(e){const p=e.prof||{},v=k=>esc(p[k]||'');return `<div class="card"><h3 style="margin:0">Scholar-controlled profile</h3><p class="tiny">Are you ${esc(e.name)}? Claim and curate this profile. Everything you enter is stored in this browser and can be exported/imported as JSON; “verified” means a DOI you entered belongs to this scholar’s records. Papers marked “not mine” are removed from this profile’s metrics and ranking.</p>
 <label class="f">Affiliation <input type="text" id="x5pa" value="${v('aff')}"></label><label class="f">ORCID <input type="text" id="x5po" placeholder="0000-0002-1825-0097" value="${v('orcid')}"></label><label class="f">Website <input type="text" id="x5pw" value="${v('web')}"></label><label class="f">Bio / research interests <textarea id="x5pb" rows="2">${v('bio')}</textarea></label>
 <label class="f">Evidence DOI (one of your papers) <input type="text" id="x5pd" value="${v('doi')}"></label><label class="f">Mentors (names; separate with ;) <input type="text" id="x5pm" value="${esc((p.mentors||[]).join('; '))}"></label><label class="f">Mentees (names; separate with ;) <input type="text" id="x5pe" value="${esc((p.mentees||[]).join('; '))}"></label>
 <details><summary>Mark papers that are not yours (${e.all.length})</summary>${e.all.slice(0,60).map(i=>`<label class="f"><input type="checkbox" data-ex="${i}" ${(p.ex||[]).includes(i)?'checked':''}> ${esc(R[i][2].slice(0,110))} <span class="tiny">(${R[i][3]})</span></label>`).join('')}</details>
 <div class="row"><button class="primary" id="x5ps">Save profile</button><button class="ghost" id="x5px">⇩ Export all profiles</button><button class="ghost" id="x5pi">⇧ Import</button><button class="ghost" id="x5pd2">Delete this profile</button><input type="file" id="x5pf" accept=".json" style="display:none"></div><div id="x5pm2" class="tiny"></div></div>`}
function saveProfile(e){const g=s=>Q(s).value.trim(),L=s=>g(s).split(/;/).map(x=>x.trim()).filter(Boolean),o=g('#x5po'),d=doiN(g('#x5pd')),msg=[];
 if(o&&!orcidOk(o)){Q('#x5pm2').innerHTML='<span class="bad">ORCID is not valid (format or checksum).</span>';return}
 const v=d&&e.all.some(i=>doiN(R[i][9])===d);if(d&&!v)msg.push('DOI not found among this scholar’s records — saved as unverified.');
 const P=profs();P[e.id]={aff:g('#x5pa'),orcid:o.replace(/^https?:\/\/orcid\.org\//,''),web:g('#x5pw'),bio:g('#x5pb'),doi:d,v:v?1:0,mentors:L('#x5pm'),mentees:L('#x5pe'),ex:QA('[data-ex]:checked').map(c=>+c.dataset.ex),ts:new Date().toISOString()};lp('x5Profiles',P);recalc(false);toast('Profile saved'+(v?' · verified':''));X.pend=['scholar',e.ix];window.openSemanticLayer('x5pf')}
function pf(el){el.innerHTML=`<div class="x5"><div class="note"><b>Detailed profiles</b> for every scholar, institution, journal, country, program and specialty. Scholars can claim and control their own profile.</div><div class="row"><select id="x5pl">${LAY.map(([k,l])=>`<option value="${k}">${l}</option>`).join('')}</select><input type="text" id="x5pq" size="30" placeholder="Search by name or ID…"><button class="primary" id="x5pg">Search</button></div><div id="x5pr"></div><div id="x5pv"></div></div>`;
 const show=(l,ix)=>{X.cur=[l,ix];Q('#x5pv').innerHTML=profile(l,ix);Q('#x5pr').innerHTML='';const e=X.L[l][ix];if(l==='scholar'){Q('#x5ps').onclick=()=>saveProfile(e);Q('#x5px').onclick=()=>download('scholar-profiles.json',JSON.stringify({format:'are-scholar-profiles/1',profiles:profs()},null,1),'application/json');Q('#x5pi').onclick=()=>Q('#x5pf').click();
  Q('#x5pf').onchange=async ev=>{try{const j=JSON.parse(await ev.target.files[0].text()),P={...profs(),...(j.profiles||{})};lp('x5Profiles',P);recalc(false);toast('Profiles imported');show(l,ix)}catch{toast('Not a valid profile file')}};
  Q('#x5pd2').onclick=()=>{if(!confirm('Delete this profile?'))return;const P=profs();delete P[e.id];lp('x5Profiles',P);recalc(false);show(l,ix)}}};
 const find=()=>{const l=Q('#x5pl').value,n=norm(Q('#x5pq').value);if(!n)return;const a=X.L[l].filter(e=>e.id.toLowerCase()===n||norm(e.name).includes(n)||(e.aliases||[]).some(x=>norm(x).includes(n))).sort((a,b)=>(a.rank||1e9)-(b.rank||1e9)).slice(0,25);Q('#x5pr').innerHTML=a.map(e=>`<span class="chip" data-pf="${l}:${e.ix}">${esc(e.name)} <small>#${e.rank}</small></span>`).join('')||'<span class="tiny">No match</span>'};
 Q('#x5pg').onclick=find;Q('#x5pq').onkeydown=e=>{if(e.key==='Enter')find()};X.show=show;
 const c=X.pend||X.cur;X.pend=null;if(c)show(...c)}
function ld(l,ix){const e=X.L[l][ix],ty={scholar:'Person',country:'Country'}[l]||'Organization',p=e.prof||{};return JSON.stringify({'@context':{schema:'https://schema.org/'},'@id':'urn:are:'+e.id,'@type':'schema:'+(l==='scholar'?'Person':ty),'schema:name':e.name,'schema:identifier':e.id,...(p.orcid?{'schema:sameAs':'https://orcid.org/'+p.orcid}:{}),...(p.aff?{'schema:affiliation':p.aff}:{}),'schema:alternateName':e.aliases||[],'are:rank':e.rank,'are:impactIndex':+D(e.sii,2),'are:papers':e.n,'are:citations':e.c,'are:hIndex':e.h},null,1)}

/* ---------- tab: mentorship trees ---------- */
function mentees(s){const m=new Map(),sid=s.ix;for(const i of s.papers){const a=X.ps[i];if(a.length<2)continue;const last=a[a.length-1]===sid;for(const j of a)if(j!==sid){const o=m.get(j)||m.set(j,{n:0,l:0}).get(j);o.n++;if(last)o.l++}}
 return [...m].map(([j,o])=>{const t=X.L.scholar[j],sh=o.n/(t.papers.length||1);return o.n>=2&&sh>=.5&&s.papers.length>=1.5*t.papers.length&&s.fy<=t.fy?{t,k:'inferred',n:o.n,sc:.5*sh+.3*Math.min(o.n,5)/5+.2*o.l/o.n}:null}).filter(Boolean).sort((a,b)=>b.sc-a.sc).slice(0,8)}
function mentors(s){const m=new Map();s.papers.forEach(i=>X.ps[i].forEach(j=>{if(j!==s.ix)m.set(j,(m.get(j)||0)+1)}));return [...m].sort((a,b)=>b[1]-a[1]).slice(0,15).map(([j])=>X.L.scholar[j]).map(c=>{const x=mentees(c).find(y=>y.t===s);return x?{t:c,k:'inferred',n:x.n,sc:x.sc}:null}).filter(Boolean)}
const kids=s=>[...mentees(s),...(X.dec.get(s.ix)||[]).map(t=>({t,k:'declared'}))];
function treeData(s,d,seen){seen.add(s.ix);return{s,kids:d>0?kids(s).filter(x=>!seen.has(x.t.ix)).map(x=>({...x,...treeData(x.t,d-1,new Set(seen))})):[]}}
const tHtml=(n,o)=>`<li><details ${o?'open':''}><summary>${lnk('scholar',n.s)} <span class="tiny">${F(n.s.n)} papers · ${F(n.s.c)} cites · ${n.s.fy||''}–${n.s.ly||''}</span> ${n.k?`<span class="${n.k==='inferred'?'inf':'dec'}">${n.k}${n.sc?' '+D(n.sc,2):''}</span>`:''}</summary>${n.kids.length?`<ul class="tree">${n.kids.map(c=>tHtml(c,false)).join('')}</ul>`:''}</details></li>`;
const tMd=(n,d=0)=>'  '.repeat(d)+'- '+n.s.name+' ('+n.s.id+')'+(n.k?' ['+n.k+']':'')+'\n'+n.kids.map(c=>tMd(c,d+1)).join('');
const tDot=n=>n.kids.map(c=>`  "${n.s.name}" -> "${c.s.name}" [label="${c.k}"];\n`+tDot(c)).join('');
function mt(el){const sel=X.mt!==undefined?X.mt:X.rk.scholar[0].ix;el.innerHTML=`<div class="x5"><div class="note"><b>Academic Mentorship Trees.</b> The records carry no supervisor data, so two kinds of edges are shown: <span class="dec">declared</span> (entered by scholars in their own profiles) and <span class="inf">inferred</span> from publication patterns (≥2 joint papers, ≥50% of the junior’s output with the senior, senior has ≥1.5× the output and started no later). Inferred edges are indicative, not proof of supervision.</div><div class="row"><input type="text" id="x5tq" size="30" placeholder="Search a scholar…"><button class="primary" id="x5tg">Search</button><label>Depth <select id="x5td"><option>1</option><option selected>2</option><option>3</option></select></label><button class="ghost" id="x5tj">⇩ JSON</button><button class="ghost" id="x5tm">⇩ Markdown</button><button class="ghost" id="x5tdot">⇩ Graphviz</button></div><div id="x5tr"></div><div id="x5tt"></div></div>`;
 let cur=sel,T=null;const draw=()=>{const s=X.L.scholar[cur];T=treeData(s,+Q('#x5td').value,new Set());const mm=mentors(s);Q('#x5tt').innerHTML=`<p><b>Likely mentors of ${esc(s.name)}:</b> ${mm.map(x=>lnk('scholar',x.t)+` <span class="inf">${D(x.sc,2)}</span>`).join(', ')||'<span class="tiny">none detected</span>'}</p><ul class="tree" style="margin-left:0">${tHtml(T,true)}</ul>`;X.mt=cur};
 Q('#x5td').onchange=draw;Q('#x5tg').onclick=()=>{const n=norm(Q('#x5tq').value);if(!n)return;const a=X.L.scholar.filter(e=>norm(e.name).includes(n)||e.aliases.some(x=>norm(x).includes(n))).sort((a,b)=>a.rank-b.rank).slice(0,15);Q('#x5tr').innerHTML=a.map(e=>`<span class="chip" data-mts="${e.ix}">${esc(e.name)} <small>#${e.rank}</small></span>`).join('')};
 el.addEventListener('click',e=>{const c=e.target.closest('[data-mts]');if(c){cur=+c.dataset.mts;Q('#x5tr').innerHTML='';draw()}});
 const clean=n=>({id:n.s.id,name:n.s.name,papers:n.s.n,citations:n.s.c,relation:n.k||'root',score:n.sc?+D(n.sc,3):undefined,mentees:n.kids.map(clean)});
 Q('#x5tj').onclick=()=>download('mentorship-tree.json',JSON.stringify(clean(T),null,1),'application/json');Q('#x5tm').onclick=()=>download('mentorship-tree.md',tMd(T),'text/markdown');Q('#x5tdot').onclick=()=>download('mentorship-tree.dot','digraph mentorship {\n  rankdir=LR;\n'+tDot(T)+'}\n','text/vnd.graphviz');draw()}

/* ---------- tab: integrated analytics ---------- */
const DIM={country:['Country',i=>cn(i)||'Unspecified'],program:['Program area',i=>X.pl[i].map(p=>PROG[p][0])],inst:['Institution',i=>trim(PUB[R[i][5]])||'Unspecified'],year:['Year',i=>String(R[i][3])],venue:['Journal',i=>S[R[i][4]]]};
function an(el){const sel=(id,v)=>`<select id="${id}">${Object.entries(DIM).map(([k,d])=>`<option value="${k}" ${k===v?'selected':''}>${d[0]}</option>`).join('')}</select>`;
 el.innerHTML=`<div class="x5"><div class="note"><b>Integrated analytics</b> across scholars, institutions, countries and specialties: cross-tabulate any two dimensions, then read the automatic insights.</div><div class="row"><label>Rows ${sel('x5ar','country')}</label><label>Columns ${sel('x5ac','program')}</label><label>Measure <select id="x5am"><option value="n">Papers</option><option value="c">Citations</option><option value="fw">Mean FWCI</option><option value="rca">Specialization (RCA)</option></select></label><label>Max rows <input type="number" id="x5ax" value="12" style="width:56px"></label><button class="ghost" id="x5acv">⇩ CSV</button></div><div id="x5ao" style="overflow:auto"></div><h3>Insights</h3><div id="x5ai"></div></div>`;
 let CSV='';const draw=()=>{const r=DIM[Q('#x5ar').value][1],c=DIM[Q('#x5ac').value][1],m=Q('#x5am').value,mx=+Q('#x5ax').value||12,cell=new Map(),rt=new Map(),ct=new Map();let T=0;
  for(let i=0;i<R.length;i++){const rs=[].concat(r(i)),cs=[].concat(c(i));rs.forEach(a=>cs.forEach(b=>{const k=a+'\u0001'+b,o=cell.get(k)||cell.set(k,{n:0,c:0,f:0}).get(k);o.n++;o.c+=R[i][0];o.f+=X.fw[i];rt.set(a,(rt.get(a)||0)+1);ct.set(b,(ct.get(b)||0)+1);T++}))}
  const rows=[...rt].sort((a,b)=>b[1]-a[1]).slice(0,mx).map(x=>x[0]),cols=[...ct].sort((a,b)=>b[1]-a[1]).slice(0,10).map(x=>x[0]);
  const val=(a,b)=>{const o=cell.get(a+'\u0001'+b);if(!o)return 0;return m==='n'?o.n:m==='c'?o.c:m==='fw'?o.f/o.n:(o.n/rt.get(a))/(ct.get(b)/T)};
  const all=rows.flatMap(a=>cols.map(b=>val(a,b))),hi=Math.max(...all,1e-9);const cl=v=>`background:rgba(24,78,119,${(.08+.8*v/hi).toFixed(2)});color:${v/hi>.55?'#fff':'#162033'}`;
  Q('#x5ao').innerHTML=`<table><tr><th></th>${cols.map(b=>`<th>${esc(b.length>22?b.slice(0,21)+'…':b)}</th>`).join('')}</tr>${rows.map(a=>`<tr><th>${esc(a.length>30?a.slice(0,29)+'…':a)}</th>${cols.map(b=>{const v=val(a,b);return `<td style="${cl(v)}">${m==='n'||m==='c'?F(v):D(v)}</td>`}).join('')}</tr>`).join('')}</table>`;
  CSV='row,'+cols.map(csvq).join(',')+'\n'+rows.map(a=>csvq(a)+','+cols.map(b=>D(val(a,b),3)).join(',')).join('\n')};
 ['x5ar','x5ac','x5am','x5ax'].forEach(i=>Q('#'+i).onchange=draw);Q('#x5acv').onclick=()=>download('cross-tab.csv',CSV,'text/csv');draw();
 const sc=X.L.scholar,gini=a=>{a=a.slice().sort((x,y)=>x-y);const n=a.length,s=a.reduce((x,y)=>x+y,0)||1;return a.reduce((t,v,i)=>t+(2*(i+1)-n-1)*v,0)/(n*s)},tc=sc.map(e=>e.c).sort((a,b)=>b-a),tot=tc.reduce((a,b)=>a+b,0)||1,top1=tc.slice(0,Math.ceil(sc.length*.01)).reduce((a,b)=>a+b,0);
 const grow=X.L.program.filter(e=>e.n>=50).map(e=>[e,e.papers.filter(i=>R[i][3]>=2023).length/Math.max(1,e.papers.filter(i=>R[i][3]<2023).length)]).sort((a,b)=>b[1]-a[1]),multi=sc.filter(e=>new Set(e.papers.map(cn).filter(Boolean)).size>=2).length;
 const cc=X.L.country.filter(e=>e.n>=100),spec=[];cc.forEach(c=>X.L.program.forEach(p=>{const ov=c.papers.filter(i=>X.pl[i].includes(p.k)).length;if(ov>=20)spec.push([c,p,(ov/c.n)/(p.n/R.length)])}));spec.sort((a,b)=>b[2]-a[2]);
 Q('#x5ai').innerHTML=`<ul><li><b>Concentration:</b> the top 1% of scholars (${F(Math.ceil(sc.length*.01))}) hold ${D(100*top1/tot,1)}% of all citations; citation Gini = ${D(gini(tc.slice().reverse()),2)}.</li><li><b>Leading scholar:</b> ${lnk('scholar',X.rk.scholar[0])} (${F(X.rk.scholar[0].c)} citations, h=${X.rk.scholar[0].h}); <b>leading institution:</b> ${lnk('inst',X.rk.inst[0])}; <b>leading country:</b> ${lnk('country',X.rk.country[0])}.</li>${grow[0]?`<li><b>Fastest-rising program area</b> (2023–25 vs 2020–22 output): ${lnk('program',grow[0][0])} (×${D(grow[0][1])}).</li>`:''}${spec[0]?`<li><b>Strongest national specialization:</b> ${lnk('country',spec[0][0])} in ${lnk('program',spec[0][1])} (RCA ${D(spec[0][2])}).</li>`:''}<li><b>Cross-border publishing:</b> ${F(multi)} scholars publish in journals from two or more countries.</li></ul>`}

/* ---------- tab: natural-language questions ---------- */
function plan(q){const t=norm(q),p={layer:'scholar',metric:'sii',n:10};let m;
 if(/countr|nation/.test(t))p.layer='country';else if(/institution|publisher|universit|organi[sz]ation/.test(t))p.layer='inst';else if(/journal|venue/.test(t))p.layer='venue';else if(/program|discipline|field|area/.test(t))p.layer='program';else if(/concept|topic|keyword|specialt/.test(t))p.layer='spec';
 if(/h-?index/.test(t))p.metric='h';else if(/cit/.test(t))p.metric='c';else if(/productiv|prolific|most papers|publications/.test(t))p.metric='n';else if(/fwci|field.?weighted|influen/.test(t))p.metric='fw';else if(/grow|rising|recent|emerging/.test(t))p.metric='rec';
 if(m=t.match(/\b(?:top|best|leading|first)\s+(\d{1,3})\b/)||t.match(/\b(\d{1,3})\s+(?:top|best|most)\b/))p.n=Math.min(100,+m[1]);
 if(m=t.match(/(?:since|after|from)\s+((?:19|20)\d\d)/))p.from=+m[1];if(m=t.match(/(?:before|until)\s+((?:19|20)\d\d)/))p.to=+m[1];if(m=t.match(/\bin\s+((?:19|20)\d\d)\b/))p.from=p.to=+m[1];
 if(m=t.match(/(?:compare|versus)\s+(.+?)\s+(?:and|vs\.?|versus|with)\s+(.+?)[?.!]?$/))p.cmp=[m[1],m[2]];else if(m=t.match(/(?:co-?authors? of|collaborat\w+ with|works? with)\s+(.+?)[?.!]?$/))p.co=m[1];else if(m=t.match(/(?:mentees? of|students? of|mentor\w* of|lineage of)\s+(.+?)[?.!]?$/))p.mt=m[1];else if(m=t.match(/(?:profile of|tell me about|who is)\s+(.+?)[?.!]?$/))p.who=m[1];
 else{if(m=t.match(/(?:published |publishing )?(?:in|from) (india|united states|usa|united kingdom|uk|canada|sweden|germany|south korea|netherlands|iran|singapore|australia)\b/)){const k=m[1];p.cty={usa:'United States','united states':'United States',uk:'United Kingdom'}[k]||k.replace(/\b\w/g,c=>c.toUpperCase())}
  if(m=t.match(/\b(?:in|on|about|regarding)\s+(?!(?:19|20)\d\d\b)(?!the\b)([a-z][a-z0-9 -]{2,40}?)(?=\s+(?:since|after|before|from|until|by|in)\b|[?.!]?$)/)){if(!/^(india|united|usa|uk|canada|sweden|germany|south|netherlands|iran|singapore|australia|library|world)/.test(m[1])||/librar/.test(m[1]))p.topic=m[1]}}
 return p}
function findEnt(q,pref){const n=norm(q).trim();for(const l of [pref,'scholar','country','inst','program','venue','spec'].filter(Boolean)){const a=X.L[l].filter(e=>norm(e.name)===n||(e.aliases||[]).some(x=>norm(x)===n));if(a.length)return[l,a[0]]}for(const l of [pref,'scholar','country','inst','program','venue','spec'].filter(Boolean)){const a=X.L[l].filter(e=>norm(e.name).includes(n)||(e.aliases||[]).some(x=>norm(x).includes(n))).sort((a,b)=>a.rank-b.rank);if(a.length)return[l,a[0]]}return null}
function runPlan(p){const E=(l,e)=>lnk(l,e),tbl=(l,a)=>`<table><tr><th>#</th><th>Name</th><th>ID</th><th>Papers</th><th>Cites</th><th>h</th><th>FWCI</th></tr>${a.map((e,i)=>`<tr><td>${i+1}</td><td>${E(l,e)}</td><td class="mono">${e.id}</td><td>${F(e.n)}</td><td>${F(e.c)}</td><td>${e.h}</td><td>${D(e.fw)}</td></tr>`).join('')}</table>`;
 if(p.cmp){const a=findEnt(p.cmp[0],p.layer),b=a&&findEnt(p.cmp[1],a[0]);if(!a||!b)return'<p class="bad">I could not match both names.</p>';const rows=[['Rank',e=>e.rank],['Impact Index',e=>D(e.sii,1)],['Papers',e=>F(e.n)],['Citations',e=>F(e.c)],['h-index',e=>e.h],['FWCI',e=>D(e.fw)],['Top-10% papers',e=>e.t10]];return `<table><tr><th></th><th>${E(a[0],a[1])}</th><th>${E(b[0],b[1])}</th></tr>${rows.map(([l,f])=>`<tr><td>${l}</td><td>${f(a[1])}</td><td>${f(b[1])}</td></tr>`).join('')}</table>`}
 if(p.who){const r=findEnt(p.who,p.layer);return r?profile(...[r[0],r[1].ix]):'<p class="bad">No matching entity.</p>'}
 if(p.co){const r=findEnt(p.co,'scholar');if(!r)return'<p class="bad">Scholar not found.</p>';const m=new Map();r[1].papers.forEach(i=>X.ps[i].forEach(s=>{if(s!==r[1].ix)m.set(s,(m.get(s)||0)+1)}));return `<p>Co-authors of ${E('scholar',r[1])}:</p><table><tr><th>Co-author</th><th>Joint papers</th></tr>${[...m].sort((a,b)=>b[1]-a[1]).slice(0,p.n).map(([s,v])=>`<tr><td>${E('scholar',X.L.scholar[s])}</td><td>${v}</td></tr>`).join('')}</table>`}
 if(p.mt){const r=findEnt(p.mt,'scholar');if(!r)return'<p class="bad">Scholar not found.</p>';X.mt=r[1].ix;return `<p>Mentees of ${E('scholar',r[1])} (inferred + declared): ${kids(r[1]).map(x=>E('scholar',x.t)+` <span class="${x.k==='inferred'?'inf':'dec'}">${x.k}</span>`).join(', ')||'none detected'}. <a class="ent" data-tab="x5mt">Open the full tree →</a></p>`}
 let L=p.layer,rows;const filt=p.from||p.to||p.cty||p.topic;
 if(!filt)rows=X.rk[L].slice();else{const tk=p.topic?tokens(p.topic).filter(w=>w.length>2):[],ok=i=>(!p.from||R[i][3]>=p.from)&&(!p.to||R[i][3]<=p.to)&&(!p.cty||cn(i)===p.cty)&&(!tk.length||tk.every(w=>INDEX[i].t.includes(w)||INDEX[i].k.includes(w))),m=new Map();let np=0;
  for(let i=0;i<R.length;i++){if(!ok(i))continue;np++;[].concat(X.kf[L](i)).forEach(k=>{if(k===''||k==null)return;(m.get(k)||m.set(k,[]).get(k)).push(i)})}
  rows=[...m].map(([k,ps])=>{const b=X.ent[L].get(k);return b?metrics({ix:b.ix,name:b.name,id:b.id,papers:ps}):null}).filter(Boolean);p.np=np;if(!np)return'<p class="bad">No records match those filters.</p>'}
 const key=p.metric==='sii'?(filt?'c':'sii'):p.metric;rows=rows.filter(e=>e.n>=(L==='scholar'&&!filt?1:1)).sort((a,b)=>b[key]-a[key]||b.c-a.c).slice(0,p.n);
 return `<p class="tiny">${LN[L]} ranked by ${key==='sii'?'Impact Index':({n:'papers',c:'citations',h:'h-index',fw:'FWCI',rec:'recent output'})[key]}${p.np!==undefined?` · ${F(p.np)} matching records`:''}${p.topic?` · topic “${esc(p.topic)}”`:''}${p.cty?` · publisher country ${esc(p.cty)}`:''}${p.from?` · from ${p.from}`:''}${p.to?` · to ${p.to}`:''}</p>`+tbl(L,rows)}
async function llmPlan(q){const c=ls('x4AI',{});if(!c.key||c.mode==='local')return null;const sys='Convert the question about a bibliometric corpus into JSON only, no prose. Keys (all optional): layer(scholar|inst|venue|country|program|spec), metric(sii|n|c|h|fw|rec), n(int), from(int year), to(int year), cty(country name), topic(string), cmp([nameA,nameB]), co(scholar name), mt(scholar name), who(entity name).';
 try{let txt;if(c.mode==='anthropic'){const r=await fetch('https://api.anthropic.com/v1/messages',{method:'POST',headers:{'content-type':'application/json','x-api-key':c.key,'anthropic-version':'2023-06-01','anthropic-dangerous-direct-browser-access':'true'},body:JSON.stringify({model:c.model||'claude-sonnet-5-5',max_tokens:300,system:sys,messages:[{role:'user',content:q}]})});const j=await r.json();txt=(j.content||[]).map(x=>x.text||'').join('')}
  else{const r=await fetch((c.endpoint||'https://api.openai.com/v1').replace(/\/$/,'')+'/chat/completions',{method:'POST',headers:{'content-type':'application/json',Authorization:'Bearer '+c.key},body:JSON.stringify({model:c.model,messages:[{role:'system',content:sys},{role:'user',content:q}],max_tokens:300})});const j=await r.json();txt=j.choices?.[0]?.message?.content||''}
  const o=JSON.parse(txt.replace(/```json|```/g,'').trim());return {layer:'scholar',metric:'sii',n:10,...o}}catch{return null}}
function nl(el){const EX=['Top 10 scholars in information literacy since 2022','Which countries lead in artificial intelligence?','Most cited journals on open access','Compare India and United States','Co-authors of Brady Lund','Mentees of Manoj Kumar Verma','Who is Yi Bu'];
 el.innerHTML=`<div class="x5"><div class="note"><b>Ask in plain language.</b> Questions are translated into a structured query over scholars, institutions, countries, programs and specialties and answered from the corpus. Works offline with the built-in engine${ls('x4AI',{}).key&&ls('x4AI',{}).mode!=='local'?'; your configured LLM is used to interpret the question first (only the question text is sent)':'; configure an LLM under AI Search to use it as the question interpreter'}.</div><div class="row"><input type="text" id="x5nq" size="60" placeholder="e.g. top 15 scholars in bibliometrics since 2021"><button class="primary" id="x5ng">Ask</button></div><p>${EX.map(x=>`<span class="chip" data-nq="${esc(x)}">${esc(x)}</span>`).join('')}</p><div id="x5no"></div></div>`;
 const run=async q=>{if(!q.trim())return;Q('#x5no').innerHTML='<p class="tiny">Thinking…</p>';let p=await llmPlan(q),src='LLM interpreter';if(!p){p=plan(q);src='built-in interpreter'}Q('#x5no').innerHTML=`<p class="tiny">Interpreted by ${src}: <span class="mono">${esc(JSON.stringify(p))}</span></p>`+runPlan(p)};
 Q('#x5ng').onclick=()=>run(Q('#x5nq').value);Q('#x5nq').onkeydown=e=>{if(e.key==='Enter')run(e.target.value)};el.addEventListener('click',e=>{const c=e.target.closest('[data-nq]');if(c){Q('#x5nq').value=c.dataset.nq;run(c.dataset.nq)}})}

/* ---------- registry ---------- */
const TABS={x5cov:cov,x5rk:rk,x5id:idt,x5pf:pf,x5mt:mt,x5an:an,x5nl:nl};
window.X5={tabs:[['x5cov','★ Coverage'],['x5rk','★ Global rankings'],['x5id','★ Top & identity'],['x5pf','★ Profiles'],['x5mt','★ Mentorship trees'],['x5an','★ Analytics'],['x5nl','★ Ask (NL)']],
 render(k,el){if(typeof R==='undefined'||!R){el.innerHTML='<p class="tiny">Data is still loading…</p>';return}
  const go=()=>{try{TABS[k](el)}catch(e){el.innerHTML='<div class="note bad">Could not render: '+esc(e.message||e)+'</div>'}
   if(!el.__x5){el.__x5=1;el.addEventListener('click',ev=>{const a=ev.target.closest('[data-pf]'),p=ev.target.closest('[data-p]'),m=ev.target.closest('[data-mt]'),j=ev.target.closest('[data-json]'),t=ev.target.closest('[data-tab]');
    if(a){const[l,ix]=a.dataset.pf.split(':');X.pend=[l,+ix];window.openSemanticLayer('x5pf')}else if(p){ev.preventDefault();detail(+p.dataset.p)}else if(m){X.mt=+m.dataset.mt;window.openSemanticLayer('x5mt')}else if(t)window.openSemanticLayer(t.dataset.tab);
    else if(j){const[l,ix]=j.dataset.json.split(':');download('profile.jsonld',ld(l,+ix),'application/ld+json')}})}};
  if(X.ok===R)go();else{el.innerHTML='<p class="tiny">Building scholar identities, programs and indices for '+R.length.toLocaleString()+' records… (one-time, a few seconds)</p>';setTimeout(()=>{try{build()}catch(e){el.innerHTML='<div class="note bad">Build failed: '+esc(e.message||e)+'</div>';return}go()},40)}}};

Object.assign(window.X5,{build:()=>{if(typeof R!=='undefined'&&R)build()},ok:()=>X.ok===R,ps:i=>X.ok===R?X.ps[i]:null,name:ix=>X.L.scholar[ix].name,
 find:(q,n)=>{const t=norm(q).trim();if(!t||X.ok!==R)return[];return X.L.scholar.filter(e=>norm(e.name).includes(t)||e.aliases.some(a=>norm(a).includes(t))).sort((a,b)=>a.rank-b.rank).slice(0,n||20)},
 byOrcid:o=>X.ok===R?X.L.scholar.find(e=>e.prof&&e.prof.orcid&&e.prof.orcid.toUpperCase()===String(o).toUpperCase())||null:null,
 openProfile:(l,ix)=>{X.pend=[l,ix];window.openSemanticLayer('x5pf')}});
window.openScholarRankings=()=>window.openSemanticLayer&&window.openSemanticLayer('x5rk');
})();
;
/* ---- x6-discovery-geo ---- */
/* ===== Discovery search cards (Top Journals, Referee Finder, Trends, ORCID, Authors, DOI) + geographic map in Knowledge Graph results (existing features untouched) ===== */
(()=>{
'use strict';
const Q=s=>document.querySelector(s),QA=s=>[...document.querySelectorAll(s)];
const F=n=>Math.round(+n||0).toLocaleString(),D=(n,k=2)=>(+n||0).toFixed(k),trim=s=>String(s||'').replace(/\u00a0/g,' ').trim();
const CNM={usa:'United States','united states of america':'United States','united state of america':'United States',america:'United States',england:'United Kingdom'};
const GEO={
'India':[22,79],'United States':[39,-98],'United Kingdom':[54,-2],'Canada':[56,-106],'Sweden':[62,15],'Germany':[51,10],
'South Korea':[36.5,127.8],'Netherlands':[52.2,5.3],'Iran':[32,53],'Singapore':[1.35,103.8],'Australia':[-25,134],
'China':[35,103],'Japan':[36,138],'France':[46.5,2.5],'Italy':[42.8,12.5],'Spain':[40,-3.7],'Brazil':[-10,-52],
'South Africa':[-29,24],'Nigeria':[9.1,8.7],'Malaysia':[4.2,102],'Pakistan':[30,70],'Turkey':[39,35],
'Switzerland':[46.8,8.2],'Norway':[61,9],'Denmark':[56,10],'Finland':[64,26],'Russia':[60,90],'Mexico':[23,-102],
'Taiwan':[23.7,121],'Hong Kong':[22.3,114.2],'Saudi Arabia':[24,45],'Egypt':[26,30],'Kenya':[0.5,38],'Ghana':[7.9,-1],
'Indonesia':[-2,118],'Bangladesh':[23.7,90.3],'Sri Lanka':[7.8,80.7],'Poland':[52,19],'Belgium':[50.6,4.6],
'New Zealand':[-41,174],'Ireland':[53,-8],'Israel':[31.5,35],'Thailand':[15,101],'Vietnam':[16,107.5],
'Philippines':[12.8,122],'Greece':[39,22],'Portugal':[39.5,-8],'Austria':[47.5,14.5],'Czech Republic':[49.8,15.5],
'Ethiopia':[9,39.5],'Tanzania':[-6.3,34.9],'Uganda':[1.4,32.3],'Zimbabwe':[-19,29.8],'Jordan':[31,36.5],
'UAE':[24,54],'Qatar':[25.3,51.2],'Iraq':[33,44],'Nepal':[28.4,84],'Argentina':[-34,-64],'Chile':[-35,-71],
'Colombia':[4,-72],'Peru':[-10,-76],'Venezuela':[8,-66],'Morocco':[32,-5],'Algeria':[28,3],'Tunisia':[34,9],
'Libya':[27,17],'Sudan':[15,30],'Senegal':[14,-14],'Cameroon':[6,12],'Angola':[-12,17],'Mozambique':[-18.5,35],
'Romania':[46,25],'Hungary':[47,19],'Bulgaria':[42.7,25.5],'Serbia':[44,21],'Croatia':[45.1,15.2],
'Ukraine':[49,32],'Belarus':[53,28],'Lithuania':[55,24],'Latvia':[57,24],'Estonia':[59,25],
'South Korea':[36.5,127.8],'North Korea':[40,127],'Mongolia':[46,105],'Kazakhstan':[48,68],'Uzbekistan':[41.5,64],
'Afghanistan':[33,65],'Myanmar':[22,96],'Cambodia':[12.5,105],'Laos':[18,105],'Brunei':[4.5,114.7],
'Papua New Guinea':[-6,147],'Fiji':[-18,178],'Iceland':[65,-18],'Luxembourg':[49.8,6.1],'Malta':[35.9,14.5],
'Cyprus':[35,33],'Georgia':[42,43.5],'Armenia':[40,45],'Azerbaijan':[40.5,47.5],'Oman':[21,57],
'Kuwait':[29.3,47.5],'Bahrain':[26,50.5],'Yemen':[15.5,48],'Lebanon':[33.8,35.8],'Syria':[35,38],
'Palestine':[31.9,35.2],'Bolivia':[-17,-65],'Ecuador':[-1.8,-78],'Paraguay':[-23,-58],'Uruguay':[-33,-56],
'Cuba':[22,-80],'Jamaica':[18.1,-77.3],'Dominican Republic':[19,-70.7],'Haiti':[19,-72.3],
'Costa Rica':[10,-84],'Panama':[8.5,-80],'Guatemala':[15.5,-90.3],'Honduras':[15,-86.5],'El Salvador':[13.7,-88.9],
'Nicaragua':[13,-85],'Botswana':[-22,24],'Namibia':[-22,17],'Zambia':[-13,28],'Malawi':[-13.5,34],
'Rwanda':[-2,30],'Burundi':[-3.5,30],'Madagascar':[-20,47],'Mauritius':[-20.3,57.5]
};
const REGION={
'Northern America':['United States','Canada','Mexico'],
'Latin America & Caribbean':['Brazil','Argentina','Chile','Colombia','Peru','Venezuela','Bolivia','Ecuador','Paraguay','Uruguay','Cuba','Jamaica','Dominican Republic','Haiti','Costa Rica','Panama','Guatemala','Honduras','El Salvador','Nicaragua'],
'Western Europe':['United Kingdom','Ireland','France','Germany','Netherlands','Belgium','Switzerland','Austria','Luxembourg'],
'Northern Europe':['Sweden','Norway','Denmark','Finland','Iceland','Estonia','Latvia','Lithuania'],
'Southern Europe':['Spain','Portugal','Italy','Greece','Malta','Cyprus','Croatia','Serbia'],
'Eastern Europe':['Poland','Czech Republic','Romania','Hungary','Bulgaria','Ukraine','Belarus','Russia'],
'West Asia / Middle East':['Turkey','Israel','Saudi Arabia','UAE','Qatar','Iraq','Jordan','Iran','Oman','Kuwait','Bahrain','Yemen','Lebanon','Syria','Palestine','Georgia','Armenia','Azerbaijan'],
'South Asia':['India','Pakistan','Bangladesh','Sri Lanka','Nepal','Afghanistan'],
'East Asia':['China','Japan','South Korea','North Korea','Taiwan','Hong Kong','Mongolia'],
'Southeast Asia':['Singapore','Malaysia','Indonesia','Thailand','Vietnam','Philippines','Myanmar','Cambodia','Laos','Brunei'],
'Central Asia':['Kazakhstan','Uzbekistan'],
'Oceania':['Australia','New Zealand','Papua New Guinea','Fiji'],
'North Africa':['Egypt','Morocco','Algeria','Tunisia','Libya','Sudan'],
'Sub-Saharan Africa':['Nigeria','Kenya','Ghana','South Africa','Ethiopia','Tanzania','Uganda','Zimbabwe','Senegal','Cameroon','Angola','Mozambique','Botswana','Namibia','Zambia','Malawi','Rwanda','Burundi','Madagascar','Mauritius']
};
const A2={IN:'India',US:'United States',GB:'United Kingdom',CA:'Canada',SE:'Sweden',DE:'Germany',KR:'South Korea',NL:'Netherlands',IR:'Iran',SG:'Singapore',AU:'Australia',CN:'China',JP:'Japan',FR:'France',IT:'Italy',ES:'Spain',BR:'Brazil',ZA:'South Africa',NG:'Nigeria',MY:'Malaysia',PK:'Pakistan',TR:'Turkey',CH:'Switzerland',NO:'Norway',DK:'Denmark',FI:'Finland',RU:'Russia',MX:'Mexico',TW:'Taiwan',HK:'Hong Kong',SA:'Saudi Arabia',EG:'Egypt',KE:'Kenya',GH:'Ghana',ID:'Indonesia',BD:'Bangladesh',LK:'Sri Lanka',PL:'Poland',BE:'Belgium',NZ:'New Zealand',IE:'Ireland',IL:'Israel',TH:'Thailand',VN:'Vietnam',PH:'Philippines',GR:'Greece',PT:'Portugal',AT:'Austria',CZ:'Czech Republic',ET:'Ethiopia',TZ:'Tanzania',UG:'Uganda',ZW:'Zimbabwe',JO:'Jordan',AE:'UAE',QA:'Qatar',IQ:'Iraq',NP:'Nepal'};
const cn=i=>{const c=trim(CO[R[i][7]]);return c?(CNM[norm(c)]||c):''};
const STOP=new Set('a an and are as at be by for from has have in into is it its of on or that the their this to was were which with we our using use used study based analysis paper research results also can may these those between among through new'.split(' '));
const jfetch=(u,o)=>onlineFetchJson(u,{timeout:12000,headers:{Accept:'application/json'},...o});
const st=document.createElement('style');st.textContent=`
.dc-wrap{max-width:1500px;margin:14px auto 0;padding:0 20px}.dc-head{font:700 15px var(--serif,Georgia,serif);color:var(--brand);margin:0 0 8px}
.dc-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:14px}@media(max-width:900px){.dc-grid{grid-template-columns:1fr}}
.dc-card{background:#fff;border:1px solid var(--line);border-top:9px solid var(--c);border-radius:4px;padding:12px 14px 14px;box-shadow:var(--shadow)}
.dc-card h3{margin:0 0 6px;padding-bottom:3px;border-bottom:1px solid var(--c);color:var(--c);font:700 18px var(--serif,Georgia,serif)}.dc-card p{margin:6px 0 10px;font-size:13.5px;color:var(--c);min-height:40px}
.dc-form{display:flex;border:5px solid #c4c4c4;border-radius:6px;overflow:hidden;background:#c4c4c4}.dc-form input{flex:1;min-width:0;border:0;padding:9px 10px;font-size:13px;outline:0}.dc-form button{border:0;background:var(--c);color:#fff;font-weight:800;font-size:12px;padding:0 14px;border-radius:0}
.dc-btn{border:2px solid #5e86d6;background:linear-gradient(#2f64c7,#1e4aa0);color:#fff;font-weight:800;border-radius:6px;padding:8px 14px}
.dcm .row{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin:8px 0}.dcm table{width:100%;border-collapse:collapse;font-size:12.5px}.dcm th,.dcm td{text-align:left;padding:6px;border-bottom:1px solid var(--line);vertical-align:top}.dcm textarea,.dcm input[type=text]{border:1px solid var(--line);border-radius:8px;padding:7px 9px;font:inherit;width:100%}.dcm .bar{display:inline-block;height:9px;background:var(--brand2);border-radius:3px;vertical-align:middle}.dcm .tiny{font-size:11.5px;color:var(--muted)}.dcm a.ent{color:var(--brand);font-weight:600;cursor:pointer;text-decoration:underline dotted}.dcm .card{border:1px solid var(--line);border-radius:10px;padding:10px;margin:8px 0;background:#fff}.dcm .chip{display:inline-block;border:1px solid var(--line);background:#f3f8fb;border-radius:999px;padding:2px 9px;font-size:12px;margin:2px;cursor:pointer}.dcm .grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:8px;margin:8px 0}.dcm .kpi{border:1px solid var(--line);border-radius:10px;padding:8px;background:#f6fafc}.dcm .kpi b{display:block;font-size:18px;color:var(--brand)}.dcm .kpi span{font-size:11.5px;color:var(--muted)}
.kg-mapstage{display:none;position:relative;border:1px solid var(--line);border-radius:12px;overflow:hidden;background:#eaf3f9;min-height:560px}.kg-layout.maponly .kg-stage{display:none}.kg-layout.maponly .kg-mapstage{display:block}
.kg-mapstage svg{width:100%;height:100%;display:block;touch-action:none}.kg-mapstage .mapctl{position:absolute;left:8px;top:8px;display:flex;gap:6px;flex-wrap:wrap;background:rgba(255,255,255,.92);border:1px solid var(--line);border-radius:8px;padding:5px 8px;font-size:12px;align-items:center}
.kg-mapside{font-size:12.5px;margin-top:8px}#modal.kg-full .kg-mapstage{min-height:0;height:100%}`;document.head.appendChild(st);
const idr=()=>{try{window.X5&&X5.build();return !!(window.X5&&X5.ok())}catch(e){return false}};
const modal=(t,b)=>{$('#modalCard').classList.add('x2-wide');showModal(`<div class="dcm"><h2>${t}</h2>${b}</div>`)};
const prep=s=>tokens(s).filter(w=>w.length>2&&!STOP.has(w));
const rows=(h,a)=>`<table><tr>${h.map(x=>`<th>${x}</th>`).join('')}</tr>${a.map(r=>`<tr>${r.map(x=>`<td>${x}</td>`).join('')}</tr>`).join('')}</table>`;
const pLink=i=>`<a href="#" data-p="${i}">${esc(R[i][2])}</a>`;
function wire(root){root.onclick=e=>{const p=e.target.closest('[data-p]'),k=e.target.closest('[data-kw]'),s=e.target.closest('[data-sc]');if(p){e.preventDefault();detail(+p.dataset.p)}else if(k){const f=cards[k.dataset.tool];f&&f(k.dataset.kw)}else if(s&&window.X5){X5.openProfile('scholar',+s.dataset.sc)}}}
const kwMatch=(q,i)=>{const tk=prep(q);return tk.length&&tk.every(w=>INDEX[i].t.includes(w)||INDEX[i].k.includes(w))};

/* ---------- 1 Top journals by keyword ---------- */
function topJournals(q){q=String(q||'').trim();if(!q){toast('Enter keyword(s)');return}const m=new Map();let n=0;
 for(let i=0;i<R.length;i++)if(kwMatch(q,i)){n++;const e=m.get(R[i][4])||m.set(R[i][4],{n:0,c:0,y:new Set()}).get(R[i][4]);e.n++;e.c+=R[i][0];e.y.add(R[i][3])}
 const a=[...m].sort((x,y)=>y[1].n-x[1].n||y[1].c-x[1].c),mx=a.length?a[0][1].n:1;
 modal('Top Journals by Keyword',`<div class="row"><input type="text" id="dcq" value="${esc(q)}"><button class="primary" id="dcg">Search</button></div><p class="tiny">${F(n)} papers matching “${esc(q)}” in title or keywords, across ${a.length} journals.</p>${rows(['#','Journal','Papers','','Citations','Cites/paper'],a.slice(0,25).map(([k,e],i)=>[i+1,`<a class="ent" data-jr="${k}">${esc(S[k])}</a>`,e.n,`<span class="bar" style="width:${Math.round(150*e.n/mx)}px"></span>`,F(e.c),D(e.c/e.n,1)]))}`);
 Q('#dcg').onclick=()=>topJournals(Q('#dcq').value);Q('#dcq').onkeydown=e=>{if(e.key==='Enter')topJournals(e.target.value)};
 Q('.dcm').onclick=e=>{const j=e.target.closest('[data-jr]');if(j){closeModal();state.query='"'+q+'"';state.source=String(j.dataset.jr);$('#sourceFilter').value=state.source;$('#q').value=state.query;state.page=1;document.body.classList.add('has-search');doSearch()}}}

/* ---------- 2 Referee finder ---------- */
function refereeFinder(){modal('Referee Finder',`<p class="tiny">Paste a manuscript’s title and abstract. Researchers are ranked by how closely their publications of the last five years (${M.maxYear-4}–${M.maxYear}) match its vocabulary, weighted by recency and citations. Manuscript authors can be excluded to avoid conflicts of interest.</p><input type="text" id="rft" placeholder="Manuscript title"><textarea id="rfa" rows="6" placeholder="Abstract" style="margin-top:6px"></textarea><div class="row"><input type="text" id="rfx" placeholder="Authors to exclude (separate with ;)" style="flex:1"><button class="dc-btn" id="rfg">Find referees</button></div><div id="rfo"></div>`);
 $('#rfg').onclick=()=>{const txt=Q('#rft').value+' '+Q('#rfa').value,tk=[...new Set(prep(txt))];if(tk.length<3){toast('Add a title and abstract');return}const ex=Q('#rfx').value.split(';').map(x=>norm(x).trim()).filter(Boolean),df=new Map();
  for(let i=0;i<R.length;i++){const s=INDEX[i].t+' '+INDEX[i].k;tk.forEach(w=>{if(s.includes(w))df.set(w,(df.get(w)||0)+1)})}
  const useId=idr(),idf=w=>Math.log(1+R.length/(1+(df.get(w)||0))),sc=new Map(),from=M.maxYear-4;let used=0;
  for(let i=0;i<R.length;i++){if(R[i][3]<from)continue;const ix=INDEX[i],s=ix.t+' '+ix.k+' '+ix.b;let v=0;tk.forEach(w=>{if(ix.t.includes(w))v+=2*idf(w);else if(ix.k.includes(w))v+=1.5*idf(w);else if(ix.b.includes(w))v+=.6*idf(w)});if(v<=0)continue;used++;v*=1+.08*(R[i][3]-from)+.05*Math.log1p(R[i][0]);
   const ids=useId?X5.ps(i):null;(ids||splitAuthors(R[i][1]).map(a=>'n:'+a)).forEach(a=>{const e=sc.get(a)||sc.set(a,{v:0,n:0,p:[]}).get(a);e.v+=v;e.n++;e.p.push([v,i])})}
  const out=[...sc].map(([k,e])=>{const nm=typeof k==='number'?X5.name(k):k.slice(2);return{k,nm,...e}}).filter(e=>!ex.some(x=>norm(e.nm).includes(x))).sort((a,b)=>b.v-a.v).slice(0,20);
  $('#rfo').innerHTML=`<p class="tiny">${F(used)} recent papers matched ${tk.length} manuscript terms.</p>`+rows(['#','Researcher','Match score','Recent papers','Best matching paper'],out.map((e,i)=>{const b=e.p.sort((x,y)=>y[0]-x[0])[0][1];return[i+1,typeof e.k==='number'?`<a class="ent" data-sc="${e.k}">${esc(e.nm)}</a>`:esc(e.nm),D(e.v,1),e.n,pLink(b)]}));wire(Q('.dcm'))}}

/* ---------- 3 Research trends ---------- */
function trends(q){q=String(q||'').trim();if(!q){toast('Enter keyword(s)');return}const terms=q.split(/[,;]+/).map(x=>x.trim()).filter(Boolean).slice(0,5),ys=M.yearCounts.map(y=>y[0]).sort((a,b)=>a-b),tot=Object.fromEntries(M.yearCounts),col=['#184e77','#c2410c','#047857','#7c3aed','#be123c'];
 const data=terms.map(t=>ys.map(y=>{let n=0;for(let i=0;i<R.length;i++)if(R[i][3]===y&&kwMatch(t,i))n++;return n})),mx=Math.max(1,...data.flat()),W=640,H=260,x=i=>50+i*(W-80)/Math.max(1,ys.length-1),yy=v=>H-35-v/mx*(H-60);
 const svg=`<svg viewBox="0 0 ${W} ${H}" style="width:100%;max-height:300px">${[0,.25,.5,.75,1].map(f=>`<line x1="50" x2="${W-30}" y1="${yy(mx*f)}" y2="${yy(mx*f)}" stroke="#e5e7eb"/><text x="44" y="${yy(mx*f)+4}" font-size="10" text-anchor="end" fill="#687386">${Math.round(mx*f)}</text>`).join('')}${ys.map((y,i)=>`<text x="${x(i)}" y="${H-14}" font-size="11" text-anchor="middle" fill="#687386">${y}</text>`).join('')}${data.map((d,k)=>`<polyline fill="none" stroke="${col[k]}" stroke-width="2.5" points="${d.map((v,i)=>x(i)+','+yy(v)).join(' ')}"/>${d.map((v,i)=>`<circle cx="${x(i)}" cy="${yy(v)}" r="3.5" fill="${col[k]}"><title>${esc(terms[k])} ${ys[i]}: ${v}</title></circle>`).join('')}`).join('')}</svg>`;
 modal('Research Trends by Keyword',`<div class="row"><input type="text" id="dcq" value="${esc(terms.join(', '))}"><button class="primary" id="dcg">Show trends</button></div><p class="tiny">Papers per year whose title or keywords contain every word of the term. Separate up to five terms with commas.</p>${svg}<p>${terms.map((t,k)=>`<span style="color:${col[k]};font-weight:700">● ${esc(t)}</span>`).join(' &nbsp; ')}</p>${rows(['Year',...terms.map(esc),'All papers'],ys.map((y,i)=>[y,...data.map(d=>d[i]),F(tot[y])]))}`);
 Q('#dcg').onclick=()=>trends(Q('#dcq').value);Q('#dcq').onkeydown=e=>{if(e.key==='Enter')trends(e.target.value)}}

/* ---------- 4 ORCID ---------- */
const orcidOk=o=>{o=String(o||'').replace(/^https?:\/\/orcid\.org\//,'').trim().toUpperCase();if(!/^\d{4}-\d{4}-\d{4}-\d{3}[\dX]$/.test(o))return null;const d=o.replace(/-/g,'');let t=0;for(let i=0;i<15;i++)t=(t+ +d[i])*2;const r=(12-t%11)%11;return d[15]===(r===10?'X':String(r))?o:null};
async function byOrcid(q){q=String(q||'').trim();if(!q){toast('Enter an ORCID');return}const o=orcidOk(q);
 modal('Find an Author by ORCID',`<div class="row"><input type="text" id="dcq" value="${esc(q)}"><button class="primary" id="dcg">Look up</button></div><div id="dco"></div>`);Q('#dcg').onclick=()=>byOrcid(Q('#dcq').value);Q('#dcq').onkeydown=e=>{if(e.key==='Enter')byOrcid(e.target.value)};
 if(!o){Q('#dco').innerHTML='<p style="color:#b42318">That is not a valid ORCID iD (format 0000-0000-0000-000X with a correct check digit).</p>';return}
 let h=`<p><b>${o}</b> · <a href="https://orcid.org/${o}" target="_blank" rel="noopener">ORCID record ↗</a></p>`;const prof=idr()?X5.byOrcid(o):null;
 if(prof)h+=`<div class="card">Claimed in this portal by <a class="ent" data-sc="${prof.ix}">${esc(prof.name)}</a> (${prof.id}) · rank ${prof.rank} · ${F(prof.n)} papers · ${F(prof.c)} citations</div>`;
 Q('#dco').innerHTML=h+'<p class="tiny">Looking up OpenAlex…</p>';wire(Q('.dcm'));
 try{const a=await jfetch('https://api.openalex.org/authors/https://orcid.org/'+o),ins=(a.last_known_institutions||[]).map(x=>x.display_name+(x.country_code?' ('+x.country_code+')':'')).join('; ')||'—',tp=(a.topics||[]).slice(0,8).map(t=>t.display_name).join('; ');
  const m=idr()?X5.find(a.display_name,1)[0]:null,cy=(a.counts_by_year||[]).slice(0,8);
  Q('#dco').innerHTML=h+`<div class="card"><h3 style="margin:0">${esc(a.display_name)}</h3><div class="grid"><div class="kpi"><b>${F(a.works_count)}</b><span>works</span></div><div class="kpi"><b>${F(a.cited_by_count)}</b><span>citations</span></div><div class="kpi"><b>${a.summary_stats?.h_index??'—'}</b><span>h-index</span></div><div class="kpi"><b>${a.summary_stats?.i10_index??'—'}</b><span>i10-index</span></div></div><p><b>Institution(s):</b> ${esc(ins)}</p><p><b>Topics:</b> ${esc(tp)}</p>${cy.length?rows(['Year','Works','Cited by'],cy.map(c=>[c.year,c.works_count,c.cited_by_count])):''}${m?`<p><b>In this corpus:</b> <a class="ent" data-sc="${m.ix}">${esc(m.name)}</a> — ${F(m.n)} papers, ${F(m.c)} citations (${m.id})</p>`:''}</div>`}
 catch(e){Q('#dco').innerHTML=h+'<p class="tiny">Online lookup unavailable ('+esc(e.message||e)+'). Author statistics from the global index need an internet connection; the ORCID format is valid.</p>'}wire(Q('.dcm'))}

/* ---------- 5 Authors by name ---------- */
async function byName(q){q=String(q||'').trim();if(!q){toast('Enter a name');return}
 modal('Find Authors by Name',`<div class="row"><input type="text" id="dcq" value="${esc(q)}"><button class="primary" id="dcg">Search</button></div><div id="dco"></div><div id="dcon"></div>`);Q('#dcg').onclick=()=>byName(Q('#dcq').value);Q('#dcq').onkeydown=e=>{if(e.key==='Enter')byName(e.target.value)};
 const a=idr()?X5.find(q,20):[];
 Q('#dco').innerHTML=`<h4>In this portal’s corpus</h4>`+(a.length?rows(['#','Author','ID','Rank','Papers','Citations','h'],a.map((e,i)=>[i+1,`<a class="ent" data-sc="${e.ix}">${esc(e.name)}</a>${e.aliases.length?`<div class="tiny">aka ${esc(e.aliases.slice(0,2).join('; '))}</div>`:''}`,`<span class="tiny">${e.id}</span>`,e.rank,F(e.n),F(e.c),e.h])):'<p class="tiny">No author with that name in the corpus.</p>');
 Q('#dcon').innerHTML='<h4>Global index (OpenAlex)</h4><p class="tiny">Searching…</p>';wire(Q('.dcm'));
 try{const r=await jfetch('https://api.openalex.org/authors?per-page=8&search='+encodeURIComponent(q));Q('#dcon').innerHTML='<h4>Global index (OpenAlex)</h4>'+rows(['Author','Institution','Works','Citations','ORCID'],(r.results||[]).map(x=>[esc(x.display_name),esc((x.last_known_institutions||[])[0]?.display_name||'—'),F(x.works_count),F(x.cited_by_count),x.orcid?`<a class="ent" data-orcid="${esc(x.orcid.replace('https://orcid.org/',''))}">${esc(x.orcid.replace('https://orcid.org/',''))}</a>`:'—']));
  Q('#dcon').onclick=e=>{const o=e.target.closest('[data-orcid]');if(o)byOrcid(o.dataset.orcid)}}catch(e){Q('#dcon').innerHTML='<h4>Global index (OpenAlex)</h4><p class="tiny">Offline or blocked — corpus results above are complete for this dataset.</p>'}}

/* ---------- 6 Article by DOI ---------- */
async function byDoi(q){q=String(q||'').trim();if(!q){toast('Enter a DOI');return}const d=q.replace(/^https?:\/\/(dx\.)?doi\.org\//i,'').trim().toLowerCase(),i=R.findIndex(r=>String(r[9]||'').toLowerCase().replace(/^https?:\/\/(dx\.)?doi\.org\//,'')===d);
 modal('Find Article by DOI',`<div class="row"><input type="text" id="dcq" value="${esc(d)}"><button class="primary" id="dcg">Look up</button></div><div id="dco"></div><div id="dcon"></div>`);Q('#dcg').onclick=()=>byDoi(Q('#dcq').value);Q('#dcq').onkeydown=e=>{if(e.key==='Enter')byDoi(e.target.value)};
 Q('#dco').innerHTML=i>=0?`<div class="card"><b>${pLink(i)}</b><div class="tiny">${esc(R[i][1])} · ${R[i][3]} · ${esc(S[R[i][4]])} · ${F(R[i][0])} citations in this corpus · <a href="https://doi.org/${encodeURI(d)}" target="_blank" rel="noopener">doi.org ↗</a></div><button class="ghost" id="dckg">⌘ Knowledge graph of this record</button></div>`:'<p class="tiny">Not in the local corpus; checking online sources.</p>';
 if(i>=0)Q('#dckg').onclick=()=>{closeModal();kgOpen([{i,score:1,why:[]}],'single',i)};
 Q('#dcon').innerHTML='<p class="tiny">Loading citation analysis from OpenAlex…</p>';wire(Q('.dcm'));
 try{const w=await jfetch('https://api.openalex.org/works/doi:'+encodeURIComponent(d)),cit=await jfetch(w.cited_by_api_url+'&per-page=50&select=id,display_name,publication_year,primary_location,authorships'),L=cit.results||[],by=new Map(),cc=new Map(),yr=new Map();
  L.forEach(x=>{const v=x.primary_location?.source?.display_name;if(v)by.set(v,(by.get(v)||0)+1);yr.set(x.publication_year,(yr.get(x.publication_year)||0)+1);(x.authorships||[]).forEach(a=>(a.countries||[]).forEach(c=>cc.set(c,(cc.get(c)||0)+1)))});
  const top=m=>[...m].sort((a,b)=>b[1]-a[1]).slice(0,8);
  Q('#dcon').innerHTML=`<h4>${esc(w.display_name||'')}</h4><div class="grid"><div class="kpi"><b>${F(w.cited_by_count)}</b><span>cited by</span></div><div class="kpi"><b>${w.referenced_works_count??'—'}</b><span>references</span></div><div class="kpi"><b>${w.open_access?.is_oa?'Open':'Closed'}</b><span>access</span></div></div><div class="grid" style="grid-template-columns:1fr 1fr 1fr"><div><b>Where cited (journals)</b>${rows(['Journal','n'],top(by).map(([k,v])=>[esc(k),v]))}</div><div><b>Who cited (countries)</b>${rows(['Country','n'],top(cc).map(([k,v])=>[esc(k),v]))}</div><div><b>Citations by year</b>${rows(['Year','n'],[...yr].sort((a,b)=>a[0]-b[0]).map(([k,v])=>[k,v]))}</div></div><p class="tiny">Based on the ${L.length} most recent citing works returned by OpenAlex.</p>`}
 catch(e){Q('#dcon').innerHTML='<p class="tiny">Online citation analysis unavailable ('+esc(e.message||e)+'). Local record details are shown above when the DOI is in the corpus.</p>'}wire(Q('.dcm'))}

const cards={topj:topJournals,trend:trends,orcid:byOrcid,name:byName,doi:byDoi};
function mountCards(){if(Q('#dcWrap'))return;const host=Q('.hero-shell');if(!host)return;const defs=[['topj','#1b86bd','Top Journals by Keyword','Find which journals publish the most about a given keyword.','Keyword(s)'],['ref','#e08a00','Referee Finder','Paste a manuscript’s title and abstract to find the researchers who published most on its topic in the last five years.',null],['trend','#c70000','Research Trends by Keyword','Check the trends of keywords by number of publications over years.','Keyword(s)'],['orcid','#0bb300','Find an Author by ORCID','Full analysis of each author including who and where cited.','ORCID'],['name','#5b00ff','Find Authors by Name','Search for an author by name (firstname lastname).','Firstname Lastname'],['doi','#31659b','Find Article by DOI','Statistical analysis (who cited? where cited?) of a single article, looked up by its DOI.','DOI']];
 const w=document.createElement('section');w.id='dcWrap';w.className='dc-wrap';w.setAttribute('aria-label','Discovery tools');w.innerHTML=`<h2 class="dc-head">Discovery tools</h2><div class="dc-grid">${defs.map(([k,c,t,p,ph])=>`<div class="dc-card" style="--c:${c}"><h3>${t}</h3><p>${p}</p>${ph?`<form class="dc-form" data-k="${k}"><input aria-label="${t}" placeholder="${ph}"><button>GO</button></form>`:`<button class="dc-btn" type="button" data-k="ref">Find referees</button>`}</div>`).join('')}</div>`;host.insertAdjacentElement('afterend',w);
 w.addEventListener('submit',e=>{const f=e.target.closest('.dc-form');if(!f)return;e.preventDefault();cards[f.dataset.k](f.querySelector('input').value)});w.querySelector('[data-k=ref]').onclick=refereeFinder}
mountCards();

/* ---------- geographic map in knowledge graph results ---------- */
const CONT=[[[-168,66],[-140,70],[-95,72],[-80,68],[-62,60],[-55,50],[-67,44],[-76,35],[-81,25],[-97,26],[-105,22],[-110,30],[-123,38],[-125,49],[-140,60],[-165,60]],[[-83,9],[-77,8],[-80,0],[-70,-18],[-75,-40],[-70,-54],[-55,-36],[-40,-22],[-35,-6],[-50,3],[-62,10],[-75,11]],[[-10,36],[-9,44],[-2,48],[3,52],[8,57],[12,65],[25,71],[40,68],[60,70],[80,73],[110,76],[140,72],[170,68],[165,58],[142,50],[130,40],[122,30],[110,20],[105,10],[98,16],[92,22],[80,12],[73,18],[66,25],[56,27],[48,30],[36,36],[27,37],[22,37],[12,38],[0,38]],[[-17,21],[-6,36],[10,37],[32,31],[43,12],[51,12],[40,-10],[35,-25],[20,-35],[13,-22],[9,-1],[-8,5],[-17,14]],[[114,-22],[130,-12],[142,-11],[153,-27],[147,-39],[135,-35],[117,-35]],[[-52,60],[-40,65],[-22,70],[-30,82],[-60,80],[-72,76]],[[130,31],[141,36],[145,44],[140,41],[132,34]],[[-10,50],[-6,58],[2,56],[1,51]]];
const PTS=ps=>ps.map(([x,y])=>(x+180)*(1000/360)+','+(90-y)*(500/180)).join(' '),proj=(lat,lon)=>[(lon+180)*1000/360,(90-lat)*500/180];
function geoData(hits,sel){const m=new Map(),L=new Map(),sc=new Map();hits.forEach(h=>{const i=typeof h==='object'?h.i:h;if(typeof i!=='number')return;const c=cn(i);if(!c)return;const e=m.get(c)||m.set(c,{n:0,c:0,p:[],au:new Set(),jr:new Set()}).get(c);e.n++;e.c+=R[i][0];e.p.push(i);e.jr.add(S[R[i][4]]);splitAuthors(R[i][1]).forEach(a=>{const k=norm(a);e.au.add(k);(sc.get(k)||sc.set(k,new Set()).get(k)).add(c)})});
 sc.forEach(cs=>{const a=[...cs].sort();for(let x=0;x<a.length;x++)for(let y=x+1;y<a.length;y++){const k=a[x]+'|'+a[y];L.set(k,(L.get(k)||0)+1)}});
 const jc=new Map();m.forEach((e,c)=>e.jr.forEach(j=>(jc.get(j)||jc.set(j,new Set()).get(j)).add(c)));jc.forEach(cs=>{const a=[...cs].sort();for(let x=0;x<a.length;x++)for(let y=x+1;y<a.length;y++){const k=a[x]+'|'+a[y];L.set(k,(L.get(k)||0)+.25)}});return{m,L}}
function regionOf(c){for(const[r,list] of Object.entries(REGION||{})){if(list.includes(c))return r}return 'Other / unmapped'}
function mapDraw(root,side,hits,state_){
 const g=geoData(hits);
 const active=[...g.m].filter(([c])=>GEO[c]);
 const allCountries=state_.showAll?[...new Set([...Object.keys(GEO),...active.map(([c])=>c)])]:active.map(([c])=>c);
 const pts=allCountries.map(c=>{
   const e=g.m.get(c)||{n:0,c:0,p:[],au:new Set(),jr:new Set()};
   return [c,e];
 }).filter(([c])=>GEO[c]);
 const mx=Math.max(1,...pts.map(([,e])=>e.n));
 const sel=state_.sel;
 const edges=[...g.L].filter(([k])=>k.split('|').every(c=>GEO[c])).sort((a,b)=>b[1]-a[1]).slice(0,50);
 const em=Math.max(1,...edges.map(e=>e[1]));
 const miss=[...g.m].filter(([c])=>!GEO[c]).reduce((a,[,e])=>a+e.n,0);
 /* region centroids for labels */
 const regLabels=[];
 if(state_.regions){
   Object.entries(REGION||{}).forEach(([r,list])=>{
     const coords=list.filter(c=>GEO[c]).map(c=>GEO[c]);
     if(!coords.length)return;
     const lat=coords.reduce((s,c)=>s+c[0],0)/coords.length;
     const lon=coords.reduce((s,c)=>s+c[1],0)/coords.length;
     const n=list.reduce((s,c)=>s+((g.m.get(c)||{}).n||0),0);
     regLabels.push({r,lat,lon,n});
   });
 }
 const regionSvg=regLabels.map(({r,lat,lon,n})=>{
   const[x,y]=proj(lat,lon);
   return `<text x="${x}" y="${y}" text-anchor="middle" font-size="9" font-weight="700" fill="#5b3aa0" opacity=".75" stroke="#fff" stroke-width="2.5" paint-order="stroke">${esc(r)}${n?` (${n})`:''}</text>`;
 }).join('');
 root.querySelector('svg').innerHTML=`<rect width="1000" height="520" fill="#dcebf5"/>
${[-60,-30,0,30,60].map(l=>`<line x1="0" x2="1000" y1="${proj(l,0)[1]}" y2="${proj(l,0)[1]}" stroke="#fff" stroke-opacity=".7"/>`).join('')}
${[-120,-60,0,60,120].map(l=>`<line y1="0" y2="520" x1="${proj(0,l)[0]}" x2="${proj(0,l)[0]}" stroke="#fff" stroke-opacity=".7"/>`).join('')}
${CONT.map(p=>`<polygon points="${PTS(p)}" fill="#f4f1e4" stroke="#b9b49c" stroke-width="1"/>`).join('')}
<g id="mg">
${state_.links?edges.map(([k,v])=>{
  const[a,b]=k.split('|').map(c=>proj(...GEO[c]));
  const mx_=(a[0]+b[0])/2,my=(a[1]+b[1])/2-Math.hypot(a[0]-b[0],a[1]-b[1])*.18;
  return `<path d="M${a[0]},${a[1]} Q${mx_},${my} ${b[0]},${b[1]}" fill="none" stroke="#7c3aed" stroke-opacity="${sel&&!k.split('|').includes(sel)?.08:.45}" stroke-width="${(.6+3*v/em).toFixed(1)}"><title>${esc(k.replace('|',' ↔ '))}: ${D(v,1)} shared authors/journals</title></path>`;
}).join(''):''}
${pts.map(([c,e])=>{
  const[x,y]=proj(...GEO[c]);
  const has=e.n>0;
  const r=has?6+30*Math.sqrt(e.n/mx):3.5;
  const fill=has?'#184e77':'#94a3b8';
  const op=has?.62:.28;
  return `<g data-c="${esc(c)}" style="cursor:pointer"><circle cx="${x}" cy="${y}" r="${r.toFixed(1)}" fill="${fill}" fill-opacity="${op}" stroke="${sel===c?'#f59e0b':'#fff'}" stroke-width="${sel===c?4:1.5}"><title>${esc(c)}: ${e.n} papers, ${e.c} citations · ${regionOf(c)}</title></circle>${has?`<text x="${x}" y="${y+4}" text-anchor="middle" font-size="${r>14?11:9}" fill="#fff" font-weight="700">${e.n}</text>`:''}<text x="${x}" y="${y+r+11}" text-anchor="middle" font-size="9" fill="#14213d" stroke="#fff" stroke-width="3" paint-order="stroke">${esc(c)}</text></g>`;
}).join('')}
${regionSvg}
</g>
<text x="12" y="512" font-size="10" fill="#64748b">Global map · bubbles = papers by publisher country · grey dots = mapped countries with no hits in this result set</text>`;
 const e=sel&&g.m.get(sel);
 /* regional summary */
 const regSum={};
 [...g.m].forEach(([c,ev])=>{const r=regionOf(c);const x=regSum[r]||(regSum[r]={n:0,c:0,countries:0});x.n+=ev.n;x.c+=ev.c;x.countries++});
 const regRows=Object.entries(regSum).sort((a,b)=>b[1].n-a[1].n).map(([r,v])=>`<tr><td>${esc(r)}</td><td>${v.countries}</td><td>${v.n}</td><td>${F(v.c)}</td></tr>`).join('');
 side.innerHTML=`<b>${active.length} countries with hits</b> · ${pts.length} mapped · ${F(hits.length)} graph records${miss?` · ${miss} records without map coordinates`:''}.
<br><span class="tiny">Bubbles = paper counts by publisher country. Purple arcs = shared authors or journals across countries. Grey dots = countries in the atlas with no hits here. Click a bubble for details.</span>
<div class="card" style="margin-top:8px;overflow:auto"><b>Global regions</b>
<table style="width:100%;font-size:11.5px;border-collapse:collapse;margin-top:4px"><thead><tr><th align="left">Region</th><th>Ctries</th><th>Papers</th><th>Cites</th></tr></thead><tbody>${regRows||'<tr><td colspan="4">No regional data</td></tr>'}</tbody></table></div>
`+(e?`<div class="card" style="margin-top:8px"><b>${esc(sel)}</b> · ${regionOf(sel)} · ${e.n} papers · ${F(e.c)} citations · ${e.au.size} authors · ${e.jr.size} journals
<ol>${e.p.sort((a,b)=>R[b][0]-R[a][0]).slice(0,5).map(i=>`<li>${pLink(i)}</li>`).join('')}</ol>
<button class="ghost" data-mf="${esc(sel)}">Filter search to ${esc(sel)}</button>
<a class="ghost" href="https://en.wikipedia.org/wiki/${encodeURIComponent(sel.replace(/ /g,'_'))}" target="_blank" rel="noopener" style="display:inline-block;margin-left:6px;padding:7px 9px;border:1px solid var(--line);border-radius:8px;text-decoration:none">Wikipedia ↗</a>
</div>`:'');
}
function kgMap(){const lay=Q('.kg-layout');if(!lay||Q('#kgMapStage'))return;const tb=Q('.kg-toolbar'),stage=document.createElement('div');stage.className='kg-mapstage';stage.id='kgMapStage';stage.innerHTML=`<svg viewBox="0 0 1000 520" preserveAspectRatio="xMidYMid meet"></svg><div class="mapctl"><label><input type="checkbox" id="kgMapLinks" checked> Collaboration arcs</label><label><input type="checkbox" id="kgMapRegions" checked> Region labels</label><label><input type="checkbox" id="kgMapAll" checked> Show all mapped countries</label></div>`;lay.insertBefore(stage,lay.querySelector('.kg-side'));
 const side=document.createElement('div');side.className='kg-mapside';lay.querySelector('.kg-side').appendChild(side);stage.dataset.x='1';
 const S_={sel:null,links:true,regions:true,showAll:true},st_=()=>(KG.nodes.filter(n=>n.type==='paper'&&typeof n.paperIndex==='number').map(n=>n.paperIndex));
 const hitsNow=()=>{const p=st_();return p.length?p:(KG.baseHits||[]).map(h=>h.i)};
 const draw=()=>mapDraw(stage,side,hitsNow(),S_);
 const btn=document.createElement('button');btn.className='ghost';btn.id='kgMapBtn';btn.textContent='🗺 Geographic map';btn.onclick=()=>{const on=lay.classList.toggle('maponly');btn.textContent=on?'⌘ Back to graph':'🗺 Geographic map';btn.style.background=on?'#e6f6ee':'';if(on)draw()};tb.insertBefore(btn,tb.querySelector('.spacer')||null);
 stage.addEventListener('click',e=>{const c=e.target.closest('[data-c]');if(c){S_.sel=S_.sel===c.dataset.c?null:c.dataset.c;draw()}});
 side.addEventListener('click',e=>{const p=e.target.closest('[data-p]'),f=e.target.closest('[data-mf]');if(p){e.preventDefault();detail(+p.dataset.p)}else if(f){const c=f.dataset.mf,ix=CO.findIndex(x=>(CNM[norm(trim(x))]||trim(x))===c);if(ix>=0){closeModal();state.country=String(ix);$('#countryFilter').value=state.country;state.page=1;doSearch()}}});
 Q('#kgMapLinks').onchange=e=>{S_.links=e.target.checked;draw()};
 const rg=Q('#kgMapRegions');if(rg)rg.onchange=e=>{S_.regions=e.target.checked;draw()};
 const al=Q('#kgMapAll');if(al)al.onchange=e=>{S_.showAll=e.target.checked;draw()};
 ['#kgModel','#kgLimit','.kgType'].forEach(s=>QA(s).forEach(x=>x.addEventListener('change',()=>setTimeout(()=>{if(lay.classList.contains('maponly'))draw()},60))))}
/* ---------- Interactive Geographical Places Grid in knowledge graph results ----------
   Tiles for every country/place in the current results. Uses the same data as the
   Geographic map; does not change the map, graph or tree. */
const PG_CSS=`
.kg-gridstage{display:none;border:1px solid var(--line);border-radius:12px;background:#f7f9fb;padding:12px;min-height:560px}
.kg-layout.gridonly .kg-gridstage{display:block!important}
.kg-layout.gridonly .kg-stage,.kg-layout.gridonly .kg-mapstage,.kg-layout.gridonly .kg-treestage{display:none!important}
.pg-bar{display:flex;flex-wrap:wrap;gap:10px;align-items:center;justify-content:space-between;margin-bottom:10px;font-size:12.5px}
.pg-bar select{font:inherit;padding:4px 6px;border:1px solid var(--line);border-radius:8px;background:#fff}
.pg-sum{color:#475569}
.pg-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(158px,1fr));gap:10px}
.pg-tile{position:relative;text-align:left;font:inherit;color:#14213d;background:#fff;border:1px solid var(--line);border-radius:12px;padding:10px 11px 9px;cursor:pointer;overflow:hidden}
.pg-tile:hover{box-shadow:0 2px 10px rgba(15,23,42,.10);border-color:#184e77}
.pg-tile:focus-visible{outline:3px solid #2563eb;outline-offset:1px}
.pg-tile.sel{outline:3px solid #f59e0b;outline-offset:1px}
.pg-tile.unm{border-style:dashed;opacity:.85}
.pg-name{font-weight:700;font-size:13px;line-height:1.2;margin-bottom:3px}
.pg-reg{font-size:10.5px;color:#64748b}
.pg-num{font-size:22px;font-weight:800;color:#184e77;margin-top:6px}
.pg-sub{font-size:11px;color:#475569}
.pg-bar2{height:5px;border-radius:3px;background:#e2e8f0;margin-top:7px;overflow:hidden}
.pg-bar2 i{display:block;height:100%;background:linear-gradient(90deg,#184e77,#0f766e)}
.pg-detail{margin-top:12px;border:1px solid var(--line);border-radius:12px;background:#fff;padding:12px;font-size:12.5px}
.pg-detail ol{margin:6px 0 8px 18px;padding:0}
.pg-empty{padding:30px;text-align:center;color:#64748b}
`;
function pgHits(){
  const p=KG.nodes.filter(n=>n.type==='paper'&&typeof n.paperIndex==='number').map(n=>n.paperIndex);
  return p.length?p:(KG.baseHits||[]).map(h=>h.i);
}
function pgDraw(stage,S){
  const g=geoData(pgHits());
  let rows=[...g.m].map(([c,e])=>({c,n:e.n,cit:e.c,au:e.au.size,jr:e.jr.size,reg:regionOf(c),mapped:!!GEO[c]}));
  if(S.region!=='all')rows=rows.filter(r=>r.reg===S.region);
  rows.sort(S.sort==='name'?(a,b)=>a.c.localeCompare(b.c)
           :S.sort==='cites'?(a,b)=>(b.cit-a.cit)||(b.n-a.n)
           :(a,b)=>(b.n-a.n)||(b.cit-a.cit));
  const total=rows.reduce((s,r)=>s+r.n,0),mx=Math.max(1,...rows.map(r=>r.n));
  const mapped=rows.filter(r=>r.mapped).length;
  stage.querySelector('#pgSum').textContent=`${rows.length} places · ${F(total)} papers${S.region!=='all'?` in ${S.region}`:''} · ${mapped} on the map`;
  stage.querySelector('#pgGrid').innerHTML=rows.length?rows.map(r=>
    `<button type="button" class="pg-tile${r.mapped?'':' unm'}${S.sel===r.c?' sel':''}" data-pc="${esc(r.c)}" aria-pressed="${S.sel===r.c}" title="${esc(r.c)}: ${r.n} papers, ${F(r.cit)} citations · ${esc(r.reg)}">`+
    `<div class="pg-name">${esc(r.c)}</div><div class="pg-reg">${esc(r.reg)}${r.mapped?'':' · no map coordinates'}</div>`+
    `<div class="pg-num">${r.n}</div><div class="pg-sub">papers · ${F(r.cit)} citations · ${r.au} authors</div>`+
    `<div class="pg-bar2"><i style="width:${(100*r.n/mx).toFixed(1)}%"></i></div></button>`).join('')
    :'<div class="pg-empty">No places in this result set.</div>';
  const det=stage.querySelector('#pgDetail');
  const e=S.sel&&g.m.get(S.sel);
  if(!e){det.innerHTML='';return}
  const top=[...e.p].sort((a,b)=>R[b][0]-R[a][0]).slice(0,5);
  det.innerHTML=`<div class="pg-detail"><b>${esc(S.sel)}</b> · ${esc(regionOf(S.sel))} · ${e.n} papers · ${F(e.c)} citations · ${e.au.size} authors · ${e.jr.size} journals`+
    `<ol>${top.map(i=>`<li>${pLink(i)}</li>`).join('')}</ol>`+
    `<button class="ghost" data-pg-filter="${esc(S.sel)}">Filter search to ${esc(S.sel)}</button></div>`;
}
function kgGrid(){
  const lay=Q('.kg-layout');
  if(!lay||Q('#kgGridStage'))return;
  const tb=Q('.kg-toolbar');if(!tb)return;
  if(!document.getElementById('pg-css')){const st=document.createElement('style');st.id='pg-css';st.textContent=PG_CSS;document.head.appendChild(st)}
  const stage=document.createElement('div');
  stage.className='kg-gridstage';stage.id='kgGridStage';
  const regions=['all',...Object.keys(REGION||{}),'Other / unmapped'];
  stage.innerHTML=`<div class="pg-bar">
    <label>Region <select id="pgRegion">${regions.map(r=>`<option value="${esc(r)}">${r==='all'?'All regions':esc(r)}</option>`).join('')}</select></label>
    <label>Sort by <select id="pgSort"><option value="papers">Papers</option><option value="cites">Citations</option><option value="name">Country A–Z</option></select></label>
    <span class="pg-sum" id="pgSum"></span></div>
    <div class="pg-grid" id="pgGrid"></div><div id="pgDetail"></div>`;
  lay.insertBefore(stage,lay.querySelector('.kg-side'));
  const S={region:'all',sort:'papers',sel:null};
  const draw=()=>pgDraw(stage,S);

  const btn=document.createElement('button');
  btn.className='ghost';btn.id='kgGridBtn';btn.textContent='▦ Places grid';
  btn.title='Interactive grid of the countries and places in these results';
  const resetOthers=()=>{
    const mb=Q('#kgMapBtn');if(mb){mb.textContent='🗺 Geographic map';mb.style.background=''}
    const tb2=Q('#kgTreeBtn');if(tb2){tb2.textContent='🌳 Knowledge Tree';tb2.style.background=''}
  };
  btn.onclick=()=>{
    const on=!lay.classList.contains('gridonly');
    if(on){lay.classList.remove('maponly','treeonly');resetOthers();lay.classList.add('gridonly');draw()}
    else lay.classList.remove('gridonly');
    btn.textContent=on?'⌘ Back to graph':'▦ Places grid';
    btn.style.background=on?'#e6f6ee':'';
  };
  tb.insertBefore(btn,tb.querySelector('.spacer')||null);
  /* the map and tree buttons take over the view: leave the grid when they do */
  new MutationObserver(()=>{
    if(lay.classList.contains('gridonly')&&(lay.classList.contains('maponly')||lay.classList.contains('treeonly'))){
      lay.classList.remove('gridonly');btn.textContent='▦ Places grid';btn.style.background='';
    }
  }).observe(lay,{attributes:true,attributeFilter:['class']});

  stage.querySelector('#pgRegion').onchange=e=>{S.region=e.target.value;draw()};
  stage.querySelector('#pgSort').onchange=e=>{S.sort=e.target.value;draw()};
  stage.addEventListener('click',e=>{
    const t=e.target.closest('[data-pc]');
    if(t){const c=t.dataset.pc;S.sel=S.sel===c?null:c;draw();return}
    const p=e.target.closest('[data-p]');
    if(p){e.preventDefault();detail(+p.dataset.p);return}
    const f=e.target.closest('[data-pg-filter]');
    if(f){
      const c=f.dataset.pgFilter,ix=CO.findIndex(x=>(CNM[norm(trim(x))]||trim(x))===c);
      if(ix>=0){closeModal();state.country=String(ix);$('#countryFilter').value=state.country;state.page=1;doSearch()}
    }
  });
  ['#kgModel','#kgLimit','.kgType'].forEach(s=>QA(s).forEach(x=>x.addEventListener('change',()=>setTimeout(()=>{if(lay.classList.contains('gridonly'))draw()},60))));
}
const _ko=window.kgOpen;window.kgOpen=function(){const r=_ko.apply(this,arguments);try{setTimeout(kgMap,30);setTimeout(kgGrid,35)}catch(e){console.warn(e)}return r};
window.Discovery={topJournals,refereeFinder,trends,byOrcid,byName,byDoi};
})();
;
/* ---- x7-knowledge-tree ---- */
/* ===== Knowledge Tree tab — illustration template + linked nodes + relationships =====
   Optional KG view. Force graph + Geographic map + all other facilities unchanged. */
(()=>{
'use strict';
const Q=s=>document.querySelector(s),QA=s=>[...document.querySelectorAll(s)];
const F=n=>Number(n||0).toLocaleString();
const esc=s=>{const d=document.createElement('div');d.textContent=s==null?'':String(s);return d.innerHTML};

const st=document.createElement('style');st.textContent=`
.kg-treestage{display:none;position:relative;border:1px solid var(--line);border-radius:12px;overflow:hidden;
  background:#e9edf2;min-height:720px}
.kg-layout.treeonly .kg-stage{display:none}
.kg-layout.treeonly .kg-mapstage{display:none}
.kg-layout.treeonly .kg-treestage{display:block}
.kg-layout.maponly .kg-treestage{display:none}
.kg-treestage svg{width:100%;height:100%;min-height:720px;display:block;touch-action:none}
.kg-treestage .treectl{position:absolute;top:10px;left:12px;display:flex;gap:8px;flex-wrap:wrap;align-items:center;
  background:rgba(255,255,255,.96);border:1px solid var(--line);border-radius:10px;padding:6px 10px;font-size:12.5px;z-index:3;
  box-shadow:0 2px 10px rgba(15,23,42,.08)}
.kg-treestage .treectl label{display:flex;align-items:center;gap:4px;cursor:pointer;user-select:none}
.kg-treeside{margin-top:10px;font-size:12.5px;line-height:1.45}
.kg-treeside .card{border:1px solid var(--line);border-radius:10px;padding:10px;margin-top:8px;background:#fff}
.kg-treeside .chip{display:inline-block;border:1px solid var(--line);border-radius:999px;padding:2px 8px;margin:2px;font-size:11px;background:#f8fafc}
.kg-treeside a.chip-link{color:var(--brand);text-decoration:none}
.kg-treeside a.chip-link:hover{text-decoration:underline}
#kgTreeBtn{white-space:nowrap}
.kt-hit{cursor:pointer}
`;
document.head.appendChild(st);

const ORB=['#f97316','#fb923c','#ea580c','#3b82f6','#60a5fa','#2563eb','#10b981','#34d399','#f59e0b','#fbbf24',
  '#8b5cf6','#a78bfa','#ec4899','#06b6d4','#0f172a','#1e3a5f','#64748b','#fdba74','#93c5fd'];
const col=(t,i)=>{
  const map={paper:0,author:3,keyword:6,year:8,journal:10,publisher:12,place:13,query:14,doi:16,url:16};
  return ORB[((map[t]!=null?map[t]:i)+i)%ORB.length];
};
const REL_COL={
  'authored by':'#3b82f6','writes':'#3b82f6',
  'published in':'#8b5cf6','published by':'#ec4899',
  'has keyword':'#10b981','described by':'#10b981',
  'published in year':'#f59e0b','appears in':'#f59e0b',
  'associated country':'#06b6d4','located in':'#06b6d4',
  'related':'#64748b',
  'shared author':'#2563eb','shared keyword':'#059669','same journal':'#7c3aed'
};
const relColor=r=>{
  if(!r)return '#94a3b8';
  const k=Object.keys(REL_COL).find(x=>String(r).toLowerCase().includes(x)||x.includes(String(r).toLowerCase()));
  return k?REL_COL[k]:'#94a3b8';
};

function resolveUrl(n){
  if(!n)return '';
  let u=n.url||'';
  if(!u && typeof nodeUrlFor==='function'){
    const o=(n.type==='paper'&&typeof n.paperIndex==='number'&&typeof recObj==='function')?recObj(n.paperIndex):null;
    u=nodeUrlFor(n.type,n.label,o)||'';
  }
  if(!u && (n.type==='paper'||n.type==='keyword')){
    const q=encodeURIComponent(String(n.label||'').trim());
    if(q)u='https://scholar.google.com/scholar?q='+q;
  }
  if(typeof safeUrl==='function')u=safeUrl(u)||u;
  return u||'';
}

/* icons matching the template */
function iconBook(x,y,s,fill){
  return `<g transform="translate(${x},${y})">
    <path d="M${-s*.55} ${-s*.15} Q${-s*.55} ${-s*.55} 0 ${-s*.45} Q${s*.55} ${-s*.55} ${s*.55} ${-s*.15}
             L${s*.55} ${s*.5} Q${s*.55} ${s*.62} 0 ${s*.52} Q${-s*.55} ${s*.62} ${-s*.55} ${s*.5} Z"
      fill="${fill}" stroke="#fff" stroke-width="1.1"/>
    <path d="M0 ${-s*.45} L0 ${s*.52}" stroke="#fff" stroke-width="1.3" opacity=".9"/>
  </g>`;
}
function iconClock(x,y,s,fill){
  return `<g transform="translate(${x},${y})">
    <circle r="${s*.58}" fill="${fill}" stroke="#fff" stroke-width="1.5"/>
    <circle r="${s*.4}" fill="#fff" opacity=".95"/>
    <line x1="0" y1="0" x2="0" y2="${-s*.3}" stroke="${fill}" stroke-width="2.1" stroke-linecap="round"/>
    <line x1="0" y1="0" x2="${s*.22}" y2="${s*.1}" stroke="${fill}" stroke-width="1.7" stroke-linecap="round"/>
    <circle r="2" fill="${fill}"/>
  </g>`;
}
function iconDisc(x,y,s,fill){
  return `<g transform="translate(${x},${y})">
    <circle r="${s*.58}" fill="${fill}" stroke="#fff" stroke-width="1.3"/>
    <circle r="${s*.38}" fill="none" stroke="#fff" stroke-width="1.1" opacity=".75"/>
    <circle r="${s*.16}" fill="#fff" opacity=".92"/><circle r="${s*.06}" fill="${fill}"/>
  </g>`;
}
function iconPerson(x,y,s,fill){
  return `<g transform="translate(${x},${y})">
    <circle cy="${-s*.26}" r="${s*.3}" fill="${fill}" stroke="#fff" stroke-width="1.2"/>
    <path d="M${-s*.48} ${s*.52} Q${-s*.48} 0 0 0 Q${s*.48} 0 ${s*.48} ${s*.52} Z" fill="${fill}" stroke="#fff" stroke-width="1.2"/>
  </g>`;
}
function iconOrb(x,y,s,fill){
  return `<g transform="translate(${x},${y})">
    <circle r="${s*.55}" fill="${fill}" stroke="#fff" stroke-width="1.4"/>
    <circle cx="${-s*.14}" cy="${-s*.14}" r="${s*.16}" fill="#fff" opacity=".32"/>
  </g>`;
}
function iconFor(type,x,y,r,fill){
  const s=Math.max(9,r*1.25);
  if(type==='paper')return iconBook(x,y,s,fill);
  if(type==='year')return iconClock(x,y,s,fill);
  if(type==='publisher')return iconDisc(x,y,s,fill);
  if(type==='author')return iconPerson(x,y,s,fill);
  return iconOrb(x,y,s,fill);
}

/* hierarchy from REAL paper-to-entity relationships only. No query hub and no "matched search" edges.
   The trunk is the author, keyword, journal, publisher or place shared by the most papers in this graph. */
const TREE_TRUNK=['author','keyword','journal','publisher','place'];
const TREE_CHILD_ORDER=['author','keyword','year','journal','publisher','place','country'];
function buildGraph(nodes,edges){
  if(!nodes||!nodes.length)return null;
  const paperIds=new Set(nodes.filter(n=>n.type==='paper').map(n=>n.id));
  const isHub=n=>!!n&&n.type!=='query'&&!n.root;
  const links=[];
  (edges||[]).forEach(e=>{
    const a=e.a||e.source,b=e.b||e.target;if(!a||!b)return;
    const rel=String(e.relation||e.label||e.type||'related');
    if(/matched search/i.test(rel))return;
    const pa=paperIds.has(a.id),pb=paperIds.has(b.id);
    if(pa&&!pb&&isHub(b))links.push({paper:a,entity:b,relation:rel});
    else if(pb&&!pa&&isHub(a))links.push({paper:b,entity:a,relation:rel});
  });
  const shared=new Map();
  links.forEach(l=>{
    if(!TREE_TRUNK.includes(l.entity.type))return;
    if(!shared.has(l.entity.id))shared.set(l.entity.id,new Set());
    shared.get(l.entity.id).add(l.paper.id);
  });
  let trunkId=null,best=0;
  shared.forEach((ps,id)=>{if(ps.size>best){best=ps.size;trunkId=id}});
  if(trunkId==null)return null;
  const root=links.find(l=>l.entity.id===trunkId).entity;
  const kids=new Map(); /* parentId -> [{node, relation}] */
  const add=(pid,c,rel)=>{
    if(!kids.has(pid))kids.set(pid,[]);
    if(!kids.get(pid).some(x=>x.node.id===c.id))kids.get(pid).push({node:c,relation:rel});
  };
  links.filter(l=>l.entity.id===trunkId).forEach(l=>add(root.id,l.paper,l.relation));
  const plist=(kids.get(root.id)||[]).slice(0,16);
  kids.set(root.id,plist);
  plist.forEach(({node:p})=>{
    const ents=[];
    links.forEach(l=>{
      if(l.paper.id===p.id&&l.entity.id!==trunkId&&!ents.some(x=>x.node.id===l.entity.id))ents.push({node:l.entity,relation:l.relation});
    });
    ents.sort((a,b)=>(TREE_CHILD_ORDER.indexOf(a.node.type)+99)-(TREE_CHILD_ORDER.indexOf(b.node.type)+99));
    kids.set(p.id,ents.slice(0,10));
  });
  const all=[root,...plist.map(x=>x.node)];
  kids.forEach(arr=>arr.forEach(x=>all.push(x.node)));
  all.forEach(n=>{if(n&&!n.url)n.url=resolveUrl(n)});
  const note=`${root.type} "${root.label}" is shared by ${best} paper${best===1?'':'s'} in this graph`;
  return {root,kids,note};
}

/* illustration layout: trunk canopy + hanging ornaments with parent anchors */
function layout(hier,W,H){
  if(!hier)return {placed:[],links:[]};
  const {root,kids}=hier;
  const placed=[],links=[];
  const CX=W*0.5, canopyY=H*0.30, groundY=H*0.93;

  placed.push({n:root,x:CX,y:H*0.11,r:17,depth:0,hang:false});

  const papers=(kids.get(root.id)||[]).filter(x=>x.node.type==='paper');
  const nP=Math.max(1,papers.length);
  const rx=W*0.38, ry=H*0.12;
  papers.forEach((item,i)=>{
    const t=nP===1?0.5:i/(nP-1);
    const ang=-Math.PI*0.82+t*Math.PI*1.64;
    const x=CX+Math.cos(ang)*rx;
    const y=canopyY+Math.sin(ang)*ry*0.65+(i%3-1)*8;
    const p=item.node;
    const r=12+Math.min(7,Math.log1p(p.cites||0)*1.3);
    placed.push({n:p,x,y,r,depth:1,hang:false,branch:true});
    links.push({fromId:root.id,toId:p.id,relation:item.relation||'related',kind:'branch'});

    const ents=kids.get(p.id)||[];
    ents.forEach((ent,j)=>{
      const side=(j%2===0?1:-1);
      const offsetX=side*(8+(j%5)*11)+(Math.sin(j*1.7+i)*6);
      const hangLen=30+(j%8)*20+((j*13)%15);
      const x2=x+offsetX;
      const y2=Math.min(groundY-22,y+hangLen);
      const e=ent.node;
      const r2=6.5+Math.min(6,Math.log1p(e.weight||1)*1.2)+(e.type==='year'?2:0);
      placed.push({n:e,x:x2,y:y2,r:r2,depth:2,hang:true,ax:x,ay:y+4});
      links.push({fromId:p.id,toId:e.id,relation:ent.relation||'related',kind:'hang'});
    });
  });
  return {placed,links};
}

function ambientDots(W,H){
  let s='';
  for(let i=0;i<55;i++){
    const x=25+((i*89+11)%(W-50)),y=18+((i*53+7)%(H*0.72)),rr=1.3+(i%7)*0.9;
    s+=`<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="${rr}" fill="${ORB[i%ORB.length]}" opacity="${0.2+(i%5)*0.07}"/>`;
  }
  return s;
}
function beads(x1,y1,x2,y2,n,c1,c2){
  let s='';
  for(let i=1;i<=n;i++){
    const t=i/(n+1),x=x1+(x2-x1)*t+Math.sin(i*2.2)*1.1,y=y1+(y2-y1)*t,rr=1.5+(i%3===0?1.4:0);
    s+=`<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="${rr}" fill="${i%2?c1:c2}" opacity=".88"/>`;
  }
  return s;
}

function drawTree(stage,side,S){
  const W=1120,H=760;
  const hier=buildGraph(KG.nodes||[],KG.edges||[]);
  if(!hier){
    stage.querySelector('svg').outerHTML='<svg viewBox="0 0 1120 760" xmlns="http://www.w3.org/2000/svg"><rect width="1120" height="760" fill="#e7e8eb"/></svg>';
    side.innerHTML='<b>Knowledge Tree</b><br><span class="tiny">These papers share no authors, keywords, journals or publishers, so no tree can be drawn. Try the Bibliographic or Co-authorship model.</span>';
    return;
  }
  const {placed,links}=layout(hier,W,H);
  const byId=new Map(placed.map(p=>[p.n.id,p]));
  const sel=S.sel;
  const relCount={};
  const bump=r=>{relCount[r]=(relCount[r]||0)+1};
  const shortRel=r=>{r=String(r||'related');return r.length>24?r.slice(0,22)+'…':r};
  const pillW=t=>Math.max(34,t.length*5.6+14);
  const edgeEls=[],pillEls=[];

  /* one relationship line: curved, coloured by relation, labelled with a pill */
  const drawEdge=(a,b,rel,bend,dashed,title)=>{
    const dx=b.x-a.x,dy=b.y-a.y,L=Math.hypot(dx,dy)||1;
    const nx=-dy/L,ny=dx/L;
    const cx=(a.x+b.x)/2+nx*bend,cy=(a.y+b.y)/2+ny*bend;
    const c=relColor(rel);
    edgeEls.push(`<path d="M${a.x.toFixed(1)} ${a.y.toFixed(1)} Q${cx.toFixed(1)} ${cy.toFixed(1)} ${b.x.toFixed(1)} ${b.y.toFixed(1)}" fill="none" stroke="${c}" stroke-width="${dashed?1.7:2.4}" stroke-linecap="round" opacity="${dashed?.7:.9}"${dashed?' stroke-dasharray="6 5"':''}><title>${esc(title)}</title></path>`);
    if(S.rels){
      const mx=0.25*a.x+0.5*cx+0.25*b.x,my=0.25*a.y+0.5*cy+0.25*b.y;
      const t=shortRel(rel),w=pillW(t);
      pillEls.push(`<g transform="translate(${mx.toFixed(1)},${my.toFixed(1)})"><title>${esc(title)}</title><rect x="${(-w/2).toFixed(1)}" y="-9" width="${w.toFixed(1)}" height="18" rx="9" fill="#fff" stroke="${c}" stroke-width="1.2"/><text text-anchor="middle" y="4" font-size="10" font-weight="700" fill="${c}">${esc(t)}</text></g>`);
    }
  };

  /* hierarchy edges: query -> paper -> entities */
  links.forEach((L,i)=>{
    const a=byId.get(L.fromId),b=byId.get(L.toId);if(!a||!b)return;
    const rel=L.relation||'related';
    bump(rel);
    const d=Math.hypot(b.x-a.x,b.y-a.y);
    drawEdge(a,b,rel,(i%2?1:-1)*Math.min(38,d*0.12),false,`${a.n.label} → ${b.n.label} (${rel})`);
  });

  /* papers that share an author, keyword or journal are joined by dashed arcs */
  const relFor={author:'shared author',keyword:'shared keyword',journal:'same journal'};
  const groups=new Map();
  placed.filter(p=>p.depth===1).forEach(p=>{
    ((hier&&hier.kids.get(p.n.id))||[]).forEach(x=>{
      const t=x.node.type;if(!relFor[t])return;
      const k=t+'|'+String(x.node.label||'').toLowerCase();
      if(!groups.has(k))groups.set(k,{t,label:x.node.label,ps:[]});
      groups.get(k).ps.push(p);
    });
  });
  let arcCount=0;const seen=new Set();
  groups.forEach(g=>{
    for(let i=0;i<g.ps.length;i++)for(let j=i+1;j<g.ps.length;j++){
      if(arcCount>=40)break;
      const a=g.ps[i],b=g.ps[j];
      const key=[a.n.id,b.n.id].sort().join('~')+'|'+g.t;
      if(seen.has(key))continue;
      seen.add(key);arcCount++;
      const rel=relFor[g.t];
      bump(rel);
      drawEdge(a,b,rel,-Math.min(120,Math.hypot(b.x-a.x,b.y-a.y)*0.3),true,`${a.n.label} ↔ ${b.n.label}: ${rel} "${g.label}"`);
    }
  });

  /* nodes, icons, labels and hover tips */
  const nodeEls=[],labelEls=[];
  placed.forEach((p,i)=>{
    const n=p.n,fill=col(n.type,i),isSel=sel===n.id,u=resolveUrl(n);
    const tip=[n.label,n.type+(n.year?' · '+n.year:'')+(n.cites!=null?' · '+F(n.cites)+' citations':''),u?'Click to open: '+u:'No link for this node (click to select)'].join('\n');
    nodeEls.push(`<circle cx="${p.x.toFixed(1)}" cy="${p.y.toFixed(1)}" r="${(p.r+6).toFixed(1)}" fill="${fill}" opacity=".14"/>`);
    nodeEls.push(iconFor(n.type,p.x,p.y,p.r,fill));
    if(isSel)nodeEls.push(`<circle cx="${p.x.toFixed(1)}" cy="${p.y.toFixed(1)}" r="${(p.r+10).toFixed(1)}" fill="none" stroke="#f59e0b" stroke-width="3"/>`);
    nodeEls.push(`<circle class="kt-hit" data-id="${esc(n.id)}" data-url="${esc(u)}" cx="${p.x.toFixed(1)}" cy="${p.y.toFixed(1)}" r="${Math.max(12,p.r+5).toFixed(1)}" fill="transparent" style="cursor:${u?'pointer':'default'}"><title>${esc(tip)}</title></circle>`);
    if(S.labels){
      const lab=(n.label||'').length>22?(n.label.slice(0,20)+'…'):(n.label||'');
      labelEls.push(`<text x="${p.x.toFixed(1)}" y="${(p.y+p.r+13).toFixed(1)}" text-anchor="middle" font-size="${p.depth===0?13:10.5}" font-weight="${p.depth<2?700:500}" fill="#1e293b" stroke="#f3f6f9" stroke-width="3" paint-order="stroke">${esc(lab)}</text>`);
    }
  });

  const ambi=S.decor?ambientDots(W,H):'';
  const stemEls=placed.map(p=>`<line x1="${p.x.toFixed(1)}" y1="${(p.y-p.r-46).toFixed(1)}" x2="${p.x.toFixed(1)}" y2="${(p.y-p.r).toFixed(1)}" stroke="#1d2b40" stroke-opacity=".28" stroke-width="1.2" pointer-events="none"/>`).join('');
  const hill='<path d="M120 760 C260 690 420 672 560 676 C720 680 880 690 1000 760 Z" fill="#17606f"/><path d="M190 760 C330 720 470 708 560 710 C690 712 840 726 940 760 Z" fill="#0e4658"/>';
  stage.querySelector('svg').outerHTML=`<svg viewBox="0 0 ${W} ${H}" preserveAspectRatio="xMidYMid meet" xmlns="http://www.w3.org/2000/svg">
    <defs><radialGradient id="ktBg" cx="50%" cy="25%" r="75%">
      <stop offset="0%" stop-color="#fbfcfd"/><stop offset="100%" stop-color="#e6ecf2"/>
    </radialGradient></defs>
    <rect width="${W}" height="${H}" fill="#e7e8eb"/>
    ${hill}${S.decor?stemEls:''}${ambi}${edgeEls.join('')}${nodeEls.join('')}${pillEls.join('')}${labelEls.join('')}
  </svg>`;

  const typeCount={};placed.forEach(p=>{typeCount[p.n.type]=(typeCount[p.n.type]||0)+1});
  const relChips=Object.entries(relCount).sort((x,y)=>y[1]-x[1]).map(([r,c])=>`<span class="chip" style="border-color:${relColor(r)}"><i style="display:inline-block;width:9px;height:9px;border-radius:50%;background:${relColor(r)};margin-right:4px"></i>${esc(r)} ${c}</span>`).join('');
  let selHtml='';
  if(sel){
    const p=placed.find(x=>x.n.id===sel);
    if(p){
      const n=p.n,u=resolveUrl(n);
      const outL=links.filter(L=>L.fromId===n.id);
      const inL=links.filter(L=>L.toId===n.id);
      selHtml=`<div class="card"><b>${esc(n.label)}</b><br>
        <span class="tiny">${esc(n.type)}${n.cites!=null?` · ${F(n.cites)} citations`:''}${n.year?` · ${n.year}`:''}</span>
        ${u?`<div class="tiny" style="margin-top:6px;word-break:break-all"><b>Link:</b> <a href="${esc(u)}" target="_blank" rel="noopener">${esc(u.length>60?u.slice(0,58)+'…':u)}</a></div>
        <a class="ghost" href="${esc(u)}" target="_blank" rel="noopener" style="display:inline-block;margin-top:6px;padding:7px 9px;border:1px solid var(--line);border-radius:8px;text-decoration:none">Open link ↗</a>`:'<div class="tiny" style="margin-top:6px">No link available for this node.</div>'}
        ${n.type==='paper'&&typeof n.paperIndex==='number'?`<button class="ghost" data-kt-detail="${n.paperIndex}" style="margin-top:6px;margin-left:4px">Open details</button>`:''}
        ${['author','journal','keyword','publisher','place','year'].includes(n.type)
          ?`<button class="ghost" data-kt-search="${esc(n.type)}|${esc(n.label)}" style="margin-top:6px;margin-left:4px">Search this</button>`:''}
        ${inL.length?`<div style="margin-top:8px"><b class="tiny">Incoming relations</b><br>${inL.map(L=>`<span class="chip" style="border-color:${relColor(L.relation)}">${esc(L.relation)}</span>`).join('')}</div>`:''}
        ${outL.length?`<div style="margin-top:4px"><b class="tiny">Outgoing relations</b><br>${outL.map(L=>`<span class="chip" style="border-color:${relColor(L.relation)}">${esc(L.relation)}</span>`).join('')}</div>`:''}
      </div>`;
    }
  }
  side.innerHTML=`<b>Knowledge Tree</b> · ${placed.length} nodes · ${links.length+arcCount} relationships<br>
    ${hier.note?`<span class="tiny">${esc(hier.note)}</span><br>`:''}
    <span class="tiny">Click a node to select it and open its link (years have no link). Lines show how nodes are related; the label on each line names the relationship. Dashed arcs join papers that share an author, keyword or journal. Hover a node for its full name and link.</span>
    <div style="margin-top:6px">${Object.entries(typeCount).map(([t,c])=>`<span class="chip">${esc(t)} ${c}</span>`).join('')}</div>
    <div style="margin-top:6px"><b class="tiny">Relationship legend</b><br>${relChips||'<span class="tiny">No relationships in this view.</span>'}</div>
    ${selHtml}`;
}

function kgTree(){
  const lay=Q('.kg-layout');
  if(!lay||Q('#kgTreeStage'))return;

  const tb=Q('.kg-toolbar');
  const stage=document.createElement('div');
  stage.className='kg-treestage';
  stage.id='kgTreeStage';
  stage.innerHTML=`<div class="treectl">
    <label><input type="checkbox" id="kgTreeLabels" checked> Node labels</label>
    <label><input type="checkbox" id="kgTreeRels" checked> Relationship labels</label>
    <label><input type="checkbox" id="kgTreeDecor" checked> Ambient dots</label>
    <button class="ghost" id="kgTreePng" type="button">Save PNG</button>
  </div>
  <svg viewBox="0 0 1120 760" preserveAspectRatio="xMidYMid meet"></svg>`;
  lay.insertBefore(stage,lay.querySelector('.kg-side'));

  const side=document.createElement('div');
  side.className='kg-treeside';
  lay.querySelector('.kg-side').appendChild(side);

  const S={sel:null,labels:true,rels:true,decor:true};
  const draw=()=>{try{drawTree(stage,side,S)}catch(err){console.warn('Knowledge Tree',err);side.innerHTML='<span class="bad">Could not render tree.</span>'}};

  const btn=document.createElement('button');
  btn.className='ghost';btn.id='kgTreeBtn';
  btn.textContent='🌳 Knowledge Tree';
  btn.title='Illustration-style knowledge tree with linked nodes and relationships';
  btn.onclick=()=>{
    const on=lay.classList.toggle('treeonly');
    if(on){
      lay.classList.remove('maponly');
      const mb=Q('#kgMapBtn');
      if(mb){mb.textContent='🗺 Geographic map';mb.style.background=''}
    }
    btn.textContent=on?'⌘ Back to graph':'🌳 Knowledge Tree';
    btn.style.background=on?'#e6f6ee':'';
    if(on)draw();
  };

  const mapBtn=Q('#kgMapBtn');
  if(mapBtn){
    tb.insertBefore(btn,mapBtn.nextSibling);
    const prev=mapBtn.onclick;
    mapBtn.onclick=function(ev){
      if(typeof prev==='function')prev.call(this,ev);
      if(lay.classList.contains('maponly')){
        lay.classList.remove('treeonly');
        btn.textContent='🌳 Knowledge Tree';btn.style.background='';
      }
    };
  }else tb.insertBefore(btn,tb.querySelector('.spacer')||null);

  stage.addEventListener('click',e=>{
    const hit=e.target.closest('.kt-hit');if(!hit)return;
    S.sel=hit.dataset.id;draw();
    const u=hit.dataset.url;
    if(u)window.open(u,'_blank','noopener');
  });

  side.addEventListener('click',e=>{
    const d=e.target.closest('[data-kt-detail]');
    const s=e.target.closest('[data-kt-search]');
    if(d){e.preventDefault();if(typeof detail==='function')detail(+d.dataset.ktDetail)}
    else if(s){
      const [type,label]=s.dataset.ktSearch.split('|');
      if(typeof kgSearchByNode==='function'){
        const n=(KG.nodes||[]).find(x=>x.type===type&&x.label===label);
        if(n)kgSearchByNode(n);
      }else{
        if(typeof closeModal==='function')closeModal();
        if(window.state){state.q=label;state.page=1;if(typeof doSearch==='function')doSearch()}
      }
    }
  });

  Q('#kgTreeLabels').onchange=e=>{S.labels=e.target.checked;draw()};
  Q('#kgTreeRels').onchange=e=>{S.rels=e.target.checked;draw()};
  Q('#kgTreeDecor').onchange=e=>{S.decor=e.target.checked;draw()};

  Q('#kgTreePng').onclick=()=>{
    const svg=stage.querySelector('svg');if(!svg)return;
    const xml=new XMLSerializer().serializeToString(svg);
    const img=new Image();
    const url=URL.createObjectURL(new Blob([xml],{type:'image/svg+xml;charset=utf-8'}));
    img.onload=()=>{
      const c=document.createElement('canvas');c.width=img.width*2;c.height=img.height*2;
      const ctx=c.getContext('2d');ctx.scale(2,2);
      ctx.fillStyle='#e9edf2';ctx.fillRect(0,0,img.width,img.height);
      ctx.drawImage(img,0,0);
      c.toBlob(b=>{const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download='knowledge-tree.png';a.click();URL.revokeObjectURL(a.href)},'image/png');
      URL.revokeObjectURL(url);
    };
    img.src=url;
  };

  ['#kgModel','#kgLimit','.kgType'].forEach(sel=>{
    QA(sel).forEach(el=>el.addEventListener('change',()=>setTimeout(()=>{if(lay.classList.contains('treeonly'))draw()},80)));
  });
}

const _ko=window.kgOpen;
window.kgOpen=function(){
  const r=_ko&&_ko.apply(this,arguments);
  try{setTimeout(kgTree,40)}catch(e){console.warn(e)}
  return r;
};
})();
;
/* ---- zoom-pan-v1 ---- */
/* Zoom, pan and pinch for the Knowledge Tree and Geographic map. Changes only the SVG viewBox. */
(()=>{
'use strict';
const MIN=0.6,MAX=10;
function sync(stage){
  const svg=stage.querySelector('svg'),st=stage._zs;
  if(!svg||!st)return null;
  if(svg!==st.svg){
    const v=(svg.getAttribute('viewBox')||'0 0 1000 600').trim().split(/[\s,]+/).map(Number);
    st.svg=svg;st.base=v.slice();st.vb=v.slice();
  }
  return st;
}
function apply(st){st.svg.setAttribute('viewBox',st.vb.map(n=>+n.toFixed(3)).join(' '))}
function zoomAt(stage,cx,cy,f){
  const st=sync(stage);if(!st)return;
  const ctm=st.svg.getScreenCTM();if(!ctm)return;
  const pt=st.svg.createSVGPoint();pt.x=cx;pt.y=cy;
  const p=pt.matrixTransform(ctm.inverse());
  const bw=st.base[2],bh=st.base[3];
  const cur=bw/st.vb[2];
  const ns=Math.min(MAX,Math.max(MIN,cur*f));
  const nw=bw/ns,nh=bh/ns;
  const fx=(p.x-st.vb[0])/st.vb[2],fy=(p.y-st.vb[1])/st.vb[3];
  st.vb=[p.x-fx*nw,p.y-fy*nh,nw,nh];apply(st);
}
function zoomBy(stage,f){
  const svg=stage.querySelector('svg');if(!svg)return;
  const r=svg.getBoundingClientRect();
  zoomAt(stage,r.left+r.width/2,r.top+r.height/2,f);
}
function attach(stage){
  stage.dataset.zoomBound='1';
  stage._zs={svg:null,base:null,vb:null};
  const bar=stage.querySelector('.treectl,.mapctl');
  if(bar){
    const g=document.createElement('span');
    g.className='zc-group';
    g.innerHTML='<button type="button" class="ghost zc-in" title="Zoom in">+</button><button type="button" class="ghost zc-out" title="Zoom out">−</button><button type="button" class="ghost zc-fit" title="Reset zoom">Reset zoom</button>';
    bar.appendChild(g);
    g.querySelector('.zc-in').addEventListener('click',e=>{e.preventDefault();zoomBy(stage,1.25)});
    g.querySelector('.zc-out').addEventListener('click',e=>{e.preventDefault();zoomBy(stage,1/1.25)});
    g.querySelector('.zc-fit').addEventListener('click',e=>{
      e.preventDefault();const st=sync(stage);if(!st)return;st.vb=st.base.slice();apply(st);
    });
  }
  stage.addEventListener('wheel',e=>{
    if(!sync(stage))return;
    e.preventDefault();
    zoomAt(stage,e.clientX,e.clientY,e.deltaY<0?1.15:1/1.15);
  },{passive:false});

  const pts=new Map();let last=null,dragged=false,lastDist=0;
  stage.addEventListener('pointerdown',e=>{
    if(e.target.closest('button,input,label,select,.treectl,.mapctl'))return;
    if(!sync(stage))return;
    dragged=false;
    pts.set(e.pointerId,{x:e.clientX,y:e.clientY});
    if(pts.size===2){
      const [a,b]=[...pts.values()];lastDist=Math.hypot(a.x-b.x,a.y-b.y);
    }
  });
  stage.addEventListener('pointermove',e=>{
    if(!pts.has(e.pointerId))return;
    const prev=pts.get(e.pointerId);
    pts.set(e.pointerId,{x:e.clientX,y:e.clientY});
    const st=sync(stage);if(!st)return;
    if(pts.size===1){
      const dx=e.clientX-prev.x,dy=e.clientY-prev.y;
      if(!dragged&&Math.hypot(dx,dy)<4&&!stage._panning)return;
      if(!dragged){dragged=true;stage._panning=true;st.svg.classList.add('panning');try{stage.setPointerCapture(e.pointerId)}catch(_){}}
      const ctm=st.svg.getScreenCTM();if(!ctm)return;
      st.vb[0]-=dx/ctm.a;st.vb[1]-=dy/ctm.d;apply(st);
    }else if(pts.size>=2){
      const [a,b]=[...pts.values()];
      const d=Math.hypot(a.x-b.x,a.y-b.y);
      if(lastDist>0&&d>0){
        dragged=true;
        zoomAt(stage,(a.x+b.x)/2,(a.y+b.y)/2,d/lastDist);
      }
      lastDist=d;
    }
  });
  const end=e=>{
    pts.delete(e.pointerId);
    if(pts.size<2)lastDist=0;
    if(pts.size===0){
      stage._panning=false;
      const st=stage._zs;if(st&&st.svg)st.svg.classList.remove('panning');
    }
  };
  stage.addEventListener('pointerup',end);
  stage.addEventListener('pointercancel',end);
  /* swallow the click that ends a drag so nodes are not selected by accident */
  stage.addEventListener('click',e=>{
    if(dragged){e.stopPropagation();e.preventDefault();dragged=false}
  },true);
}
function bindAll(){
  ['#kgTreeStage','#kgMapStage'].forEach(sel=>{
    const st=document.querySelector(sel);
    if(st&&!st.dataset.zoomBound)attach(st);
  });
}
new MutationObserver(bindAll).observe(document.body,{childList:true,subtree:true});
bindAll();
})();
;
/* ---- nav-organiser-v1 ---- */
/* Final navigation order by purpose. Moves existing buttons (listeners kept); no behaviour changed. */
(function(){
  function organise(){
    const bar=document.querySelector('header nav.toolbar');
    if(!bar)return;
    bar.querySelectorAll('.nav-sep').forEach(n=>n.remove());
    const spacer=bar.querySelector('.nav-spacer');
    const groups=[
      [['.nav-home','Home'],['.nav-search','Search'],['#advancedBtn','Advanced Search'],['#aiBtn','AI Search'],['#dxBtn','Diamond OA'],['#mobileFilterBtn',null]],
      [['#lrBtn','Literature Review'],['#graphResultsBtn','Knowledge Graph'],['#mmBtn','Mind Map'],['#semBtn','Semantic Layer'],['#riNavBtn','Research Insights'],['#relatedPapersBtn','Related Papers'],['#evalBtn','Evaluation'],['#dashBtn','Dashboard'],['#journalMapBtn','Journal Map']],
      [['#onlineSearchBtn','Online Lookup'],['#federatedSearchBtn','Federated Search'],['#lodBtn','Linked Data'],['#dbIntegrationBtn','Graph Database'],['#uploadDatasetBtn','Upload Dataset'],['#exportResultsBtn','Export']]
    ];
    groups.forEach((g,gi)=>{
      if(gi>0&&spacer){const sep=document.createElement('span');sep.className='nav-sep';sep.setAttribute('aria-hidden','true');bar.insertBefore(sep,spacer)}
      g.forEach(([sel,label])=>{
        const el=bar.querySelector(sel); if(!el)return;
        if(label){const s=el.querySelector('span:not(.countpill)'); if(s)s.textContent=label}
        if(spacer)bar.insertBefore(el,spacer); else bar.appendChild(el);
      });
    });
    const vs=bar.querySelector('.view-switch'); if(vs)bar.appendChild(vs);
  }
  organise();
  __onLoad(organise);
})();
;
/* ---- journal-map-overlay ---- */
(function(){
  const btn=document.getElementById('journalMapBtn'),ov=document.getElementById('jmOverlay'),
        frame=document.getElementById('jmFrame'),closeBtn=document.getElementById('jmClose');
  if(!btn||!ov||!frame)return;
  let lastFocus=null;
  let jmUrl=null;
  function jmLoad(){
    if(!jmUrl){
      const b64=document.getElementById('jmEmbedded').textContent.trim().slice(6);
      jmUrl=(async()=>{
        const bin=Uint8Array.from(atob(b64),c=>c.charCodeAt(0));
        const text=await new Response(new Blob([bin]).stream().pipeThrough(new DecompressionStream('gzip'))).text();
        return URL.createObjectURL(new Blob([text],{type:'text/html'}));
      })();
    }
    jmUrl.then(u=>{frame.src=u});
  }
  function open(){
    lastFocus=document.activeElement;
    const cur=frame.getAttribute('src');
    if(!cur||cur==='about:blank')jmLoad();
    ov.hidden=false;
    closeBtn.focus();
  }
  function close(){
    ov.hidden=true;
    frame.src='about:blank'; // stop the 3D renderer when hidden
    if(lastFocus&&lastFocus.focus)lastFocus.focus();
  }
  btn.addEventListener('click',open);
  closeBtn.addEventListener('click',close);
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!ov.hidden)close()});
  // The embedded map asks to close via postMessage; accept it only from our frame.
  window.addEventListener('message',e=>{
    if(e.source===frame.contentWindow&&e.data&&e.data.type==='journal-map:close')close();
  });
})();
;
/* ---- x-enhancements ---- */
/* ===== Usability enhancements (NEAR, facets toggle, search history, type-ahead, ARIA already applied) =====
   All existing facilities are left intact. */
(()=>{
'use strict';
const Q=s=>document.querySelector(s);
const KEY='lisKgHistory';
const MAX=25;

function loadHist(){try{return JSON.parse(localStorage.getItem(KEY)||'[]')}catch(e){return[]}}
function saveHist(arr){try{localStorage.setItem(KEY,JSON.stringify(arr.slice(0,MAX)))}catch(e){}}
function pushHist(q){
  q=String(q||'').trim(); if(!q||q.length<2)return;
  const h=loadHist().filter(x=>x!==q);
  h.unshift(q); saveHist(h); renderHist();
}

function renderHist(){
  const list=Q('#searchHistoryList'); if(!list)return;
  const h=loadHist();
  list.innerHTML=h.length
    ? h.map(q=>`<button type="button" class="ghost hist-item" data-hq="${q.replace(/"/g,'&quot;')}" style="display:block;width:100%;text-align:left;margin:2px 0;padding:6px 10px;font-size:12.5px">${q.replace(/</g,'&lt;')}</button>`).join('')
    : '<span class="tiny">No saved queries yet. Searches are stored locally in this browser.</span>';
  list.querySelectorAll('[data-hq]').forEach(b=>b.onclick=()=>{
    const inp=Q('#q'); if(inp){inp.value=b.dataset.hq; inp.dispatchEvent(new Event('input',{bubbles:true}));}
    if(typeof doSearch==='function')doSearch(true);
  });
}

/* Type-ahead from top keywords / authors once data is ready */
function buildSuggest(){
  const dl=Q('#qSuggest'); if(!dl||typeof R==='undefined'||!R)return;
  const freq=new Map();
  const add=t=>{if(!t||t.length<3||t.length>40)return; const k=t.toLowerCase(); freq.set(k,(freq.get(k)||0)+1)};
  try{
    for(let i=0;i<Math.min(R.length,8000);i++){
      (R[i][11]||'').split(/[;|,]/).forEach(k=>add(k.trim()));
      (R[i][1]||'').split(';').forEach(a=>{const p=a.trim().split(',').pop(); if(p)add(p.trim())});
    }
  }catch(e){}
  const top=[...freq.entries()].sort((a,b)=>b[1]-a[1]).slice(0,120).map(([t])=>t);
  dl.innerHTML=top.map(t=>`<option value="${t.replace(/"/g,'&quot;')}">`).join('');
}

/* Facets toggle — default: keep side panels visible during search */
function initFacetsToggle(){
  const prefer=localStorage.getItem('lisKgResultsOnly')==='1';
  if(prefer)document.body.classList.add('results-only');
  const btn=document.createElement('button');
  btn.type='button'; btn.className='ghost'; btn.id='toggleFacetsBtn';
  btn.title='Show or hide the left filters and right insights panels while results are shown';
  const sync=()=>{
    const on=document.body.classList.contains('results-only');
    btn.textContent=on?'Show side panels':'Hide side panels';
    btn.setAttribute('aria-pressed', on?'true':'false');
  };
  sync();
  btn.onclick=()=>{
    document.body.classList.toggle('results-only');
    localStorage.setItem('lisKgResultsOnly', document.body.classList.contains('results-only')?'1':'0');
    sync();
  };
  const bar=Q('.resultbar')||Q('#results .toolbar')||Q('.toolbar')||Q('#results');
  if(bar) bar.appendChild(btn);
  else document.body.appendChild(btn);
}

/* Hook doSearch to record history */
const _ds=window.doSearch;
if(typeof _ds==='function'){
  window.doSearch=function(){
    const q=(Q('#q')&&Q('#q').value)||(window.state&&state.query)||'';
    pushHist(q);
    return _ds.apply(this,arguments);
  };
}

/* Wire UI once DOM ready */
function boot(){
  const inp=Q('#q');
  if(inp && !Q('#qSuggest')){
    const dl=document.createElement('datalist');
    dl.id='qSuggest';
    inp.setAttribute('list','qSuggest');
    inp.parentNode.appendChild(dl);
  }
  /* History panel under hero search if present */
  if(!Q('#searchHistoryPanel')){
    const panel=document.createElement('div');
    panel.id='searchHistoryPanel';
    panel.style.cssText='max-width:920px;margin:8px auto 0;padding:0 4px';
    panel.innerHTML=`<details style="font-size:13px"><summary style="cursor:pointer;color:var(--brand);font-weight:600">Recent searches (local)</summary>
      <div id="searchHistoryList" style="margin-top:6px"></div>
      <button type="button" class="ghost" id="clearHist" style="margin-top:6px;font-size:12px">Clear history</button>
      <p class="tiny" style="margin-top:6px">Operators: <code>AND</code> <code>OR</code> <code>NOT</code> <code>NEAR</code> / <code>NEAR/n</code> (proximity, default window 5). Wildcards <code>*</code> <code>?</code>. Quotes for phrases. Operators must be CAPITALS.</p>
    </details>`;
    const hero=Q('.hero-search')||Q('.global-search')||inp&&inp.closest('form')||inp&&inp.parentNode;
    if(hero&&hero.parentNode) hero.parentNode.insertBefore(panel, hero.nextSibling);
    else document.body.appendChild(panel);
    const ch=Q('#clearHist'); if(ch)ch.onclick=()=>{saveHist([]);renderHist()};
  }
  renderHist();
  initFacetsToggle();
  /* retry suggestions after dataset loads */
  let tries=0;
  const t=setInterval(()=>{
    tries++;
    if(typeof R!=='undefined'&&R&&R.length){buildSuggest();clearInterval(t)}
    if(tries>40)clearInterval(t);
  },500);
}
if(document.readyState==='loading')__onReady(boot);
else boot();
})();
;
/* ---- x-missing-facilities ---- */
/* ===== Missing-facility pack (personalisation, citation helpers, provenance,
   client monitoring, performance & usability evaluation kit)
   Existing facilities are left intact. ===== */
(()=>{
'use strict';
const Q=s=>document.querySelector(s);
const QA=s=>[...document.querySelectorAll(s)];
const esc=s=>{const d=document.createElement('div');d.textContent=s==null?'':String(s);return d.innerHTML};
const F=n=>(+n||0).toLocaleString();

/* ---------- 1. Personalised search & recommendation ---------- */
const PROF_KEY='lisKgProfile';
const defaultProf=()=>({authors:{},journals:{},keywords:{},countries:{},savedBoost:true,updated:0});
function loadProf(){try{return Object.assign(defaultProf(),JSON.parse(localStorage.getItem(PROF_KEY)||'{}'))}catch(e){return defaultProf()}}
function saveProf(p){p.updated=Date.now();try{localStorage.setItem(PROF_KEY,JSON.stringify(p))}catch(e){}}
function bump(map,key,w){if(!key)return;const k=String(key).trim();if(!k)return;map[k]=(map[k]||0)+w}
function learnFromRecord(i,w){
  if(typeof R==='undefined'||!R[i])return;
  const p=loadProf();const r=R[i];
  (r[1]||'').split(';').forEach(a=>bump(p.authors,a.trim(),w));
  if(typeof S!=='undefined'&&S[r[4]])bump(p.journals,S[r[4]],w*1.2);
  (r[11]||'').split(/[;|,]/).forEach(k=>bump(p.keywords,k.trim().toLowerCase(),w*0.8));
  if(typeof CO!=='undefined'&&CO[r[7]])bump(p.countries,CO[r[7]],w*0.5);
  saveProf(p);
}
function learnFromQuery(q){
  if(!q)return;const p=loadProf();
  String(q).toLowerCase().split(/[^a-z0-9\u0900-\u097f\u0980-\u09ff]+/).filter(t=>t.length>3).forEach(t=>bump(p.keywords,t,0.3));
  saveProf(p);
}
function personalScore(i){
  const p=loadProf();if(!p.savedBoost)return 0;
  if(typeof R==='undefined'||!R[i])return 0;
  const r=R[i];let s=0;
  (r[1]||'').split(';').forEach(a=>{const k=a.trim();if(p.authors[k])s+=Math.min(8,p.authors[k])});
  if(typeof S!=='undefined'&&S[r[4]]&&p.journals[S[r[4]]])s+=Math.min(10,p.journals[S[r[4]]]*1.2);
  (r[11]||'').split(/[;|,]/).forEach(k=>{const t=k.trim().toLowerCase();if(p.keywords[t])s+=Math.min(4,p.keywords[t]*0.5)});
  return s;
}
function topProfile(map,n){return Object.entries(map).sort((a,b)=>b[1]-a[1]).slice(0,n||8)}
function recommendForYou(limit){
  if(typeof R==='undefined'||!R)return [];
  const p=loadProf();const scored=[];
  for(let i=0;i<R.length;i++){
    const ps=personalScore(i);if(ps<=0)continue;
    scored.push({i,ps,c:R[i][0]});
  }
  scored.sort((a,b)=>b.ps-a.ps||b.c-a.c);
  return scored.slice(0,limit||12);
}

/* ---------- 2. Citation-based search helpers ---------- */
/* Dataset has no reference lists; we expose citation-count discovery & ranking modes. */
function citationLeaders(n){
  if(typeof R==='undefined'||!R)return [];
  return R.map((r,i)=>({i,c:r[0]})).sort((a,b)=>b.c-a.c).slice(0,n||20);
}
function filterByCiteRange(hits,min,max){
  return (hits||[]).filter(h=>{
    const i=typeof h==='object'?h.i:h;const c=R[i][0];
    if(min!=null&&c<min)return false;if(max!=null&&c>max)return false;return true;
  });
}

/* ---------- 3. Provenance & source verification ---------- */
function datasetFingerprint(){
  try{
    if(typeof R==='undefined'||!R)return {records:0,note:'Dataset not loaded'};
    let cites=0,withDoi=0,withAbs=0,years=new Set();
    for(let i=0;i<R.length;i++){const r=R[i];cites+=r[0]||0;if(r[9])withDoi++;if(r[12]&&String(r[12]).length>40)withAbs++;if(r[3])years.add(r[3])}
    const src=(typeof S!=='undefined'?S.length:0);
    return {
      records:R.length,sources:src,countries:(typeof CO!=='undefined'?CO.length:0),
      withDoi,withAbs,cites,yearMin:Math.min(...years),yearMax:Math.max(...years),
      loadedAt:new Date().toISOString(),
      client:'LIS KG Explorer (browser)',
      note:'Snapshot integrity is local. Records are a fixed bibliographic extract; no external harvest ledger is attached.'
    };
  }catch(e){return {error:String(e)}}
}
function provenanceHtml(){
  const f=datasetFingerprint();
  if(f.error)return '<p class="note bad">'+esc(f.error)+'</p>';
  return `<div class="card" style="padding:12px">
    <h3 style="margin:0 0 8px">Dataset provenance</h3>
    <table style="width:100%;font-size:13px;border-collapse:collapse">
      <tr><td><b>Records</b></td><td>${F(f.records)}</td></tr>
      <tr><td><b>Journals / sources</b></td><td>${F(f.sources)}</td></tr>
      <tr><td><b>Countries</b></td><td>${F(f.countries)}</td></tr>
      <tr><td><b>With DOI</b></td><td>${F(f.withDoi)} (${f.records?((100*f.withDoi/f.records).toFixed(1)):0}%)</td></tr>
      <tr><td><b>With substantial abstract</b></td><td>${F(f.withAbs)}</td></tr>
      <tr><td><b>Citation sum</b></td><td>${F(f.cites)}</td></tr>
      <tr><td><b>Year span</b></td><td>${f.yearMin}–${f.yearMax}</td></tr>
      <tr><td><b>Loaded at (local)</b></td><td>${esc(f.loadedAt)}</td></tr>
      <tr><td><b>Client</b></td><td>${esc(f.client)}</td></tr>
    </table>
    <p class="tiny" style="margin-top:8px">${esc(f.note)} Export this statement with results when citing the tool.</p>
    <button class="ghost" type="button" id="provExport">Download provenance JSON</button>
  </div>`;
}

/* ---------- 4. Monitoring & quality assurance (client-side) ---------- */
const LOG_KEY='lisKgMonitor';
function monLog(level,msg,extra){
  try{
    const arr=JSON.parse(localStorage.getItem(LOG_KEY)||'[]');
    arr.unshift({t:new Date().toISOString(),level,msg,extra:extra||null});
    localStorage.setItem(LOG_KEY,JSON.stringify(arr.slice(0,200)));
  }catch(e){}
}
function monDump(){try{return JSON.parse(localStorage.getItem(LOG_KEY)||'[]')}catch(e){return[]}}
window.addEventListener('error',e=>monLog('error',e.message||'error',{src:e.filename,line:e.lineno}));
window.addEventListener('unhandledrejection',e=>monLog('error','unhandledrejection',{reason:String(e.reason)}));

/* ---------- 5 & 6. Performance & usability evaluation kit ---------- */
const EVAL_KEY='lisKgEval';
const GOLD_QUERIES=[
  {id:'q1',q:'digital libraries',note:'Core LIS topic'},
  {id:'q2',q:'information retrieval OR "information seeking"',note:'Boolean OR'},
  {id:'q3',q:'metadata NOT survey',note:'NOT operator'},
  {id:'q4',q:'knowledge NEAR organization',note:'Proximity'},
  {id:'q5',q:'open access',note:'Phrase-like topic'},
  {id:'q6',q:'bibliometrics OR scientometrics',note:'Metrics'},
  {id:'q7',q:'पुस्तकालय',note:'Hindi cross-language'},
  {id:'q8',q:'গ্রন্থাগার',note:'Bengali cross-language'},
];
function loadEval(){try{return JSON.parse(localStorage.getItem(EVAL_KEY)||'{"runs":[],"sus":[],"rels":{}}')}catch(e){return{runs:[],sus:[],rels:{}}}}
function saveEval(e){try{localStorage.setItem(EVAL_KEY,JSON.stringify(e))}catch(err){}}
function timeSearch(q){
  return new Promise(resolve=>{
    const t0=performance.now();
    const inp=Q('#q');
    if(inp){inp.value=q;inp.dispatchEvent(new Event('input',{bubbles:true}))}
    if(typeof state!=='undefined'){state.query=q;state.page=1}
    const done=()=>{
      const t1=performance.now();
      const n=(typeof currentResults!=='undefined'?currentResults.length:0);
      resolve({q,ms:Math.round(t1-t0),results:n,at:new Date().toISOString()});
    };
    if(typeof doSearch==='function'){
      try{doSearch(false)}catch(e){}
      setTimeout(done,80);
    }else done();
  });
}
async function runGoldBattery(){
  const out=[];
  for(const g of GOLD_QUERIES){
    monLog('info','eval query',g);
    const r=await timeSearch(g.q);
    out.push(Object.assign({id:g.id,note:g.note},r));
  }
  const ev=loadEval();ev.runs.push({at:new Date().toISOString(),battery:out});saveEval(ev);
  return out;
}
function susScore(answers){
  // answers: array of 10 scores 1-5 (SUS)
  if(!answers||answers.length!==10)return null;
  let sum=0;
  for(let i=0;i<10;i++){
    const a=+answers[i];if(!(a>=1&&a<=5))return null;
    sum += (i%2===0)?(a-1):(5-a);
  }
  return sum*2.5;
}
const SUS_ITEMS=[
  'I think that I would like to use this system frequently.',
  'I found the system unnecessarily complex.',
  'I thought the system was easy to use.',
  'I think that I would need the support of a technical person to be able to use this system.',
  'I found the various functions in this system were well integrated.',
  'I thought there was too much inconsistency in this system.',
  'I would imagine that most people would learn to use this system very quickly.',
  'I found the system very cumbersome to use.',
  'I felt very confident using the system.',
  'I needed to learn a lot of things before I could get going with this system.'
];

/* ---------- Ranking hook: personalisation boost ---------- */
(function hookRanking(){
  const tryHook=()=>{
    if(typeof relevance!=='function')return false;
    if(relevance._personal)return true;
    const orig=relevance;
    function wrapped(i,q,opt){
      const base=orig.call(this,i,q,opt)||{score:0,why:[]};
      const boost=personalScore(i);
      if(boost>0){
        base.score=(base.score||0)+Math.min(12,boost);
        (base.why=base.why||[]).push(['personal interest',Math.min(12,boost)]);
      }
      return base;
    }
    wrapped._personal=true;
    try{window.relevance=wrapped;relevance=wrapped}catch(e){window.relevance=wrapped}
    return true;
  };
  if(!tryHook()){let n=0;const t=setInterval(()=>{if(tryHook()||++n>40)clearInterval(t)},500)}
})();

/* Learn from searches & saves */
(function hookLearn(){
  const wrap=()=>{
    if(typeof doSearch==='function'&&!doSearch._learn){
      const o=doSearch;
      window.doSearch=function(){
        const q=(Q('#q')&&Q('#q').value)||(window.state&&state.query)||'';
        learnFromQuery(q);
        monLog('info','search',{q});
        return o.apply(this,arguments);
      };
      window.doSearch._learn=true;
    }
  };
  wrap();setInterval(wrap,2000);
  document.addEventListener('click',e=>{
    const s=e.target.closest('[data-save],[data-saved],.save-btn,#saveBtn');
    if(!s)return;
    const card=e.target.closest('[data-i],.result-card');
    const i=card&&(card.dataset.i!=null?+card.dataset.i:null);
    if(i!=null&&!isNaN(i)){learnFromRecord(i,3);monLog('info','save',{i})}
  });
})();

/* ---------- UI panel ---------- */
function openFacilitiesPanel(tab){
  const p=loadProf();
  const topA=topProfile(p.authors,8).map(([k,v])=>`<li>${esc(k)} <span class="tiny">×${v.toFixed?v.toFixed(1):v}</span></li>`).join('')||'<li class="tiny">None yet — search and save to build a profile</li>';
  const topJ=topProfile(p.journals,8).map(([k,v])=>`<li>${esc(k)} <span class="tiny">×${v.toFixed?v.toFixed(1):v}</span></li>`).join('')||'<li class="tiny">None yet</li>';
  const topK=topProfile(p.keywords,10).map(([k,v])=>`<li>${esc(k)} <span class="tiny">×${v.toFixed?v.toFixed(1):v}</span></li>`).join('')||'<li class="tiny">None yet</li>';
  const recs=recommendForYou(10);
  const recHtml=recs.length?`<ol>${recs.map(x=>{
    const o=typeof recObj==='function'?recObj(x.i):{title:R[x.i][2],cites:R[x.i][0]};
    return `<li><a href="#" data-p="${x.i}">${esc(o.title||R[x.i][2])}</a> <span class="tiny">interest ${x.ps.toFixed(1)} · cites ${o.cites||R[x.i][0]}</span></li>`;
  }).join('')}</ol>`:'<p class="tiny">Save papers or run searches to get recommendations.</p>';
  const leaders=citationLeaders(15);
  const citeHtml=`<ol>${leaders.map(x=>`<li><a href="#" data-p="${x.i}">${esc(R[x.i][2])}</a> <span class="tiny">${F(x.c)} cites</span></li>`).join('')}</ol>`;
  const log=monDump().slice(0,30);
  const logHtml=log.length?`<table style="width:100%;font-size:11px"><thead><tr><th>Time</th><th>Level</th><th>Message</th></tr></thead><tbody>${
    log.map(e=>`<tr><td>${esc(e.t)}</td><td>${esc(e.level)}</td><td>${esc(e.msg)}</td></tr>`).join('')
  }</tbody></table>`:'<p class="tiny">No client events logged yet.</p>';
  const susForm=SUS_ITEMS.map((t,i)=>`<label style="display:block;margin:6px 0;font-size:12.5px">${i+1}. ${esc(t)}
    <select data-sus="${i}" style="margin-left:8px">${[1,2,3,4,5].map(n=>`<option value="${n}">${n}</option>`).join('')}</select>
  </label>`).join('');
  const goldList=GOLD_QUERIES.map(g=>`<li><code>${esc(g.q)}</code> — ${esc(g.note)} <button class="ghost" type="button" data-gold="${esc(g.q)}">Run</button></li>`).join('');

  const body=`<h2>Research facilities</h2>
  <p class="tiny">Personalisation, citation helpers, provenance, client monitoring, and an evaluation kit. Existing search, KG, maps and multilingual features are unchanged.</p>
  <div class="kg-toolbar" style="flex-wrap:wrap;gap:6px">
    <button class="ghost fac-tab" data-ftab="personal" type="button">Personalised</button>
    <button class="ghost fac-tab" data-ftab="citation" type="button">Citation-based</button>
    <button class="ghost fac-tab" data-ftab="prov" type="button">Provenance</button>
    <button class="ghost fac-tab" data-ftab="monitor" type="button">Monitoring</button>
    <button class="ghost fac-tab" data-ftab="eval" type="button">Evaluation kit</button>
  </div>
  <div id="facPanel" style="margin-top:10px">
    <div data-fpane="personal">
      <h3>Interest profile (local only)</h3>
      <p class="tiny">Built from your searches and saved records in this browser. Ranking receives a small personal boost when enabled.</p>
      <label><input type="checkbox" id="profBoost" ${p.savedBoost?'checked':''}> Apply personal interest boost to ranking</label>
      <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px;margin-top:10px">
        <div><b>Authors</b><ul>${topA}</ul></div>
        <div><b>Journals</b><ul>${topJ}</ul></div>
        <div><b>Keywords</b><ul>${topK}</ul></div>
      </div>
      <h3>Recommended for you</h3>
      ${recHtml}
      <button class="ghost" type="button" id="profClear">Clear profile</button>
    </div>
    <div data-fpane="citation" hidden>
      <h3>Citation-based discovery</h3>
      <p class="tiny">This collection has <b>citation counts</b> but <b>no reference lists</b>, so citing/cited navigation and co-citation search are not possible. Use count-based discovery instead.</p>
      <div class="row" style="gap:8px;flex-wrap:wrap;margin:8px 0">
        <label>Min citations <input type="number" id="citeMin" value="10" min="0" style="width:80px"></label>
        <button class="primary" type="button" id="citeFilter">Filter current results</button>
        <button class="ghost" type="button" id="citeLeaders">Show highly cited (collection)</button>
      </div>
      <div id="citeOut">${citeHtml}</div>
    </div>
    <div data-fpane="prov" hidden>${provenanceHtml()}</div>
    <div data-fpane="monitor" hidden>
      <h3>Client-side monitoring</h3>
      <p class="tiny">Last 200 events in this browser (searches, errors). Not sent to a server.</p>
      ${logHtml}
      <div class="row" style="gap:8px;margin-top:8px">
        <button class="ghost" type="button" id="monExport">Export log JSON</button>
        <button class="ghost" type="button" id="monClear">Clear log</button>
      </div>
    </div>
    <div data-fpane="eval" hidden>
      <h3>Systematic performance &amp; usability evaluation kit</h3>
      <p class="tiny">Run a fixed query battery with timings, mark relevance on result cards (for offline P@k calculation), and capture SUS scores. Results stay in localStorage until exported.</p>
      <h4>Gold-standard style sample queries</h4>
      <ol>${goldList}</ol>
      <button class="primary" type="button" id="evalBattery">Run full battery (timed)</button>
      <div id="evalOut" class="tiny" style="margin-top:8px"></div>
      <h4 style="margin-top:14px">System Usability Scale (SUS)</h4>
      <p class="tiny">1 = Strongly disagree … 5 = Strongly agree</p>
      <div id="susForm">${susForm}</div>
      <button class="primary" type="button" id="susSave">Save SUS response</button>
      <div id="susOut" class="tiny" style="margin-top:6px"></div>
      <h4 style="margin-top:14px">Relevance marks</h4>
      <p class="tiny">On any result card, use the buttons added below titles when evaluation mode is on.</p>
      <label><input type="checkbox" id="evalRelMode"> Enable relevance marking on results</label>
      <button class="ghost" type="button" id="evalExport">Export all evaluation JSON</button>
    </div>
  </div>`;

  if(typeof showModal==='function')showModal(body);
  else{alert('Modal unavailable');return}

  const showPane=name=>{
    QA('#facPanel [data-fpane]').forEach(el=>{el.hidden=el.getAttribute('data-fpane')!==name});
    QA('.fac-tab').forEach(b=>b.style.fontWeight=b.dataset.ftab===name?'700':'');
  };
  showPane(tab||'personal');
  QA('.fac-tab').forEach(b=>b.onclick=()=>showPane(b.dataset.ftab));

  const boost=Q('#profBoost');if(boost)boost.onchange=()=>{const pr=loadProf();pr.savedBoost=boost.checked;saveProf(pr)};
  const pc=Q('#profClear');if(pc)pc.onclick=()=>{saveProf(defaultProf());openFacilitiesPanel('personal')};
  QA('#facPanel [data-p]').forEach(a=>a.onclick=e=>{e.preventDefault();if(typeof detail==='function')detail(+a.dataset.p)});

  const cf=Q('#citeFilter');
  if(cf)cf.onclick=()=>{
    const min=+(Q('#citeMin').value||0);
    if(typeof state!=='undefined'){state.minCites=min;if(Q('#minCites'))Q('#minCites').value=min;state.page=1}
    if(typeof doSearch==='function')doSearch(false);
    monLog('info','citation filter',{min});
    if(typeof toast==='function')toast('Filtered to ≥ '+min+' citations');
  };
  const cl=Q('#citeLeaders');
  if(cl)cl.onclick=()=>{
    const list=citationLeaders(25);
    Q('#citeOut').innerHTML=`<ol>${list.map(x=>`<li><a href="#" data-p="${x.i}">${esc(R[x.i][2])}</a> <span class="tiny">${F(x.c)} cites</span></li>`).join('')}</ol>`;
    QA('#citeOut [data-p]').forEach(a=>a.onclick=e=>{e.preventDefault();if(typeof detail==='function')detail(+a.dataset.p)});
  };

  const pe=Q('#provExport');
  if(pe)pe.onclick=()=>{
    const blob=new Blob([JSON.stringify(datasetFingerprint(),null,2)],{type:'application/json'});
    const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='lis-kg-provenance.json';a.click();
  };

  const me=Q('#monExport');
  if(me)me.onclick=()=>{
    const blob=new Blob([JSON.stringify(monDump(),null,2)],{type:'application/json'});
    const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='lis-kg-monitor.json';a.click();
  };
  const mc=Q('#monClear');if(mc)mc.onclick=()=>{localStorage.removeItem(LOG_KEY);openFacilitiesPanel('monitor')};

  QA('[data-gold]').forEach(b=>b.onclick=async()=>{
    const r=await timeSearch(b.dataset.gold);
    Q('#evalOut').textContent=`${r.q}: ${r.ms} ms, ${r.results} results`;
  });
  const bat=Q('#evalBattery');
  if(bat)bat.onclick=async()=>{
    bat.disabled=true;bat.textContent='Running…';
    const out=await runGoldBattery();
    bat.disabled=false;bat.textContent='Run full battery (timed)';
    Q('#evalOut').innerHTML='<table style="width:100%;font-size:12px"><tr><th>Query</th><th>ms</th><th>Results</th></tr>'+
      out.map(r=>`<tr><td>${esc(r.q)}</td><td>${r.ms}</td><td>${r.results}</td></tr>`).join('')+'</table>';
    monLog('info','eval battery done',{n:out.length});
  };
  const ss=Q('#susSave');
  if(ss)ss.onclick=()=>{
    const ans=QA('[data-sus]').map(s=>+s.value);
    const score=susScore(ans);
    if(score==null){Q('#susOut').textContent='Please answer all 10 items (1–5).';return}
    const ev=loadEval();ev.sus.push({at:new Date().toISOString(),answers:ans,score});saveEval(ev);
    Q('#susOut').textContent='SUS score saved: '+score+' (0–100). Local only until export.';
    monLog('info','SUS',{score});
  };
  const erm=Q('#evalRelMode');
  if(erm)erm.onchange=()=>{document.body.classList.toggle('eval-rel-mode',erm.checked)};
  const ee=Q('#evalExport');
  if(ee)ee.onclick=()=>{
    const blob=new Blob([JSON.stringify(loadEval(),null,2)],{type:'application/json'});
    const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='lis-kg-evaluation.json';a.click();
  };
}

/* Relevance mark buttons when evaluation mode is on */
document.addEventListener('click',e=>{
  if(!document.body.classList.contains('eval-rel-mode'))return;
  const btn=e.target.closest('[data-rel]');
  if(!btn)return;
  e.preventDefault();
  const i=+btn.dataset.relI, val=btn.dataset.rel;
  const ev=loadEval();const q=(window.state&&state.query)||'';
  if(!ev.rels[q])ev.rels[q]={};
  ev.rels[q][i]=val;saveEval(ev);
  btn.textContent=val==='1'?'Relevant ✓':'Not relevant ✓';
  monLog('info','relevance',{q,i,val});
});
(function injectRelButtons(){
  const obs=new MutationObserver(()=>{
    if(!document.body.classList.contains('eval-rel-mode'))return;
    QA('.result-card, [data-i]').forEach(card=>{
      if(card.querySelector('[data-rel]'))return;
      const i=card.dataset.i!=null?+card.dataset.i:null;if(i==null||isNaN(i))return;
      const row=document.createElement('div');
      row.className='eval-rel-row';
      row.style.cssText='margin-top:4px;display:flex;gap:6px';
      row.innerHTML=`<button type="button" class="ghost" data-rel="1" data-rel-i="${i}" style="font-size:11px">Relevant</button>
        <button type="button" class="ghost" data-rel="0" data-rel-i="${i}" style="font-size:11px">Not relevant</button>`;
      card.appendChild(row);
    });
  });
  obs.observe(document.body,{childList:true,subtree:true});
})();

/* Toolbar button */
function mountFacBtn(){
  if(Q('#facilitiesBtn'))return;
  const btn=document.createElement('button');
  btn.type='button';btn.className='ghost';btn.id='facilitiesBtn';
  btn.textContent='▣ Facilities';
  btn.title='Personalisation, citation helpers, provenance, monitoring, evaluation kit';
  btn.onclick=()=>openFacilitiesPanel('personal');
  const host=Q('.head-actions')||Q('.toolbar')||Q('header')||document.body;
  host.appendChild(btn);
}
if(document.readyState==='loading')__onReady(mountFacBtn);
else mountFacBtn();
setTimeout(mountFacBtn,1500);

window.LISFacilities={open:openFacilitiesPanel,profile:loadProf,recommend:recommendForYou,provenance:datasetFingerprint,monitor:monDump,eval:loadEval};
monLog('info','facilities pack loaded');
})();
;
/* ---- federated-search ---- */
/* ===== Federated Search: one query across the local library and live scholarly sources =====
   Sends the query to every selected source at the same time, merges duplicates (by DOI, or by title),
   and ranks results with reciprocal rank fusion, so records found by several sources rise to the top.
   Adds a facility only: search, online lookup, graphs, maps and tree are unchanged. */
const FED_CSS=`
.fed-chips{display:flex;flex-wrap:wrap;gap:6px;margin:6px 0 4px}
.fed-chip{border:1px solid var(--line);border-radius:999px;padding:3px 9px;font-size:12px;background:#f8fafc}
.fed-chip.err{border-color:#f59e0b;color:#92400e;background:#fff7ed}
.fed-actions{margin-top:8px;display:flex;flex-wrap:wrap;gap:6px}
.fed-actions .ghost{padding:6px 9px;border:1px solid var(--line);border-radius:8px;font-size:12.5px}
.sample-header .toolbar #federatedSearchBtn{background:#e8f5ef!important;color:#0f5c63!important}
`;
const FED={perSource:10,k:60};
const FED_SOURCES={
  local:{id:'local',label:'Local library',desc:'This portal’s corpus, ranked by the same relevance engine as search',on:true},
  openalex:{id:'openalex',label:'OpenAlex',desc:'Global open scholarly index: works, authors, DOIs, citations',on:true,run:q=>searchOpenAlex(q,FED.perSource)},
  crossref:{id:'crossref',label:'Crossref',desc:'DOI registry: journal articles and books',on:true,run:q=>searchCrossref(q,FED.perSource)},
  doaj:{id:'doaj',label:'DOAJ',desc:'Directory of Open Access Journals: free full-text articles',on:true,run:q=>searchDOAJ(q,FED.perSource)},
  wikipedia:{id:'wikipedia',label:'Wikipedia',desc:'Encyclopedic articles and summaries',on:false,run:q=>searchWikipedia(q,FED.perSource)},
  dbpedia:{id:'dbpedia',label:'DBpedia',desc:'Structured knowledge extracted from Wikipedia (some browsers block it)',on:false,run:q=>searchDBpedia(q,FED.perSource)}
};

/* DOAJ article search: GET /api/search/articles/{query}; results carry a "bibjson" record */
async function searchDOAJ(q,limit=10){
  const url=`https://doaj.org/api/search/articles/${encodeURIComponent(q)}?page=1&pageSize=${limit}`;
  const data=await onlineFetchJson(url);
  return (data.results||[]).map(x=>{
    const b=x.bibjson||{};
    const doiId=((b.identifier||[]).find(i=>String(i.type||'').toLowerCase()==='doi')||{}).id||'';
    const full=(b.link||[]).find(l=>String(l.type||'').toLowerCase()==='fulltext');
    const link=(full&&full.url)||(doiId?'https://doi.org/'+doiId:'');
    const journal=b.journal||{};
    return {
      source:journal.title||'DOAJ',sourceId:'doaj',
      title:b.title||'Untitled',
      authors:(b.author||[]).slice(0,6).map(a=>a.name).filter(Boolean).join('; '),
      year:b.year||'',doi:doiId,cites:0,url:link,
      abstract:b.abstract||'',keywords:(b.keywords||[]).join('; '),
      publisher:journal.publisher||'',type:'journal-article',openAccess:true
    };
  });
}

/* local library hits in relevance order, using the same engine and filters as search */
function fedLocal(q,limit){
  const sq=prepareSearchQuery(q).searchQ;
  const qo={expand:state.expand!==false};
  SEARCH_SAVED=state.savedOnly?savedSet():null;
  const cand=[];
  for(let i=0;i<R.length;i++){
    if(!passesFacets(i))continue;
    const rel=relevance(i,sq,qo),score=typeof rel==='number'?rel:rel.score;
    if(score>0)cand.push({i,score});
  }
  cand.sort((a,b)=>b.score-a.score);
  return cand.slice(0,limit);
}
function fedFromLocal(i){
  const o=recObj(i);
  return {title:o.title||'Untitled',authors:o.authors||'',year:o.year||'',source:o.source||'',publisher:o.publisher||'',
    doi:o.doi||'',url:o.url||'',cites:Number(o.cites)||0,abstract:o.abstract||'',keywords:o.keywords||'',country:o.country||'',type:'',openAccess:false};
}
/* duplicate key: DOI when present, otherwise the normalised title */
function fedKey(r){
  const doi=String(r.doi||'').toLowerCase().trim().replace(/^(https?:\/\/)?(dx\.)?doi\.org\//,'').replace(/^doi:/,'');
  if(doi)return 'doi:'+doi;
  const t=String(r.title||'').toLowerCase().replace(/[^a-z0-9\u0980-\u09ff]+/g,' ').trim();
  return t?'t:'+t:'';
}
/* merge each source's ranked list; score = sum over sources of 1/(k + rank) */
function fedMerge(results){
  const map=new Map(),raw=[];
  results.forEach(res=>{
    if(res.err||!res.list)return;
    res.list.forEach((item,rank)=>{
      const rec=res.id==='local'?fedFromLocal(item.i):item;
      raw.push(res.id);
      const key=fedKey(rec)||('#'+res.id+':'+rank);
      let m=map.get(key);
      if(!m){
        m={title:'',authors:'',year:'',source:'',publisher:'',doi:'',url:'',cites:0,abstract:'',keywords:'',country:'',type:'',
           openAccess:false,localI:null,hits:[],score:0};
        map.set(key,m);
      }
      if(!m.title)m.title=rec.title||'';
      ['authors','abstract','keywords','publisher','country','source','year','doi','type'].forEach(f=>{
        if(rec[f]&&String(rec[f]).length>String(m[f]||'').length)m[f]=rec[f];
      });
      if(rec.url&&(!m.url||/doi\.org/.test(rec.url)))m.url=rec.url;
      m.cites=Math.max(m.cites,Number(rec.cites)||0);
      m.openAccess=m.openAccess||!!rec.openAccess;
      if(res.id==='local'&&m.localI==null)m.localI=item.i;
      m.hits.push({id:res.id,label:FED_SOURCES[res.id].label,rank:rank+1});
      m.score+=1/(FED.k+rank+1);
    });
  });
  const items=[...map.values()].sort((a,b)=>(b.score-a.score)||(b.cites-a.cites));
  return {items,raw:raw.length};
}
/* run every selected source in parallel; one failing source never stops the others */
async function federatedRun(q,selected,perSource){
  FED.perSource=perSource;
  return Promise.all(selected.map(id=>{
    const t0=performance.now();
    const job=id==='local'?Promise.resolve().then(()=>fedLocal(q,perSource*2))
                           :Promise.resolve().then(()=>FED_SOURCES[id].run(q));
    return job.then(list=>({id,list:list||[],ms:Math.round(performance.now()-t0)}))
              .catch(e=>({id,err:(e&&e.message)||'request failed',ms:Math.round(performance.now()-t0)}));
  }));
}
function fedStatusHtml(results,items,raw){
  const chips=results.map(r=>{
    const label=esc(FED_SOURCES[r.id].label);
    return r.err?`<span class="fed-chip err">${label}: ${esc(r.err)}</span>`
                :`<span class="fed-chip">${label} · ${r.list.length} · ${r.ms} ms</span>`;
  }).join('');
  const multi=items.filter(m=>m.hits.length>1).length,dups=raw-items.length;
  return `<div class="fed-chips">${chips}</div>`+
    `<b>${items.length}</b> unique result${items.length===1?'':'s'} · ${multi} found by more than one source · ${dups} duplicate${dups===1?'':'s'} merged`;
}
function fedCardHtml(m,k){
  const doiUrl=m.doi?'https://doi.org/'+String(m.doi).replace(/^(https?:\/\/)?(dx\.)?doi\.org\//,''):'';
  const href=safeUrl(m.url)||safeUrl(doiUrl)||'';
  const title=href?`<a href="${esc(href)}" target="_blank" rel="noopener">${esc(m.title)}</a>`:esc(m.title);
  const abs=m.abstract?`<div class="abstract">${esc(m.abstract.slice(0,360))}${m.abstract.length>360?'…':''}</div>`:'';
  return `<article class="result-card fed-card" data-fed="${k}">
    <h3 class="rtitle">${title}</h3>
    <div class="meta">${esc([m.authors,m.year,m.source].filter(Boolean).join(' · '))}</div>
    <div class="badges">${m.hits.map(h=>`<span class="badge">${esc(h.label)} #${h.rank}</span>`).join('')}${m.hits.length>1?`<span class="badge access">Found in ${m.hits.length} sources</span>`:''}${m.cites?`<span class="badge cites">${Number(m.cites).toLocaleString()} cites</span>`:''}${m.openAccess?'<span class="badge access">Open Access</span>':''}</div>
    ${abs}
    <div class="fed-actions">${m.localI!=null?`<button class="ghost" data-fed-detail="${m.localI}">Open in library</button>`:''}</div>
  </article>`;
}
function federatedSearchModal(){
  const q=($('#q')&&$('#q').value)||state.query||'';
  showModal(`<h2>🔀 Federated Search</h2>
    <p class="tiny">One query, sent to your local library and to the live sources you select at the same time. Duplicates are merged by DOI or title, and results are ranked by how strongly the sources agree.</p>
    <div class="db-form" style="margin:12px 0">
      <label>Query <input id="fedQuery" value="${esc(q)}" placeholder="e.g. knowledge graphs in digital libraries"></label>
      <div style="margin-top:10px"><b>Sources</b></div>
      <div class="checklist" style="margin-top:6px;max-height:none">
        ${Object.values(FED_SOURCES).map(s=>`<label class="check"><input type="checkbox" class="fedSrc" value="${s.id}" ${s.on?'checked':''}><span><b>${esc(s.label)}</b> — ${esc(s.desc)}</span></label>`).join('')}
      </div>
      <label style="margin-top:10px;display:inline-block">Results per source <select id="fedLimit"><option>5</option><option selected>10</option><option>20</option></select></label>
    </div>
    <div class="actions" style="margin:12px 0">
      <button class="primary" id="fedRunBtn">Search all selected sources</button>
      <button class="ghost" id="fedKgBtn" disabled style="opacity:.5" title="Build a knowledge graph from the federated results">⌘ Build Knowledge Graph</button>
      <button class="ghost" id="fedClose">Close</button>
    </div>
    <div id="fedStatus" class="tiny" style="margin-bottom:8px;color:var(--muted)"></div>
    <div id="fedResults" class="result-list" style="max-height:55vh;overflow:auto"></div>
    <p class="note" style="margin-top:12px">Local results use this portal's relevance engine and current filters. Online results come from public APIs with no key needed; please respect each provider's rate limits.</p>`);
  const run=async()=>{
    const query=$('#fedQuery').value.trim();
    const selected=$$('.fedSrc:checked').map(c=>c.value);
    if(!query){toast('Enter a search query first');return}
    if(!selected.length){toast('Select at least one source');return}
    const perSource=Number($('#fedLimit').value)||10;
    const status=$('#fedStatus'),list=$('#fedResults'),kg=$('#fedKgBtn');
    status.innerHTML='<span class="spinner" style="width:14px;height:14px;display:inline-block;border-width:2px"></span> Searching '+selected.length+' source'+(selected.length===1?'':'s')+'…';
    list.innerHTML='';kg.disabled=true;kg.style.opacity='.5';
    const results=await federatedRun(query,selected,perSource);
    const {items,raw}=fedMerge(results);
    status.innerHTML=fedStatusHtml(results,items,raw);
    list.innerHTML=items.length?items.map(fedCardHtml).join(''):'<div class="note">No results from the selected sources. Try other keywords or sources.</div>';
    kg.disabled=!items.length;kg.style.opacity=items.length?'1':'.5';
    kg.onclick=()=>{window.__lastOnlineResults=items;kgOpenOnline(items,query)};
  };
  $('#fedRunBtn').onclick=run;
  $('#fedQuery').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();run()}});
  $('#fedClose').onclick=closeModal;
  $('#fedResults').addEventListener('click',e=>{
    const d=e.target.closest('[data-fed-detail]');
    if(d){e.preventDefault();detail(+d.dataset.fedDetail)}
  });
  if(q.trim())setTimeout(run,200);
}
(()=>{
  if(!document.getElementById('fed-css')){const st=document.createElement('style');st.id='fed-css';st.textContent=FED_CSS;document.head.appendChild(st)}
  const b=document.getElementById('federatedSearchBtn');
  if(b)b.onclick=federatedSearchModal;
})();
;
/* ---- results-first-ui ---- */
(()=>{
  const body=document.body, facets=document.getElementById('facets'), fb=document.getElementById('mobileFilterBtn');
  const bar=document.querySelector('main#results .resultbar');
  /* "Show overview" brings back the landing title and metric cards after a search */
  if(bar&&!document.getElementById('overviewToggleBtn')){
    const ov=document.createElement('button');
    ov.type='button';ov.className='ghost';ov.id='overviewToggleBtn';ov.textContent='Show overview';ov.setAttribute('aria-pressed','false');
    ov.onclick=()=>{const on=body.classList.toggle('show-overview');ov.textContent=on?'Hide overview':'Show overview';ov.setAttribute('aria-pressed',on?'true':'false')};
    bar.insertBefore(ov,bar.querySelector('.sort')||null);
  }
  /* The existing Filters button now toggles the filter panel (it used to only open it) */
  if(fb&&facets){
    fb.onclick=()=>{const on=facets.classList.toggle('mobile-open');fb.textContent=on?'✕ Hide filters':'☰ Filters';fb.setAttribute('aria-expanded',on?'true':'false')};
  }
  /* Reset the toggles when the search is cleared or the filter panel closes another way (Escape) */
  const reset=()=>{
    if(!body.classList.contains('has-search')){
      body.classList.remove('show-overview');
      if(facets)facets.classList.remove('mobile-open');
      const ov=document.getElementById('overviewToggleBtn');if(ov){ov.textContent='Show overview';ov.setAttribute('aria-pressed','false')}
    }
    if(facets&&!facets.classList.contains('mobile-open')&&fb){fb.textContent='☰ Filters';fb.setAttribute('aria-expanded','false')}
  };
  if(body)new MutationObserver(reset).observe(body,{attributes:true,attributeFilter:['class']});
  if(facets)new MutationObserver(reset).observe(facets,{attributes:true,attributeFilter:['class']});
})();
;
/* ---- x6-module ---- */
(function(){
'use strict';
/* ===== x6: spelling suggestions, Study Lab (usability + search success + blind baseline comparison),
   maintenance (performance test, metadata audit, backup/restore) and accessibility controls ===== */
const ls=(k,d)=>{try{const v=localStorage.getItem(k);return v?JSON.parse(v):d}catch(e){return d}};
const sv=(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v));return true}catch(e){return false}};
const H=s=>esc(s);
const med=a=>{if(!a.length)return null;const s=[...a].sort((x,y)=>x-y),m=s.length>>1;return s.length%2?s[m]:(s[m-1]+s[m])/2};
const mean=a=>a.length?a.reduce((x,y)=>x+y,0)/a.length:null;
const fx=(x,d=1)=>(x==null||isNaN(x))?'–':Number(x).toFixed(d);
const pc=x=>(x==null||isNaN(x))?'–':Math.round(100*x)+'%';
const q$=s=>document.querySelector(s), q$$=s=>[...document.querySelectorAll(s)];

/* ---------- 1. “Did you mean…?” spelling suggestions ---------- */
let VOC=null,BYLEN=null;
function vocab(){
  if(VOC)return VOC;
  VOC=new Map();
  for(let i=0;i<R.length;i++){const r=R[i];for(const w of tokens((r[2]||'')+' '+(r[11]||''))){const k=w.replace(/[.+#-]+$/,'');if(k.length>=3)VOC.set(k,(VOC.get(k)||0)+1)}}
  BYLEN=new Map();
  for(const [w,c] of VOC){const n=w.length;if(!BYLEN.has(n))BYLEN.set(n,[]);BYLEN.get(n).push([w,c])}
  return VOC;
}
function dl(a,b,max){
  const n=a.length,m=b.length;if(Math.abs(n-m)>max)return max+1;
  let p2=null,p1=Array.from({length:m+1},(_,j)=>j);
  for(let i=1;i<=n;i++){
    const c=[i];let mn=i;
    for(let j=1;j<=m;j++){
      let v=Math.min(p1[j]+1,c[j-1]+1,p1[j-1]+(a[i-1]===b[j-1]?0:1));
      if(i>1&&j>1&&a[i-1]===b[j-2]&&a[i-2]===b[j-1])v=Math.min(v,p2[j-2]+1);
      c[j]=v;if(v<mn)mn=v;
    }
    if(mn>max)return max+1;
    p2=p1;p1=c;
  }
  return p1[m];
}
function suggestWord(w){
  const max=w.length<=5?1:2;let best=null;
  for(let L=w.length-max;L<=w.length+max;L++){
    const arr=BYLEN.get(L);if(!arr)continue;
    for(const [c,f] of arr){
      if(c===w||f<2)continue;
      const d=dl(w,c,max);if(d>max)continue;
      if(!best||d<best.d||(d===best.d&&f>best.f))best={w:c,d,f};
    }
  }
  return best;
}
function spellSuggestion(q,nResults){
  if(!q||/[^\x00-\x7F]/.test(q))return null;
  vocab();
  const raw=q.split(/\s+/),fixes=[];
  for(const part of raw){
    const w=norm(part).replace(/^[-("']+|[)"',.;:]+$/g,'');
    if(w.length<4||/\d/.test(w)||/[*?]/.test(w)||/^(and|or|not|near)(\/\d+)?$/.test(w))continue;
    const f=VOC.get(w)||0;
    if(f>=3)continue;
    const s=suggestWord(w);
    if(!s)continue;
    if(f===0||(nResults<5&&f<=1&&s.f>=20))fixes.push([w,s.w]);
  }
  if(!fixes.length)return null;
  let out=q;
  for(const [a,b] of fixes)out=out.replace(new RegExp('\\b'+a.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+'\\b','ig'),b);
  return out===q?null:out;
}
function showDym(q,n){
  let box=q$('#dymBox');
  if(!box){
    const anchor=q$('#resultSummary');if(!anchor)return;
    box=document.createElement('div');box.id='dymBox';box.setAttribute('role','status');box.className='x6-dym';
    anchor.parentNode.insertBefore(box,anchor);
  }
  let s=null;try{s=spellSuggestion(q,n)}catch(e){s=null}
  if(!s){box.style.display='none';box.innerHTML='';return}
  box.style.display='block';
  box.innerHTML='Did you mean: <button type="button" class="x6-dym-btn">'+H(s)+'</button> <span class="tiny">(spelling suggestion from the collection vocabulary)</span>';
  box.querySelector('button').onclick=()=>{
    const qe=q$('#q');if(qe)qe.value=s;state.query=s;state.page=1;doSearch(true);
  };
}

/* ---------- 2. Automatic search log: response time + search success ---------- */
let SLOG=ls('lisSearchLog',[]);
function logSearch(q,n,ms){
  if(!q)return;
  const last=SLOG[SLOG.length-1];
  if(last&&last.q===q){last.n=n;last.ms=ms;}
  else{SLOG.push({q,n,ms:+ms.toFixed(1),eng:false,tEng:null,ts:Date.now()});if(SLOG.length>500)SLOG=SLOG.slice(-500)}
  sv('lisSearchLog',SLOG);
}
document.addEventListener('click',e=>{
  const t=e.target.closest&&e.target.closest('#resultList [data-act], #resultList a.full, #resultList .rtitle a');
  if(!t)return;
  const last=SLOG[SLOG.length-1];
  if(last&&!last.eng&&last.n>0){last.eng=true;last.tEng=+((Date.now()-last.ts)/1000).toFixed(1);sv('lisSearchLog',SLOG)}
},true);
function hookSearch(){
  if(typeof doSearch!=='function'||doSearch._x6)return;
  const o=doSearch;
  const w=function(){
    const t0=performance.now();
    const r=o.apply(this,arguments);
    const ms=performance.now()-t0;
    try{const q=(state.query||'').trim();logSearch(q,currentResults.length,ms);showDym(q,currentResults.length)}catch(e){console.warn('x6',e)}
    return r;
  };
  Object.assign(w,o);w._x6=true;window.doSearch=w;
}

/* ---------- 3. Retrieval helpers for the blind comparison ---------- */
function explorerTop(q,k){
  const li=prepareSearchQuery(q),sq=li.searchQ,qo={expand:true},out=[];
  for(let i=0;i<R.length;i++){const rel=relevance(i,sq,qo),sc=typeof rel==='number'?rel:rel.score;if(sc>0)out.push([i,sc])}
  out.sort((a,b)=>b[1]-a[1]||R[b[0]][0]-R[a[0]][0]);
  return {top:out.slice(0,k).map(x=>x[0]),total:out.length};
}
function baselineTop(q,k){
  const tk=[...new Set(tokens(q.replace(/\b(AND|OR|NOT|NEAR)\b/g,' ')))].filter(w=>w.length>1),out=[];
  if(!tk.length)return {top:[],total:0};
  for(let i=0;i<R.length;i++){const x=INDEX[i],hay=x.t+' '+x.k+' '+x.b;if(tk.every(w=>hay.includes(w)))out.push(i)}
  out.sort((a,b)=>R[b][0]-R[a][0]);
  return {top:out.slice(0,k),total:out.length};
}

/* ---------- 4. Study Lab ---------- */
const DEFAULT_TASKS=[
 'Find a paper about “open access” using the search box and open its details.',
 'Use Advanced Search to find papers whose title contains “bibliometric”.',
 'Restrict results to one journal and a year range using the filters.',
 'Open any paper’s details and copy its citation.',
 'Build a knowledge graph from the current search results.',
 'Search in Bengali or Banglish (e.g. “pustakalay”) and open one result.'
];
let ST=ls('lisStudy',{pid:'P1',runs:[],sat:{}});
let TASKS=ls('lisStudyTasks',DEFAULT_TASKS);
const saveST=()=>sv('lisStudy',ST);
let ACTIVE=null,TICK=null;

function openModal(html,wide){
  const c=q$('#modalCard');c.classList.toggle('x2-wide',!!wide);
  showModal(html);
}
const TABS=[['tasks','Usability tasks'],['search','Search success'],['cmp','Blind baseline comparison'],['maint','Maintenance & audit']];
function studyModal(tab){
  tab=tab||'tasks';
  openModal('<h2>Study Lab</h2><p class="tiny">Structured evaluation: task completion time, task success, ease ratings, satisfaction, search success rate, and a blind comparison with a keyword-only baseline. Data stay in this browser; export as CSV.</p><div class="x6-tabs" role="tablist">'+TABS.map(([k,l])=>'<button type="button" role="tab" aria-selected="'+(k===tab)+'" class="x6-tab'+(k===tab?' on':'')+'" data-x6t="'+k+'">'+l+'</button>').join('')+'</div><div id="x6Body"></div>',true);
  q$$('[data-x6t]').forEach(b=>b.onclick=()=>studyModal(b.dataset.x6t));
  ({tasks:tabTasks,search:tabSearch,cmp:tabCmp,maint:tabMaint})[tab](q$('#x6Body'));
}
function csv(rows){return rows.map(r=>r.map(csvCell).join(',')).join('\n')}

/* --- tab: usability tasks --- */
function tabTasks(B){
  const runs=ST.runs;
  const perTask=TASKS.map((t,i)=>{
    const r=runs.filter(x=>x.task===i),ok=r.filter(x=>x.outcome==='success');
    return {t,n:r.length,sr:r.length?ok.length/r.length:null,mt:mean(ok.map(x=>x.secs)),md:med(ok.map(x=>x.secs)),seq:mean(r.map(x=>x.seq).filter(x=>x))};
  });
  const sats=Object.values(ST.sat);
  const all=runs.length,okAll=runs.filter(x=>x.outcome==='success');
  B.innerHTML='<div class="x6-grid">'
   +'<div class="x6-card"><b>'+all+'</b><span>task attempts</span></div>'
   +'<div class="x6-card"><b>'+pc(all?okAll.length/all:null)+'</b><span>task success rate</span></div>'
   +'<div class="x6-card"><b>'+fx(mean(okAll.map(x=>x.secs)),1)+' s</b><span>mean time (successful)</span></div>'
   +'<div class="x6-card"><b>'+fx(mean(sats),2)+' / 5</b><span>mean satisfaction (n='+sats.length+')</span></div></div>'
   +'<h3>Run a task</h3><div class="x6-row"><label>Participant ID <input id="x6Pid" value="'+H(ST.pid)+'" size="10"></label>'
   +'<label>Overall satisfaction (1–5) <select id="x6Sat"><option value="">–</option>'+[1,2,3,4,5].map(n=>'<option>'+n+'</option>').join('')+'</select></label><button type="button" id="x6SatSave" class="ghost">Save satisfaction</button></div>'
   +'<table class="x6-t"><tr><th>#</th><th>Task</th><th>Attempts</th><th>Success</th><th>Mean time (s)</th><th>Median (s)</th><th>Ease (1–7)</th><th></th></tr>'
   +perTask.map((p,i)=>'<tr><td>'+(i+1)+'</td><td>'+H(p.t)+'</td><td>'+p.n+'</td><td>'+pc(p.sr)+'</td><td>'+fx(p.mt)+'</td><td>'+fx(p.md)+'</td><td>'+fx(p.seq)+'</td><td><button type="button" class="primary" data-x6start="'+i+'">Start</button></td></tr>').join('')+'</table>'
   +'<p class="tiny">Start closes this window and shows a timer panel. Perform the task in the app, then choose Success / Failed / Gave up and rate how easy it was.</p>'
   +'<details><summary>Edit task list (one task per line)</summary><textarea id="x6TaskEdit" rows="6" style="width:100%">'+H(TASKS.join('\n'))+'</textarea><div class="x6-row"><button type="button" class="ghost" id="x6TaskSave">Save tasks</button></div></details>'
   +'<div class="x6-row"><button type="button" class="ghost" id="x6Csv">Export runs (CSV)</button><button type="button" class="ghost" id="x6Clear">Clear study data</button></div>'
   +'<p class="tiny">The System Usability Scale (SUS) questionnaire is in the Evaluate window (Usability tab).</p>';
  q$$('[data-x6start]').forEach(b=>b.onclick=()=>startTask(+b.dataset.x6start));
  q$('#x6Pid').onchange=e=>{ST.pid=e.target.value.trim()||'P1';saveST()};
  q$('#x6SatSave').onclick=()=>{const v=+q$('#x6Sat').value;if(!v){toast('Choose a score first');return}ST.pid=q$('#x6Pid').value.trim()||'P1';ST.sat[ST.pid]=v;saveST();toast('Satisfaction saved');tabTasks(B)};
  q$('#x6TaskSave').onclick=()=>{const a=q$('#x6TaskEdit').value.split('\n').map(s=>s.trim()).filter(Boolean);if(!a.length)return;TASKS=a;sv('lisStudyTasks',a);toast('Tasks saved');tabTasks(B)};
  q$('#x6Csv').onclick=()=>download('usability_runs.csv',csv([['participant','task_no','task','outcome','seconds','ease_1_7','timestamp']].concat(runs.map(x=>[x.pid,x.task+1,TASKS[x.task]||'',x.outcome,x.secs,x.seq||'',new Date(x.ts).toISOString()]))),'text/csv');
  q$('#x6Clear').onclick=()=>{if(confirm('Delete all usability study data in this browser?')){ST={pid:ST.pid,runs:[],sat:{}};saveST();tabTasks(B)}};
}
function taskPanel(){
  let p=q$('#x6Task');
  if(!p){p=document.createElement('div');p.id='x6Task';p.className='x6-task';p.setAttribute('role','region');p.setAttribute('aria-label','Usability task timer');document.body.appendChild(p)}
  return p;
}
function startTask(i){
  ST.pid=(q$('#x6Pid')&&q$('#x6Pid').value.trim())||ST.pid||'P1';saveST();
  closeModal();
  ACTIVE={i,t0:Date.now(),pid:ST.pid};
  const p=taskPanel();p.style.display='block';
  p.innerHTML='<b>Task '+(i+1)+' · '+H(ST.pid)+'</b><div>'+H(TASKS[i])+'</div><div class="x6-time" id="x6Time" aria-live="off">0.0 s</div><div class="x6-row"><button type="button" class="primary" data-x6o="success">Success</button><button type="button" data-x6o="failed">Failed</button><button type="button" data-x6o="gave_up">Gave up</button></div>';
  clearInterval(TICK);TICK=setInterval(()=>{const e=q$('#x6Time');if(e&&ACTIVE)e.textContent=((Date.now()-ACTIVE.t0)/1000).toFixed(1)+' s'},200);
  p.querySelectorAll('[data-x6o]').forEach(b=>b.onclick=()=>endTask(b.dataset.x6o));
}
function endTask(outcome){
  if(!ACTIVE)return;
  clearInterval(TICK);
  const secs=+((Date.now()-ACTIVE.t0)/1000).toFixed(1),a=ACTIVE;
  const p=taskPanel();
  p.innerHTML='<b>Task '+(a.i+1)+': '+H(outcome.replace('_',' '))+' in '+secs+' s</b><div>How easy was this task? (1 = very difficult … 7 = very easy)</div><div class="x6-row">'+[1,2,3,4,5,6,7].map(n=>'<button type="button" data-x6seq="'+n+'">'+n+'</button>').join('')+'<button type="button" class="ghost" data-x6seq="0">Skip</button></div>';
  p.querySelectorAll('[data-x6seq]').forEach(b=>b.onclick=()=>{
    ST.runs.push({pid:a.pid,task:a.i,outcome,secs,seq:+b.dataset.x6seq||null,ts:Date.now()});saveST();
    ACTIVE=null;p.style.display='none';toast('Task result recorded');
  });
}

/* --- tab: search success --- */
function tabSearch(B){
  const L=SLOG,n=L.length,zero=L.filter(x=>!x.n).length,okS=L.filter(x=>x.n>0&&x.eng),ms=L.map(x=>x.ms).filter(x=>x!=null);
  B.innerHTML='<div class="x6-grid">'
   +'<div class="x6-card"><b>'+n+'</b><span>searches logged</span></div>'
   +'<div class="x6-card"><b>'+pc(n?okS.length/n:null)+'</b><span>search success rate</span></div>'
   +'<div class="x6-card"><b>'+pc(n?zero/n:null)+'</b><span>zero-result searches</span></div>'
   +'<div class="x6-card"><b>'+fx(mean(okS.map(x=>x.tEng)),1)+' s</b><span>mean time to first action</span></div>'
   +'<div class="x6-card"><b>'+fx(med(ms),1)+' ms</b><span>median response time</span></div>'
   +'<div class="x6-card"><b>'+fx(ms.length?Math.max(...ms):null,1)+' ms</b><span>slowest search</span></div></div>'
   +'<p class="tiny"><b>Definition:</b> a search is <i>successful</i> when it returns at least one result and the user then opens a record, link, citation, graph or other result action. Searches are logged automatically (query text, result count, response time).</p>'
   +'<table class="x6-t"><tr><th>Time</th><th>Query</th><th>Results</th><th>ms</th><th>Action taken</th><th>Seconds to action</th></tr>'
   +L.slice(-25).reverse().map(x=>'<tr><td>'+new Date(x.ts).toLocaleTimeString()+'</td><td>'+H(x.q)+'</td><td>'+x.n+'</td><td>'+fx(x.ms)+'</td><td>'+(x.eng?'yes':'no')+'</td><td>'+fx(x.tEng)+'</td></tr>').join('')+'</table>'
   +'<div class="x6-row"><button type="button" class="ghost" id="x6SlCsv">Export search log (CSV)</button><button type="button" class="ghost" id="x6SlClr">Clear log</button></div>';
  q$('#x6SlCsv').onclick=()=>download('search_log.csv',csv([['timestamp','query','results','ms','action_taken','seconds_to_action']].concat(L.map(x=>[new Date(x.ts).toISOString(),x.q,x.n,x.ms,x.eng?1:0,x.tEng==null?'':x.tEng]))),'text/csv');
  q$('#x6SlClr').onclick=()=>{if(confirm('Clear the search log?')){SLOG=[];sv('lisSearchLog',SLOG);tabSearch(B)}};
}

/* --- tab: blind baseline comparison --- */
let CMP=ls('lisCompare',[]),CUR=null;
function tabCmp(B){
  const done=CMP;
  const m=k=>mean(done.map(x=>x[k]).filter(v=>v!=null));
  B.innerHTML='<p class="tiny">Compare the Explorer’s ranking (Boolean/wildcard parsing, query expansion, relevance scoring) with a <b>keyword-only baseline</b> (all terms must appear in title, keywords or abstract; no expansion; ordered by citation count). Systems are shown blind as “A” and “B”. Mark each top-10 result you judge relevant, then reveal the scores.</p>'
   +'<div class="x6-row"><input id="x6Cq" placeholder="Enter a query, e.g. digital libraries" size="40" aria-label="Comparison query"><button type="button" class="primary" id="x6Run">Run blind comparison</button></div><div id="x6CmpArea"></div>'
   +'<h3>Saved comparisons ('+done.length+')</h3>'
   +(done.length?'<table class="x6-t"><tr><th>Query</th><th>Explorer P@10</th><th>Baseline P@10</th><th>Explorer pooled recall</th><th>Baseline pooled recall</th><th>Explorer F1</th><th>Baseline F1</th><th>Overlap</th></tr>'
     +done.map(x=>'<tr><td>'+H(x.q)+'</td><td>'+pc(x.pE)+'</td><td>'+pc(x.pB)+'</td><td>'+pc(x.rE)+'</td><td>'+pc(x.rB)+'</td><td>'+fx(x.fE,2)+'</td><td>'+fx(x.fB,2)+'</td><td>'+x.ov+'</td></tr>').join('')
     +'<tr class="x6-sum"><td>Mean</td><td>'+pc(m('pE'))+'</td><td>'+pc(m('pB'))+'</td><td>'+pc(m('rE'))+'</td><td>'+pc(m('rB'))+'</td><td>'+fx(m('fE'),2)+'</td><td>'+fx(m('fB'),2)+'</td><td></td></tr></table>'
     +'<div class="x6-row"><button type="button" class="ghost" id="x6CmpCsv">Export comparisons (CSV)</button><button type="button" class="ghost" id="x6CmpClr">Clear</button></div>'
     :'<p class="tiny">No comparisons saved yet.</p>')
   +'<p class="tiny">Pooled recall = relevant items found by a system ÷ all items marked relevant across both top-10 lists (the standard pooling approximation; true recall needs a full judged set).</p>';
  q$('#x6Run').onclick=()=>runCmp(B);
  q$('#x6Cq').onkeydown=e=>{if(e.key==='Enter')runCmp(B)};
  const c=q$('#x6CmpCsv');if(c)c.onclick=()=>download('baseline_comparison.csv',csv([['query','explorer_P10','baseline_P10','explorer_pooled_recall','baseline_pooled_recall','explorer_F1','baseline_F1','overlap']].concat(done.map(x=>[x.q,x.pE,x.pB,x.rE,x.rB,x.fE,x.fB,x.ov]))),'text/csv');
  const d=q$('#x6CmpClr');if(d)d.onclick=()=>{if(confirm('Clear saved comparisons?')){CMP=[];sv('lisCompare',CMP);tabCmp(B)}};
}
function runCmp(B){
  const q=q$('#x6Cq').value.trim();if(!q){toast('Enter a query');return}
  const area=q$('#x6CmpArea');area.innerHTML='<p class="tiny">Running both systems…</p>';
  setTimeout(()=>{
    const ex=explorerTop(q,10),bl=baselineTop(q,10);
    const flip=Math.random()<.5;
    CUR={q,ex,bl,flip,A:flip?bl:ex,Bs:flip?ex:bl};
    const list=(sys,tag)=>'<div class="x6-col"><h4>System '+tag+' <span class="tiny">('+sys.total.toLocaleString()+' matches)</span></h4>'+(sys.top.length?'<ol>'+sys.top.map(i=>'<li><label><input type="checkbox" data-x6rel="'+tag+'" data-i="'+i+'"> <b>'+H(R[i][2])+'</b></label><div class="tiny">'+H((R[i][1]||'').slice(0,90))+' · '+R[i][3]+' · '+R[i][0]+' cites</div></li>').join('')+'</ol>':'<p class="tiny">No results.</p>')+'</div>';
    area.innerHTML='<div class="x6-two">'+list(CUR.A,'A')+list(CUR.Bs,'B')+'</div><div class="x6-row"><button type="button" class="primary" id="x6Reveal">Compute scores &amp; reveal systems</button></div><div id="x6Res"></div>';
    q$('#x6Reveal').onclick=()=>reveal(B);
  },30);
}
function reveal(B){
  const rel={A:new Set(),B:new Set()};
  q$$('[data-x6rel]').forEach(c=>{if(c.checked)rel[c.dataset.x6rel].add(+c.dataset.i)});
  const pool=new Set([...rel.A,...rel.B]);
  const pr=(set,sys)=>sys.top.length?set.size/sys.top.length:null;
  const rc=set=>pool.size?set.size/pool.size:null;
  const f=(p,r)=>(p!=null&&r!=null&&p+r>0)?2*p*r/(p+r):(p!=null&&r!=null?0:null);
  const mapSys=CUR.flip?{E:'B',B:'A'}:{E:'A',B:'B'};/* Explorer's letter, baseline's letter */
  const eSet=rel[CUR.flip?'B':'A'],bSet=rel[CUR.flip?'A':'B'];
  const pE=pr(eSet,CUR.ex),pB=pr(bSet,CUR.bl),rE=rc(eSet),rB=rc(bSet);
  const ov=CUR.ex.top.filter(i=>CUR.bl.top.includes(i)).length;
  const rec={q:CUR.q,pE,pB,rE,rB,fE:f(pE,rE),fB:f(pB,rB),ov};
  CMP.push(rec);sv('lisCompare',CMP);
  const note='<div class="note"><b>Reveal:</b> System '+(CUR.flip?'B':'A')+' = Explorer, System '+(CUR.flip?'A':'B')+' = keyword-only baseline. Explorer P@10 = '+pc(pE)+', baseline P@10 = '+pc(pB)+'; pooled recall '+pc(rE)+' vs '+pc(rB)+'; F1 '+fx(rec.fE,2)+' vs '+fx(rec.fB,2)+'; '+ov+' of 10 results are shared.</div>';
  toast('Comparison saved');
  tabCmp(B);
  const ar=q$('#x6CmpArea');if(ar)ar.innerHTML=note;
}

/* --- tab: maintenance & audit --- */
const PERF_Q=['digital library','open access','bibliometric analysis','information literacy','knowledge organization','"machine learning"','librar* AND (covid OR pandemic)','research data management','altmetrics','user studies NOT children'];
function tabMaint(B){
  B.innerHTML='<h3>1. Response-time test</h3><p class="tiny">Runs '+PERF_Q.length+' representative queries (Boolean, phrase, wildcard) against all '+R.length.toLocaleString()+' records and reports timings.</p><div class="x6-row"><button type="button" class="primary" id="x6Perf">Run performance test</button></div><div id="x6PerfOut"></div>'
   +'<h3>2. Metadata quality &amp; authority audit</h3><p class="tiny">Counts missing fields, duplicate DOIs and possible author-name variants that need authority-control review.</p><div class="x6-row"><button type="button" class="primary" id="x6Audit">Run metadata audit</button></div><div id="x6AuditOut"></div>'
   +'<h3>3. Backup &amp; restore (browser data)</h3><p class="tiny">Saved items, search history, judgments, usability data and accessibility settings live in this browser. Export them regularly; restore them on another browser or after clearing data. Secrets (passwords/tokens) are never exported.</p><div class="x6-row"><button type="button" class="ghost" id="x6Bk">Download backup (JSON)</button><label class="ghost x6-file">Restore backup… <input type="file" id="x6Rs" accept=".json,application/json" hidden></label></div>'
   +'<h3>4. Deployment checklist (server side)</h3><ul class="tiny"><li>Serve over HTTPS with gzip/Brotli; set <code>Content-Security-Policy</code>, <code>X-Content-Type-Options</code> and <code>Referrer-Policy</code> headers at the web server.</li><li>Keep Neo4j/GraphDB credentials on a backend proxy, never in this page.</li><li>Schedule nightly backups of the dataset file and the graph databases; test a restore each quarter.</li><li>Monitor uptime, 4xx/5xx rates and response times; load-test with the expected number of concurrent users.</li><li>Re-run the audit above after every dataset upload.</li></ul><p class="tiny">Items in this list are operating procedures; a single HTML file cannot perform them itself.</p>';
  q$('#x6Perf').onclick=perfTest;q$('#x6Audit').onclick=audit;q$('#x6Bk').onclick=backup;
  q$('#x6Rs').onchange=restore;
}
function perfTest(){
  const out=q$('#x6PerfOut');out.innerHTML='<p class="tiny">Running…</p>';
  const rows=[];let i=0;
  const step=()=>{
    if(i>=PERF_Q.length){
      const t=rows.map(r=>r.ms),mem=(performance.memory&&performance.memory.usedJSHeapSize)?(performance.memory.usedJSHeapSize/1048576).toFixed(0)+' MB':'n/a';
      out.innerHTML='<div class="x6-grid"><div class="x6-card"><b>'+fx(mean(t),0)+' ms</b><span>mean</span></div><div class="x6-card"><b>'+fx(med(t),0)+' ms</b><span>median</span></div><div class="x6-card"><b>'+fx(Math.max(...t),0)+' ms</b><span>slowest</span></div><div class="x6-card"><b>'+Math.round(R.length/(mean(t)/1000)).toLocaleString()+'</b><span>records scored / second</span></div><div class="x6-card"><b>'+mem+'</b><span>JS heap in use</span></div></div><table class="x6-t"><tr><th>Query</th><th>Matches</th><th>Time (ms)</th></tr>'+rows.map(r=>'<tr><td>'+H(r.q)+'</td><td>'+r.n.toLocaleString()+'</td><td>'+fx(r.ms,0)+'</td></tr>').join('')+'</table>';
      return;
    }
    const q=PERF_Q[i++],t0=performance.now();let n=0;
    try{n=explorerTop(q,10).total}catch(e){n=-1}
    rows.push({q,n,ms:performance.now()-t0});
    out.innerHTML='<p class="tiny">Running… '+i+' / '+PERF_Q.length+'</p>';
    setTimeout(step,10);
  };
  setTimeout(step,20);
}
function audit(){
  const out=q$('#x6AuditOut');out.innerHTML='<p class="tiny">Auditing…</p>';
  setTimeout(()=>{
    const N=R.length,miss={title:0,authors:0,year:0,abstract:0,doi:0,keywords:0},doi=new Map(),grp=new Map();
    for(let i=0;i<N;i++){
      const r=R[i];
      if(!r[2])miss.title++;if(!r[1])miss.authors++;if(!r[3])miss.year++;if(!r[12])miss.abstract++;if(!r[9])miss.doi++;if(!r[11])miss.keywords++;
      if(r[9]){const d=String(r[9]).toLowerCase().replace(/^https?:\/\/(dx\.)?doi\.org\//,'').trim();doi.set(d,(doi.get(d)||0)+1)}
      for(const a of String(r[1]||'').split(';')){
        const nm=a.trim();if(nm.length<3)continue;
        const tk=norm(nm).match(/[a-z]+/g);if(!tk||!tk.length)continue;
        const longest=tk.reduce((x,y)=>y.length>x.length?y:x,'');
        const other=tk.find(t=>t!==longest);
        const key=longest+'|'+(other?other[0]:'');
        let g=grp.get(key);if(!g){g=new Set();grp.set(key,g)}
        g.add(nm);
      }
    }
    const dupDoi=[...doi.values()].filter(c=>c>1).length;
    const variants=[...grp.entries()].filter(([k,s])=>s.size>1).sort((a,b)=>b[1].size-a[1].size);
    const rowM=(l,v)=>'<tr><td>'+l+'</td><td>'+v.toLocaleString()+'</td><td>'+(100*v/N).toFixed(1)+'%</td></tr>';
    out.innerHTML='<table class="x6-t"><tr><th>Check</th><th>Records</th><th>Share</th></tr>'+rowM('Missing title',miss.title)+rowM('Missing authors',miss.authors)+rowM('Missing year',miss.year)+rowM('Missing abstract',miss.abstract)+rowM('Missing DOI',miss.doi)+rowM('Missing keywords',miss.keywords)+'<tr><td>DOIs used by more than one record</td><td>'+dupDoi.toLocaleString()+'</td><td></td></tr><tr><td>Author-name groups with possible variants</td><td>'+variants.length.toLocaleString()+'</td><td></td></tr></table>'
     +(variants.length?'<h4>Possible author-name variants (review against VIAF/LCNAF)</h4><table class="x6-t"><tr><th>Variants found</th></tr>'+variants.slice(0,20).map(([k,s])=>'<tr><td>'+[...s].slice(0,5).map(H).join(' &nbsp;|&nbsp; ')+'</td></tr>').join('')+'</table><p class="tiny">Heuristic grouping by surname-like token and first initial; verify before merging.</p>':'');
  },30);
}
const SECRET=/pass|token|secret|apikey|api_key|credential/i;
function backup(){
  const data={};
  for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);if(SECRET.test(k))continue;data[k]=localStorage.getItem(k)}
  download('lis-kg-explorer-backup-'+new Date().toISOString().slice(0,10)+'.json',JSON.stringify({app:'LIS-KG-Explorer',version:1,created:new Date().toISOString(),data},null,1),'application/json');
  toast('Backup downloaded');
}
function restore(e){
  const f=e.target.files[0];if(!f)return;
  const rd=new FileReader();
  rd.onload=()=>{
    try{
      const j=JSON.parse(rd.result);if(j.app!=='LIS-KG-Explorer'||!j.data)throw new Error('Not a LIS-KG-Explorer backup');
      let n=0;for(const [k,v] of Object.entries(j.data)){if(SECRET.test(k)||typeof v!=='string')continue;localStorage.setItem(k,v);n++}
      toast('Restored '+n+' items — reloading');setTimeout(()=>location.reload(),900);
    }catch(err){toast('Restore failed: '+err.message)}
  };
  rd.readAsText(f);
}

/* ---------- 5. Accessibility controls ---------- */
let A11=ls('lisA11y',{zoom:1,hc:false,ul:false,rm:false});
function applyA11(){
  document.documentElement.style.zoom=A11.zoom===1?'':String(A11.zoom);
  document.body.classList.toggle('x6-hc',!!A11.hc);
  document.body.classList.toggle('x6-ul',!!A11.ul);
  document.body.classList.toggle('x6-rm',!!A11.rm);
}
function a11yModal(){
  openModal('<h2>Accessibility settings</h2><p class="tiny">Settings are remembered in this browser. Keyboard: Tab / Shift+Tab to move, Enter to activate, Esc to close windows. A “Skip to search results” link is available at the top of the page.</p>'
   +'<div class="x6-row"><span>Text size</span><button type="button" class="ghost" id="x6Zm" aria-label="Smaller text">A−</button><span id="x6Zv">'+Math.round(A11.zoom*100)+'%</span><button type="button" class="ghost" id="x6Zp" aria-label="Larger text">A+</button></div>'
   +'<label class="check"><input type="checkbox" id="x6Hc" '+(A11.hc?'checked':'')+'><span>High-contrast mode</span></label>'
   +'<label class="check"><input type="checkbox" id="x6Ul" '+(A11.ul?'checked':'')+'><span>Always underline links</span></label>'
   +'<label class="check"><input type="checkbox" id="x6Rm" '+(A11.rm?'checked':'')+'><span>Reduce motion and animation</span></label>'
   +'<div class="x6-row"><button type="button" class="ghost" id="x6A11Rs">Reset to defaults</button></div>');
  const upd=()=>{sv('lisA11y',A11);applyA11();q$('#x6Zv').textContent=Math.round(A11.zoom*100)+'%'};
  q$('#x6Zm').onclick=()=>{A11.zoom=Math.max(.8,+(A11.zoom-.1).toFixed(2));upd()};
  q$('#x6Zp').onclick=()=>{A11.zoom=Math.min(1.5,+(A11.zoom+.1).toFixed(2));upd()};
  q$('#x6Hc').onchange=e=>{A11.hc=e.target.checked;upd()};
  q$('#x6Ul').onchange=e=>{A11.ul=e.target.checked;upd()};
  q$('#x6Rm').onchange=e=>{A11.rm=e.target.checked;upd()};
  q$('#x6A11Rs').onclick=()=>{A11={zoom:1,hc:false,ul:false,rm:false};upd();a11yModal()};
}

/* ---------- init ---------- */
function init(){
  const nav=q$('nav.toolbar'),ev=q$('#evalBtn');
  if(nav&&!q$('#studyBtn')){
    const mk=(id,html,title,fn)=>{const b=document.createElement('button');b.className='ghost';b.id=id;b.type='button';b.title=title;b.innerHTML=html;b.onclick=fn;return b};
    const b1=mk('studyBtn','👥 <span>Study Lab</span>','Usability tasks, search success rate, blind baseline comparison, performance and metadata audit',()=>studyModal('tasks'));
    const b2=mk('a11yBtn','♿ <span>Accessibility</span>','Text size, high contrast, underline links, reduce motion',a11yModal);
    if(ev&&ev.parentNode===nav){ev.after(b1);b1.after(b2)}else{nav.appendChild(b1);nav.appendChild(b2)}
  }
  const rc=q$('#resultCount');if(rc){rc.setAttribute('role','status');rc.setAttribute('aria-live','polite')}
  applyA11();
  hookSearch();setInterval(hookSearch,1500);
}
const css=document.createElement('style');
css.textContent='.x6-dym{margin:8px 0;padding:9px 12px;border:1px solid #e0a63a;background:#fff8e6;border-radius:9px;display:none}.x6-dym-btn{background:none;border:0;color:#0b5394;font:inherit;font-weight:700;text-decoration:underline;cursor:pointer;padding:0 2px}'
+'.x6-tabs{display:flex;flex-wrap:wrap;gap:6px;margin:12px 0;border-bottom:1px solid var(--line,#dbe3ee);padding-bottom:8px}.x6-tab{border:1px solid var(--line,#dbe3ee);background:#fff;border-radius:8px;padding:7px 12px;cursor:pointer;font:inherit}.x6-tab.on{background:#075b9d;color:#fff;border-color:#075b9d}'
+'.x6-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px;margin:10px 0}.x6-card{border:1px solid var(--line,#dbe3ee);border-radius:10px;padding:10px;background:#f8fbff;text-align:center}.x6-card b{display:block;font-size:20px;color:#075b9d}.x6-card span{font-size:12px;color:#5b6b7f}'
+'.x6-row{display:flex;flex-wrap:wrap;gap:10px;align-items:center;margin:10px 0}.x6-t{width:100%;border-collapse:collapse;font-size:13px;margin:8px 0}.x6-t th,.x6-t td{border:1px solid var(--line,#dbe3ee);padding:6px 8px;text-align:left;vertical-align:top}.x6-t th{background:#eef4fb}.x6-sum td{font-weight:700;background:#f4f8fc}'
+'.x6-two{display:grid;grid-template-columns:1fr 1fr;gap:14px}@media(max-width:780px){.x6-two{grid-template-columns:1fr}}.x6-col ol{padding-left:20px;margin:6px 0}.x6-col li{margin-bottom:8px}.x6-file{cursor:pointer;padding:7px 12px;border:1px solid var(--line,#dbe3ee);border-radius:8px}'
+'.x6-task{display:none;position:fixed;left:14px;bottom:14px;z-index:99999;max-width:360px;background:#fff;border:2px solid #075b9d;border-radius:12px;padding:12px 14px;box-shadow:0 8px 28px rgba(0,0,0,.25);font-size:14px}.x6-time{font-size:24px;font-weight:700;color:#075b9d;margin:6px 0}'
+'body.x6-hc{background:#fff!important;color:#000!important}body.x6-hc a{color:#0030a0!important;text-decoration:underline!important}body.x6-hc button,body.x6-hc input,body.x6-hc select,body.x6-hc textarea{border:2px solid #000!important}body.x6-hc :focus-visible{outline:4px solid #000!important;outline-offset:2px}'
+'body.x6-ul a{text-decoration:underline!important}body.x6-rm *{animation:none!important;transition:none!important;scroll-behavior:auto!important}';
document.head.appendChild(css);
if(document.readyState==='loading')__onReady(init);else init();
window.x6={spellSuggestion,explorerTop,baselineTop,dl,studyModal,a11yModal,vocab};
})();
